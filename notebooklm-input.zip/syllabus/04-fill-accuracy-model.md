# Fill Accuracy — What the Numbers Mean and What They Tell You

## The Core Metric: Tick Deviation

Every time you get a fill, the system measures how far the actual fill price was from your intended entry price, in ticks. This is the Tick Deviation (TD):

- **TD = 0** (Zero): Filled at exactly your price. Perfect.
- **TD < 0** (Payup): Filled at a worse price than intended. You paid up to get the fill. On buys, this means you paid higher; on sells, you received lower.
- **TD > 0** (Backoff): Filled at a better price than intended. The market came to you.

**Accuracy** converts this to a percentage: 100% at your exact price, dropping 20% per tick of adverse deviation. So a 1-tick payup = 80%, a 0.5-tick payup = 90%, a 1-tick backoff = 120%.

## What 56% Grand Accuracy Actually Means

The WP-01 analysis of 3,225 production fills (March 1–13, 2026) found grand accuracy of 56.32%. This means the average fill is about 0.22 ticks adverse from your target. In dollar terms at $12.50 per tick on SR3, that's about $2.75 per fill of execution cost.

This is not a crisis — you're profitable. But the model identified that accuracy varies dramatically by group, and some groups are actively destroying value.

## The Production Fill Landscape

### By Expiry Group

| Group | Accuracy | What This Means |
|-------|---------|-----------------|
| Dec26 | 59.8% | Best in class. Tight basis, deep books. Most fills are Zero or small payup. |
| Mar26 | ~57% | Decent. Slightly noisier than Dec26 but structurally sound. |
| Jun26 | ~54% | Mixed. Buy side is OK, but SR3|ZQ sell-side drags the average down (49.3%). |
| Sep26 | ~51% | Structurally the worst. Wide basis volatility, thin books. Every fill costs more here. |
| X/Y | −120% to −380% | Catastrophic. Not just bad — actively losing money on every fill in most cases. |

### What the Groups Reveal

The accuracy differences aren't random. They're structural:

**Dec26 is cleanest** because the December expiry is far enough out that the SR1 sub-month basis (Jan27, Feb27) is range-bound. The books are deep. The microprice signal is reliable. When you set a price, the market generally fills you near that price.

**Sep26 is worst** because October and November SR1-ZQ basis is structurally wider and more volatile. The books are thinner. The microprice signal is noisier. When you set a price, the market often fills you at a worse level because the basis moved between your calculation and the fill.

**X/Y aliases are broken** not because of market conditions but because the entry price calculation appears to be fundamentally wrong for these ASE types. The system is consistently pricing X/Y orders at levels that guarantee adverse fills. This is a code/formula issue, not a market issue.

## The Eight Structural Patterns

The WP-01 model identified eight recurring patterns. Understanding these helps you evaluate whether a bad session is noise or structural:

1. **Dec26 cleanest**: Confirmed. If Dec26 accuracy drops below 55%, something unusual is happening — investigate.
2. **Sep26 worst**: Confirmed. If Sep26 accuracy rises above 55%, your defensive parameters may be working.
3. **Buy-side volume sensitivity**: Higher daily fill count degrades buy-side accuracy. Above 500 lots in a single alias, buy accuracy drops meaningfully. This is why the model recommends clip reduction for high-volume aliases.
4. **SR3|ZQ sell-side structural payup**: Jun26 SR3|ZQ sells are structurally adverse. This is the pattern addressed by the BS_FF=−0.05 recommendation for Jun26.
5. **X/Y extreme payup**: Confirmed broken. No parameter tuning fixes a broken price formula.
6. **Dec26 backoff rate highest**: Dec26 gets the most favorable fills (backoff). This is the reward for the cleanest basis — the market often comes to you.
7. **Loss concentration in falling spreads**: When the O-spread is falling (moving against your buy side), losses concentrate in a few aliases. These are the "flipping markets" described in the kill rules.
8. **Matched P&L concentration**: Most of your profit comes from a small number of aliases with Zero-TD or backoff fills. Protecting these profitable aliases (keeping their parameters stable) matters more than fixing marginal ones.

## How to Read Your Accuracy Numbers

### Good session:
- Group A above 60%, Group B above 55%, Group C above 50%
- Zero-TD fills are the majority in Group A
- No alias showing both-side accuracy below 30%

### Bad session:
- Any group dropping more than 5 points from the prior 5-day average
- Matched P&L negative for the session in any group
- Sep26 accuracy below 45% despite defensive parameters

### Structural problem (not just a bad day):
- 3+ consecutive sessions with declining accuracy in the same alias
- Degradation ranking shows the same alias deteriorating across multiple metrics
- Average sell price consistently below average buy price on matched fills

## What Accuracy Doesn't Tell You

Accuracy measures execution quality, not strategy quality. You can have perfect 100% accuracy and still lose money if your O_target is wrong. Conversely, 50% accuracy can be profitable if your O_target has enough edge to absorb the execution cost.

The goal is not to maximize accuracy in isolation. The goal is to ensure execution cost doesn't eat your edge. The parameter changes recommended by the models are designed to reduce execution cost where it's highest (Sep26, X/Y) without significantly reducing fill count where accuracy is already good (Dec26).
