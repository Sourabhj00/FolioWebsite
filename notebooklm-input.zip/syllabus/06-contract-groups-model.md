# Contract Groups — Why One Size Doesn't Fit All

## The Core Insight

Running identical parameters across Dec26 and Sep26 is like driving a sports car and a truck at the same speed. Dec26 has tight basis, deep books, and reliable microprices — it can handle aggressive parameters. Sep26 has wide basis, thin books, and noisy microprices — it needs protection.

The WP-03 model classified every alias into one of four groups based on two dimensions: expiry distance (which drives basis volatility and book depth) and ASE type (standard A/B vs. X/Y). Each group gets its own parameter set optimized for its structural characteristics.

## The Four Groups

### Group A — Core (Dec26)
**What makes it work:** December expiry is furthest out. The SR1 sub-months (Jan27, Feb27) have a range-bound basis. Books are the deepest in the complex. Microprice calculations are most reliable here.

**Accuracy:** 59.8% combined, 67–70% on the best aliases. Highest Zero-TD fill rate. Highest backoff rate (the market comes to you more often here than anywhere else).

**Parameter approach:** Tighten avoidance to capture more fills. The basis is stable enough to handle tighter spreads without accuracy degradation. Think of this as your "Alpha" — where most of your clean profit comes from.

### Group B — Standard (Mar26, Jun26)
**What makes it work — and what doesn't:** Mid-curve expiries. Mar26 is close to front, Jun26 is mid-range. Books are adequate. Basis volatility is moderate.

**The Jun26 problem:** SR3|ZQ sell-side on Jun26 has structural payup at 49.3% accuracy. The model's hypothesis: the ZQ sell side absorbs slippage into SR3 because of thin ZQ book depth on that side. The BS_FF=−0.05 recommendation attempts to offset this by making buy prices slightly more aggressive on Legs 3 & 4.

**Accuracy:** ~54-57% combined. Acceptable but not great. The Jun26 ZQ sell-side drag is the main issue.

**Parameter approach:** Slightly widen avoidance (0.05 → 0.07) to account for moderate basis volatility. Apply targeted BS_FF correction on Jun26 only. Don't over-optimize — Group B is your bread-and-butter volume.

### Group C — Defensive (Sep26)
**Why it bleeds:** September expiry has the widest basis volatility in the complex. October SR1-ZQ basis is structurally wider than other months. Books are the thinnest. Microprice calculations are the noisiest.

**The degradation problem:** Sep26 accuracy isn't just low — it degrades over time. The 10-day test window showed some aliases declining from −54% to −133%. This suggests the basis is trending (not just noisy), which means your static O_target becomes increasingly stale for Sep26.

**Accuracy:** ~51% combined. Some aliases are catastrophic (SR3|ZQ Sep Oct26 at −87%).

**Parameter approach:** Dramatically widen avoidance (0.05 → 0.12). Require more liquidity before HitMan fires. Back off more aggressively. Cut payup budgets. Reduce total exposure. The goal is not to make Sep26 profitable per fill — it's to stop it from destroying value while you get fewer, better fills.

**What to watch for:** If the wider avoidance brings accuracy above 55% with adequate fill count, Sep26 becomes viable again. If accuracy stays below 50% even at Av=0.12, consider pausing the worst individual aliases (start with SR3|ZQ Sep Oct26).

### Group D — Restricted (X/Y Aliases)
**Why it's broken:** X/Y aliases embed the ZQ calendar into a 3-leg ASE structure. The entry price calculation for these appears to produce systematically wrong prices — the system buys high and sells low on almost every fill.

**This is not a parameter problem.** When accuracy is −300%, no amount of avoidance or HitMan tuning helps. The raw price calculation is producing the wrong number. Until the X/Y pricing formula is reviewed and corrected, these aliases should not trade (with the possible exception of Dec26 X/Y, which performs at acceptable levels).

## How Groups Transition Over Time

When contracts roll:
- Mar26 expires → the new back contract (probably Mar27) enters as Group B until data says otherwise.
- Sep26 eventually becomes front month. Front contracts have deeper books, so Sep26 may improve. But keep it in Group C until data confirms the improvement.
- New Dec27 aliases enter as Group A if they show Dec26-like characteristics (tight basis, deep books).

The event calendar tracks roll dates so you can plan these transitions.

## Decision Tree: Assigning New Contracts

1. Is it an X or Y ASE type? → **Group D** (Restricted), regardless of expiry.
2. Is the expiry 9+ months out with historically tight basis? → **Group A** (Core).
3. Is the expiry 3–6 months out? → **Group B** (Standard).
4. Is the expiry 6–9 months out with volatile/thin basis? → **Group C** (Defensive).

When unsure, start with Group B parameters and tighten or widen based on the first week's accuracy data.

## The 5× and 10× Path

**5× profits** comes from:
- Stopping the bleed on Sep26 and X/Y (eliminate negative-accuracy fills)
- Tightening Dec26 (capture more fills at the best accuracy)
- Targeted fixes on Jun26 ZQ sell-side

**10× round turns** comes from:
- Timer Logic (more fills through smarter rounding)
- Tighter Dec26/Group A parameters (more fills from lower avoidance)
- Network Valuation Engine (future: auto-update O_target so you can run wider and catch more edge)
- Directional bias model (future: Treasury lead-lag signal adds fills during momentum windows)

The parameter playbook handles the immediate path. Timer Logic and the valuation engine are the next phase.
