# Timer Logic — Your New Edge

## What Timer Logic Does

Every pricing cycle, your system computes a raw leg price — a continuous number like 4.37. But orders must be at valid tick levels (whole or half ticks: 4.0, 4.5, 5.0). So the raw price must be rounded.

**Without Timer Logic (current):** Hard defensive rounding. Buys always round down, sells always round up. A raw buy of 4.37 rounds to 4.0. A raw buy of 4.49 also rounds to 4.0. The decimal precision of your microprice signal is thrown away.

**With Timer Logic:** Evidence-conditioned rounding. If market evidence suggests the nearer tick (4.5 in this case) is fillable, Timer Logic rounds toward market instead of defensively. A raw buy of 4.49 becomes 4.5 — one tick more aggressive, but one tick more likely to fill.

The result: more fills at a slightly higher execution cost per fill, but a better cost per fill than what you'd pay through payup after a missed defensive fill.

## The Expansion Parameter

The key concept is **expansion** — a number between 0 and 0.5 that encodes how confident the system is that the nearer tick will fill.

- **Expansion = 0**: Pure defensive rounding. Timer Logic has no effect. Identical to current behavior.
- **Expansion = 0.25**: If the raw price is within 0.25 ticks of the nearer tick, round toward market. Otherwise, round defensively.
- **Expansion = 0.49**: Almost always round toward market. Very aggressive.

Think of expansion as a confidence threshold. The raw price's decimal part tells you how close you are to the next tick. Expansion tells you how close is "close enough" to go for it.

### Worked Example

Raw buy price = 4.37. Tick floor = 4.0, tick ceiling = 4.5.
Distance from raw price to ceiling = 4.5 − 4.37 = 0.13.

- If expansion = 0.10: Is 0.13 ≤ 0.10? No. → Round defensively to 4.0.
- If expansion = 0.15: Is 0.13 ≤ 0.15? Yes. → Round toward market to 4.5.
- If expansion = 0.25: Is 0.13 ≤ 0.25? Yes. → Round toward market to 4.5.

The higher the expansion, the more often you get the aggressive tick. The trade-off is clear: more fills, but each aggressive-rounded fill costs 1 tick of edge compared to the defensive round.

## Where Timer Logic Sits in the Pipeline

Timer Logic applies at one specific point:

1. You set O_Buy and O_Sell (your judgment)
2. Diff computation splits the O price between near/far months
3. Raw leg prices are calculated for all 4 legs
4. Avoidance adjustment widens the spread (risk protection)
5. B/S Bias adjustment tilts directionally (your conviction)
6. **→ TIMER LOGIC replaces the rounding step ←**
7. Discretized prices go to ASE for execution
8. ASE rules (HitMan, ASM, Backoff) evaluate and execute

Everything upstream and downstream of Timer Logic stays the same. Timer Logic only changes how the final rounding happens.

## What the Verification Found

WP-04 verified that Timer Logic's math is sound. The core rounding mechanism is correct and produces consistent results across all test cases. But the audit found important nuances:

### The Crossed-Market Boundary

There's a maximum safe expansion value per pricing cycle. If expansion is too high, your buy price can cross above your sell price — you'd be offering to buy at a higher price than you're offering to sell. Timer Logic has a guard for this, but understanding the concept matters:

The safe expansion limit depends on the current raw price gap between buy and sell. When the gap is tight (your O spread is narrow), safe expansion is lower. When the gap is wide, safe expansion is higher. The implementation enforces this automatically, but it explains why Timer Logic is more beneficial on wider O spreads.

### Timer Logic and Dynamic Avoidance

During FOMC windows, dynamic avoidance widens your spread by increasing Av_FF/Av_ZQ. But if Timer Logic then aggressively rounds those widened prices back toward market, it partially cancels the avoidance protection.

The WP-04 recommendation: during FOMC/data windows, reduce expansion toward zero. Let avoidance do its job without Timer Logic fighting it. This is implemented in the TC-18 test case.

## Why 56% Accuracy Might Be Closer to Optimal Than You Think

Intuition says higher accuracy is better. But accuracy and fill count are inversely related. If you set avoidance to 1.0, you'd have near-perfect accuracy — and zero fills.

Timer Logic creates a deliberate, controlled trade-off: accept slightly lower accuracy per fill in exchange for more fills. The net effect on profitability depends on whether the extra fills generate more edge than the per-fill accuracy cost.

The math works when your edge per round turn (the O-spread convergence) exceeds the execution cost increase from Timer Logic. Since your edge is 1-2 ticks on the O-spread and Timer Logic costs at most 0.5 ticks per fill when it rounds aggressively, the math is favorable as long as expansion is kept below the safe maximum.

## Phase 1 Deployment Plan

When Timer Logic goes to SIM:

1. **Legs 1 & 2 only** — These are the SR3|SR1 legs, algebraically simpler and the primary quoting legs where Timer Logic has the most impact.
2. **Start with expansion = 0.15** — Conservative starting point. About 30% of fills will be affected (the ones where the raw price is within 0.15 of the nearer tick).
3. **Monitor accuracy change** — Compare Leg 1/2 accuracy with Timer Logic vs. without. Expected: accuracy drops 3-5 points, fill count increases 10-20%.
4. **Check profitability** — More fills × slightly lower accuracy should equal more total profit. If total profit drops, expansion is too high.
5. **Phase 2: Add Legs 3 & 4** — After validating the infrastructure, add ZQ legs. These involve the BS_FF correction and need the updated formula.

## The Formula Correction You Need to Know

WP-04 found that execution-modifiers.md §5 is MISSING the −BS_FF term in Leg 3/4 base formulas. The Timer Logic C# implementation already uses the correct formula from price-formulas-complete.md.

If you or anyone else works on pricing formulas, always reference price-formulas-complete.md as the authoritative source. The execution-modifiers document has a known error that would produce wrong Leg 3/4 prices.
