# When Things Go Wrong — Intervention Guide

## Decision Framework

Not every bad session requires intervention. Markets are noisy. The models give you baselines and structural patterns, but single-session accuracy can fluctuate ±5 points from random variation alone. The intervention triggers below are designed to separate signal from noise.

**Rule of thumb:** If the issue persists for 2+ consecutive sessions, it's structural. If it's one session, monitor but don't change parameters.

## Scenario 1: Sudden Accuracy Drop on a Single Alias

**Symptom:** One alias drops from 55%+ to below 35% within a session while others in the same group are fine.

**Likely cause:** Book thinning on that specific instrument, or a one-sided flow event (large institutional order absorbing one side of the book).

**Action:**
1. Check the monitoring instrument's bid-ask spread. If it's > 1 tick, the spread guard should have paused the alias. If it hasn't, there may be a configuration issue.
2. If the spread is normal but accuracy is bad, check whether fills are all on one side (buy or sell). One-sided bad accuracy suggests flow, not a systemic problem.
3. If it persists past the current hour, manually pause that alias for the session.
4. If it recurs the next session, escalate to Group C parameters for that alias specifically.

## Scenario 2: Whole Group Accuracy Drops

**Symptom:** All aliases in a group (e.g., all Jun26 standard) drop accuracy by 5+ points simultaneously.

**Likely cause:** Basis regime change (the SR1-ZQ basis has moved structurally), data release shock, or a broad liquidity event.

**Action:**
1. Check event calendar — is there an event today? If yes, wait for the event window to pass and then reassess.
2. If no event, check whether the O-spread itself has moved significantly. Your O_target may be stale relative to where the market now is. Compare to curve-implied fair value if available.
3. If the group is Sep26 (Group C), you're already running defensive parameters. Consider pausing the worst individual alias rather than further widening parameters.
4. If the group is Dec26 (Group A) and accuracy drops below 55%, this is unusual and worth investigating immediately. Dec26 accuracy issues often indicate a monitoring instrument problem.

## Scenario 3: Fill Surge Without Price Change

**Symptom:** Dramatically more fills than usual, but your O_target and parameters haven't changed.

**Likely cause:** Market has moved toward your prices. Your quotes, previously away from the action, are now at or inside the market.

**Action:**
1. This can be good (the market is converging to your fair value, which is the thesis) or bad (a large move has swept through your levels without mean-reversion).
2. Check accuracy of the surge fills. If accuracy is above 50%, the fills are fine — the market came to you.
3. If accuracy is below 40%, the fills are adverse — you're getting picked off. Reduce clip sizes immediately and widen avoidance.
4. If the surge is on one side only (e.g., all buys), you may want to temporarily reduce that side's quantity or widen avoidance asymmetrically.

## Scenario 4: Crossed-Market Warning

**Symptom:** System indicates a crossed-market condition (buy price ≥ sell price after rounding).

**Likely cause:** O spread is very narrow AND aggressive expansion settings push buy and sell prices to the same or crossing tick levels.

**Action:**
1. If you're running Timer Logic, reduce expansion toward 0 for the affected contract.
2. If you're on hard rounding, a crossed-market means your O_Buy and O_Sell are too tight for the current diff level. Widen your O spread.
3. Check diff: has the SR1 calendar moved dramatically? A large diff move can push one leg's prices into the other's territory.

## Scenario 5: Spread Guard Pauses a Contract

**Symptom:** The system pauses a contract because a monitoring instrument's bid-ask spread exceeded 1 tick.

**Likely cause:** Temporary liquidity withdrawal on the monitoring instrument. Common around data releases, roll dates, or end-of-day.

**Action:**
1. This is a safety feature working correctly. Do not manually override it.
2. Monitor the spread. When it returns below 1 tick, the system should auto-resume.
3. If the pause persists for more than 30 minutes during normal trading hours, investigate the instrument — it may have gone illiquid (end-of-life, holiday thinning, exchange issue).

## Scenario 6: Sep26 Accuracy Keeps Declining Despite Defensive Parameters

**Symptom:** Even after implementing Group C parameters (Av=0.12, tighter HitMan/ASM/Backoff), Sep26 accuracy continues to drop session over session.

**Likely cause:** Structural basis trend that defensive parameters can't overcome. The O-spread for Sep26 may be trending away from your target, making every fill increasingly adverse.

**Action:**
1. Compare your Sep26 O_target to curve-implied fair value. If fair value has moved significantly, update your target.
2. Check the degradation ranking: which specific aliases are deteriorating? Consider pausing the worst 1-2 aliases rather than the entire group.
3. If accuracy drops below 40% for the group average over 3 sessions, pause all Sep26 aliases and reassess. The bleeding is destroying value faster than occasional good fills can recover.
4. This may indicate that Sep26 is temporarily unquotable — some expiry groups go through periods where the basis dynamics make the arbitrage unprofitable. It's OK to sit out.

## Scenario 7: Timer Logic Fill Rate Is Too High/Low

**Symptom:** After deploying Timer Logic in SIM, fill rate change doesn't match expectations.

**Action:**
- If fills barely increased: Expansion may be too low. Increase by 0.05 increments and re-test.
- If fills increased dramatically with plummeting accuracy: Expansion is too high. Reduce by 0.05 increments.
- If accuracy stayed stable but fills increased 10-20%: This is the expected result. Validate that per-fill profitability is maintained.
- If crossed-market warnings appear: Expansion is exceeding the safe maximum for the current O spread width. Reduce expansion.

## General Principles

1. **Don't chase accuracy on bad groups.** Pouring parameter effort into Sep26 to push it from 51% to 53% has less impact than protecting Dec26 at 60%+.
2. **Pause before you tune.** When an alias is losing money, pausing it immediately stops the loss. Parameter tuning takes time to validate. Pause first, tune later.
3. **One variable at a time.** If you change avoidance AND HitMan AND Backoff simultaneously, you can't tell which change helped. Change one parameter, run for 2-3 sessions, evaluate, then change the next.
4. **The models will be refined.** WP-06 will bring real fill accuracy patterns. WP-07 will bring dynamic avoidance auto-tuning. Today's parameter playbook is the best available set, but it will evolve.
