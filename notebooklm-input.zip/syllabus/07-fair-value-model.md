# Fair Value — From Gut to Curve

## What the SOFR Bootstrap Does

You currently set your O_target (buyBiased/sellBiased) based on curve intuition, historical range, and discretionary adjustment. This works — you're profitable. The SOFR bootstrap methodology doesn't replace your judgment. It gives you a mathematical anchor to compare it against.

The core idea: the SR3 quarterly SOFR future prices the average overnight SOFR rate over a 3-month period. But that 3-month period can be decomposed into three 1-month sub-periods. Each 1-month sub-period has its own expected rate, observable from the OIS curve, SR1 futures, and ZQ futures.

When you decompose SR3 this way and compare the implied SR1 prices to the live market, the difference is your O-spread fair value — derived from the curve, not from your intuition.

## Why This Matters

Two weaknesses of judgment-based pricing that the curve addresses:

**1. Auditability:** After a losing session, you can't evaluate whether your O_target was wrong or just unluckily timed. With a curve-derived fair value, you can measure: was your target above or below fair value? By how much? Was the loss from bad target-setting or bad execution?

**2. Staleness:** When the curve moves overnight (Fed commentary, economic data, global rates), your O_target from yesterday might be stale. The curve updates automatically. In the future (WP-13 Pricing Engine), the fair value feed will update in real time.

## How to Use It Today

The SOFR bootstrap is not yet automated. The Python implementation (sofr_bootstrap_fair_value.py) can be run manually to produce curve-implied fair values. Here's the practical workflow:

1. **Once per day (pre-market):** Run the bootstrap against current SOFR/FF curve data. This gives you an implied SR1 price per sub-month, and from that, an implied O-spread fair value per expiry group.

2. **Compare to your manual O_target.** If they agree within 0.5 ticks, your intuition is well-calibrated. If they diverge by more than 1 tick, investigate: has the curve moved? Are you anchored to a stale level?

3. **Use divergence as a signal:** When your O_target is below fair value, you're pricing cheap — fills should converge faster (good). When your O_target is above fair value, you're pricing expensive — fills may take longer or not converge (risk).

4. **Don't auto-replace your judgment yet.** The curve gives you the "what should be" number. Your judgment adds "what the market is actually doing" — flow conditions, time-of-day effects, event positioning. The combination is stronger than either alone.

## The Network Valuation Engine — What's Coming Next

The SOFR bootstrap handles the outrights-to-spread decomposition. The Network Valuation Engine (designed but not yet deployed) extends this to the full network of ~300 instruments:

- Subscribe to live market data for all listed SR3, SR1, ZQ instruments
- Build a web of no-arbitrage equations (outright + spread = components)
- Identify which specific instruments are most mispriced relative to the network
- Output a ranked list: most undervalued to most overvalued, with confidence

This gives you two things you don't have today:
- **Per-instrument mispricing scores** — know exactly which leg is cheap and which is rich
- **Rogue detection** — if an instrument's price diverges from the network by more than expected, it might be a data feed error rather than an opportunity

The valuation engine is the foundation for WP-07 (dynamic avoidance auto-tuning) and WP-13 (real-time fair value feed). Both are future work packages.

## Sensitivity: What Moves Fair Value

From the SOFR bootstrap analysis, the key sensitivities are:

- **±1bp parallel shift in SOFR curve:** Moves O-spread fair value by approximately ±0.2 ticks per expiry group. Front months (Mar26) are most sensitive, back months (Dec26) least.
- **SOFR-FF basis widening:** Currently modeled as a fixed spread. When the actual SOFR-FF basis diverges from the model's assumption, Leg 3/4 fair values become less reliable. This is flagged for future dynamic modeling.
- **Interpolation method:** LogLinear vs MonotonicCubic vs FlatForward produce differences of < 0.1bp in typical conditions. The choice matters more during curve inversions or at seasonal turning points.

## What This Means for Your Trading

The practical takeaway: your intuition-based O_target is a valid approach and should remain your primary input. The curve-derived fair value is a sanity check and calibration tool that becomes progressively more valuable as:

1. You build confidence that it tracks reality (compare daily for a few weeks)
2. The Network Valuation Engine automates the real-time feed
3. Dynamic avoidance can reference fair value divergence to auto-widen during dislocation

For now, it's a dashboard instrument. In six months, it could be the primary pricing input with your judgment as the override.
