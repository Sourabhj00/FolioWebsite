# STIR Trading System — Training Syllabus

## How to Use

Upload all 10 numbered `.md` files to a single NotebookLM notebook as sources. NotebookLM will:
- Generate an audio overview (~15 min podcast-style summary)
- Create a study guide with key points from each file
- Enable Q&A grounded in your actual system documentation

### Suggested first questions to ask NotebookLM:
- "What are the highest-priority parameter changes I should make today?"
- "Why is Sep26 accuracy so bad and what should I do about it?"
- "How does Timer Logic improve my fill rate?"
- "When should I pause an alias during a trading session?"
- "What's the difference between Group A and Group C parameter settings?"

## File Overview

### Section 1: Quick Start (adopt immediately)
1. `01-whats-new.md` — What 6 completed models found, priority action list
2. `02-parameter-playbook.md` — Exact parameter changes by contract group
3. `03-daily-workflow.md` — How to trade with the new models, open-to-close

### Section 2: Model Deep Dives (understand the "why")
4. `04-fill-accuracy-model.md` — Production fill analysis, 8 structural patterns
5. `05-timer-logic-model.md` — Evidence-conditioned rounding, expansion tuning
6. `06-contract-groups-model.md` — A/B/C/D framework, per-group behavior
7. `07-fair-value-model.md` — SOFR curve-derived O_target methodology
8. `08-event-calendar-model.md` — Risk windows, FOMC playbook, seasonality
9. `09-intervention-guide.md` — 7 scenarios with decision trees

### Section 3: Reference (lookup as needed)
10. `10-glossary-and-parameters.md` — Every term, every parameter, decision trees

## Updating This Syllabus

This syllabus reflects work packages completed through March 31, 2026. As new models deliver:
- **WP-06 (real fill patterns):** Update `02-parameter-playbook.md` with validated parameters
- **WP-07 (dynamic avoidance):** Add new file `11-dynamic-avoidance-model.md`
- **WP-11 (regime detection):** Add new file `12-regime-detection-model.md`
- **WP-13 (pricing engine):** Update `07-fair-value-model.md` with real-time feed instructions

Re-upload updated files to NotebookLM to refresh the knowledge base.
