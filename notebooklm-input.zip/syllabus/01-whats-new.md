# What Changed & What To Do Now

## Who This Is For

You trade the SR3|SR1 O-spread on TT Autospreader. You know the strategy, you know your instruments, you set your own prices. This guide covers the six analysis models completed between March 1–30, 2026 — what they found, and what you should change in your trading.

## The Six Models — Executive Summary

### WP-01: Fill Accuracy Analysis

**What it did:** Analyzed 3,225 production fills (Mar 1–13, 2026) across all active aliases, measuring tick deviation from entry price.

**What it found:**
- Grand accuracy is 56.32% combined (buy 56.16%, sell 56.44%). This means on average, fills execute at about 0.22 ticks worse than your target price.
- Dec26 is your cleanest expiry (59.8%). Sep26 is structurally the worst.
- Jun26 sell-side accuracy on SR3|ZQ legs is notably low (49.3%) — structural payup.
- X/Y aliases are catastrophically bad (−120% to −380%). These are losing money on every fill in many cases.

**What to do:** Pause Sep26 and Jun26 X/Y aliases immediately. Tighten Sep26 standard parameters defensively. See the Parameter Playbook file.

### WP-02: Fair Value (SOFR Curve Bootstrap)

**What it did:** Replaced your judgment-based O_target with a mathematical framework that derives fair value from the SOFR curve.

**What it found:**
- Your intuition is good — the strategy is profitable. But the fair value anchor is implicit and can't be audited or auto-updated.
- The SOFR bootstrap decomposes the 3-month SR3 rate into three 1-month sub-periods, giving a precise implied SR1 price per month.
- The difference between curve-implied fair value and the live O-spread price is your true edge signal.

**What to do:** Start tracking curve-implied fair value alongside your manual O_target. When they diverge significantly, investigate why. Over time, use the curve as the primary anchor and your judgment as the override. The Network Valuation Engine (next phase) will automate this.

### WP-03: Contract Segmentation

**What it did:** Classified all aliases into 4 execution groups (Core, Standard, Defensive, Restricted) with per-group parameter recommendations.

**What it found:**
- Not all contracts should run the same parameters. Dec26 can be tighter (better fills with maintained accuracy). Sep26 needs to be much wider (stop the bleeding). X/Y aliases in most expiries are fundamentally broken.
- Specific parameter changes were derived for every group: avoidance levels, HitMan thresholds, Backoff triggers, WCT budgets, and reload clips.

**What to do:** Implement the Group A–D parameter changes. This is the single highest-impact action available. See the Parameter Playbook file for exact numbers.

### WP-04: Timer Logic Verification

**What it did:** Audited all pricing formulas across 9 knowledge-base documents, algebraically verified every reverse formula, and produced 20 test cases.

**What it found:**
- CRITICAL: execution-modifiers §5 is missing the −BS_FF term in Leg 3/4 base formulas. If anyone implements from that document, Leg 3/4 prices will be wrong.
- The authoritative formula source is price-formulas-complete.md — use that, not execution-modifiers, for any Leg 3/4 work.
- The accuracy measurement cross-check identity (L1+L2 implied O comparison) is wrong when BS_ZQ ≠ 0. The corrected formula adds |BS_ZQ| to the expected difference.
- Timer Logic's core math is sound and algebraically verified.

**What to do:** If you modify any formula-related code or parameters, always reference price-formulas-complete.md, never execution-modifiers.md §5. The Timer Logic implementation (WP-05) already uses the correct formulas.

### WP-05: Timer Logic Implementation

**What it did:** Built the C# implementation of Timer Logic with 20 test cases. 151 of 152 tests pass.

**What it found:**
- Timer Logic works. The one failing test (TC-15) is a test-case bug (expected value should be 3.0, not 3.5), not an implementation defect.
- The implementation uses the corrected formulas from price-formulas-complete.md, including the −BS_FF term.

**What to do:** When deploying Timer Logic, start with Legs 1 & 2 only (Phase 1 recommendation from WP-04). This gives you the primary edge improvement with lower risk. Add Legs 3 & 4 in Phase 2 after validating the infrastructure.

### WP-12: Event Calendar

**What it did:** Mapped every time-sensitive trading event from April 2026 through March 2027: FOMC meetings, contract expiries, roll dates, CPI/NFP releases, quarter-end effects.

**What it found:**
- Eight FOMC meetings in the period. Dynamic avoidance (12:55–13:05 window at 0.11) is already configured for these.
- For Sep26 (Group C), data releases (CPI, NFP, PCE) outside the current FOMC window also pose risk due to thin books. These deserve their own avoidance escalation windows.
- Roll dynamics affect contract group transitions — when Mar26 expires and a new back contract appears, it enters as Group B until data says otherwise.

**What to do:** Add CPI/NFP/PCE avoidance windows for Sep26 using the existing TimedParameterService infrastructure. Check the Event Calendar file before each week's trading for upcoming events.

## Priority Action List

1. **Today:** Pause all Jun26 and Sep26 X/Y aliases.
2. **Today:** Review and implement Group C (Sep26) defensive parameters.
3. **This week:** Implement Group A (Dec26) and Group B (Mar26/Jun26) parameter changes.
4. **This week:** Add data-release avoidance windows for Sep26.
5. **Ongoing:** Start tracking curve-implied fair value alongside your manual O_target.
6. **When ready:** Deploy Timer Logic to SIM for Legs 1 & 2.
