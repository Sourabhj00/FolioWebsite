# Parameter Playbook — What to Change, By Group

## How to Use This File

This file contains every parameter change recommended by the WP-01 (fill accuracy) and WP-03 (contract segmentation) models. Parameters are organized by execution group. Each change includes the current value, recommended value, and the reasoning.

**Important:** These recommendations are initial positions derived from 3,225 fills of production data plus structural analysis. They will be refined when WP-06 delivers real fill accuracy patterns. Where a recommendation is speculative, it's flagged.

## Group A — Core (Dec26 Standard Aliases)

**Philosophy:** The system's best-performing group. Don't break it. Small tightening to capture more fills.

| Parameter | Current | Recommended | Reasoning |
|-----------|---------|-------------|-----------|
| Av_ZQ | 0.05 | **0.03** | Dec26 basis is tight and stable. Accuracy holds at 67–70% even with volume increases. Tighter avoidance captures more fills. |
| Av_FF | 0.05 | **0.03** | SR1-ZQ basis for Jan/Feb sub-months is historically range-bound. Same logic. |
| BS_ZQ | 0.0 | **0.0** | No directional conviction on Dec26 calendar. Leave neutral. |
| BS_FF | 0.0 | **0.0** | Same. |
| HitMan LiqCheckLegII | 400 | **350** | Dec26 SR3 books are deep enough at 350. More HitMan fires = more momentum fills. |
| ASM LiqChkVolLegII | 150 | **120** | Slightly looser join threshold. Reliable depth at 120 lots on Dec26 quoting leg. |
| Everything else | — | **No change** | Backoff, WCT, reload clip all stay. Consider 6:10 clip after WP-06 real data confirms. |

**Expected impact:** Slightly more fills at maintained accuracy. Low risk — Dec26 is structurally forgiving.

## Group B — Standard (Mar26, Jun26 Standard Aliases)

**Philosophy:** Middle of the curve. Mostly fine, but widen slightly and fix the Jun26 ZQ sell-side payup.

| Parameter | Current | Recommended | Reasoning |
|-----------|---------|-------------|-----------|
| Av_ZQ | 0.05 | **0.07** | Mar/Jun calendars are more volatile than Dec. Moderate widening reduces adverse fills. |
| Av_FF | 0.05 | **0.07** | Matches ZQ spread treatment. Apr/May/Jul/Aug sub-months have moderate basis volatility. |
| BS_ZQ | 0.0 | **0.0** | No persistent calendar direction identified. Revisit in WP-06. |
| BS_FF (Mar26) | 0.0 | **0.0** | No change for Mar26. |
| BS_FF (Jun26) | 0.0 | **−0.05** | Jun26 ZQ sell-side has structural payup (WP-01 pattern 4). Light buy bias makes Leg 3/4 buy prices slightly more aggressive, offsetting sell-side slippage. **Speculative — validate with real data.** |
| Everything else | — | **No change** | HitMan, ASM, Backoff, WCT, reload all stay at current. |

**Expected impact:** Fewer adverse fills from basis volatility. The Jun26 BS_FF change is the most speculative — monitor closely. If buy-side accuracy drops instead of improving, revert to 0.0.

## Group C — Defensive (Sep26 Standard Aliases)

**Philosophy:** Sep26 is bleeding at ~51% accuracy. Priority is stop the bleeding, not capture more fills. Every parameter change here is defensive.

| Parameter | Current | Recommended | Reasoning |
|-----------|---------|-------------|-----------|
| Av_ZQ | 0.05 | **0.12** | Large widening. Pulls quotes into depth, reducing adverse fill rate. Fill count will drop — that's intentional. |
| Av_FF | 0.05 | **0.12** | October SR1-ZQ basis is structurally wider. Same defensive logic. |
| BS_ZQ | 0.0 | **0.0** | Don't layer directional bias onto volatile underlying. Risk of being wrong exceeds benefit. |
| BS_FF | 0.0 | **0.0** | Same. |
| HitMan LiqCheckLegII | 400 | **600** | Require substantially more hedge liquidity before crossing. Sep26 SR3 books are thin and prone to gapping. |
| HitMan VolRatioLegII | 0.10 | **0.07** | Tighter vol ratio — HitMan only fires when offer at bid+1 is truly thin. Reduces false momentum signals. |
| ASM LiqChkVolLegII | 150 | **200** | Higher liquidity floor for joining. Sep26 quoting leg has less reliable depth at 150. |
| ASM LiqAtGapLegII | 1500 | **2000** | Gap markets on Sep26 are especially dangerous. |
| Backoff QtyThreshold (SR1) | 300 | **200** | Back off more often. At 200 lots offered, retreat and wait for better price. |
| Backoff QtyThreshold (SR3) | 1000 | **700** | Same on SR3 leg. |
| Backoff QtyRatio | 0.30 | **0.25** | Easier ratio-based backoff trigger. 25% offer-to-bid ratio is enough evidence to wait. |
| WCT NumberOfPayups | 5 | **3** | Cut payup budget from 6 ticks to 4 ticks. Sep26 hedges needing 5+ ticks of payup are almost certainly adverse. |
| WCT WCTTicks | 1 | **2** | More patience before payup. Wait 2 ticks beyond initial before engaging. Gives time for mean-reversion. |
| WCT AntiStopVol | 4000 | **3000** | More caution paying into walls. 3000-lot offer on Sep26 is likely structural, not temporary. |
| Reload clip | 3:5 | **3:5** | Keep clip size but reduce active clips by ~25%. Lower total Sep26 exposure. |

**Additional:** Add CPI, NFP, and PCE avoidance windows (08:28–08:35 ET) using TimedParameterService. Sep26 thin books are most vulnerable to data-driven moves.

**Expected impact:** Fewer fills, but better fills. Accuracy should improve from ~51% toward the 55–60% range. Profit per round turn improves even as volume drops.

## Group D — Restricted (X/Y Aliases)

**Philosophy:** Structural accuracy problem that parameter tuning cannot fix. Restrict or pause.

| Subgroup | Action | Accuracy (Test Data) |
|----------|--------|---------------------|
| Sep26 X/Y | **Pause entirely** | −380% / −359%. Every fill is a guaranteed loss. |
| Jun26 X/Y | **Pause entirely** | −314% / −293%. Systematic buying high, selling low. |
| Mar26 X | **Minimum clip, monitor** | 36.5%. Survivable but thin. One 3:5 unit only. |
| Mar26 Y | **Pause** | −15.2%. Marginal and trending worse. |
| Dec26 X | **Reduced clip, monitor** | 52%. Performing at Group B levels. One 3:5 unit. |
| Dec26 Y | **Reduced clip, monitor** | 60%. Actually decent. One 3:5 unit, increase if real data confirms. |

For active X/Y aliases, apply Group C defensive parameters (Av=0.12, reduced WCT budget).

## Flipping Markets — Intraday Kill Rules

Beyond group parameters, pause any alias showing these symptoms during a session:

1. **Both-side accuracy below 30%**: Paying up on every fill in both directions. Pause for remainder of session.
2. **Average sell price below average buy price on matched fills**: Buying strength, selling weakness. If this persists 2+ consecutive sessions, pause until spread direction stabilizes.
3. **Fill count > 500 lots with buy accuracy below 40%**: Volume is degrading buy-side quality. Reduce buy clip sizes or pause buy-side quoting.

## Dynamic Avoidance Schedule

| Window | Time (ET) | Av_FF/Av_ZQ override | Applies to |
|--------|-----------|---------------------|------------|
| FOMC | 12:55–13:05 | 0.11 | All groups |
| CPI/NFP/PCE | 08:28–08:35 | 0.11 | Group C (Sep26) — **new** |
| Quarter-end | Last 2 trading days | Consider +0.03 on all groups | All groups |

## What to Validate After Implementing

After 5 trading days with the new parameters, check:

1. Did Sep26 accuracy improve from ~51% toward 55–60%?
2. Did Dec26 fill count increase without accuracy dropping below 60%?
3. Did the Jun26 BS_FF=−0.05 change improve or worsen SR3|ZQ buy-side accuracy?
4. Are the paused X/Y aliases actually paused (no accidental fills)?
5. Did total round turns drop more than 30%? If yes, Group C avoidance may be too aggressive.
