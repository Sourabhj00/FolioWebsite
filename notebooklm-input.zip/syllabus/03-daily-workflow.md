# Daily Workflow — Trading With the Models

## Pre-Market (Before 08:00 ET)

### 1. Check the Event Calendar
Open the Event Calendar (WP-12). Look for today's events:
- **FOMC day?** Dynamic avoidance is already configured (12:55–13:05). No action needed, but be ready for extended volatility after 13:00.
- **CPI/NFP/PCE day?** If you've implemented the Group C avoidance windows, Sep26 will automatically widen at 08:28. For other groups, consider manually widening avoidance 2 minutes before the release.
- **Roll date approaching?** Check if any SR3, SR1, or ZQ contracts expire this week. Liquidity will thin in the expiring contract and shift to the next. Reduce clip sizes on the rolling contract.
- **Quarter-end?** Last 2 trading days of the quarter can see unusual flows. Consider +0.03 on avoidance across all groups.

### 2. Set Your O Prices
You set buyBiased/sellBiased as you always have — this is your judgment call and the models don't replace it. What changes:
- If you're tracking curve-implied fair value (from the SOFR bootstrap methodology), compare your manual O_target to the curve. Divergence > 0.5 ticks deserves investigation: has the curve moved overnight? Are you stale?
- The fair value model is not yet automated. For now, it's a sanity check on your manual pricing.

### 3. Verify Group Parameters
Confirm the correct parameter set is loaded for each group:
- Group A (Dec26): Tight — Av 0.03, standard HitMan/ASM
- Group B (Mar/Jun26): Moderate — Av 0.07, Jun26 BS_FF=−0.05
- Group C (Sep26): Defensive — Av 0.12, elevated HitMan/ASM/Backoff thresholds
- Group D (X/Y): Paused or minimal clip per the Playbook

## Market Hours (08:30–15:00 ET)

### Monitoring Cadence
Check these at the top of each hour, and immediately after any data release:

**Accuracy pulse:**
- Are any aliases showing both-side accuracy below 30%? → Pause that alias.
- Is any group's buy-side accuracy dropping below 40% with high fill count? → Reduce buy clips.
- Is Sep26 accuracy holding above 50% with the new parameters? If it's dropping below 45%, something structural has changed — consider further widening or pausing individual aliases.

**Fill quality check:**
- Are you seeing more Zero-TD fills (filled at your price exactly) on Dec26 after tightening? That's the expected result of lower avoidance.
- On Sep26, are you seeing fewer fills but better quality? Fewer fills at 55%+ accuracy is better than more fills at 51%.

**Spread health:**
- If any monitoring instrument (SR1-ZQ or ZQ calendar) widens beyond 1 tick, the microprice becomes unreliable. The system should auto-pause that contract via the spread guard. Verify it's working.

### Parameter Adjustments During the Day
- **Don't touch Group A or B parameters intraday** unless you see a specific red flag. The models' recommendations are designed for session-level stability.
- **Group C is your active management zone.** Sep26's thin books mean conditions can change within an hour. If you see a sudden accuracy drop, consider pausing individual Sep26 aliases rather than changing parameters.
- **After a data release**, give the system 5–10 minutes to normalize before evaluating accuracy. Fills during the release itself will have low accuracy by design — the dynamic avoidance window handles this.

## Post-Market (After 15:00 ET)

### End-of-Day Review
1. **Pull fill data** for the session. Compare per-group accuracy to the targets:
   - Group A: > 60% combined
   - Group B: > 55% combined
   - Group C: > 50% combined (improvement over the 51% baseline)
   - Group D: Should have near-zero fills (paused/minimal)

2. **Check matched P&L** by group. Are the parameter changes improving profit per round turn even if fill count dropped?

3. **Flag anomalies** for investigation:
   - Any alias that flipped from profitable to losing
   - Any group where accuracy degraded from the prior session by more than 5 points
   - Any alias showing degradation patterns (getting worse over consecutive days)

4. **Update O_target** if needed based on overnight curve moves, positioning changes, or fair value divergence.

## Weekly Review

At week's end, review the 5-day rolling metrics:
- Are the parameter changes producing the expected direction of change?
- Is Sep26's accuracy improving or just its fill count dropping?
- Are the paused X/Y aliases still paused?
- Does the fair value anchor agree with your manual O_target on average, or has a structural divergence appeared?
- Are there any events next week that require parameter pre-adjustment?

## When Something Unexpected Happens

See the "When Things Go Wrong" file for decision trees on common scenarios: sudden accuracy drops, spread blowouts, fill surges, crossed markets, and system-level issues.
