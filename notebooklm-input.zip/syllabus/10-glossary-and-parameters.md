# Glossary & Parameter Reference

## Part 1: Glossary

### Strategy Terms

| Term | What It Means |
|------|--------------|
| **O-spread** | The SR3|SR1 3-leg structure (short 10 SR3, long 3+3 SR1). Your core position. |
| **Contract** | An expiry group (Mar26, Jun26, Sep26, Dec26). Each has 4 standard legs + X/Y variants. |
| **Leg 1 / Leg 2** | SR3|SR1 inter-product spreads for the two SR1 sub-months (near and far). |
| **Leg 3 / Leg 4** | SR3|ZQ inter-product spreads, derived from Legs 1/2 minus the SR1-ZQ basis. |
| **diff** | Synthetic SR1 calendar spread: v1 − v2 + v3. Drives how the O price splits between near/far month legs. |
| **buyBiased / sellBiased** | Your target O buy/sell prices. The system computes all leg prices from these. |
| **Microprice** | Book-weighted midpoint: (Bid × AskQty + Ask × BidQty) / (BidQty + AskQty). Falls back to simple midpoint if spread > 0.5 ticks. |
| **Set A / Set B** | Duplicate ASE slots for the same contract. Allows parallel execution or independent parameter testing. |
| **X / Y ASEs** | 3-leg spreads embedding the ZQ calendar. Currently performing poorly — most are paused or restricted. |

### Execution Terms

| Term | What It Means |
|------|--------------|
| **ASE** | Autospreader Engine (TT). Handles multi-leg execution, hedging, payup/backoff. |
| **HitMan** | Aggressive execution rule. Monitors liquidity and volume ratios to decide when to "hit" the market. |
| **ASM** | Passive quoting rule. Controls when to join the book and at what price. |
| **Backoff** | Quote retreat rule. Pulls quotes away when adverse conditions are detected (thin book, high fill probability). |
| **WCT** | Working Conditional Ticks. Liquidity-aware payup rule with configurable tick budget. |
| **Payup** | Fill at a worse price than intended. Buys filled higher, sells filled lower. |
| **Backoff (fill type)** | Fill at a better price than intended. The market came to you. |
| **Zero-TD** | Fill at exactly your intended price. The ideal outcome. |
| **Reload** | Auto-reloading clip system. Submits reloadBuyQty/reloadSellQty at a time, up to totalBuyQty/totalSellQty. |
| **phaseStart** | Canary order system. Sends 1-lot test orders per leg; if any fills (meaning price is too aggressive), pauses the contract. |
| **Spike** | Circuit breaker watching a reference instrument. If price moves > N ticks in M seconds, all orders pause. |

### Model Terms

| Term | What It Means |
|------|--------------|
| **Accuracy** | Fill quality metric. 100% = filled at entry price. Drops 20% per tick of adverse deviation. |
| **Tick Deviation (TD)** | Difference between actual fill price and intended entry price, in ticks. |
| **Expansion** | Timer Logic confidence parameter (0 to 0.5). Higher = more aggressive rounding = more fills at higher per-fill cost. |
| **Timer Logic** | Evidence-conditioned rounding replacing hard RD/RU. Not related to time-based scheduling. |
| **Implied O** | O-spread price reverse-calculated from a fill. Deviation from target O measures total system accuracy. |
| **Fair Value** | Curve-derived O-spread anchor from SOFR bootstrap. Mathematical alternative to judgment-based O_target. |
| **Contract Group** | A/B/C/D classification from WP-03. Determines which parameter set an alias runs. |
| **Degradation** | Accuracy decline over time for a specific alias. Measured as first_accuracy minus last_accuracy. |

### Infrastructure Terms

| Term | What It Means |
|------|--------------|
| **Dynamic Avoidance** | TimedParameterService auto-adjusting avoidance during specific windows (e.g., FOMC 12:55–13:05). |
| **PauseWindow** | Time-based trading halt for known events (PPI, Chicago PMI, market close). |
| **Traffic Controller** | API rate limiter preventing exchange throttling. Monitors messages per instrument per time window. |
| **Spread Guard** | Auto-pause when monitoring instrument's bid-ask spread exceeds 1 tick (microprice unreliable). |

## Part 2: Parameter Reference

### Avoidance Parameters

| Parameter | Legs | Effect | Group A | Group B | Group C |
|-----------|------|--------|---------|---------|---------|
| Av_ZQ | 1, 2 | Symmetric spread widening on SR3|SR1 legs. Buy −Av, Sell +Av. | 0.03 | 0.07 | 0.12 |
| Av_FF | 3, 4 | Symmetric spread widening on SR3|ZQ legs. Buy −Av, Sell +Av. | 0.03 | 0.07 | 0.12 |

**What it controls:** How far your quotes sit from the market. Higher = wider spread = fewer fills but better fill quality. Lower = tighter = more fills but higher adverse selection risk.

**When to increase:** Volatile markets, thin books, data releases, degrading accuracy.
**When to decrease:** Stable basis, deep books, accuracy consistently above target.

### B/S Bias Parameters

| Parameter | Legs | Effect | Group A | Group B (Mar) | Group B (Jun) | Group C |
|-----------|------|--------|---------|--------------|--------------|---------|
| BS_ZQ | 1, 2 | Asymmetric calendar residual aggression. | 0.0 | 0.0 | 0.0 | 0.0 |
| BS_FF | 3, 4 | Symmetric ZQ basis aggression. | 0.0 | 0.0 | −0.05 | 0.0 |

**What it controls:** Directional tilt within the spread. Positive = more aggressive on buy side. Negative = more aggressive on sell side (for BS_FF, negative actually makes buys more aggressive on Legs 3/4 — the sign convention is counterintuitive).

**When to use:** Only when you have evidence of persistent one-sided structural cost. The Jun26 BS_FF=−0.05 is the only current recommendation.

### HitMan Parameters

| Parameter | What It Controls | Group A | Group B | Group C |
|-----------|-----------------|---------|---------|---------|
| LiqCheckLegII | Minimum hedge-side lots before crossing | 350 | 400 | 600 |
| VolRatioLegII | Offer-to-bid ratio trigger for crossing | 0.10 | 0.10 | 0.07 |

**Practical meaning:** LiqCheck = "how much liquidity must be there before I cross." VolRatio = "how thin must the opposite side be to trigger." Higher LiqCheck = more conservative. Lower VolRatio = more conservative.

### ASM Parameters

| Parameter | What It Controls | Group A | Group B | Group C |
|-----------|-----------------|---------|---------|---------|
| LiqChkVolLegII | Minimum lots before joining the book | 120 | 150 | 200 |
| LiqAtGapLegII | Minimum lots before joining in a gap market | 1500 | 1500 | 2000 |

### Backoff Parameters

| Parameter | What It Controls | Group A | Group B | Group C |
|-----------|-----------------|---------|---------|---------|
| QtyThreshold (SR1) | Back off when offered volume ≤ this | 300 | 300 | 200 |
| QtyThreshold (SR3) | Back off when offered volume ≤ this | 1000 | 1000 | 700 |
| QtyRatio | Back off when offer/bid ratio ≤ this | 0.30 | 0.30 | 0.25 |

### WCT Parameters

| Parameter | What It Controls | Group A | Group B | Group C |
|-----------|-----------------|---------|---------|---------|
| NumberOfPayups | Maximum payup ticks beyond WCT | 5 | 5 | 3 |
| WCTTicks | Initial patience ticks before payup begins | 1 | 1 | 2 |
| AntiStopVol | Don't pay up into offers larger than this | 4000 | 4000 | 3000 |

**Total payup budget:** WCTTicks + NumberOfPayups. Group A/B: 6 ticks. Group C: 5 ticks.

### Timer Logic Parameters (When Deployed)

| Parameter | What It Controls | Starting Value | Safe Range |
|-----------|-----------------|---------------|------------|
| Expansion | Rounding aggressiveness | 0.15 | 0.0–0.35 |
| Fed Window Expansion | Override during FOMC/data releases | 0.0 | Always 0.0 |

**Key constraint:** Expansion must stay below the crossed-market boundary for the current O spread width. The implementation enforces this automatically.

## Part 3: Quick Decision Trees

### "Should I widen avoidance on this alias?"
→ Is accuracy below the group target for 2+ sessions? → **Yes**: Widen by 0.02.
→ Is it a data release day? → **Yes**: Group C already has dynamic widening. For A/B, consider +0.02 temporary.
→ Is the monitoring instrument's spread above 0.5? → The system should already be handling this via microprice fallback.

### "Should I pause this alias?"
→ Both-side accuracy below 30% for the current session? → **Pause immediately.**
→ Avg sell price below avg buy price on matched fills? → **Pause if persists 2 sessions.**
→ X/Y alias on Jun26 or Sep26? → **Should already be paused.**
→ Accuracy degrading 3+ consecutive sessions? → **Pause and investigate.**

### "Should I change my O_target?"
→ Compare to curve-implied fair value (if available). Divergence > 1 tick → **Investigate why.**
→ Have multiple sessions shown fills consistently on one side only? → **Your target may be stale. Adjust toward the fill side by 0.5 ticks.**
→ Has a major event (FOMC, data surprise) shifted the curve? → **Re-anchor to post-event levels.**
