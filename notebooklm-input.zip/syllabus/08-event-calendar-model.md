# Event Calendar & Seasonality — When Risk Changes

## Why Events Matter to Your System

Your system quotes passively and hedges reactively. During event-driven volatility, three things happen simultaneously: books thin (less liquidity to hedge against), microprices gap (your diff calculation becomes stale within milliseconds), and fill rates spike (aggressive orders hit your resting quotes before parameters can adjust).

The dynamic avoidance system handles the FOMC window (12:55–13:05). The event calendar extends this protection to all risk windows throughout the year.

## Event Categories and Their Impact

### FOMC Meetings (8 per year)
**Impact:** Highest single-event risk. Rate decision at 14:00 ET, but positioning begins at 12:55.
**Current protection:** Dynamic avoidance escalates Av_FF/Av_ZQ to 0.11 during 12:55–13:05.
**Recommendation:** No change needed for FOMC handling. The existing window and level are appropriate.

**2026–2027 FOMC dates:**
- May 5–6, Jun 16–17, Jul 28–29, Sep 15–16, Oct 27–28, Dec 15–16 (2026)
- Jan 26–27, Mar 16–17 (2027)

### Data Releases (CPI, NFP, PCE)
**Impact:** High. These release at 08:30 ET (pre-market for many participants, but your system is already live). Books thin around 08:28. Immediate volatility spike.
**Current protection:** None specific — only FOMC has a dynamic avoidance window.
**New recommendation (from WP-03/WP-12):** Add avoidance windows at 08:28–08:35 ET for Group C (Sep26). Sep26's thin books are most vulnerable. Groups A and B can absorb data releases without special handling.

### SR3/SR1/ZQ Contract Expiries and Rolls
**Impact:** Medium. Liquidity shifts from expiring to next contract over the roll period. Your monitoring instruments' microprices become less reliable as the expiring contract's books thin.
**What to do:** Check the event calendar weekly for upcoming expiries. In the 2–3 trading days before an SR1 or ZQ sub-month expires, consider widening avoidance by 0.02 on aliases using that sub-month. After expiry, the new contract takes over — reset parameters.

**Key roll dates (2026):**
- SR1 Apr26 expires: April 28 (last trading day April 27)
- SR1 May26 expires: May 27
- SR3 Jun26 expires: June 15 (third Wednesday)
- ZQ follows similar monthly cycle

### Quarter-End Effects
**Impact:** Low-medium. Institutional rebalancing, regulatory reporting, and funding pressures can create unusual flows in the last 2 trading days of March, June, September, December.
**Recommendation:** Consider +0.03 on avoidance across all groups during the last 2 trading days of each quarter.

### Roll Dynamics — When Group Memberships Change
When an SR3 quarterly expires:
- The front contract's aliases leave the system entirely.
- All other groups shift forward: what was Jun26 (Group B) is now the new front, what was Sep26 (Group C) moves closer to front.
- A new back contract enters (e.g., Mar27). It starts as Group B until data establishes its accuracy profile.

**Critical:** When Sep26 eventually becomes the front contract, its book depth may improve (front contracts are more liquid). But don't preemptively upgrade it to Group B — wait for at least 5 sessions of accuracy data above 55%.

## Seasonal Patterns

### Time-of-Day Effects
- **08:30–09:00 ET:** Data release window. Highest volatility. Dynamic avoidance recommended for Group C.
- **09:00–11:00 ET:** Peak liquidity. Best period for aggressive parameters.
- **11:00–12:00 ET:** Liquidity begins to thin as European markets close.
- **12:55–13:05 ET:** FOMC window (on meeting days). Dynamic avoidance active.
- **13:00–15:00 ET:** Post-FOMC volatility can persist. On non-FOMC days, this is a normal but lower-liquidity period.
- **15:00–16:00 ET:** End-of-day. Books thin. Consider manually widening avoidance if accuracy degrades.

### Monthly Patterns
- First Friday: NFP release — data release avoidance for Group C.
- Second-to-last Friday before FOMC: Blackout period begins. No Fed speeches. Market tends to be quieter but can see pre-positioning.
- Third Wednesday of March/June/September/December: SR3 quarterly expiry. Roll effects peak.

## Using the Full Event Calendar

The WP-12 event calendar (event-calendar-2026-2027.md) contains a month-by-month chronological listing of all events through March 2027. The practical workflow:

1. **Sunday evening:** Open the event calendar, review the upcoming week.
2. **Flag any FOMC, CPI, NFP, PCE, or expiry events.** These are your "parameter alert" days.
3. **On alert days:** Verify dynamic avoidance windows are configured. For Group C, add data-release windows if not already present.
4. **On expiry weeks:** Monitor roll progress. Widen avoidance on aliases using the expiring sub-month.
5. **On quarter-end:** Apply temporary +0.03 avoidance buffer.

The calendar is a static document that will be refreshed as new dates are confirmed. Keep it accessible during your pre-market routine.
