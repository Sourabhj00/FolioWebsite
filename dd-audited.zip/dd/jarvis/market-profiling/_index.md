---
title: Market Profiling — Map of Content
wp: WP-03, WP-12
status: complete
last-updated: 2026-03-31
lines: 27
---

# Market Profiling — Map of Content

WP-03 contract segmentation (4 groups with execution characteristics and
parameter recommendations) plus WP-12 event calendar (Fed meetings, rolls,
FOMC, payrolls through March 2027). Together these inform when and how
aggressively to trade each contract group. (~764 lines total)

## Files

- [[contract-segmentation]] — 4 contract groups (A=Core Dec26, B=Standard Mar/Jun, C=Defensive Sep26, D=Restricted X/Y) with execution characteristics, parameter recommendations per group (Avoidance, B/S Bias, HitMan, ASM, Backoff, WCT), .NET config mappings, markets-to-avoid list. (~338 lines)
- [[event-calendar-2026-2027]] — Systematic reference of time-sensitive trading events: FOMC meetings, SR3/SR1/ZQ expiry dates, tax deadlines, quarter-end effects, roll dynamics, seasonality patterns with chronological master calendar. (~426 lines)

## KB Dependencies

- [[knowledge-base/strategy/execution-modifiers]] — Avoidance/bias formulas that segmentation recommends tuning
- [[knowledge-base/ase-rules/custom-rules-production]] — Production rules receiving group-specific parameter recommendations
- [[knowledge-base/core/instruments-and-platform]] — Contract specs defining the instruments being segmented
- [[knowledge-base/execution-analysis/methodology-and-framework]] — Accuracy metrics used to validate segmentation

## Related Folders

- [[fill-analysis/_index|Fill Analysis]] — Accuracy data validating segmentation group boundaries
- [[timer-logic/_index|Timer Logic]] — Formula corrections relevant to group-level accuracy
- [[strategy-research/_index|Strategy Research]] — Directional bias model operating across contract groups
- [[fair-value/_index|Fair Value]] — Fair value methodology interacting with group parameters
- [[plan/_index|Plan]] — WP-03/WP-12 completion status
