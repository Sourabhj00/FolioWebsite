---
title: Contract Segmentation — 4-Group Parameter Framework
wp: WP-03
status: complete
created: 2026-03-20
last-updated: 2026-03-31
lines: 338
kb-depends:
  - knowledge-base/execution-analysis/methodology-and-framework.md
  - knowledge-base/ase-rules/custom-rules-production.md
  - knowledge-base/strategy/execution-modifiers.md
  - knowledge-base/core/instruments-and-platform.md
  - knowledge-base/strategy/core-quad-leg-arbitrage.md
  - knowledge-base/ase-rules/ase-mechanics-and-parameters.md
jarvis-depends:
  - jarvis/fill-analysis/README.md
  - jarvis/market-profiling/event-calendar-2026-2027.md
---

# Contract Segmentation & Parameter Recommendations

## Caveat

These recommendations are built from structural patterns documented in `methodology-and-framework.md`, the market profiling framework in `proposed-additions.md`, and directional confirmation from the WP-01 test pipeline (synthetic data). Every parameter recommendation here is an **initial position** to be validated and refined when real fill data flows through WP-01 in WP-06. Where the reasoning depends on an assumption that real data might contradict, it's flagged explicitly.

---

## 1. Group Definitions

Four groups, defined by two primary dimensions: **expiry group** (which drives basis volatility and book depth) and **fill type** (standard A/B vs. X/Y).

| Group | Name | Members | Defining Characteristics |
|-------|------|---------|--------------------------|
| **A** | Core | Dec26 standard aliases: SR3\|SR1 Dec Jan26, SR3\|SR1 Dec Feb26, SR3\|ZQ Dec Jan26, SR3\|ZQ Dec Feb26 | Historically cleanest accuracy (methodology doc: 67–70% combined). Tightest spreads. Lowest basis volatility. Highest ratio of zero-TD fills. |
| **B** | Standard | Mar26 + Jun26 standard aliases: SR3\|SR1 Mar Apr26, Mar May26, Jun Jul26, Jun Aug26; SR3\|ZQ Mar Apr26, Mar May26, Jun Jul26, Jun Aug26 | Mixed accuracy. Mar26 slightly better than Jun26. Jun26 SR3\|ZQ sell side shows structural payup (pattern 4). Moderate directional tendency on front contracts. |
| **C** | Defensive | Sep26 standard aliases: SR3\|SR1 Sep Oct26, Sep Nov26; SR3\|ZQ Sep Oct26, Sep Nov26 | Structurally worst accuracy (~51% in methodology doc, confirmed worst in test data). Widest basis volatility. October SR1-ZQ basis structurally wider. Most degradation over time. |
| **D** | Restricted | All X/Y aliases across all expiries | Extreme payup (methodology: −120% to −300%). Entry price calculation may be fundamentally wrong for these ASE types. Jun26/Sep26 X/Y worst; Dec26 X/Y survivable but still underperforming. |

### Membership Criteria — Decision Tree

To assign a new contract to a group:

1. Is it an X or Y ASE type? → **Group D** (Restricted), regardless of expiry.
2. Is the SR3 quarterly expiry ≥ 9 months out, with sub-month contracts historically showing tight basis ranges? → **Group A** (Core). Currently only Dec26 qualifies.
3. Is the SR3 quarterly expiry 3–6 months out? → **Group B** (Standard). Currently Mar26 and Jun26.
4. Is the SR3 quarterly expiry 6–9 months out AND the sub-month basis is historically volatile or thin? → **Group C** (Defensive). Currently Sep26.

**When expiry groups roll forward** (e.g., Mar26 expires and Mar27 is added), the new back contract enters as Group A if it exhibits Dec26-like characteristics, or as Group B until its accuracy profile is established. Sep26 will eventually move to front status, at which point it may improve (front contracts have deeper books) — but keep it in Group C until data confirms the improvement.

### Why These Groups and Not Others

The proposed-additions doc suggests front/mid/back as the grouping axis. But the data shows expiry-specific structural effects that don't map cleanly to time-to-expiry alone:

- **Sep26 is specifically bad**, not "all mid-dated contracts are bad." The October SR1-ZQ basis has structural volatility that doesn't appear in other months at similar maturities.
- **Dec26 is specifically good** despite being the furthest-dated. This is counterintuitive (furthest = thinnest books) but consistent with the pattern that far-dated bases are less volatile, producing more zero-TD fills even with thinner order books.
- **X/Y fills are a distinct problem** that cuts across all expiries. Grouping them separately allows targeted fixes (entry price review, clip reduction) without penalizing standard aliases in the same expiry.

---

## 2. Current Production Parameters (Baseline)

All contracts currently run identical parameters. These are the values from `custom-rules-production.md`:

| Parameter | Current Value | Where Set |
|-----------|--------------|-----------|
| **HitMan** VolRatioLegII | 0.10 | ASE Rule 1 |
| **HitMan** VolRatioLegI | 0.10 | ASE Rule 1 |
| **HitMan** StopVolLegI | 100 | ASE Rule 1 |
| **HitMan** LiqCheckLegII | 400 | ASE Rule 1 |
| **ASM** VolRatioLegII | 0.12 | ASE Rule 2 |
| **ASM** LiqChkVolLegII (1-tick) | 150 | ASE Rule 2 |
| **ASM** LiqAtGapLegII (2-tick) | 1500 | ASE Rule 2 |
| **Backoff** QtyRatio | 0.30 | ASE Rule 6 |
| **Backoff** MinAvailableLiq | 80 | ASE Rule 6 |
| **Backoff** QtyThreshold (SR1) | 300 | ASE Rule 6 |
| **Backoff** QtyThreshold (SR3) | 1000 | ASE Rule 6 |
| **WCT Payup** QtyRatio | 0.09 | ASE Rule 8 |
| **WCT Payup** StopVol | 20 | ASE Rule 8 |
| **WCT Payup** NumberOfPayups | 5 | ASE Rule 8 |
| **WCT Payup** WCTTicks | 1 | ASE Rule 8 |
| **WCT Payup** AntiStopVol | 4000 | ASE Rule 8 |
| **Av_ZQ** (ZQ spread avoidance) | 0.05 (dynamic: 0.11 during 12:55–13:05) | .NET config |
| **Av_FF** (SR1FF avoidance) | 0.05 (dynamic: 0.11 during 12:55–13:05) | .NET config |
| **BS_ZQ** (ZQ spread B/S bias) | 0.0 (neutral) | .NET config |
| **BS_FF** (SR1FF B/S bias) | 0.0 (neutral) | .NET config |
| **Reload clip** | 3:5 standard (6:10 double) | ASE config |

**Note on avoidance values**: The execution-modifiers doc uses 0.1 as an example. The 0.05 default with 0.11 FOMC dynamic scheduling is inferred from the TimedParameterService description. If the actual production baseline differs, adjust the deltas below accordingly.

---

## 3. Parameter Recommendations by Group

### Group A — Core (Dec26)

**Philosophy**: This is where the system works best. Don't fix what isn't broken. Minor tweaks to capture slightly more fills without degrading accuracy.

| Parameter | Current | Recommended | Change | Reasoning |
|-----------|---------|-------------|--------|-----------|
| Av_ZQ | 0.05 | **0.03** | −0.02 | Dec26 basis is tight and stable. Lower avoidance lets the system quote tighter spreads, capturing more fill opportunities. Methodology doc confirms Dec26 accuracy holds at 67–70% even with volume increases — the basis isn't the problem here. |
| Av_FF | 0.05 | **0.03** | −0.02 | Same logic. SR1-ZQ basis for Jan/Feb sub-months is historically range-bound. |
| BS_ZQ | 0.0 | **0.0** | No change | No directional conviction warranted on Dec26 calendar. Leave neutral until real data shows a persistent skew. |
| BS_FF | 0.0 | **0.0** | No change | Same. |
| HitMan LiqCheckLegII | 400 | **350** | −50 | Dec26 hedge books (SR3) are deep enough at 350 lots. Lowering this threshold lets HitMan fire slightly more often, capturing more momentum-driven fills. Conservative reduction — still requires substantial liquidity. |
| ASM LiqChkVolLegII | 150 | **120** | −30 | Slightly looser join threshold. Dec26 quoting leg (SR1/ZQ) has reliable book depth at these levels. |
| ASM LiqAtGapLegII | 1500 | **1500** | No change | Don't loosen gap-aware threshold. Gap markets are risky regardless of expiry quality. |
| Backoff QtyThreshold (SR1) | 300 | **300** | No change | |
| Backoff QtyThreshold (SR3) | 1000 | **1000** | No change | |
| WCT NumberOfPayups | 5 | **5** | No change | Full 6-tick budget is appropriate. Dec26 hedges are likely to fill within the budget. |
| WCT WCTTicks | 1 | **1** | No change | |
| Reload clip | 3:5 | **3:5** | No change | Can consider 6:10 on Dec26 after real data confirms accuracy holds at higher volumes. Not yet — wait for WP-06. |

**Dynamic avoidance**: Keep the 12:55–13:05 FOMC escalation at 0.11 for all groups including A. Event risk doesn't respect basis quality.

### Group B — Standard (Mar26, Jun26)

**Philosophy**: The middle of the curve. Current parameters are roughly appropriate but not optimized. Key risk: SR3|ZQ sell-side structural payup on Jun26. Address this specifically.

| Parameter | Current | Recommended | Change | Reasoning |
|-----------|---------|-------------|--------|-----------|
| Av_ZQ | 0.05 | **0.07** | +0.02 | Mar26/Jun26 calendars show more volatility than Dec26. Wider avoidance reduces adverse fill risk on the near/far calendar residual. The methodology doc's pattern 2 (Sep worst) and pattern 1 (Dec cleanest) imply Mar/Jun sit in between — moderate widening is appropriate. |
| Av_FF | 0.05 | **0.07** | +0.02 | SR1-ZQ basis for Apr/May/Jul/Aug sub-months has moderate volatility. Matches the ZQ spread treatment. |
| BS_ZQ | 0.0 | **0.0** | No change | No persistent calendar direction yet identified for these expiries. Will revisit in WP-06 with real data. |
| BS_FF | 0.0 | **−0.05** (light buy bias, Jun26 only) | −0.05 on Jun26 | Pattern 4 confirms SR3\|ZQ sell-side structural payup. A light buy bias on the SR1-ZQ basis makes buy prices slightly more aggressive on Legs 3 & 4, offsetting the structural cost of selling. Apply only to Jun26 where the effect is most pronounced. Mar26 stays neutral. |
| HitMan LiqCheckLegII | 400 | **400** | No change | |
| ASM LiqChkVolLegII | 150 | **150** | No change | |
| ASM LiqAtGapLegII | 1500 | **1500** | No change | |
| Backoff QtyThreshold (SR1) | 300 | **300** | No change | |
| Backoff QtyThreshold (SR3) | 1000 | **1000** | No change | |
| WCT NumberOfPayups | 5 | **5** | No change | |
| WCT WCTTicks | 1 | **1** | No change | |
| Reload clip | 3:5 | **3:5** | No change | |

**Jun26 SR3|ZQ sub-note**: The BS_FF = −0.05 recommendation for Jun26 is the most speculative change in this document. The reasoning chain is: pattern 4 shows ZQ sell-side structural payup → the sell side absorbs slippage into SR3 → making buy prices more aggressive partially compensates by getting better buy fills → net effect is a tighter realized spread. However, if the structural payup is caused by ZQ book thinness (not basis direction), a buy bias may not help and could increase adverse selection on the buy side. **Validate with real data before committing.**

### Group C — Defensive (Sep26)

**Philosophy**: Sep26 is bleeding. The priority is to stop the bleeding by reducing exposure and widening the defensive envelope. Accuracy improvement matters more than fill count here.

| Parameter | Current | Recommended | Change | Reasoning |
|-----------|---------|-------------|--------|-----------|
| Av_ZQ | 0.05 | **0.12** | +0.07 | Sep26 combined accuracy is structurally the worst (methodology: ~51%). The SR1 near-far calendar (Oct/Nov) has the widest basis volatility. A large avoidance increase pulls both buy and sell quotes into depth, reducing the rate of adverse fills. This will reduce fill count — that's intentional. |
| Av_FF | 0.05 | **0.12** | +0.07 | October SR1-ZQ basis is structurally wider. Same defensive logic. |
| BS_ZQ | 0.0 | **0.0** | No change | Don't layer directional bias onto a volatile underlying. The risk of being wrong on direction is higher here than the benefit of being right. |
| BS_FF | 0.0 | **0.0** | No change | Same reasoning. |
| HitMan LiqCheckLegII | 400 | **600** | +200 | Require substantially more hedge liquidity before crossing. Sep26 SR3 books are thinner and more prone to gapping. 600 lots on bid ensures genuine depth before committing to a cross. |
| HitMan VolRatioLegII | 0.10 | **0.07** | −0.03 | Tighter vol ratio means HitMan only fires when the offer at bid+1 is truly thin relative to bid. Reduces false momentum signals in a thinner book. |
| ASM LiqChkVolLegII | 150 | **200** | +50 | Higher liquidity floor for joining. Sep26 quoting leg has less reliable depth at 150 lots. |
| ASM LiqAtGapLegII | 1500 | **2000** | +500 | Gap markets on Sep26 are especially dangerous. 2000-lot threshold adds a meaningful safety margin. |
| Backoff QtyThreshold (SR1) | 300 | **200** | −100 | **Back off more often** by lowering the threshold. At 200 lots offered, the hedge should back off and try for a better price. Sep26's high payup rate suggests the system is crossing into offers too aggressively. |
| Backoff QtyThreshold (SR3) | 1000 | **700** | −300 | Same logic on the SR3 leg. Lower the bar for backing off. |
| Backoff QtyRatio | 0.30 | **0.25** | −0.05 | Slightly easier to trigger ratio-based backoff. In Sep26's thinner book, a 25% offer-to-bid ratio is sufficient evidence to wait. |
| WCT NumberOfPayups | 5 | **3** | −2 | Reduce total payup budget from 6 ticks (1 WCT + 5 payup) to 4 ticks (1 WCT + 3 payup). Sep26 hedges that require 5+ ticks of payup are almost certainly adverse — the market has moved. Capping earlier limits the damage. |
| WCT WCTTicks | 1 | **2** | +1 | Increase the patience buffer. Wait for the market to move 2 ticks beyond initial before engaging payup logic (vs. 1 tick currently). Total budget becomes 2 WCT + 3 payups = 5 ticks, but the extra WCT tick gives more time for mean-reversion before paying up. |
| WCT AntiStopVol | 4000 | **3000** | −1000 | Be more cautious about paying up into walls. A 3000-lot offer on Sep26 is likely structural. |
| Reload clip | 3:5 | **3:5** (but reduce active clips) | Reduce simultaneous clips from N to N−1 | Don't increase individual clip size. Instead, run fewer simultaneous clips on Sep26. This reduces total exposure while maintaining the 3:5 ratio structure. Specific clip count reduction depends on current N — target a ~25% reduction in active Sep26 exposure. |

**Dynamic avoidance for Sep26**: Consider extending the FOMC-window avoidance (currently 12:55–13:05 at 0.11) to also cover CPI, NFP, and PCE release windows (typically 08:28–08:35 ET). Sep26's thin books are most vulnerable to data-driven moves. The TimedParameterService already supports this — add the additional windows.

### Group D — Restricted (X/Y Aliases)

**Philosophy**: X/Y fills have a structural accuracy problem that parameter tuning alone cannot fix. The entry price calculation appears fundamentally wrong for these ASE types (methodology: "may indicate aggressive market-taking or stale entry prices"). Until the entry price logic is reviewed, restrict these heavily.

| Subgroup | Action | Rationale |
|----------|--------|-----------|
| **Sep26 X/Y** | **Pause entirely** | Accuracy is catastrophic (methodology: −120% or worse). Every fill is a guaranteed loss. No parameter setting fixes a broken entry price. |
| **Jun26 X/Y** | **Pause entirely** | Same. Test data shows −293% to −313% accuracy. The system is systematically buying high and selling low. |
| **Mar26 X/Y** | **Restrict to minimal clip** | Mar26 X shows 36.5% accuracy (survivable). Mar26 Y at −15.2% is marginal. Reduce to minimum clip size (one 3:5 unit) and monitor. If accuracy doesn't improve with real data, pause. |
| **Dec26 X/Y** | **Maintain at reduced clip** | Dec26 X at 52%, Dec26 Y at 60% — these are actually performing at Group B levels. Maintain but at reduced clip (one 3:5 unit) as a conservative starting point. Increase if real data confirms. |

For the X/Y aliases that remain active, apply Group C's defensive parameters (Av_ZQ=0.12, Av_FF=0.12, reduced WCT budget).

---

## 4. .NET Configuration Changes

Below is the mapping from recommendations to specific config parameters. I'm presenting these in the format `Parameter.Field = value` — adapt to your actual .NET config structure (likely per-alias or per-group config sections).

### Group A (Dec26 Standard)

```
// Avoidance
Dec26.avoidanceValue_ZQ = 0.03          // was 0.05
Dec26.avoidanceValue_FF = 0.03          // was 0.05
Dec26.bsValue_ZQ = 0.0                  // unchanged
Dec26.bsValue_FF = 0.0                  // unchanged

// HitMan
Dec26.HitMan.LiqCheckLegII = 350        // was 400

// ASM
Dec26.ASM.LiqChkVolLegII = 120          // was 150

// All other parameters: inherit from production baseline (no change)
```

### Group B — Mar26

```
// Avoidance
Mar26.avoidanceValue_ZQ = 0.07          // was 0.05
Mar26.avoidanceValue_FF = 0.07          // was 0.05
Mar26.bsValue_ZQ = 0.0                  // unchanged
Mar26.bsValue_FF = 0.0                  // unchanged

// All other parameters: inherit from production baseline (no change)
```

### Group B — Jun26

```
// Avoidance
Jun26.avoidanceValue_ZQ = 0.07          // was 0.05
Jun26.avoidanceValue_FF = 0.07          // was 0.05
Jun26.bsValue_ZQ = 0.0                  // unchanged
Jun26.bsValue_FF = -0.05               // was 0.0 — light buy bias on SR1-ZQ basis

// All other parameters: inherit from production baseline (no change)
```

### Group C (Sep26 Standard)

```
// Avoidance
Sep26.avoidanceValue_ZQ = 0.12          // was 0.05
Sep26.avoidanceValue_FF = 0.12          // was 0.05
Sep26.bsValue_ZQ = 0.0                  // unchanged
Sep26.bsValue_FF = 0.0                  // unchanged

// HitMan
Sep26.HitMan.LiqCheckLegII = 600        // was 400
Sep26.HitMan.VolRatioLegII = 0.07       // was 0.10

// ASM
Sep26.ASM.LiqChkVolLegII = 200          // was 150
Sep26.ASM.LiqAtGapLegII = 2000          // was 1500

// Backoff
Sep26.Backoff.QtyThreshold_SR1 = 200    // was 300
Sep26.Backoff.QtyThreshold_SR3 = 700    // was 1000
Sep26.Backoff.QtyRatio = 0.25           // was 0.30

// WCT Payup
Sep26.WCT.NumberOfPayups = 3            // was 5
Sep26.WCT.WCTTicks = 2                  // was 1
Sep26.WCT.AntiStopVol = 3000            // was 4000

// Dynamic avoidance: add CPI/NFP/PCE windows
Sep26.TimedParameter.additionalWindows = [
    { start: "08:28", end: "08:35", avoidanceValue: 0.15 }
]

// Reload: reduce active clip count by ~25%
Sep26.maxActiveClips = <current_N - 1>  // or floor(current_N * 0.75)
```

### Group D (X/Y Aliases)

```
// Sep26 X/Y — PAUSE
Sep26_X.enabled = false
Sep26_Y.enabled = false

// Jun26 X/Y — PAUSE
Jun26_X.enabled = false
Jun26_Y.enabled = false

// Mar26 X/Y — RESTRICT
Mar26_X.maxClips = 1                    // minimum single clip
Mar26_Y.maxClips = 1
// Apply Group C defensive avoidance
Mar26_X.avoidanceValue_ZQ = 0.12
Mar26_X.avoidanceValue_FF = 0.12
Mar26_Y.avoidanceValue_ZQ = 0.12
Mar26_Y.avoidanceValue_FF = 0.12

// Dec26 X/Y — MAINTAIN REDUCED
Dec26_X.maxClips = 1
Dec26_Y.maxClips = 1
// Apply Group B avoidance (not C — Dec X/Y accuracy is decent)
Dec26_X.avoidanceValue_ZQ = 0.07
Dec26_X.avoidanceValue_FF = 0.07
Dec26_Y.avoidanceValue_ZQ = 0.07
Dec26_Y.avoidanceValue_FF = 0.07
```

---

## 5. Markets to Avoid

| Contract | Action | Rationale |
|----------|--------|-----------|
| **SR3\|SR1 Sep26 X** | **Do not quote** | Accuracy: −380% (test data). Every fill is deep adverse selection. Entry price calculation appears broken for this ASE/expiry combination. |
| **SR3\|SR1 Sep26 Y** | **Do not quote** | Accuracy: −359%. Same structural problem as Sep26 X. |
| **SR3\|SR1 Jun26 X** | **Do not quote** | Accuracy: −314%. Extreme payup on Jun26 X/Y indicates stale entry prices or aggressive market-taking with no edge. |
| **SR3\|SR1 Jun26 Y** | **Do not quote** | Accuracy: −293%. Same. |
| **SR3\|ZQ Sep Oct26** (conditional) | **Review before continuing** | Accuracy: −87% (test data), structurally worst standard alias. If real data confirms accuracy below −50%, pause and investigate the October SR1-ZQ basis dynamics. May be unquotable without fundamentally different parameters. |
| **SR3\|ZQ Sep Nov26** (conditional) | **Review before continuing** | Similar to Sep Oct26 but with degradation trend (−54% → −133% over 10 days in test data). If degradation continues, pause. |

### "Flipping markets" avoidance (from proposed-additions)

Beyond specific contracts, avoid any alias that shows these symptoms on a given day:

- **Both-side accuracy below 30%**: The system is paying up on every fill in both directions. Pattern 7 confirms this concentrates losses. Pause the alias for the remainder of the session.
- **Avg sell price below avg buy price on matched fills**: Pattern 8. The system is buying strength and selling weakness. If this persists for 2+ consecutive sessions, pause until spread direction stabilizes.
- **Fill count > 500 lots with buy accuracy below 40%**: Pattern 3. Volume is degrading buy-side accuracy beyond acceptable levels. Reduce buy clip sizes or pause buy-side quoting for the alias.

---

## 6. What Changes When Real Data Arrives (WP-06)

The real WP-01 fill data will either confirm or break several assumptions underlying these recommendations. Here's what to watch for and how it affects each group:

**Assumption 1: Dec26 is cleanest.**
The methodology doc says 67–70%. The test data shows 39–60% (lower, but still the best group). If real data shows Dec26 below 50%, the Group A "tighten avoidance" recommendation reverses — move Dec26 to Group B parameters instead.

**Assumption 2: Sep26 is structurally worst.**
Confirmed in both methodology doc and test data. This is the highest-confidence assumption. Real data is unlikely to contradict it, but may reveal *why* — is it October basis volatility, thin SR1 Oct/Nov books, or something else? The "why" determines whether the fix is avoidance (volatility) or clip reduction (thinness) or both.

**Assumption 3: X/Y entry prices are wrong.**
The extreme negative accuracy on X/Y fills (-120% to -380%) strongly suggests a calculation error, not just bad luck. Real data should confirm whether X/Y fills are always bad or only bad in specific market conditions. If the latter, conditional X/Y quoting becomes possible.

**Assumption 4: SR3|ZQ sell-side structural payup is basis-driven.**
Pattern 4 attributes this to ZQ quoting leg thinness. Real data should include ZQ bid-ask spread at time of fill (if recorded). If ZQ bid-ask is typically 1 tick (tight), the payup is basis-driven and the BS_FF = −0.05 recommendation for Jun26 is wrong. If ZQ bid-ask is often 2+ ticks (gapped), the payup is spread-driven and the recommendation may help.

**Assumption 5: Buy-side degradation is volume-driven.**
Pattern 3. Real data should include daily lot counts per alias. If the degradation threshold is actually lower than 500 lots (e.g., 300 lots), the defensive volume trigger needs to be tighter.

**Specific data points to extract from WP-01 real runs:**

1. **Per-alias accuracy by expiry group** — validates group boundaries
2. **Accuracy vs. daily volume scatter** — calibrates the volume degradation threshold for pattern 3
3. **SR3|ZQ sell accuracy vs. ZQ bid-ask spread at fill time** — tests pattern 4 root cause
4. **X/Y accuracy vs. time-of-day** — tests whether X/Y fills are always bad or event-dependent
5. **Per-rule accuracy** (requires RuleType field in fill JSON) — shows whether HitMan or ASM fills are driving the payup
6. **Sep26 accuracy vs. Av_ZQ level** — directly tests whether the 0.12 avoidance recommendation is sufficient or needs to go higher

When these data points are available, run the WP-01 pipeline with the `--rule-type` field enabled and re-segment. The group boundaries and parameter values should be treated as first drafts — the real data is the authority.

---

## Related

### Within Jarvis
- [[market-profiling/event-calendar-2026-2027]] — Events affecting group behavior and parameter timing
- [[fill-analysis/_index|Fill Analysis]] — Accuracy data validating group boundaries
- [[timer-logic/verification-report]] — Formula corrections relevant to group-level accuracy
- [[strategy-research/directional-bias-model]] — Bias model operating across these contract groups

### Knowledge Base
- [[knowledge-base/execution-analysis/methodology-and-framework]] — Accuracy metrics used for validation
- [[knowledge-base/ase-rules/custom-rules-production]] — Production rules receiving group parameters
- [[knowledge-base/strategy/execution-modifiers]] — Avoidance/bias formulas segmentation tunes
- [[knowledge-base/core/instruments-and-platform]] — Contract specs defining instruments segmented
- [[knowledge-base/strategy/core-quad-leg-arbitrage]] — Quad-leg structure defining the aliases being segmented
- [[knowledge-base/ase-rules/ase-mechanics-and-parameters]] — ASE pipeline behavior underlying group accuracy patterns <!-- TODO: verify this is a direct dependency vs inherited context -->
