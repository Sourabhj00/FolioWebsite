---
title: Event Calendar — April 2026 through March 2027
wp: WP-12
status: complete
created: 2026-03-28
last-updated: 2026-03-31
lines: 426
kb-depends:
  - knowledge-base/core/instruments-and-platform.md
jarvis-depends:
  - jarvis/market-profiling/contract-segmentation.md
tags: [events, fomc, expiry, rolls, seasonality]
domain: market-profiling
---

# Event Calendar — April 2026 through March 2027

Systematic reference of time-sensitive trading events across the SR3/SR1/ZQ complex. Covers contract mechanics, FOMC meetings, quarter-end effects, roll dynamics, and seasonal patterns. Consult weekly to plan trades and parameter adjustments.

---

## Date Reference Tables

### FOMC Meeting Schedule

| Meeting Dates | Decision | Type | Avoidance Window |
|--------------|----------|------|-----------------|
| Apr 28–29, 2026 | Apr 29 2:00pm ET | Statement only | 12:55–13:05 CT Apr 29 |
| Jun 16–17, 2026 | Jun 17 2:00pm ET | **SEP + Dot Plot** | 12:55–13:05 CT Jun 17 |
| Jul 28–29, 2026 | Jul 29 2:00pm ET | Statement only | 12:55–13:05 CT Jul 29 |
| Sep 15–16, 2026 | Sep 16 2:00pm ET | **SEP + Dot Plot** | 12:55–13:05 CT Sep 16 |
| Oct 27–28, 2026 | Oct 28 2:00pm ET | Statement only | 12:55–13:05 CT Oct 28 |
| Dec 8–9, 2026 | Dec 9 2:00pm ET | **SEP + Dot Plot** | 12:55–13:05 CT Dec 9 |
| Jan 26–27, 2027 | Jan 27 2:00pm ET | Statement only | 12:55–13:05 CT Jan 27 |
| Mar 16–17, 2027 | Mar 17 2:00pm ET | **SEP + Dot Plot** | 12:55–13:05 CT Mar 17 |

SEP meetings carry higher vol because the dot plot reprices the entire forward curve.

### SR3 Quarterly Expiry Dates

Last trading day = business day before the 3rd Wednesday of the contract delivery month. Final settlement computed on the morning of the 3rd Wednesday.

| Contract | 3rd Wednesday | Last Trading Day | Reference Quarter |
|----------|--------------|------------------|-------------------|
| SR3 M6 (Jun26) | Wed Jun 17 | **Tue Jun 16** | Mar 18 → Jun 17 |
| SR3 U6 (Sep26) | Wed Sep 16 | **Tue Sep 15** | Jun 17 → Sep 16 |
| SR3 Z6 (Dec26) | Wed Dec 16 | **Tue Dec 15** | Sep 16 → Dec 16 |
| SR3 H7 (Mar27) | Wed Mar 17 | **Tue Mar 16** | Dec 16 → Mar 17 |

**Critical overlap**: SR3 M6 LTD (Jun 16) is day 1 of the Jun FOMC meeting. SR3 U6 LTD (Sep 15) is day 1 of the Sep FOMC meeting. In both cases the SR3 contract expires the day before the rate decision is announced, meaning the final settlement price is set without knowledge of the decision.

### SR1 Monthly Expiry Dates

Last trading day = last business day of the contract delivery month.

| Contract | Last Trading Day | Notes |
|----------|------------------|-------|
| SR1 J6 (Apr26) | Thu Apr 30 | |
| SR1 K6 (May26) | Fri May 29 | Memorial Day May 25 |
| SR1 N6 (Jul26) | Fri Jul 31 | Independence Day observed Jul 3 |
| SR1 Q6 (Aug26) | Mon Aug 31 | |
| SR1 V6 (Oct26) | Fri Oct 30 | |
| SR1 X6 (Nov26) | Mon Nov 30 | Thanksgiving Nov 26 |
| SR1 F7 (Jan27) | Fri Jan 29 | |
| SR1 G7 (Feb27) | Fri Feb 26 | |

SR1 Jun26 (M6) expires Tue Jun 30. SR1 Sep26 (U6) expires Wed Sep 30. SR1 Dec26 (Z6) expires Thu Dec 31. SR1 Mar27 (H7) expires Wed Mar 31.

### ZQ Monthly Expiry Dates

Same rule as SR1: last business day of the contract delivery month. All dates identical to SR1 above.

### Quad-Leg Expiry Group Transitions

| SR3 Expiry | Groups Before | Groups After | New Back Group |
|-----------|---------------|--------------|----------------|
| SR3 M6 Jun 16 | Jun26, Sep26, Dec26, Mar27 | Sep26, Dec26, Mar27, **Jun27** | Jun27 |
| SR3 U6 Sep 15 | Sep26, Dec26, Mar27, Jun27 | Dec26, Mar27, Jun27, **Sep27** | Sep27 |
| SR3 Z6 Dec 15 | Dec26, Mar27, Jun27, Sep27 | Mar27, Jun27, Sep27, **Dec27** | Dec27 |
| SR3 H7 Mar 16 | Mar27, Jun27, Sep27, Dec27 | Jun27, Sep27, Dec27, **Mar28** | Mar28 |

---

## Master Calendar — Chronological

### April 2026

**Apr 1 (Wed) — New Quarter Opens**
- Mechanics: Q2 begins. Repo rate normalization after Q1-end spike. SOFR should drop back from quarter-end elevated levels within 1–2 business days.
- Expected behavior: SR1-ZQ basis (Alias 1, Alias 2) narrows as SOFR retreats toward EFFR. The O spread price normalizes.
- Quad-leg impact: Resume normal lot sizing after quarter-end reduction. Monitoring instruments return to tighter spreads.
- Reliability: Mechanical — quarter-end SOFR spikes reverse predictably within 1–3 days.

**Apr 15 (Wed) — IRS Individual Tax Deadline**
- Mechanics: Large cash outflows from the financial system as tax payments settle to the Treasury General Account (TGA). Reduces reserves, temporarily tightens repo markets.
- Expected behavior: SOFR may print 2–5 bps above normal for 1–2 days. SR1 contracts covering April may see slight price depression. ZQ (EFFR-based) less affected since Fed Funds is insulated from repo dynamics.
- Entry timing: No specific trade setup — monitor SR1-ZQ basis for widening. If widening exceeds 2 bps, consider it transient.
- Quad-leg impact: Minor. May cause temporary microprice unreliability on Alias 1/2. No parameter change needed unless widening persists.
- Reliability: Statistical tendency, not mechanical certainty. Magnitude depends on TGA balances and overall reserve levels.

**Apr 28–29 (Tue–Wed) — FOMC Meeting (Statement Only)**
- Mechanics: Rate decision announced Apr 29 at 2:00pm ET (1:00pm CT). No SEP/dot plot at this meeting. Press conference follows at 2:30pm ET.
- Expected behavior: Pre-meeting positioning builds from ~Apr 24. ZQ front month (Apr/May) prices embed probability shifts. SR1-ZQ basis may widen as ZQ reacts faster to rate expectations. Vol elevates ~30 min before announcement, peaks at announcement, decays over 2–4 hours.
- Entry timing: Reduce new entries starting Apr 27. The 12:55–13:05 CT dynamic avoidance window activates automatically on Apr 29.
- Quad-leg impact: Set avoidanceValue = 0.11 for the Apr 29 window. Consider reducing lot size across all groups starting Apr 28. Statement-only meetings produce less sustained vol than SEP meetings — normal operations can resume by Apr 30 morning.
- Reliability: Mechanical (meeting is scheduled). Price behavior is statistical but highly consistent.

**Apr 30 (Thu) — SR1 Apr26 / ZQ Apr26 Expiry + Month-End**
- Mechanics: Last trading day for SR1 J6 and ZQ J6. Final settlement = arithmetic average of daily SOFR/EFFR during April. Month-end balance sheet effects add to repo tightness.
- Expected behavior: SR1 Apr tick size narrows to 0.25 bps in delivery month. Liquidity thins as the month progresses. Month-end SOFR typically prints 2–8 bps above mid-month levels.
- Quad-leg impact: SR1 Apr is the near-month for the (now-expired) Mar26 group and the ZQ component of the Jun26 group. If running the Jun26 group with ZQ Apr (Leg 3), the ZQ Apr contract's final convergence to settlement value reduces trading opportunity in the last few days.
- Reliability: Mechanical (expiry) + statistical (month-end SOFR bump).

### May 2026

**May 29 (Fri) — SR1 May26 / ZQ May26 Expiry + Month-End (early close weekend)**
- Mechanics: Last trading day for SR1 K6 and ZQ K6. Memorial Day was May 25, so this is a 4-day trading week. Month-end effects compressed.
- Expected behavior: Thinner liquidity due to holiday week. Month-end SOFR bump compressed into fewer days. SR1 May settlement converging.
- Quad-leg impact: SR1 May is the far-month for the Jun26 O spread. Its expiry marks the completion of the Jun26 group's SR1 components (SR1 Jul and Aug are the actual O spread months, but ZQ May is a monitoring instrument). Ensure ZQ May calendar (Alias 3 for relevant groups) handles the convergence gracefully.
- Reliability: Mechanical.

### June 2026

**Jun 1–15 — SR3 Jun26 Roll Window**
- Mechanics: As SR3 M6 approaches its Jun 16 last trading day, roll traders enter the market to move positions from Jun to Sep. This creates predictable buying pressure on the SR3|SR1 front spread for the Jun26 group.
- Expected behavior: SR3|SR1 Jun spread pushed upward by roll activity. Per the pending seasonality trade documentation: live price deviates above fair value as roll traders arrive. Historically the move is 1–2 ticks above fair value, peaking in the final 3–5 trading days.
- Entry timing: Enter the SR3|SR1 3Leg front spread 7–10 trading days before expiry (~Jun 3). The signal confirming setup is increasing volume in the SR3 Jun26 contract with price moving toward the expected direction. The trade is time-driven, not price-driven.
- Quad-leg impact: The Jun26 expiry group's core O spread benefits from this roll pressure if positioned correctly. However, the O spread's SR3 leg is being affected — ensure the quad-leg system isn't fighting the roll flow. Consider widening the O sell price for Jun26 to capture the elevated spread, or reduce Jun26 lot size to avoid adverse fills during volatile roll activity.
- Reliability: High — roll mechanics are structural. Magnitude varies by cycle.

**Jun 15 (Mon) — Q2 Estimated Tax Payment Date**
- Mechanics: Corporate and individual estimated tax payments due. Cash drain from financial system similar to Apr 15 but typically smaller.
- Expected behavior: SOFR may print slightly elevated. Minor SR1-ZQ basis widening possible.
- Quad-leg impact: Minimal standalone. But combined with the SR3 expiry and FOMC meeting this week, creates a congested event cluster.
- Reliability: Statistical tendency.

**⚠️ Jun 16 (Tue) — SR3 M6 Last Trading Day + FOMC Day 1**
- Mechanics: CRITICAL CONFLUENCE. SR3 Jun26 expires at Globex close on Jun 16. The FOMC meeting begins the same day (Jun 16–17), with the rate decision on Jun 17. SR3 M6 settles without the FOMC outcome incorporated. This is a SEP meeting with dot plot.
- Expected behavior: Extreme positioning ahead of this date. SR3 Jun26 will have nearly converged to realized compounded SOFR, with minimal forward-looking component remaining. The Jun26 O spread group effectively ends. Vol in Sep26 group (the new front) elevates as it absorbs the rate decision impact.
- Entry timing: For the roll/seasonality trade, exit by Jun 12–15 (don't hold into the final day's chaos). For the quad-leg system, the Jun26 group should be wound down or significantly reduced by Jun 12.
- Quad-leg impact: **Pause Jun26 group by Jun 12.** The SR3 leg's final convergence plus FOMC volatility makes Jun 16 execution unpredictable. Widen avoidance on all groups for Jun 16–17 (the FOMC avoidance window covers Jun 17). Consider reducing Sep26 group lot size on Jun 16 as well, since the FOMC outcome on Jun 17 will reprice the forward curve with dot plot data.
- Reliability: Mechanical (expiry + FOMC date are fixed). The confluence amplifies both effects.

**Jun 17 (Wed) — FOMC Decision (SEP + Dot Plot) + SR3 M6 Final Settlement**
- Mechanics: Rate decision at 2:00pm ET. SEP and dot plot released simultaneously. Press conference at 2:30pm ET. SR3 M6 final settlement price computed this morning based on realized SOFR.
- Expected behavior: Dot plot reprices the entire SOFR forward curve. Sep26, Dec26, and Mar27 O spreads will all shift. Vol spike at 2:00pm ET, with sustained repricing over 2–4 hours. Post-decision, new consensus forms and spreads stabilize by next morning.
- Quad-leg impact: avoidanceValue = 0.11 for 12:55–13:05 CT. All groups should run at reduced lot size. Resume normal operations Jun 18 morning after assessing new rate expectations. Recalibrate O spread buy/sell prices for Sep26 and Dec26 groups to reflect new forward curve.
- Reliability: Mechanical.

**Jun 30 (Tue) — Q2-End + SR1 Jun26 / ZQ Jun26 Expiry**
- Mechanics: Quarter-end. Bank balance sheet window dressing peaks. Dealers reduce repo intermediation. SOFR spikes — historically 5–25 bps above mid-month levels at recent quarter-ends (Sep 2025: +25 bps, Dec 2025: record SRF usage at $74.6B). SR1 Jun and ZQ Jun expire same day.
- Expected behavior: SOFR-EFFR spread (the SR1-ZQ basis) widens materially. Alias 1 and Alias 2 will show elevated readings. The diff calculation may become unreliable if the basis spike is large enough. ZQ is relatively stable (EFFR stays within Fed target range); SR1 moves with SOFR.
- Entry timing: No entry — this is a risk management event. Begin reducing positions Jun 26. The SOFR spike is transient (1–3 days) and reverses early July.
- Quad-leg impact: **Reduce lot size across all groups starting Jun 26.** If microprice spread on monitoring instruments exceeds 1 tick, the guard pauses the contract automatically — but better to proactively reduce before that happens. The O spread's fair value calculation becomes unreliable when the SR1-ZQ basis is distorted. Resume normal operations Jul 2–3.
- Reliability: Mechanical (quarter-end is calendar-driven). Magnitude varies but the direction (SOFR spike, basis widening) is highly consistent.

### July 2026

**Jul 1–2 — Quarter-End Normalization**
- Mechanics: SOFR retreats from quarter-end spike. Repo markets normalize as balance sheet constraints lift. SR1-ZQ basis narrows.
- Expected behavior: Rapid normalization, typically within 1–2 days. Good entry window for positions that benefit from basis mean-reversion.
- Quad-leg impact: Resume normal lot sizing. The diff calculation returns to reliable territory as monitoring instruments tighten.
- Reliability: High — consistent pattern.

**Jul 3 (Fri) — Independence Day Observed (CME Closed or Early Close)**
- Mechanics: Jul 4 falls on Saturday; Friday Jul 3 is the observed holiday. CME Globex may close early or have a full closure. Thin liquidity Thursday Jul 2 afternoon into the holiday.
- Quad-leg impact: Check CME holiday schedule closer to the date. Reduce or pause around the holiday.
- Reliability: Mechanical.

**Jul–Aug — Summer Liquidity Trough**
- Mechanics: Reduced institutional participation. Thinner order books. Wider bid-ask spreads on SR1, ZQ, and the monitoring instruments. Desk staffing drops across the Street.
- Expected behavior: Lower fills, wider spreads, more erratic microprice signals. The O spread may exhibit wider-than-normal ranges but lower conviction on mean-reversion timing. Fewer counterparties means the ASE hedge leg may get worse fills.
- Entry timing: Not a single event — a persistent condition from roughly Jul 6 through Labor Day (Sep 7).
- Quad-leg impact: Consider reducing lot sizes by 20–30% during this window. Widen avoidance values slightly to avoid trading into thin markets. Monitor fill quality — if TD (tick deviation) worsens beyond acceptable thresholds, further reduce exposure.
- Reliability: Low-to-medium. Summer liquidity is a well-known pattern but the severity varies year-to-year. Some summers are nearly normal; others are noticeably thin. Validate with real-time fill data as July begins.

**Jul 28–29 (Tue–Wed) — FOMC Meeting (Statement Only)**
- Mechanics: Mid-summer meeting. Statement-only, no SEP/dot plot. Decision Jul 29 at 2:00pm ET.
- Expected behavior: Lower impact than SEP meetings. The market may already be in summer-thin mode, amplifying the vol spike relative to normal liquidity.
- Quad-leg impact: Standard FOMC protocol — avoidanceValue = 0.11 for Jul 29 window. The interaction with summer liquidity means the post-decision vol may take longer to decay than at other meetings.
- Reliability: Mechanical.

**Jul 31 (Fri) — SR1 Jul26 / ZQ Jul26 Expiry + Month-End**
- Mechanics: Last trading day for SR1 N6 and ZQ N6. Month-end on a Friday — weekend creates a compressed settlement window.
- Expected behavior: Month-end SOFR elevation. SR1 Jul convergence to monthly average.
- Quad-leg impact: SR1 Jul is the near-month for the Sep26 O spread. Its expiry completes; the Sep26 group then trades with SR1 Oct (near) and SR1 Nov (far) already in place. Monitor the group's transition — after SR1 Jul expires, the O spread for Sep26 consists of the remaining SR1 Oct/Nov legs.
- Reliability: Mechanical.

### August 2026

**Aug 31 (Mon) — SR1 Aug26 / ZQ Aug26 Expiry + Month-End**
- Mechanics: Last trading day for SR1 Q6 and ZQ Q6. Month-end.
- Expected behavior: Standard month-end SOFR bump. SR1 Aug is the far-month for the Sep26 O spread.
- Quad-leg impact: After this expiry, all SR1/ZQ components specific to the Sep26 group's O spread are finalized. The Sep26 SR3 contract itself still has ~2 weeks to expiry (Sep 15).
- Reliability: Mechanical.

### September 2026

**Sep 1–14 — SR3 Sep26 Roll Window**
- Mechanics: Roll traders migrate positions from SR3 Sep26 to SR3 Dec26. Same dynamics as the Jun roll: predictable buying pressure on SR3|SR1 front spread.
- Expected behavior: SR3|SR1 Sep spread pushed upward, 1–2 ticks above fair value, peaking in the final 3–5 trading days before Sep 15.
- Entry timing: Enter the seasonality trade ~Sep 1. Exit by Sep 11–12, well ahead of the expiry/FOMC/tax triple event on Sep 15.
- Quad-leg impact: Same as June roll — consider widening the O sell price for Sep26 to benefit from elevated spread, or reduce lot size.
- Reliability: High — structural roll mechanics.

**⚠️ Sep 15 (Tue) — SR3 U6 Last Trading Day + FOMC Day 1 + Q3 Estimated Tax Payments**
- Mechanics: TRIPLE CONFLUENCE — the most congested single day in this calendar.
  1. SR3 Sep26 expires at Globex close.
  2. FOMC meeting begins (Sep 15–16), SEP + dot plot meeting, decision Sep 16.
  3. Q3 estimated tax payments due — cash drain from the financial system.
- Expected behavior: Repo market tightness from tax payments compounds with pre-FOMC positioning. SR3 U6 is converging to settlement while the market anticipates the rate decision. The Sep26 O spread group is effectively ending. Vol in Dec26 group (the new front) elevates.
- Entry timing: Exit all seasonality/roll trades by Sep 11. Do not initiate new positions in any group on Sep 15.
- Quad-leg impact: **Pause Sep26 group by Sep 11.** Reduce Dec26 and Mar27 group lot sizes significantly on Sep 15. The combination of tax-driven SOFR pressure, SR3 expiry convergence, and FOMC anticipation makes this day extremely difficult for automated spread execution. The microprice guard (spread > 1 tick → pause) may trigger repeatedly.
- Reliability: Mechanical — all three events are calendar-fixed. The interaction is what creates outsized risk.

**Sep 16 (Wed) — FOMC Decision (SEP + Dot Plot) + SR3 U6 Final Settlement**
- Mechanics: Decision at 2:00pm ET. Dot plot reprices forward curve. SR3 U6 final settlement computed this morning.
- Quad-leg impact: Same protocol as Jun 17 — avoidanceValue = 0.11, reduced lots, recalibrate O prices after decision. Resume normal operations Sep 17.
- Reliability: Mechanical.

**Sep 30 (Wed) — Q3-End + SR1 Sep26 / ZQ Sep26 Expiry**
- Mechanics: Quarter-end. Same dynamics as Jun 30 — dealer balance sheet reduction, SOFR spike, SR1-ZQ basis widening. SR1 Sep and ZQ Sep expire.
- Expected behavior: SOFR spikes 5–25+ bps. Basis widens. Year-end preview — some institutions begin early Q4 positioning.
- Quad-leg impact: **Reduce all groups starting Sep 25.** Resume Jul 1. Same protocol as June quarter-end.
- Reliability: Mechanical.

### October 2026

**Oct 1–2 — Quarter-End Normalization**
- Same pattern as Jul 1–2. Resume normal operations.

**Oct 27–28 (Tue–Wed) — FOMC Meeting (Statement Only)**
- Mechanics: Decision Oct 28 at 2:00pm ET. No SEP/dot plot.
- Quad-leg impact: Standard FOMC protocol. avoidanceValue = 0.11 for Oct 28 window.
- Reliability: Mechanical.

**Oct 30 (Fri) — SR1 Oct26 / ZQ Oct26 Expiry + Month-End**
- Mechanics: Last trading day for SR1 V6 and ZQ V6 (Oct 31 is Saturday). Month-end.
- Quad-leg impact: SR1 Oct is the near-month for the Dec26 O spread. Standard month-end handling.
- Reliability: Mechanical.

### November 2026

**Nov 26 (Thu) — Thanksgiving (CME Closed)**
- Mechanics: CME closed Thursday. Early close Wednesday Nov 25. Reduced liquidity Mon–Wed. Friday Nov 27 is a partial session.
- Quad-leg impact: Reduce lot sizes Nov 24–27. Thinner books mean wider spreads and worse hedge fills.
- Reliability: Mechanical.

**Nov 30 (Mon) — SR1 Nov26 / ZQ Nov26 Expiry + Month-End**
- Mechanics: Last trading day for SR1 X6 and ZQ X6. Month-end.
- Quad-leg impact: SR1 Nov is the far-month for the Dec26 O spread. After this expiry, the Dec26 group's SR1/ZQ components are finalized; only the SR3 Dec leg remains active.
- Reliability: Mechanical.

### December 2026

**Dec 1–14 — SR3 Dec26 Roll Window**
- Mechanics: Roll from SR3 Z6 to SR3 H7. Same roll dynamics as prior quarters.
- Expected behavior: Roll pressure pushes SR3|SR1 Dec front spread up, but this is also the year-end wind-down period — liquidity may already be thinning.
- Entry timing: Enter seasonality trade ~Dec 1. Exit by Dec 10, before the FOMC and expiry cluster. The December roll overlaps with year-end positioning, which may amplify or dampen the roll effect unpredictably.
- Quad-leg impact: Dec26 group winding down. Similar to Jun/Sep roll handling.
- Reliability: High for the roll mechanics, but year-end effects add uncertainty to magnitude.

**Dec 8–9 (Tue–Wed) — FOMC Meeting (SEP + Dot Plot)**
- Mechanics: Decision Dec 9 at 2:00pm ET. SEP + dot plot. This is typically the final major policy signal of the year.
- Expected behavior: Dot plot reprices 2027 expectations. Higher impact on Mar27 and Jun27 groups than on Dec26 (which is about to expire). Year-end thin liquidity amplifies the vol spike.
- Quad-leg impact: avoidanceValue = 0.11 for Dec 9 window. Reduce all groups. Recalibrate Mar27 O prices after decision. The Dec26 group has only 6 trading days left after this FOMC — consider pausing it entirely post-decision.
- Reliability: Mechanical.

**Dec 15 (Tue) — SR3 Z6 Last Trading Day**
- Mechanics: SR3 Dec26 expires at Globex close. Unlike Jun and Sep, this LTD does NOT coincide with an FOMC meeting day. The FOMC already occurred Dec 9 — 4 trading days of buffer. Final settlement computed Dec 16 (Wed).
- Expected behavior: Cleaner expiry than Jun or Sep. The Dec FOMC outcome is already priced in. Roll traders have largely completed by now. Year-end positioning is the main residual factor.
- Quad-leg impact: Pause Dec26 group by Dec 11–12. The Dec26→Mar27 group transition means Mar27 becomes the new front group.
- Reliability: Mechanical.

**Dec 21–31 — Year-End Liquidity Collapse**
- Mechanics: Many desks run skeleton crews from ~Dec 21 through Jan 2. Order books thin dramatically. The Christmas-New Year's stretch typically sees the lowest liquidity of the year.
- Expected behavior: Wide bid-ask spreads. Erratic price movements on low volume. The O spread may gap or exhibit abnormal ranges. Quarter-end (Dec 31) compounds this with the annual SOFR spike — historically the largest of the year (Dec 2025 saw record $74.6B Fed SRF usage).
- Quad-leg impact: **Significantly reduce or pause all groups from Dec 21 through Jan 2.** The combination of year-end balance sheet effects, holiday liquidity, and quarter-end SOFR spike creates the worst execution environment of the year. Do not attempt to trade through this. Resume Jan 5 after assessing normalization.
- Reliability: High — year-end liquidity reduction is one of the most reliable seasonal patterns.

**Dec 25 (Fri) — Christmas (CME Closed)**
- Dec 24 early close. Dec 28–31 reduced participation.

**Dec 31 (Thu) — Q4/Year-End + SR1 Dec26 / ZQ Dec26 Expiry**
- Mechanics: Year-end quarter-end. The most extreme SOFR spike window of the year. SRF usage typically peaks. SR1 Dec and ZQ Dec expire.
- Expected behavior: SOFR may spike 10–30+ bps above normal. SR1-ZQ basis widens dramatically. This is not a trading opportunity — it's a risk event.
- Quad-leg impact: All groups should already be paused. Monitoring instruments will show extreme microprice distortion.
- Reliability: Mechanical.

### January 2027

**Jan 4–5 (Mon–Tue) — Year-End Normalization**
- Mechanics: First full trading week. SOFR normalizes from year-end spike within 1–3 days. Dealers rebuild balance sheets. Liquidity returns gradually.
- Expected behavior: Rapid basis normalization. Good window to re-enter positions that benefit from basis mean-reversion.
- Quad-leg impact: Restart all groups at reduced lot size Jan 5. Scale back to normal by Jan 8 once monitoring instruments confirm normal spreads.
- Reliability: High.

**Jan 15 (Fri) — Q4 Estimated Tax Payment Due**
- Mechanics: Final estimated tax payment for 2026. Cash drain to TGA.
- Expected behavior: Minor SOFR elevation, 1–3 bps. Less impactful than Apr/Sep tax dates.
- Quad-leg impact: Minimal. Monitor SR1-ZQ basis.
- Reliability: Statistical tendency.

**Jan 26–27 (Tue–Wed) — FOMC Meeting (Statement Only)**
- Mechanics: First FOMC of 2027. Decision Jan 27 at 2:00pm ET. No SEP/dot plot. Committee membership rotates — watch for new voter composition.
- Expected behavior: January meetings sometimes produce policy language changes that signal the year's direction. Market impact moderate.
- Quad-leg impact: Standard FOMC protocol. avoidanceValue = 0.11 for Jan 27 window.
- Reliability: Mechanical.

**Jan 29 (Fri) — SR1 Jan27 / ZQ Jan27 Expiry + Month-End**
- Mechanics: Last trading day for SR1 F7 and ZQ F7 (Jan 31 is Sunday). Month-end.
- Quad-leg impact: SR1 Jan27 is the near-month for the Mar27 O spread (SR3 Mar / SR1 Jan / SR1 Feb). Its expiry signals the Mar27 group entering its final phase.
- Reliability: Mechanical.

### February 2027

**Feb 26 (Fri) — SR1 Feb27 / ZQ Feb27 Expiry + Month-End**
- Mechanics: Last trading day for SR1 G7 and ZQ G7 (Feb 28 is Sunday). Month-end.
- Quad-leg impact: SR1 Feb27 is the far-month for the Mar27 O spread. After this expiry, the Mar27 group's SR1 components are done. Only SR3 Mar27 remains active, with ~2.5 weeks to expiry.
- Reliability: Mechanical.

### March 2027

**Mar 1–15 — SR3 Mar27 Roll Window**
- Mechanics: Roll from SR3 H7 to SR3 M7 (Jun27). Same roll dynamics.
- Entry timing: Enter seasonality trade ~Mar 1. Exit by Mar 12.
- Quad-leg impact: Mar27 group winding down.
- Reliability: High — structural roll mechanics.

**⚠️ Mar 16 (Tue) — SR3 H7 Last Trading Day + FOMC Day 1**
- Mechanics: Same FOMC/expiry confluence as Jun and Sep 2026. SR3 Mar27 expires. FOMC meeting begins (Mar 16–17), SEP + dot plot, decision Mar 17.
- Quad-leg impact: **Pause Mar27 group by Mar 12.** Same protocol as Jun 16 and Sep 15.
- Reliability: Mechanical.

**Mar 17 (Wed) — FOMC Decision (SEP + Dot Plot) + SR3 H7 Final Settlement**
- Mechanics: Decision at 2:00pm ET. Dot plot reprices 2027–2028 expectations. SR3 H7 final settlement computed this morning.
- Quad-leg impact: Recalibrate Jun27 and Sep27 O prices after decision. Resume normal operations Mar 18.
- Reliability: Mechanical.

**Mar 31 (Wed) — Q1-End + SR1 Mar27 / ZQ Mar27 Expiry**
- Mechanics: Quarter-end. Same dynamics as other quarter-ends — SOFR spike, basis widening. SR1 Mar27 and ZQ Mar27 expire.
- Quad-leg impact: **Reduce all groups starting Mar 25.** Calendar year wraps.
- Reliability: Mechanical.

---

## Month-End Patterns (Recurring)

Every month-end shows a smaller version of the quarter-end effect. SOFR typically prints 2–8 bps above mid-month levels on the last business day. The SR1-ZQ basis widens modestly. This is driven by dealer balance sheet adjustments at month-end (not as extreme as quarter-end).

For the quad-leg system, this means slightly wider microprice spreads on Alias 1/2 on the last 1–2 business days of each month. No parameter change is normally needed, but if fill quality degrades on month-end days, consider a minor lot size reduction (10–15%) on the last 2 trading days.

---

## Day-of-Week SOFR/EFFR Patterns

**Lower confidence — validate with your own fill data before acting on these.**

SOFR tends to print slightly higher on Mondays (reflecting Friday-to-Monday repo rollover with 3-day accrual). First-of-month Mondays can show larger deviations if they coincide with Treasury settlement dates. Friday SOFR sometimes shows slightly lower readings as short-term funding is less demanded going into the weekend.

These patterns are small (sub-1 bp typically) and may not materially affect the O spread. Track them in fill analysis to confirm whether they create systematic TD deviation.

---

## Entry Rules Summary

| Event | Entry Window | Trade | Exit By |
|-------|-------------|-------|---------|
| SR3 roll (quarterly) | 10–7 days before SR3 LTD | Buy SR3\|SR1 3Leg front spread | 3–5 days before LTD |
| FOMC Statement-only | No specific entry | Reduce exposure; resume next morning | Day after decision |
| FOMC SEP + Dot Plot | No specific entry | Reduce exposure; recalibrate O prices after | Day after decision |
| Quarter-end SOFR spike | No entry — risk event | Reduce/pause all groups 3–4 days before | Resume 2–3 days into new quarter |
| Year-end (Dec 21–Jan 4) | No entry — risk event | Pause all groups | Resume Jan 5 |
| SR3 expiry + FOMC overlap (Jun 16, Sep 15, Mar 16) | Exit all seasonal trades 3–5 days before | Pause expiring group 3 days before | Resume after FOMC decision next day |
| Month-end SOFR bump | No specific entry | Optional: reduce 10–15% last 2 days | Resume 1st business day |
| Tax dates (Apr 15, Jun 15, Sep 15, Jan 15) | Monitor SR1-ZQ basis | No trade unless basis widens > 2 bps | Normalizes within 1–2 days |

---

## Parameter Adjustment Schedule

This table prescribes when to deviate from baseline parameters. "Baseline" means normal operating parameters for lot size, avoidance, and group activity.

| Date(s) | Avoidance | Lot Size | Group Pause? | Notes |
|---------|-----------|----------|-------------|-------|
| **FOMC decision days** (Apr 29, Jun 17, Jul 29, Sep 16, Oct 28, Dec 9, Jan 27, Mar 17) | 0.11 during 12:55–13:05 CT | Reduce 30–50% day-of, 20% day-before | No full pause for statement-only; consider pause for SEP meetings | SEP meetings warrant larger reduction |
| **SR3 LTD** (Jun 16, Sep 15, Dec 15, Mar 16) | Widen by +0.05 for expiring group | Pause expiring group 3 days before | Yes — expiring group | Other groups can run normally unless FOMC overlap |
| **SR3 LTD + FOMC overlap** (Jun 16, Sep 15, Mar 16) | 0.11 + additional +0.05 for expiring group | Pause expiring group 5 days before; reduce all other groups 50% | Yes — expiring group; all groups reduced | Most dangerous days of the calendar |
| **Quarter-end** (Jun 30, Sep 30, Dec 31, Mar 31) | Widen by +0.05 across all groups | Reduce 50–70% starting 4 days before | Consider full pause on last 2 days | Microprice guards may auto-pause anyway |
| **Year-end** (Dec 21 – Jan 4) | N/A — groups should be paused | Pause all groups | Yes — all groups | Worst execution environment of the year |
| **Summer** (Jul 6 – Sep 7 approx.) | Widen by +0.02 baseline | Reduce 20–30% | No | Validate with real-time fill quality data |
| **Holiday weeks** (Memorial Day, July 4, Thanksgiving) | Widen by +0.02 | Reduce 20% for the week | No | Thinner books around holidays |
| **Tax dates** (Apr 15, Jun 15, Sep 15, Jan 15) | No change | No change unless basis widens | No | Monitor only |
| **Month-end** (last 2 business days each month) | No change | Optional: reduce 10–15% | No | Minor effect |

---

## Risk Clusters — Confluences to Flag

Some calendar events cluster in ways that multiply risk. These are the highest-priority dates in the entire calendar.

**Jun 15–17, 2026**: Tax payment (Jun 15) + SR3 expiry (Jun 16) + FOMC SEP (Jun 17). Three events in three consecutive days. This is a full-pause window for the Jun26 group and a significant reduction window for all other groups.

**Sep 15, 2026**: Tax payment + SR3 expiry + FOMC day 1 — all on the same day. The single most congested date in this calendar. Treat as a no-trade day for all groups.

**Dec 8–31, 2026**: FOMC SEP (Dec 9) + SR3 expiry (Dec 15) + year-end liquidity collapse (Dec 21+) + quarter-end (Dec 31). A 3-week gauntlet. The Dec26 group should be wound down by Dec 10. All groups should be paused by Dec 21.

**Mar 16–17, 2027**: SR3 expiry (Mar 16) + FOMC SEP (Mar 17). Direct overlap, same as Jun and Sep.

---

## What This Calendar Does NOT Cover

This calendar focuses on known, mechanical, and schedule-driven events. It does not cover:

- **Unscheduled data releases** (CPI, NFP, GDP) — these are significant vol events but their dates shift annually and interact with the calendar in different ways. Consider maintaining a separate data release calendar updated monthly from the BLS/BEA schedules.
- **Geopolitical events** — unpredictable by definition.
- **Treasury auction calendar** — large coupon auctions can temporarily affect repo rates and SOFR. The Treasury publishes its quarterly refunding schedule; cross-reference with this calendar if desired.
- **Fed balance sheet operations** — QT pace changes, SRF standing offer adjustments, and ON RRP rate changes all affect SOFR dynamics but are policy-dependent, not calendar-driven.
- **Euribor/SONIA/Canada** — out of scope per constraints.

---

## Maintenance Notes

This calendar should be refreshed quarterly by:
1. Verifying FOMC dates (they are "tentative" until confirmed at the prior meeting)
2. Confirming CME holiday schedule for the upcoming quarter
3. Checking if the SR3 IMM dates (3rd Wednesdays) fall as computed — leap years and holiday shifts can occasionally move the last trading day
4. Updating the quad-leg expiry group transition table as groups roll forward
5. Adding any new tax deadlines or regulatory reporting dates that might affect repo/SOFR

## Related

### Within Jarvis
- [[market-profiling/contract-segmentation]] — Contract groups affected by calendar events
- [[strategy-research/directional-bias-model]] — Bias model sensitivity to event timing

### Knowledge Base
- [[knowledge-base/core/instruments-and-platform]] — Contract specs for expiry date calculations
