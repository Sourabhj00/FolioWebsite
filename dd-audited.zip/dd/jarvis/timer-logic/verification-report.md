---
title: Timer Logic & Accuracy Measurement — Verification Report
wp: WP-04
status: complete
created: 2026-03-30
last-updated: 2026-03-31
lines: 1359
kb-depends:
  - knowledge-base/strategy/timer-logic.md
  - knowledge-base/execution-analysis/accuracy-measurement.md
  - knowledge-base/strategy/price-formulas-complete.md
  - knowledge-base/strategy/execution-modifiers.md
  - knowledge-base/strategy/core-quad-leg-arbitrage.md
  - knowledge-base/strategy/residuals-and-convergence.md
  - knowledge-base/ase-rules/custom-rules-production.md
  - knowledge-base/application/safety-mechanisms.md
jarvis-depends:
  - jarvis/timer-logic/implementation/README.md
  - jarvis/fill-analysis/README.md
---

# Timer Logic & Accuracy Measurement — Verification Report

**Date:** 2026-03-30
**Status:** Pre-implementation verification for WP-05
**Documents Verified:** timer-logic.md, accuracy-measurement.md, price-formulas-complete.md, execution-modifiers.md, core-quad-leg-arbitrage.md, residuals-and-convergence.md, custom-rules-production.md, case-distribution.md, safety-mechanisms.md

---

## PART 1 — Cross-Document Consistency Issues

Issues ranked: **CRITICAL** (blocks implementation), **HIGH** (requires fix before code), **MEDIUM** (documentation fix, no code impact if price-formulas is the source of truth), **LOW** (clarity improvement).

### ISSUE 1 — CRITICAL: execution-modifiers §5 missing −BS_FF in Leg 3/4 base formulas

**Location:** execution-modifiers.md §5 vs price-formulas-complete.md §7

execution-modifiers §5 gives the base formulas as:

```
Leg 3 Buy Raw = Leg 1 Buy Raw − v1 − Av_FF
Leg 3 Sell Raw = Leg 1 Sell Raw − v1 + Av_FF
```

price-formulas-complete §7 gives:

```
Leg 3 Buy Raw = Leg 1 Buy Raw − v1 − BS_FF − Av_FF
Leg 3 Sell Raw = Leg 1 Sell Raw − v1 − BS_FF + Av_FF
```

The `−BS_FF` term is **absent** from execution-modifiers. Combined with the conditional adjustment in execution-modifiers §6 (`If BS_FF > 0: Leg 3 Buy Raw += BS_FF`), the two documents produce **different numerical results** for every case where BS_FF ≠ 0.

**Worked proof — BS_FF = +0.1:**

| Document | Leg 3 Buy Final | Leg 3 Sell Final |
|----------|----------------|-----------------|
| execution-modifiers §5+§6 | L1_Raw − v1 − Av_FF **+ 0.1** | L1_Raw − v1 + Av_FF (unchanged) |
| price-formulas §7+§8 | L1_Raw − v1 − Av_FF (BS_FF cancels) | L1_Raw − v1 **− 0.1** + Av_FF |

execution-modifiers makes **buys** more aggressive; price-formulas makes **sells** more aggressive. These are opposite outcomes.

**Which is correct?** price-formulas-complete. The prose in both documents agrees: "Positive bsValue = sell bias → sell prices more aggressive, buy prices unaffected." The price-formulas cancellation mechanism (subtract in base, add back conditionally) achieves this. execution-modifiers' formulas contradict its own prose.

**Impact:** If a developer implements from execution-modifiers §5–§6, the BS_FF logic will be inverted. This is the exact area flagged as highest-risk.

**Fix:** Replace execution-modifiers §5 formulas with:

```
Leg 3 Buy Raw = Leg 1 Buy Raw − v1 − BS_FF − Av_FF
Leg 3 Sell Raw = Leg 1 Sell Raw − v1 − BS_FF + Av_FF
Leg 4 Buy Raw = Leg 2 Buy Raw − v2 − BS_FF − Av_FF
Leg 4 Sell Raw = Leg 2 Sell Raw − v2 − BS_FF + Av_FF
```

Then §6 conditional adds BS_FF back on one side (cancellation), matching price-formulas §8.

---

### ISSUE 2 — HIGH: accuracy-measurement §2 cross-check identity is wrong when BS_ZQ ≠ 0

**Location:** accuracy-measurement.md §2

The document states:

> "From Legs 1+2, before rounding: L1_Raw + L2_Raw = O − 2×Av_ZQ (the diff and BS_ZQ terms cancel within each side)."

**Algebraic disproof:**

For buys with BS_ZQ > 0:

```
L1_Buy_Raw = (O_Buy + diff)/2 − Av_ZQ + BS_ZQ
L2_Buy_Raw = (O_Buy − diff)/2 − Av_ZQ

Sum = O_Buy − 2×Av_ZQ + BS_ZQ    ← not O_Buy − 2×Av_ZQ
```

For buys with BS_ZQ < 0:

```
L1_Buy_Raw = (O_Buy + diff)/2 − Av_ZQ
L2_Buy_Raw = (O_Buy − diff)/2 − Av_ZQ − BS_ZQ

Sum = O_Buy − 2×Av_ZQ − BS_ZQ    ← not O_Buy − 2×Av_ZQ
```

In general: **L1_Buy_Raw + L2_Buy_Raw = O_Buy − 2×Av_ZQ + |BS_ZQ|**

And: **L1_Sell_Raw + L2_Sell_Raw = O_Sell + 2×Av_ZQ − |BS_ZQ|**

The diff terms cancel (correct), but the BS_ZQ terms do NOT cancel — they accumulate as |BS_ZQ|.

**Impact:** The cross-check code in the accuracy measurement system will flag false positives (divergence between Leg 1 and Leg 2 implied O values) whenever BS_ZQ ≠ 0, or — worse — miss genuine errors if the tolerance is widened to accommodate this.

**Fix:** Correct the identity to include the |BS_ZQ| term. The cross-check should verify:

```
L1_Buy_Raw + L2_Buy_Raw = O_Buy − 2×Av_ZQ + |BS_ZQ|
L1_Sell_Raw + L2_Sell_Raw = O_Sell + 2×Av_ZQ − |BS_ZQ|
```

---

### ISSUE 3 — HIGH: timer-logic §4 expansion examples are inconsistent with §3 formal definition

**Location:** timer-logic.md §4

§3 defines expansion ∈ [0, 0.5). §4 then gives examples:

```
Buy 4.95 → expansion ≈ 0.05
Buy 5.10 → expansion ≈ 0.40
Buy 5.40 → expansion ≈ 0.90   ← VIOLATES [0, 0.5) constraint
```

The third example (expansion ≈ 0.90) exceeds the formal upper bound of 0.5.

More fundamentally, §4 conflates two different concepts: the **expansion parameter** (a confidence threshold set by the evidence layer) and the **fractional position** of the raw price within the tick interval (which is a property of the raw price, not a parameter). The examples appear to describe the latter while calling it "expansion."

**Impact:** A developer reading §4 might implement expansion values > 0.5, which would break the tick geometry invariants in §3. Alternatively, they might misunderstand what the expansion parameter represents.

**Fix:** Rewrite §4 to clearly separate the two concepts. The "Buy 5.40" example should explain that the raw price is 0.10 from the ceiling tick (5.5), so expansion ≥ 0.10 triggers the aggressive rounding. Do not label the fractional position as "expansion."

---

### ISSUE 4 — MEDIUM: timer-logic §11 three-way decomposition doesn't match accuracy-measurement §1

**Location:** timer-logic.md §11 vs accuracy-measurement.md §1

timer-logic §11 describes a four-level O decomposition:

```
O_target → O_rounded_now → O_from_entry → O_from_match
```

With three cost layers: Rounding cost, Staleness cost, Execution cost.

accuracy-measurement §1 describes a two-snapshot system:

```
Fill Start (quote fill) → Fill Complete (hedge fill)
```

With two-level decomposition: dotnet_deviation and ase_deviation.

These are **different decompositions of the same data**. timer-logic's "Rounding cost" and "Staleness cost" are both folded into accuracy-measurement's "dotnet_deviation." The three-way decomposition from timer-logic is not implemented in accuracy-measurement's pseudocode (§5), which only computes the two-way split.

**Impact:** Not a mathematical error, but a design gap. If the implementation follows accuracy-measurement (which it should for Phase 1), the Rounding cost vs Staleness cost separation described in timer-logic §11 will not be available without additional work.

**Fix:** Either remove the three-way decomposition from timer-logic §11 (since it's aspirational) or add a note that it requires capturing the diff at .NET computation time (not just at fill time), which is not in the current FillSnapshot spec.

---

### ISSUE 5 — MEDIUM: Inconsistent avoidance mapping for monitoring instruments

**Location:** residuals-and-convergence.md §6

The document states:

> "Avoidance escalation: ZQ Spread Avoidance (Av_ZQ) for Aliases 1+2, SR1FF Avoidance (Av_FF) for Alias 3"

But the parameter mapping should be the reverse based on residual logic:

- Aliases 1 and 2 are SR1-ZQ inter-product bases → these are the residuals from Leg 3/4 fills → governed by **Av_FF** (SR1FF Avoidance)
- Alias 3 is the ZQ near-far calendar → this is the residual from Leg 1/2 fills → governed by **Av_ZQ** (ZQ Spread Avoidance)

The avoidance parameter names and their alias mappings appear swapped.

**Impact:** If someone uses this section to configure avoidance parameters, they'll apply the wrong avoidance to the wrong instruments.

**Fix:** Swap: Av_FF for Aliases 1+2, Av_ZQ for Alias 3. (Or verify against source code — the naming convention may be the opposite of what the names suggest.)

---

### ISSUE 6 — LOW: execution-modifiers §6 sign convention is confusing vs §3

**Location:** execution-modifiers.md §3 vs §6

For BS_ZQ (§3):
- Negative BS_ZQ = sell bias on SR1-ZQ calendar
- Positive BS_ZQ = buy bias on SR1-ZQ calendar

For BS_FF (§6):
- **Positive** BS_FF = sell bias on SR1-ZQ basis
- **Negative** BS_FF = buy bias on SR1-ZQ basis

The sign conventions are **opposite** for the two parameters. A positive value means "buy bias" for BS_ZQ but "sell bias" for BS_FF.

**Impact:** Confusion risk when setting parameters. Not a formula error, but a usability hazard.

**Fix:** Document this asymmetry explicitly with a warning. Consider whether the production code follows the same convention.

---

### ISSUE 7 — LOW: timer-logic §5 edge cost table only covers Legs 1 & 2

The edge cost analysis in timer-logic §5 discusses "four prices per recalculation (Leg 1 Buy, Leg 2 Buy, Leg 1 Sell, Leg 2 Sell)." This omits Legs 3 and 4 entirely. A full quad-leg expansion involves 8 prices (4 legs × buy/sell), not 4.

**Impact:** The cost classification table (Single/Double/Heavy/Quad) understates the maximum possible edge cost. A true "full expansion" across all 8 prices costs 4.0 ticks, not 2.0.

**Fix:** Clarify that the table applies to Legs 1&2 only, or extend to cover Legs 3&4.

---

## PART 2 — Algebraic Derivation of All Reverse Formulas

### Leg 1 Buy — Forward and Reverse

**Forward** (price-formulas §4–5, compact form):

```
L1_Buy_Raw = (O_Buy + diff) / 2 − Av_ZQ + max(BS_ZQ, 0)
```

**Reverse** — solve for O_Buy:

```
(O_Buy + diff) / 2 = L1_Buy_Raw + Av_ZQ − max(BS_ZQ, 0)
O_Buy + diff = 2 × (L1_Buy_Raw + Av_ZQ − max(BS_ZQ, 0))
O_Buy = 2 × (P + Av_ZQ − max(BS_ZQ, 0)) − diff       ✓ matches accuracy-measurement §2
```

### Leg 1 Sell — Forward and Reverse

**Forward:**

```
L1_Sell_Raw = (O_Sell + diff) / 2 + Av_ZQ + min(BS_ZQ, 0)
```

**Reverse:**

```
(O_Sell + diff) / 2 = L1_Sell_Raw − Av_ZQ − min(BS_ZQ, 0)
O_Sell = 2 × (P − Av_ZQ − min(BS_ZQ, 0)) − diff       ✓ matches accuracy-measurement §2
```

### Leg 2 Buy — Forward and Reverse

**Forward:**

```
L2_Buy_Raw = (O_Buy − diff) / 2 − Av_ZQ − min(BS_ZQ, 0)
```

Derivation of compact form: §5 says "If BS_ZQ < 0: Leg 2 Buy Raw −= BS_ZQ." Starting from base `(O_Buy − diff)/2 − Av_ZQ`:
- BS_ZQ > 0 → no change → `−min(BS_ZQ, 0) = 0` ✓
- BS_ZQ < 0 → subtract BS_ZQ (negative) = add |BS_ZQ| → `−min(BS_ZQ, 0) = −BS_ZQ = |BS_ZQ|` ✓

**Reverse:**

```
(O_Buy − diff) / 2 = L2_Buy_Raw + Av_ZQ + min(BS_ZQ, 0)
O_Buy = 2 × (P + Av_ZQ + min(BS_ZQ, 0)) + diff         ✓ matches accuracy-measurement §2
```

### Leg 2 Sell — Forward and Reverse

**Forward:**

```
L2_Sell_Raw = (O_Sell − diff) / 2 + Av_ZQ − max(BS_ZQ, 0)
```

**Reverse:**

```
O_Sell = 2 × (P − Av_ZQ + max(BS_ZQ, 0)) + diff         ✓ matches accuracy-measurement §2
```

### Leg 3 Buy — Forward and Reverse (chain through Leg 1)

**Forward** (price-formulas §7–8, compact form):

```
L3_Buy_Raw = L1_Buy_Raw − v1 − BS_FF − Av_FF + max(BS_FF, 0)
```

Verification: BS_FF > 0 → `−BS_FF + BS_FF = 0`, buys unaffected ✓. BS_FF < 0 → `max(BS_FF,0) = 0`, net is `−BS_FF` (positive shift = more aggressive) ✓.

Simplification: `−BS_FF + max(BS_FF, 0) = −BS_FF + max(BS_FF, 0)`. Note that `−x + max(x, 0) = −min(x, 0)`.

So: `L3_Buy_Raw = L1_Buy_Raw − v1 − Av_FF − min(BS_FF, 0)`

**Reverse** — solve for L1_Buy_Raw:

```
L1_Buy_Raw = L3_Buy + v1 + Av_FF + min(BS_FF, 0)        ✓ matches accuracy-measurement §3
```

Then chain into Leg 1 Buy reverse:

```
O_Buy = 2 × (L3_Buy + v1 + Av_FF + min(BS_FF, 0) + Av_ZQ − max(BS_ZQ, 0)) − diff
```

✓ matches accuracy-measurement §3 "Full Leg 3 Buy Expanded"

### Leg 3 Sell — Forward and Reverse (chain through Leg 1)

**Forward:**

```
L3_Sell_Raw = L1_Sell_Raw − v1 − BS_FF + Av_FF + min(BS_FF, 0)
```

Simplification: `−BS_FF + min(BS_FF, 0) = −max(BS_FF, 0)`

So: `L3_Sell_Raw = L1_Sell_Raw − v1 + Av_FF − max(BS_FF, 0)`

**Reverse:**

```
L1_Sell_Raw = L3_Sell + v1 − Av_FF + max(BS_FF, 0)       ✓ matches accuracy-measurement §3
```

### Leg 4 Buy — Forward and Reverse (chain through Leg 2)

**Forward:**

```
L4_Buy_Raw = L2_Buy_Raw − v2 − Av_FF − min(BS_FF, 0)
```

**Reverse:**

```
L2_Buy_Raw = L4_Buy + v2 + Av_FF + min(BS_FF, 0)         ✓ matches accuracy-measurement §3
```

Full expansion:

```
O_Buy = 2 × (L4_Buy + v2 + Av_FF + min(BS_FF, 0) + Av_ZQ + min(BS_ZQ, 0)) + diff
```

✓ matches accuracy-measurement §3 "Full Leg 4 Buy Expanded"

### Leg 4 Sell — Forward and Reverse (chain through Leg 2)

**Forward:**

```
L4_Sell_Raw = L2_Sell_Raw − v2 + Av_FF − max(BS_FF, 0)
```

**Reverse:**

```
L2_Sell_Raw = L4_Sell + v2 − Av_FF + max(BS_FF, 0)        ✓ matches accuracy-measurement §3
```

Full expansion:

```
O_Sell = 2 × (L4_Sell + v2 − Av_FF + max(BS_FF, 0) − Av_ZQ + max(BS_ZQ, 0)) + diff
```

### Summary: All 8 reverse formulas verified algebraically ✓

The ForwardRaw and ReverseToO functions in accuracy-measurement.md §5 are correct and consistent with price-formulas-complete.md.

---

## PART 3 — Forward-Reverse Identity Proof

**Claim:** For all legs and sides, `Reverse(Forward(O_target, params), params) = O_target` exactly, assuming no rounding is applied (raw prices only).

**Proof by construction** — demonstrated for Leg 1 Buy (all others follow the same algebraic structure):

```
Forward:  P = (O + diff) / 2 − Av_ZQ + max(BS_ZQ, 0)
Reverse:  O' = 2 × (P + Av_ZQ − max(BS_ZQ, 0)) − diff
Substitute:
  O' = 2 × ((O + diff)/2 − Av_ZQ + max(BS_ZQ, 0) + Av_ZQ − max(BS_ZQ, 0)) − diff
     = 2 × ((O + diff)/2) − diff
     = (O + diff) − diff
     = O  ✓
```

The cancellation is exact because every additive adjustment in the forward path has an exact inverse in the reverse path. This holds for all 8 formulas (4 legs × buy/sell) because each is a linear function of O with constant offsets.

**Caveat — rounding breaks the identity.** When RD/RU (or TimerRD/TimerRU) is applied, the fill price P differs from the raw price by up to 0.5 ticks. The reverse formula produces `O_target ± up to 1.0 tick` (the factor of 2 in the reverse doubles the rounding error). This is expected and is precisely what the accuracy measurement system captures as "rounding cost" / "dotnet_deviation."

---

## PART 4 — Crossed-Market Boundary Analysis

### Setup

A crossed market occurs when `Leg Buy ≥ Leg Sell` after rounding/expansion. The cross-validation guard (price-formulas §11) pauses the contract.

### Pre-Rounding Spread (per leg)

For Leg 1:

```
Spread_raw = L1_Sell_Raw − L1_Buy_Raw
  = [(O_Sell + diff)/2 + Av_ZQ + min(BS_ZQ, 0)] − [(O_Buy + diff)/2 − Av_ZQ + max(BS_ZQ, 0)]
  = (O_Sell − O_Buy)/2 + 2×Av_ZQ + min(BS_ZQ, 0) − max(BS_ZQ, 0)
  = (O_Sell − O_Buy)/2 + 2×Av_ZQ − |BS_ZQ|
```

For Leg 2: identical expression (diff cancels symmetrically).

For Legs 3 and 4:

```
Spread_raw = L3_Sell_Raw − L3_Buy_Raw
  = [L1_Sell_Raw − v1 + Av_FF − max(BS_FF, 0)] − [L1_Buy_Raw − v1 − Av_FF − min(BS_FF, 0)]
  = (L1_Sell_Raw − L1_Buy_Raw) + 2×Av_FF − max(BS_FF, 0) + min(BS_FF, 0)
  = Spread_L1_raw + 2×Av_FF − |BS_FF|
  = (O_Sell − O_Buy)/2 + 2×Av_ZQ − |BS_ZQ| + 2×Av_FF − |BS_FF|
```

### Effect of Defensive Rounding (no Timer Logic)

With hard rounding (RD buy, RU sell), the discretised spread can only INCREASE or stay the same (buy goes down, sell goes up). Crossed markets are impossible as long as `Spread_raw > 0`.

**Minimum O spread for positive raw spread (Legs 1&2):**

```
(O_Sell − O_Buy)/2 + 2×Av_ZQ − |BS_ZQ| > 0
O_Sell − O_Buy > 2×(|BS_ZQ| − 2×Av_ZQ)
```

With typical Av_ZQ = 0.1, BS_ZQ = ±0.1: O_Sell − O_Buy > 2×(0.1 − 0.2) = −0.2. Always satisfied for positive O spread. ✓

**Minimum O spread for positive raw spread (Legs 3&4):**

```
O_Sell − O_Buy > 2×(|BS_ZQ| + |BS_FF| − 2×Av_ZQ − 2×Av_FF)
```

### Effect of Timer Logic Expansion

When Timer Logic expands a buy UP by 0.5 ticks AND a sell DOWN by 0.5 ticks on the same leg, the discretised spread narrows by 1.0 tick relative to the hard-rounded spread.

**Worst-case scenario:** Both buy and sell expand on the same leg (a "double expansion on one leg").

For this to cause a cross, the hard-rounded spread must be ≤ 1.0 tick (since expansion narrows it by up to 1.0):

```
RU(Sell_raw) − RD(Buy_raw) ≤ 1.0
```

Since `RU(x) − RD(x)` for the same value equals 0 or 0.5 (if on tick or not), and for different values it equals at least the raw spread rounded up to the tick grid:

The hard-rounded spread equals `Spread_raw` rounded up to the next 0.5 boundary (approximately). For Spread_raw slightly above 1.0, the hard-rounded spread is 1.0 or 1.5, and expansion can bring it to 0.0 or 0.5.

### Exact Crossed-Market Boundary

**For Legs 1 & 2:**

The crossed market condition with maximum possible expansion (both sides flip) is:

```
(O_Sell − O_Buy)/2 + 2×Av_ZQ − |BS_ZQ| ≤ 1.0
```

Solving for O spread width W = O_Sell − O_Buy:

```
W ≤ 2 × (1.0 − 2×Av_ZQ + |BS_ZQ|)
```

**Typical parameter values and boundaries:**

| Av_ZQ | BS_ZQ | Max W for crossed market (Legs 1&2) | Typical W | Safe? |
|-------|-------|--------------------------------------|-----------|-------|
| 0.10 | 0.0 | ≤ 1.60 | 2.0 | ✓ |
| 0.10 | ±0.1 | ≤ 1.80 | 2.0 | ✓ (marginal) |
| 0.10 | ±0.2 | ≤ 2.00 | 2.0 | ✗ BOUNDARY |
| 0.05 | 0.0 | ≤ 1.80 | 2.0 | ✓ (marginal) |
| 0.05 | ±0.1 | ≤ 2.00 | 2.0 | ✗ BOUNDARY |
| 0.00 | 0.0 | ≤ 2.00 | 2.0 | ✗ BOUNDARY |

**Critical finding:** With a 2.0-tick O spread (the typical value), crossed markets are possible when `2×Av_ZQ − |BS_ZQ| < 1.0`, i.e., avoidance is insufficient to buffer against expansion. The exact threshold depends on the raw price's position within the tick grid (not all diff values trigger double expansion on the same leg).

**For Legs 3 & 4:** Add the Av_FF and BS_FF buffer:

```
W ≤ 2 × (1.0 − 2×Av_ZQ + |BS_ZQ| − 2×Av_FF + |BS_FF|)
```

With Av_FF = 0.05, BS_FF = 0: threshold shifts down by 0.2 (safer).

### Recommendation

Compute `max_safe_expansion` per contract per pricing cycle:

```
per_leg_raw_spread = (O_Sell − O_Buy)/2 + 2×Av_ZQ − |BS_ZQ|   // for Legs 1&2
max_safe_expansion = (per_leg_raw_spread − 0.5) / 2             // safety margin of 0.5 tick
```

Clamp expansion to `min(computed_expansion, max_safe_expansion)` before applying TimerRD/TimerRU.

---

## PART 5 — Timer Logic Interaction with ASE Rules (Numeric Examples)

### Example Setup

```
O_Buy = 4.0, O_Sell = 6.0 (W = 2.0)
diff = 1.0, Av_ZQ = 0.1, BS_ZQ = 0, Av_FF = 0.05, BS_FF = 0
v1 = 0.3, v2 = 0.2
Expansion = 0.15
```

### Forward Prices (Legs 1 & 2)

```
L1_Buy_Raw  = (4.0 + 1.0)/2 − 0.1 = 2.4
L1_Sell_Raw = (6.0 + 1.0)/2 + 0.1 = 3.6
L2_Buy_Raw  = (4.0 − 1.0)/2 − 0.1 = 1.4
L2_Sell_Raw = (6.0 − 1.0)/2 + 0.1 = 2.6
```

### 5.1 HitMan Interaction

**Hard rounding:** L1_Buy = RD(2.4) = 2.0. The order rests at 2.0 (passive, inside bid or deeper).

**Timer rounding:** ceil(2.4) = 2.5, distance = 2.5 − 2.4 = 0.1 ≤ 0.15 (expansion). Timer rounds UP: L1_Buy = 2.5.

**HitMan effect:** HitMan evaluates CalcPrice = 2.5 (now at or near inside bid). HitMan's Condition 3 (CalcPrice at inside bid) fires. If other conditions pass (spread check, volume ratio), HitMan crosses the market by lifting the ask. The order fills at 2.5 + 1 tick = 3.0 (HitMan adds 1 tick aggression on the quote leg).

**Net impact:** Timer Logic moved the resting order from 2.0 to 2.5 (+0.5 tick cost). HitMan then crossed from 2.5 to 3.0 (+0.5 tick additional). Total cost: 1.0 tick on this leg. In O-space: 2 × 1.0 = 2.0 tick O deviation (the factor-of-2 from the leg-to-O conversion). This is the entire edge budget for a 2.0-tick O spread.

**Conclusion:** Timer expansion + HitMan cross is a double cost. For Phase 1 with moderate expansion (0.15), this is manageable — the combination only fires when both the expansion threshold AND HitMan conditions are simultaneously met.

### 5.2 ASM Interaction

**Hard rounding:** L1_Buy = 2.0 (resting deep in book). ASM's Condition 2 checks if CalcPrice is 1 tick from inside bid. If inside bid = 2.5, then CalcPrice = 2.0 is 1.0 tick away — ASM fires and joins at 2.5.

**Timer rounding:** L1_Buy = 2.5 (already at inside bid). ASM checks: CalcPrice = 2.5, inside bid = 2.5, difference = 0. ASM does NOT fire (not "one tick from" inside — already there).

**Conclusion:** Timer Logic pre-empts ASM. Where hard rounding would require ASM to join the inside, Timer already places the order there. Net effect: same price, but Timer Logic arrives faster (on the pricing cycle, not waiting for ASM's market-event trigger).

### 5.3 Backoff Interaction

**Setup:** Quote leg (L1) fills at 2.5. Hedge leg (SR3) needs to sell.

Backoff evaluates the hedge side's L2 book. If L2 bid quantity > QtyThreshold (e.g., 500 lots), Backoff rests the hedge 1 tick back from the best bid.

Timer Logic does not affect the hedge price — it only adjusts the quote leg price. Backoff operates independently on the hedge.

**Indirect effect (State 3):** If Timer Logic expanded the quote to capture a favorable opportunity, and the hedge leg also has thick bids (State 3), Backoff may pull the hedge back 1 tick. This is a 0.5-tick cost on the hedge that partially offsets the favorable fill on the quote.

**Numeric:** Quote fills at 2.5 (Timer-expanded). Hedge should sell at 95.0 (SR3 bid). Backoff rests at 94.995 (1 tick back). If hedge fills at 94.995, the spread price is 2.5 + (95.0 − 94.995) × adjustment = marginally worse. Recommended: accept Backoff as-is for Phase 1.

### 5.4 WCT Payup Interaction

WCT Payup operates post-hedge, chasing the hedge if it doesn't fill within the WCT timer. It can add up to 6 ticks (5 payup steps + 1 WCT tick).

Timer Logic has no direct interaction — Payup operates on the hedge leg after the quote fills. However, if Timer Logic increases the fill rate (more quote fills), Payup events may increase in frequency (more hedges to manage).

**Worst case:** Timer-expanded quote fill + full WCT Payup chain = 0.5 (expansion) + 3.0 (6 × 0.5 tick payup) = 3.5 ticks total cost on the legs. In O-space: up to 7.0 ticks. This is the absolute worst-case scenario. The accuracy measurement system should flag any fill where |ase_deviation| > 1.0 for review.

---

## PART 6 — Test Cases

### Conventions

- Tick size: 0.5
- RD(x) = floor to nearest 0.5 (e.g., RD(2.4) = 2.0, RD(2.5) = 2.5)
- RU(x) = ceil to nearest 0.5 (e.g., RU(2.4) = 2.5, RU(2.5) = 2.5)
- TimerRD(x, e): if (ceil − x) ≤ e → ceil, else floor
- TimerRU(x, e): if (x − floor) ≤ e → floor, else ceil

### Base Parameters (unless overridden)

```
O_Buy = 4.0, O_Sell = 6.0
diff = 1.0
Av_ZQ = 0.1, BS_ZQ = 0.0
Av_FF = 0.05, BS_FF = 0.0
v1 = 0.3, v2 = 0.2
Expansion = 0.0 (hard rounding unless stated)
```

---

**TC-01: Leg 1 Forward-Reverse Identity (Buy, BS_ZQ = 0)**

```
Input: O_Buy = 4.0, diff = 1.0, Av_ZQ = 0.1, BS_ZQ = 0
Forward: L1_Buy_Raw = (4.0 + 1.0)/2 − 0.1 + max(0, 0) = 2.4
Reverse: O' = 2 × (2.4 + 0.1 − max(0, 0)) − 1.0 = 2 × 2.5 − 1.0 = 4.0
Expected: O' = 4.0 ✓
```

---

**TC-02: Leg 2 Forward-Reverse Identity (Sell, BS_ZQ = +0.1)**

```
Input: O_Sell = 6.0, diff = 1.0, Av_ZQ = 0.1, BS_ZQ = +0.1
Forward: L2_Sell_Raw = (6.0 − 1.0)/2 + 0.1 − max(0.1, 0) = 2.5 + 0.1 − 0.1 = 2.5
Reverse: O' = 2 × (2.5 − 0.1 + max(0.1, 0)) + 1.0 = 2 × 2.5 + 1.0 = 6.0
Expected: O' = 6.0 ✓
```

---

**TC-03: Leg 3 Forward-Reverse Identity (Buy, BS_FF = +0.1, BS_ZQ = −0.1)**

```
Input: O_Buy = 4.0, diff = 1.0, Av_ZQ = 0.1, BS_ZQ = −0.1, Av_FF = 0.05, BS_FF = 0.1, v1 = 0.3

Step 1 — L1_Buy_Raw:
  = (4.0 + 1.0)/2 − 0.1 + max(−0.1, 0) = 2.5 − 0.1 + 0 = 2.4

Step 2 — L3_Buy_Raw:
  = L1_Buy_Raw − v1 − Av_FF − min(BS_FF, 0)
  = 2.4 − 0.3 − 0.05 − min(0.1, 0)
  = 2.4 − 0.3 − 0.05 − 0 = 2.05

Reverse Step 1 — recover L1_Buy_Raw:
  L1_Raw = 2.05 + 0.3 + 0.05 + min(0.1, 0) = 2.05 + 0.3 + 0.05 + 0 = 2.4  ✓

Reverse Step 2 — recover O_Buy:
  O' = 2 × (2.4 + 0.1 − max(−0.1, 0)) − 1.0 = 2 × (2.4 + 0.1 − 0) − 1.0 = 2 × 2.5 − 1.0 = 4.0

Expected: O' = 4.0 ✓
```

---

**TC-04: Leg 4 Forward-Reverse Identity (Sell, BS_FF = −0.15, BS_ZQ = +0.05)**

```
Input: O_Sell = 6.0, diff = 1.0, Av_ZQ = 0.1, BS_ZQ = +0.05, Av_FF = 0.05, BS_FF = −0.15, v2 = 0.2

Step 1 — L2_Sell_Raw:
  = (6.0 − 1.0)/2 + 0.1 − max(0.05, 0)
  = 2.5 + 0.1 − 0.05 = 2.55

Step 2 — L4_Sell_Raw:
  = L2_Sell_Raw − v2 + Av_FF − max(BS_FF, 0)
  = 2.55 − 0.2 + 0.05 − max(−0.15, 0)
  = 2.55 − 0.2 + 0.05 − 0 = 2.4

Reverse Step 1:
  L2_Raw = 2.4 + 0.2 − 0.05 + max(−0.15, 0) = 2.4 + 0.2 − 0.05 + 0 = 2.55  ✓

Reverse Step 2:
  O' = 2 × (2.55 − 0.1 + max(0.05, 0)) + 1.0 = 2 × (2.55 − 0.1 + 0.05) + 1.0 = 2 × 2.5 + 1.0 = 6.0

Expected: O' = 6.0 ✓
```

---

**TC-05: State 1 — Both legs thin, conservative expansion**

```
Params: expansion = 0.05
L1_Buy_Raw = 2.4 → ceil = 2.5, distance = 0.1 > 0.05 → RD → L1_Buy = 2.0
L1_Sell_Raw = 3.6 → floor = 3.5, distance = 0.1 > 0.05 → RU → L1_Sell = 4.0
L2_Buy_Raw = 1.4 → ceil = 1.5, distance = 0.1 > 0.05 → RD → L2_Buy = 1.0
L2_Sell_Raw = 2.6 → floor = 2.5, distance = 0.1 > 0.05 → RU → L2_Sell = 3.0

Expansion events: 0 (all distances exceed expansion threshold)
Classification: No effect — identical to hard rounding
Leg 1 spread: 4.0 − 2.0 = 2.0 (not crossed ✓)
Leg 2 spread: 3.0 − 1.0 = 2.0 (not crossed ✓)
```

---

**TC-06: State 2 — L1 strong, L2 weak, momentum expansion**

```
Params: expansion = 0.20 (momentum detected on L1)
L1_Buy_Raw = 2.4 → distance to ceil = 0.1 ≤ 0.20 → EXPAND → L1_Buy = 2.5
L1_Sell_Raw = 3.6 → distance to floor = 0.1 ≤ 0.20 → EXPAND → L1_Sell = 3.5
L2_Buy_Raw = 1.4 → distance to ceil = 0.1 ≤ 0.20 → EXPAND → L2_Buy = 1.5
L2_Sell_Raw = 2.6 → distance to floor = 0.1 ≤ 0.20 → EXPAND → L2_Sell = 2.5

Expansion events: 4 (Quad expansion)
Classification: Quad — 2.0 ticks total cost
Edge cost: 2.0 / 2.0 (edge budget) = 100% of edge consumed

Leg 1 spread: 3.5 − 2.5 = 1.0 (not crossed ✓, but tight)
Leg 2 spread: 2.5 − 1.5 = 1.0 (not crossed ✓, but tight)
```

---

**TC-07: State 3 — Both legs strong, maximum expansion**

```
Params: expansion = 0.45 (maximum for rare opportunity)
diff = 0.8 (shifted slightly)
L1_Buy_Raw = (4.0 + 0.8)/2 − 0.1 = 2.3
L1_Sell_Raw = (6.0 + 0.8)/2 + 0.1 = 3.5  ← exactly on tick
L2_Buy_Raw = (4.0 − 0.8)/2 − 0.1 = 1.5  ← exactly on tick
L2_Sell_Raw = (6.0 − 0.8)/2 + 0.1 = 2.7

L1_Buy: ceil = 2.5, dist = 0.2 ≤ 0.45 → EXPAND → 2.5
L1_Sell: on tick → 3.5 (no expansion possible)
L2_Buy: on tick → 1.5 (no expansion possible)
L2_Sell: floor = 2.5, dist = 0.2 ≤ 0.45 → EXPAND → 2.5

Expansion events: 2 (Double — one buy, one sell on different legs)
Leg 1 spread: 3.5 − 2.5 = 1.0 ✓
Leg 2 spread: 2.5 − 1.5 = 1.0 ✓
```

---

**TC-08: State 4 — L1 thin, L2 strong, moderate expansion**

```
Params: expansion = 0.12
L1_Buy_Raw = 2.4 → dist to ceil = 0.1 ≤ 0.12 → EXPAND → L1_Buy = 2.5
L1_Sell_Raw = 3.6 → dist to floor = 0.1 ≤ 0.12 → EXPAND → L1_Sell = 3.5
L2_Buy_Raw = 1.4 → dist to ceil = 0.1 ≤ 0.12 → EXPAND → L2_Buy = 1.5
L2_Sell_Raw = 2.6 → dist to floor = 0.1 ≤ 0.12 → EXPAND → L2_Sell = 2.5

Expansion events: 4 (Quad)
Leg 1 spread: 3.5 − 2.5 = 1.0 ✓
Leg 2 spread: 2.5 − 1.5 = 1.0 ✓

Note: expansion = 0.12 just barely captures all four prices (all at dist = 0.1).
At expansion = 0.09, zero expansions fire.
```

---

**TC-09: State 5 — Sweep aftershock, spike expansion**

```
Params: expansion = 0.35 (spiked due to L2 sweep), diff = 0.7
L1_Buy_Raw = (4.0 + 0.7)/2 − 0.1 = 2.25
  → ceil = 2.5, dist = 0.25 ≤ 0.35 → EXPAND → 2.5
L1_Sell_Raw = (6.0 + 0.7)/2 + 0.1 = 3.45
  → floor = 3.0, ceil = 3.5. x − floor = 0.45 > 0.35 → RU → 3.5

Expansion events on L1: 1 (Single — only buy expands)
Leg 1 spread: 3.5 − 2.5 = 1.0 ✓
Edge cost on L1: 0.5 tick
```

---

**TC-10: State 6 — Book imbalance cascade, cross-leg convergence**

```
Params: expansion = 0.18
diff = 1.2
L1_Buy_Raw = (4.0 + 1.2)/2 − 0.1 = 2.5 (exactly on tick)
L1_Sell_Raw = (6.0 + 1.2)/2 + 0.1 = 3.7

L1_Buy: on tick → 2.5 (no expansion)
L1_Sell: floor = 3.5, dist = 0.2 > 0.18 → RU → 4.0

Expansion events on L1: 0
L2_Buy_Raw = (4.0 − 1.2)/2 − 0.1 = 1.3
L2_Sell_Raw = (6.0 − 1.2)/2 + 0.1 = 2.5 (exactly on tick)

L2_Buy: ceil = 1.5, dist = 0.2 > 0.18 → RD → 1.0
L2_Sell: on tick → 2.5

Expansion events total: 0
Note: Despite convergence signal, diff position on tick grid means no expansion fires. This is correct — expansion only helps when raw prices are near tick boundaries.
```

---

**TC-11: State 7 — Iceberg detection, lower expansion needed**

```
Params: expansion = 0.08 (iceberg detected, passive fill likely), diff = 0.92
L1_Buy_Raw = (4.0 + 0.92)/2 − 0.1 = 2.36 → dist to ceil = 0.14 > 0.08 → RD → 2.0
L1_Sell_Raw = (6.0 + 0.92)/2 + 0.1 = 3.56 → dist to floor = 0.06 ≤ 0.08 → EXPAND → 3.5

Expansion events: 1 (Single on Leg 1 sell only)
Note: Iceberg on L1 means passive fill likely. Even low expansion captures the sell
because raw price is very close to the 3.5 tick.
```

---

**TC-12: State 8 — Stale book, near-zero expansion**

```
Params: expansion = 0.01
L1_Buy_Raw = 2.4 → dist = 0.1 > 0.01 → RD → 2.0
L1_Sell_Raw = 3.6 → dist = 0.1 > 0.01 → RU → 4.0

Expansion events: 0
Classification: No effect — identical to hard rounding
Correct behavior: no expansion during inactivity.
```

---

**TC-13: State 9 — Implied liquidity alignment, increased confidence**

```
Params: expansion = 0.22
L1_Buy_Raw = 2.32 → dist to ceil = 0.18 ≤ 0.22 → EXPAND → 2.5
L1_Sell_Raw = 3.68 → dist to floor = 0.18 > 0.22? No: 0.18 ≤ 0.22 → EXPAND → 3.5

Expansion events: 2 (Double on Leg 1)
Leg 1 spread: 3.5 − 2.5 = 1.0 ✓
```

---

**TC-14: Crossed Market Detection — Expansion causes cross**

```
Params: O_Buy = 5.0, O_Sell = 6.0 (narrow W = 1.0), Av_ZQ = 0.0, BS_ZQ = 0
expansion = 0.25, diff = 1.0

L1_Buy_Raw = (5.0 + 1.0)/2 = 3.0 (on tick)
L1_Sell_Raw = (6.0 + 1.0)/2 = 3.5 (on tick)
Hard: L1_Buy = 3.0, L1_Sell = 3.5. Spread = 0.5 ✓

L2_Buy_Raw = (5.0 − 1.0)/2 = 2.0 (on tick)
L2_Sell_Raw = (6.0 − 1.0)/2 = 2.5 (on tick)
Hard: spread = 0.5 ✓

No expansion fires (all on-tick). Safe. ✓

Now shift diff = 0.9:
L1_Buy_Raw = (5.0 + 0.9)/2 = 2.95 → hard: 2.5, timer(0.25): dist = 0.05 ≤ 0.25 → 3.0
L1_Sell_Raw = (6.0 + 0.9)/2 = 3.45 → hard: 3.5, timer(0.25): dist = 0.45 > 0.25 → 3.5
Spread: 3.5 − 3.0 = 0.5 ✓

L2_Buy_Raw = (5.0 − 0.9)/2 = 2.05 → hard: 2.0, timer(0.25): dist = 0.45 > 0.25 → 2.0
L2_Sell_Raw = (6.0 − 0.9)/2 = 2.55 → hard: 3.0, timer(0.25): dist = 0.05 ≤ 0.25 → 2.5
Spread: 2.5 − 2.0 = 0.5 ✓

Still safe.

Now O_Buy = 5.5, O_Sell = 6.0 (W = 0.5), diff = 0.9, expansion = 0.30:
L1_Buy_Raw = (5.5 + 0.9)/2 = 3.2 → ceil = 3.5, dist = 0.3 ≤ 0.30 → 3.5
L1_Sell_Raw = (6.0 + 0.9)/2 = 3.45 → ceil = 3.5, floor = 3.0, dist to floor = 0.45 > 0.30 → RU → 3.5

Spread: 3.5 − 3.5 = 0.0 → Buy ≥ Sell → CROSSED MARKET → PAUSE ✗

Expected: Cross-validation guard triggers, contract pauses.
```

---

**TC-15: Crossed Market Detection — BS_ZQ tightens spread beyond safety**

```
Params: O_Buy = 4.0, O_Sell = 6.0 (W = 2.0), Av_ZQ = 0.0, BS_ZQ = +0.5
expansion = 0.25, diff = 1.0

L1_Buy_Raw = (4.0 + 1.0)/2 + 0.5 = 3.0 (on tick)
L1_Sell_Raw = (6.0 + 1.0)/2 = 3.5 (on tick, BS_ZQ > 0 doesn't affect sell)
Spread raw = 3.5 − 3.0 = 0.5

No expansion (on tick). Spread = 0.5 ✓ (barely).

Shift diff = 0.8:
L1_Buy_Raw = (4.0 + 0.8)/2 + 0.5 = 2.9 → hard: 2.5, timer(0.25): dist = 0.1 ≤ 0.25 → 3.0
L1_Sell_Raw = (6.0 + 0.8)/2 = 3.4 → hard: 3.5, timer(0.25): dist to floor = 0.4 > 0.25 → RU → 3.5
Spread: 3.5 − 3.0 = 0.5 ✓

Shift diff = 0.6:
L1_Buy_Raw = (4.0 + 0.6)/2 + 0.5 = 2.8 → hard: 2.5, timer(0.25): dist = 0.2 ≤ 0.25 → 3.0
L1_Sell_Raw = (6.0 + 0.6)/2 = 3.3 → hard: 3.5, timer(0.25): dist to floor = 0.3 > 0.25 → 3.5
Spread: 3.5 − 3.0 = 0.5 ✓ (still just safe)

Now BS_ZQ = +0.8 (aggressive), diff = 0.6:
L1_Buy_Raw = (4.0 + 0.6)/2 + 0.8 = 3.1 → timer(0.25): dist = 0.4 > 0.25 → hard → 3.0
L1_Sell_Raw = (6.0 + 0.6)/2 = 3.3 → timer(0.25): dist = 0.3 > 0.25 → RU → 3.5
Spread: 3.5 − 3.0 = 0.5 ✓

But with expansion = 0.45: dist to 3.5 = 0.4 ≤ 0.45 → BUY = 3.5
L1_Sell = 3.5 → Buy = Sell → CROSSED → PAUSE ✗
```

---

**TC-16: Double Expansion Classification**

```
Params: expansion = 0.15, diff = 1.0, base params
L1_Buy_Raw = 2.4 → dist = 0.1 ≤ 0.15 → EXPAND (+0.5)
L1_Sell_Raw = 3.6 → dist = 0.1 ≤ 0.15 → EXPAND (−0.5)
L2_Buy_Raw = 1.4 → dist = 0.1 ≤ 0.15 → EXPAND (+0.5)
L2_Sell_Raw = 2.6 → dist = 0.1 ≤ 0.15 → EXPAND (−0.5)

Classification: Quad (4 expansions)
Edge cost: 4 × 0.5 = 2.0 ticks (across Legs 1&2)

Compounding check — both L1 buy and L2 buy expand:
L1_Buy_Raw + L2_Buy_Raw = 2.4 + 1.4 = 3.8 = (O_Buy − 2×Av_ZQ) = 4.0 − 0.2 = 3.8  ✓
Both are fractional by 0.4 within tick → both at dist 0.1 from ceil → both expand.
```

---

**TC-17: Quad Expansion with Legs 3&4**

```
Params: expansion = 0.15, diff = 1.0, Av_FF = 0.05, BS_FF = 0, v1 = 0.3, v2 = 0.2

Legs 1&2 raw (from TC-16): L1_Buy = 2.4, L1_Sell = 3.6, L2_Buy = 1.4, L2_Sell = 2.6

Leg 3: L3_Buy_Raw = 2.4 − 0.3 − 0.05 = 2.05 → dist = 0.45 > 0.15 → RD → 2.0
        L3_Sell_Raw = 3.6 − 0.3 + 0.05 = 3.35 → dist = 0.35 > 0.15 → RU → 3.5
Leg 4: L4_Buy_Raw = 1.4 − 0.2 − 0.05 = 1.15 → dist = 0.35 > 0.15 → RD → 1.0
        L4_Sell_Raw = 2.6 − 0.2 + 0.05 = 2.45 → dist = 0.05 ≤ 0.15 → EXPAND → 2.5 (sell rounds DOWN)

Wait — for sells, TimerRU: if (x − floor) ≤ expansion → floor.
L4_Sell_Raw = 2.45, floor = 2.0, ceil = 2.5. x − floor = 0.45 > 0.15 → RU → 2.5.

Actually, let me recompute. floor(2.45) = 2.0? No. RD(2.45) = 2.0 (floor to 0.5 grid: 2.0). RU(2.45) = 2.5.
x − floor = 2.45 − 2.0 = 0.45 > 0.15 → ceil → 2.5.

So L4_Sell = 2.5 (no expansion).

Expansion events on Legs 3&4: 0 (the v1/v2 subtraction shifted raw prices away from tick boundaries)

Total across all legs: 4 (from Legs 1&2) + 0 (from Legs 3&4) = 4
Classification for Legs 1&2: Quad. For Legs 3&4: None.
```

---

**TC-18: Fed Window — Dynamic Avoidance at 12:55–13:05**

```
Pre-window params: Av_FF = 0.05, expansion = 0.15
During window: Av_FF dynamically set to 0.11

diff = 1.0, v1 = 0.3, v2 = 0.2

Pre-window Leg 3 Buy Raw:
  L1_Buy_Raw = 2.4, L3_Buy_Raw = 2.4 − 0.3 − 0.05 = 2.05

During window Leg 3 Buy Raw:
  L3_Buy_Raw = 2.4 − 0.3 − 0.11 = 1.99

Pre-window: RD(2.05) = 2.0. Timer: dist = 0.45 → no expansion → 2.0
During window: RD(1.99) = 1.5. Timer: dist = 0.01 ≤ 0.15 → EXPAND → 2.0

Note: The widened avoidance pushes the raw price DOWN, but Timer Logic then
rounds it back UP. The net effect: price stays at 2.0 in both cases, but
the raw price moved 0.06 deeper (the defensive intent of dynamic avoidance
is partially undone by Timer expansion).

RECOMMENDATION: During Fed window, reduce expansion to 0 or near-0 to
preserve the avoidance intent. Otherwise the dynamic avoidance increase is
counteracted by Timer Logic.
```

---

**TC-19: Wide Spread Guard — Monitoring instrument spread > 1 tick**

```
Scenario: SR1-ZQ near bid-ask spread = 1.5 ticks (> 1 tick guard)
Action: Contract paused. All orders withdrawn.

Timer Logic state: moot (no prices calculated during pause).
Expansion value: irrelevant.

Verify: On resume (spread narrows), Timer Logic resumes with current expansion.
No stale expansion values carried across pause boundaries.
```

---

**TC-20: Zero Expansion — Verify identical to hard rounding**

```
Params: expansion = 0.0 (explicitly zero)
L1_Buy_Raw = 2.4
  TimerRD(2.4, 0.0): ceil − x = 0.1 > 0.0 → floor → 2.0
  RD(2.4): 2.0
  Match: ✓

L1_Sell_Raw = 3.6
  TimerRU(3.6, 0.0): x − floor = 0.1 > 0.0 → ceil → 4.0
  RU(3.6): 4.0
  Match: ✓

L1_Buy_Raw = 2.5 (on tick)
  TimerRD(2.5, 0.0): ceil == floor → 2.5
  RD(2.5): 2.5
  Match: ✓

All legs, both sides: zero expansion produces identical results to hard rounding.
This is the fundamental invariant — Timer Logic at expansion = 0 is a no-op.
```

---

## PART 7 — BS_FF Conditional Adjustment — Detailed Risk Analysis

This section specifically addresses the highest-risk area flagged in the task.

### The Mechanism

price-formulas §7–8 implements BS_FF as a **subtract-then-add-back** pattern:

1. Subtract BS_FF from ALL four base prices (Legs 3&4 Buy and Sell)
2. Conditionally add BS_FF back to one side (Buy if BS_FF > 0, Sell if BS_FF < 0)
3. The "add-back" side is unaffected (net zero). The other side retains −BS_FF.

This is elegant but non-obvious. The compact form uses min/max:

```
Leg 3 Buy:  L1_Raw − v1 − Av_FF − min(BS_FF, 0)
Leg 3 Sell: L1_Raw − v1 + Av_FF − max(BS_FF, 0)
```

### Boundary Behavior at BS_FF = 0

When BS_FF = 0: `min(0, 0) = 0`, `max(0, 0) = 0`. Both buy and sell are unaffected. ✓

### Sign Flip Risk

If the implementation uses an if/else rather than min/max:

```csharp
// CORRECT:
if (bsFf > 0) { leg3BuyRaw += bsFf; leg4BuyRaw += bsFf; }
if (bsFf < 0) { leg3SellRaw += bsFf; leg4SellRaw += bsFf; }
```

Note: BS_FF = 0 falls into neither branch — correct behavior (no adjustment).

The `>` vs `>=` distinction matters: using `>=` would apply adjustment at zero, which adds zero — harmless. Using `>` correctly excludes zero. Either works numerically but `>` is semantically cleaner.

### max/min vs Conditional Implementation

The ForwardRaw function in accuracy-measurement uses the compact form:

```
raw = l1_raw - v1 - av_ff - bs_ff + max(bs_ff, 0)    // Buy
raw = l1_raw - v1 + av_ff - bs_ff + min(bs_ff, 0)    // Sell
```

Algebraic equivalence to the conditional form:

```
-bs_ff + max(bs_ff, 0) = -min(bs_ff, 0)     // identity: -x + max(x,0) = -min(x,0)
-bs_ff + min(bs_ff, 0) = -max(bs_ff, 0)     // identity: -x + min(x,0) = -max(x,0)
```

Both forms produce identical results. The implementation can use either, but the min/max form is branchless and avoids the if/else entirely.

### Recommendation

Use the min/max compact form in the .NET implementation to avoid branching errors:

```csharp
decimal leg3BuyRaw  = l1BuyRaw  - v1 - avFf - Math.Min(bsFf, 0);
decimal leg3SellRaw = l1SellRaw - v1 + avFf - Math.Max(bsFf, 0);
```

This eliminates the conditional entirely and is algebraically verified above.

---

## PART 8 — Phase 1 Scope Recommendation

### Question: Legs 1&2 reverse only, or all 4 legs?

**Recommendation: Legs 1&2 only for Phase 1.** Rationale:

1. **Legs 1&2 are algebraically simpler** — single-layer reverse, no v1/v2 chain. Lower implementation risk.

2. **BS_FF is the highest-risk area** — and it only affects Legs 3&4. Deferring it to Phase 2 means you can validate the Leg 1&2 infrastructure (snapshot capture, deviation computation, classification) before adding the BS_FF complexity.

3. **Legs 1&2 capture Timer Logic's primary effect** — Timer Logic applies to all legs, but its most impactful expansion decisions are on Legs 1&2 (the SR3|SR1 legs which are the primary quoting legs).

4. **accuracy-measurement.md already recommends this** — §10 "First Iteration Scope" explicitly specifies Legs 1&2 only for iteration 1.

5. **Cross-check available immediately** — with both Leg 1 and Leg 2 reverse active, the L1+L2 cross-check identity can validate data quality from day one.

### Phase 1 deliverables:
- Snapshot capture at QuoteFill and HedgeFill events
- ReverseToO for Legs 1 & 2 (Buy and Sell)
- ForwardRaw for Legs 1 & 2
- Deviation computation (dotnet, ase, total)
- Classification (Favorable/Acceptable/Costly/Adverse)
- CSV output + console running mean
- Cross-check: L1 + L2 implied O comparison (with corrected identity including |BS_ZQ|)

### Phase 2 deliverables:
- Legs 3 & 4 reverse (add v1/v2 + BS_FF/Av_FF chain)
- Segmented aggregation
- Attribution ratios
- Alerting

---

## PART 9 — GO / NO-GO Recommendation

### Verdict: **CONDITIONAL GO**

The core mathematics (reverse formulas, forward-reverse identity, Timer Logic mechanism) are sound and algebraically verified. The accuracy-measurement pseudocode is correct. Implementation can proceed **after the following blockers are resolved:**

**Must-fix before implementation (blockers):**

1. **ISSUE 1** — Fix execution-modifiers §5 Leg 3/4 base formulas to include −BS_FF. While price-formulas is the implementation source of truth, execution-modifiers will be used as a reference. A developer seeing conflicting formulas may implement the wrong one.

2. **ISSUE 2** — Fix accuracy-measurement §2 cross-check identity to include |BS_ZQ|. This directly affects the validation logic in the implementation.

3. **ISSUE 3** — Fix timer-logic §4 expansion examples (remove the 0.90 example, clarify the distinction between expansion parameter and raw price position).

**Must-fix before production (non-blocking for SIM):**

4. **ISSUE 5** — Verify avoidance-to-alias mapping against source code (residuals-and-convergence §6).

5. **TC-18 finding** — Implement expansion reduction during Fed window. Otherwise dynamic avoidance is partially counteracted.

6. Compute and enforce `max_safe_expansion` per contract per pricing cycle (Part 4 recommendation).

**Verified and ready:**

- All 8 reverse formulas (4 legs × buy/sell) — algebraically correct ✓
- Forward-reverse identity — exact cancellation proven ✓
- ForwardRaw function — correct ✓
- ReverseToO function — correct ✓
- Timer Logic rounding mechanism — sound ✓
- Crossed-market boundary — analyzed, guard exists ✓
- ASE rule interactions — documented with numeric examples ✓

---

## APPENDIX A — Test Case Summary Table

| ID | Category | Key Parameters | Expected Result |
|----|----------|---------------|-----------------|
| TC-01 | Forward-reverse L1 Buy | BS_ZQ=0 | O'=4.0 (identity) |
| TC-02 | Forward-reverse L2 Sell | BS_ZQ=+0.1 | O'=6.0 (identity) |
| TC-03 | Forward-reverse L3 Buy | BS_FF=+0.1, BS_ZQ=−0.1 | O'=4.0 (identity) |
| TC-04 | Forward-reverse L4 Sell | BS_FF=−0.15, BS_ZQ=+0.05 | O'=6.0 (identity) |
| TC-05 | State 1 | exp=0.05, dist=0.1 | 0 expansions |
| TC-06 | State 2 | exp=0.20 | 4 expansions (Quad) |
| TC-07 | State 3 | exp=0.45, diff=0.8 | 2 expansions (Double) |
| TC-08 | State 4 | exp=0.12 | 4 expansions (Quad) |
| TC-09 | State 5 | exp=0.35 (spike), diff=0.7 | 1 expansion on L1 (buy only) |
| TC-10 | State 6 | exp=0.18, diff=1.2 | 0 expansions (on-tick) |
| TC-11 | State 7 | exp=0.08, diff=0.92 | 1 expansion on L1 (sell only) |
| TC-12 | State 8 | exp=0.01 | 0 expansions |
| TC-13 | State 9 | exp=0.22, dist=0.18 | 2 expansions on L1 |
| TC-14 | Crossed market | W=0.5, exp=0.30 | PAUSE (Buy=Sell) |
| TC-15 | Crossed market + BS_ZQ | BS_ZQ=+0.8, exp=0.45 | PAUSE (Buy=Sell) |
| TC-16 | Double/Quad classification | exp=0.15 | Quad (4 expansions) |
| TC-17 | Legs 3&4 expansion | exp=0.15 | 0 expansions on L3/L4 |
| TC-18 | Fed window | Av_FF 0.05→0.11 | Expansion counteracts avoidance |
| TC-19 | Wide spread guard | spread>1 tick | Contract paused, Timer moot |
| TC-20 | Zero expansion | exp=0.0 | Identical to hard rounding |

---

## ADDENDUM — Findings from custom-rules-production.md, case-distribution.md, safety-mechanisms.md

*Added 2026-03-30 after supplementary documents provided.*

Documents verified in addendum updated to include: custom-rules-production.md, case-distribution.md, safety-mechanisms.md.

---

### ISSUE 8 — HIGH: Single-leg reverse-implied O overstates cost by 2× vs true O-space cost

**Location:** accuracy-measurement.md §7 (quality thresholds) vs case-distribution.md (cost column)

This is the most significant new finding. When Timer Logic expands ONE leg's price by 0.5 ticks (one ASE spread tick), two valid measures of the O-space impact exist:

**Measure A — Single-leg reverse-implied O:** Apply the reverse formula from that leg alone. Because O = 2 × (P + constants) − diff, a ΔP of +0.5 on one leg produces ΔO = 2 × 0.5 = **+1.0 in O-space**.

**Measure B — Paired-fill O cost:** The O structure requires fills on both Leg 1 AND Leg 2. Their prices sum to O (approximately): L1 + L2 ≈ O − 2×Av_ZQ. If only Leg 1 changes by +0.5, the sum changes by +0.5, so the true O cost is **+0.5**.

**Proof of discrepancy:**

```
L1_Buy_Raw = (O_Buy + diff)/2 − Av_ZQ     [expanded by +0.5]
L2_Buy_Raw = (O_Buy − diff)/2 − Av_ZQ     [unchanged]

Sum = O_Buy − 2×Av_ZQ + 0.5
True O deviation = +0.5                     ← Measure B

Reverse from L1 alone:
O_implied = 2 × ((L1_raw + 0.5) + Av_ZQ) − diff
         = 2 × (L1_raw + Av_ZQ) + 1.0 − diff
         = O_target + 1.0                   ← Measure A (2× overstatement)
```

**Impact on accuracy measurement:** The quality thresholds in accuracy-measurement §7 use single-leg reverse values:

| Quality | Threshold (buys) | Single expansion shows | True O cost |
|---------|------------------|----------------------|-------------|
| Acceptable | 0 to +0.5 | — | — |
| Costly | +0.5 to +1.0 | +1.0 ← misclassified here | +0.5 ← actually Acceptable |
| Adverse | > +1.0 | — | — |

A perfectly normal single expansion on one leg will be misclassified as "Costly" (boundary of Adverse) when the true O cost is only "Acceptable." This will bias the accuracy statistics and cause false alarms.

**Confirmation from case-distribution.md:** The case-distribution cost column uses Measure B (0.5 per single expansion), and its breakeven calculation (25% incremental threshold) is derived from the 0.5 cost figure. This is the correct economic framing — the O structure requires both legs.

**Fix options:**

1. **Recommended:** Compute accuracy metrics on paired fills (average implied O from Leg 1 and Leg 2 fills within the same reload cycle). Flag unpaired fills separately.
2. **Alternative:** Double the quality thresholds for single-leg metrics. Acceptable: 0 to +1.0. Costly: +1.0 to +2.0. Adverse: > +2.0.
3. **Minimum:** Add an explicit note in the documentation that single-leg implied O deviations are 2× the true O cost, and that thresholds should be interpreted accordingly.

---

### ISSUE 9 — MEDIUM: HitMan tick denomination needs clarification for O-space cost

**Location:** custom-rules-production.md §Rule 1 vs accuracy-measurement.md §E3

HitMan's action is: "Set quote price to Leg1.CalculatedQuoteOrderPrice {+} 1 tick."

The "1 tick" here is 1 tick on the **underlying instrument** (SR1), not 1 ASE spread tick. For SR1: 1 tick = 0.0025. Through the ASE multiplier (×100): the spread impact is 100 × 0.0025 = 0.25 ASE spread points, which is 0.5 ASE spread ticks.

accuracy-measurement E3 says: "The implied O will show ~0.5 tick worse than target." Derivation:

```
HitMan crossing: +0.0025 on SR1 → +0.25 in ASE spread domain
Reverse to O: 2 × 0.25 = 0.50 in O-space (Measure A)
True O cost: 0.25 (Measure B, since only one leg)
```

The ~0.5 figure in E3 is Measure A (single-leg reverse), not the true O cost (0.25). This is consistent with how the reverse formula works but could be confusing alongside the case-distribution's O-space costs which use Measure B.

**Recommendation:** Add a note to E3 clarifying that the 0.5 is the single-leg reverse metric. The paired-fill O cost of a HitMan cross is ~0.25.

---

### ISSUE 10 — MEDIUM: WCT Payup test case has misleading comparison note

**Location:** custom-rules-production.md §Rule 8, test case at T=0

The test case states:

> WCT check: 95.8025 − 1 tick = 95.800 ≥ 95.800 + 0.0025? **No** (equal but must be strictly ≥). **WCT blocks**.

The values are: LHS = 95.800, RHS = 95.8025. These are NOT equal (95.800 ≠ 95.8025). The comparison fails because 95.800 < 95.8025, not because of a strict-vs-non-strict issue. The parenthetical "(equal but must be strictly ≥)" is incorrect.

**Impact:** Minor — the test case RESULT is correct (WCT blocks), but the stated reasoning is wrong. A developer implementing the comparison might add unnecessary strict-inequality logic based on this note.

**Fix:** Replace the parenthetical with: "(95.800 < 95.8025, condition fails)."

---

### ISSUE 11 — LOW: case-distribution State 9 vs timer-logic State 9 — opposite ends of same dimension

**Location:** case-distribution.md Case 18 vs timer-logic.md §7 State 9

timer-logic State 9 (Implied liquidity alignment): DirectBidQty ≈ BidQty → **increase confidence** → higher expansion.

case-distribution Case 18 (Mostly Synthetic Orders): Real/Total < 65% → **zero expansion**.

These describe the same dimension (real vs implied composition) but opposite extremes. Not a contradiction, but the shared "implied liquidity" theme could confuse someone cross-referencing the two documents.

**Recommendation:** Add a cross-reference note in each document: "State 9 [timer-logic] represents the favorable end of the real-vs-implied spectrum; Case 18 [case-distribution] represents the unfavorable end."

---

### Verification of Part 5 (ASE Rule Interactions) Against Actual Rule Parameters

With custom-rules-production.md now available, I can validate the numeric examples in Part 5 of this report.

**HitMan interaction (Part 5.1):** My analysis stated "HitMan adds 1 tick aggression on the quote leg." Confirmed: Rule 1 action is "+1 tick" on Leg 1. My worked example showed the fill price at 2.5 + 1 tick = 3.0. This is in ASE spread terms, where 1 tick = 0.5. The O-space impact depends on whether the "tick" is an ASE spread tick (0.5) or an underlying tick (0.0025 × 100 = 0.25). Per the rule definition ("+1 tick" on the quote leg's CalculatedQuoteOrderPrice), this is 1 underlying tick = 0.25 spread points.

**Correction to Part 5.1:** My example overstated the HitMan crossing cost. The actual cost is 0.25 in spread terms (half an ASE spread tick), not 0.5. Revising: Timer expansion (0.5 spread) + HitMan cross (0.25 spread) = 0.75 spread ticks per leg. In O-space (Measure A): 2 × 0.75 = 1.5 ticks, not the 2.0 I originally stated. In true O-cost (Measure B): ~0.75.

**ASM interaction (Part 5.2):** Confirmed. ASM's Condition 2 checks "CalculatedQuoteOrderPrice + tick == BidPrice." When Timer Logic places the price AT the bid (expansion fired), there's no gap for ASM to close. ASM correctly doesn't fire. My analysis was accurate.

**Backoff interaction (Part 5.3):** Confirmed against Rule 6 parameters. SR3 QtyThreshold = 1000 lots, QtyRatio = 0.3, MinAvailableLiq = 80. My example used 500 lots on hedge bid, which is below the 1000-lot threshold. Path B fails. The ratio test (Path A): requires offer ≥ 0.3 × bid_behind AND offer > 80. Would need to check specific book values. My analysis correctly identified Backoff as independent of Timer Logic.

**WCT Payup interaction (Part 5.4):** Confirmed. Total payup budget is 6 ticks (5 payups + 1 WCT). The Backoff → Payup pipeline: InitialPrice = CalcPrice − 1 tick (Backoff), then WCT waits 1 more tick before engaging, then up to 5 payups. Worst case: CalcPrice − 1 + 6 = CalcPrice + 5 ticks on the hedge.

My original example stated "up to 3.0 (6 × 0.5 tick payup)." This should be: up to 6 underlying ticks = 6 × 0.0025 = 0.015 on SR3, which is 6 × 0.25 = 1.5 in spread terms. Not 3.0. The per-tick cost in spread terms depends on whether we're counting ASE spread ticks or underlying ticks.

**Clarification needed:** The "ticks" in WCT Payup are underlying instrument ticks (0.0025), not ASE spread ticks (0.5). 6 underlying ticks × 100 (multiplier) = 1.5 spread points = 3 ASE spread ticks. In O-space (Measure B): ~1.5. This is significant but not the "7.0 tick" worst case I originally stated.

---

### Verification of case-distribution.md Against timer-logic.md States

The 20 cases in case-distribution map to timer-logic's 9 states as follows:

| timer-logic State | case-distribution Cases | Consistent? |
|------------------|------------------------|-------------|
| State 1 (both thin, passive) | Case 1, 4, 5, 9 | ✓ |
| State 2 (L1 strong, L2 weak) | Case 6, 7 | ✓ (Case 6 = HitMan territory within State 2) |
| State 3 (both strong, rare) | Case 12 | ✓ (both docs flag ~2-3% frequency, anomaly detection at >5%) |
| State 4 (L1 weak, L2 strong) | Case 2, 8 | ✓ |
| State 5 (sweep aftershock) | Case 14 | ✓ (both use 0.35 expansion, 2-5 second window) |
| State 6 (book imbalance cascade) | Case 15 | ✓ (cross-leg signal, ASE rules can't see) |
| State 7 (iceberg detection) | Case 16 | ✓ (low expansion 0.05, clip size increase) |
| State 8 (stale book) | Case 9 | ✓ (zero expansion, 30+ second no-trade signal) |
| State 9 (implied alignment) | Case 18 (inverse) | ✓ (opposite extremes of same dimension) |

Additional case-distribution cases not in timer-logic states: Cases 3, 10, 11, 13, 17, 19, 20 cover momentum, gap, and event scenarios. These extend the state space rather than contradicting it. Case 20 (Fed window) explicitly confirms timer-logic §9.1 and the TC-18 finding: expansion should be zero during dynamic avoidance.

**Key calibration consistency:** case-distribution Case 12 uses expansion = 0.40, timer-logic State 3 recommends "maximum expansion." Both flag anomaly detection at >5% frequency. Case-distribution Case 1 uses 0.05, matching State 1's "conservative expansion." No numerical contradictions in the recommended expansion values.

---

### Verification Against safety-mechanisms.md

**Fill Threshold (§5):** 100-lot threshold triggers PauseAll. accuracy-measurement §11 notes "PhaseStart exclusion: 1-lot canary fills excluded from accuracy stats (ref: order-management §5)." timer-logic §9.6 notes "Fill Threshold may trigger more frequently" if Timer Logic increases fill rate. All three documents are consistent.

**Wide Spread Guard (§3):** safety-mechanisms confirms the ">1 tick → pause" guard. This matches price-formulas §2 ("If bid-ask spread exceeds 1 tick, all orders paused") and timer-logic §9.6 ("Timer Logic is moot during pauses"). Consistent.

**Dynamic Avoidance Scheduling:** safety-mechanisms §9 references `TimedParameterService` and the 12:55–13:05 window. execution-modifiers §8 specifies Av_FF → 0.11 during this window. case-distribution Case 20 confirms expansion = 0.00. All consistent, and all confirm the TC-18 finding.

**Spike Detection (§1):** Watches ZN Mar26 for 5-tick move in 2 seconds. This is a different instrument from the strategy's monitoring instruments (SR1-ZQ, ZQ calendar). case-distribution Case 17 notes: "This may not trigger the system-wide circuit breaker (which watches a different instrument and needs a 5-tick move in 2 seconds), so Timer Logic's zero-expansion acts as an additional layer of defense." Consistent and correctly identifies the coverage gap.

**Traffic Rate Limiter (§6):** 185 msg/sec per-instrument-alias. With 56ms quote throttle (~18 updates/sec), normal operation is well within limits. Timer Logic doesn't change message rate (it modifies prices, not send frequency). No interaction concern.

---

### Updated GO / NO-GO

The three new documents **reinforce** the Conditional GO from Part 9. No new blockers identified. The most significant new finding (ISSUE 8 — paired-fill cost measurement) is a calibration issue, not a formula error. It should be addressed before production accuracy reporting is used for parameter decisions, but does not block the SIM implementation.

**Updated must-fix list:**

| # | Issue | Severity | Blocks SIM? | Blocks Prod? |
|---|-------|----------|-------------|--------------|
| 1 | exec-modifiers §5 missing −BS_FF | CRITICAL | No (use price-formulas as source) | Yes (doc fix required) |
| 2 | accuracy-measurement §2 cross-check identity | HIGH | Yes (fix before implementing cross-check) | Yes |
| 3 | timer-logic §4 expansion examples | HIGH | Yes (implementor confusion risk) | Yes |
| 8 | Single-leg reverse overstates O cost by 2× | HIGH | No (stats bias, not crash) | Yes (misleading metrics) |
| 5 | residuals §6 avoidance-to-alias mapping | MEDIUM | No | Yes (verify vs source code) |
| 9 | HitMan tick denomination | MEDIUM | No | Yes (clarify docs) |
| 10 | WCT test case comparison note | LOW | No | No |
| 11 | State 9 naming across docs | LOW | No | No |
| TC-18 | Expansion during Fed window | — | No | Yes (enforce exp=0) |

## Related

### Within Jarvis
- [[timer-logic/implementation/README]] — WP-05 implementation validated by this audit
- [[fill-analysis/_index|Fill Analysis]] — Accuracy patterns potentially explained by formula errors found here
- [[market-profiling/contract-segmentation]] — Group-level accuracy affected by these findings

### Knowledge Base
- [[knowledge-base/strategy/timer-logic]] — Timer Logic specification audited
- [[knowledge-base/strategy/price-formulas-complete]] — Authoritative formula source (confirmed by this audit)
- [[knowledge-base/strategy/execution-modifiers]] — Document where CRITICAL §5 error was found
- [[knowledge-base/execution-analysis/accuracy-measurement]] — Accuracy methodology with BS_ZQ identity issue
- [[knowledge-base/strategy/residuals-and-convergence]] — Residual behavior verified in this audit
- [[knowledge-base/strategy/core-quad-leg-arbitrage]] — Quad-leg structure verified across all test cases
- [[knowledge-base/ase-rules/custom-rules-production]] — Production rules interacting with Timer Logic rounding
- [[knowledge-base/application/safety-mechanisms]] — Safety layers (PauseAll, kill switch) verified in this audit
