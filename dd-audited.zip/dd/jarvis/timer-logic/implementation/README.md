---
title: WP-05 Timer Logic Test Runner — README
wp: WP-05
status: complete
created: 2026-03-30
last-updated: 2026-03-31
lines: 79
kb-depends:
  - knowledge-base/strategy/price-formulas-complete.md
  - knowledge-base/strategy/timer-logic.md
  - knowledge-base/application/architecture-and-dataflow.md
jarvis-depends:
  - jarvis/timer-logic/verification-report.md
---

# WP-05 Test Runner — Timer Logic & Accuracy Math Validation

## Results: 151 passed, 1 failed (test case bug)

All formulas validated against the 20 test cases from WP-04 verification-report,
plus 3 supplementary tests for the critical findings.

## Files

| File | Purpose |
|------|---------|
| `TimerRounding.cs` | `HardRD`, `HardRU`, `TimerRD`, `TimerRU`, `MaxSafeExpansion`, `ClampExpansion` |
| `PriceFormulas.cs` | `ForwardRaw` (all 8 leg/side), `ReverseToO` (all 8), `CrossCheckLegs12`, `ApplyRounding` |
| `Program.cs` | Test runner — loads test-cases.json, runs all 20 TCs + 3 CF tests |
| `test-cases.json` | WP-04 test vectors (from WP04.zip) |
| `test-results.txt` | Full output from last run |

## Running

```bash
dotnet restore
dotnet run
```

No NuGet packages required — uses only `System.Text.Json` from the framework.

## Single Failure: TC-15 — Bug in Test Case

**TC-15 expected `L1_Sell_Final = 3.5` but correct value is `3.0`.**

The verification report computed L1_Sell at expansion=0.25 (where distance=0.3 > 0.25,
so RU → 3.5), then when switching to expansion=0.45, only re-evaluated the BUY side.
The sell also expands with 0.45 since 0.3 ≤ 0.45:

```
TimerRU(3.3, 0.45):
  floor = 3.0, ceil = 3.5
  x - floor = 3.3 - 3.0 = 0.3 ≤ 0.45 → floor = 3.0
```

The crossed-market detection is correct in both cases (Buy=3.5 ≥ Sell=3.0 → PAUSE).
The cross is actually **worse** than the test case suggests (inverted by 0.5, not just equal).

**Fix for test-cases.json:** Change TC-15 `L1_Sell_Final` from 3.5 to 3.0.

## WP-04 Critical Findings — All Verified

### CF-1: BS_FF cancellation (CRITICAL)
Verified that `price-formulas-complete.md` compact form (`-min(BS_FF,0)` for buys,
`-max(BS_FF,0)` for sells) correctly implements the subtract-then-add-back pattern:
- `+BS_FF` → sells shift by `-BS_FF`, buys unaffected ✓
- `-BS_FF` → buys shift by `-BS_FF` (positive), sells unaffected ✓

### CF-2: Cross-check identity with |BS_ZQ| (HIGH)
Verified corrected identity:
- `L1_Buy_Raw + L2_Buy_Raw = O_Buy - 2*Av_ZQ + |BS_ZQ|` ✓
- `L1_Sell_Raw + L2_Sell_Raw = O_Sell + 2*Av_ZQ - |BS_ZQ|` ✓
- Old identity (without `|BS_ZQ|`) diverges when `BS_ZQ ≠ 0` ✓

### CF-3: Safety clamp prevents crossed markets (HIGH)
Verified that `MaxSafeExpansionLegs12` clamps expansion to prevent crossed markets
in both TC-14 and TC-15 scenarios. Unclamped expansion correctly produces crosses.

## Key Design Decisions

- **`decimal` throughout** — no floating-point drift on the 0.5-tick grid
- **Branchless min/max compact form** for BS_FF (per WP-04 Part 7 recommendation)
- **Source of truth: `price-formulas-complete.md`** — not execution-modifiers

## Related

### Within Jarvis
- [[timer-logic/verification-report]] — WP-04 audit that drove this implementation

### Knowledge Base
- [[knowledge-base/strategy/price-formulas-complete]] — Formulas this code implements
- [[knowledge-base/strategy/timer-logic]] — Timer Logic specification
- [[knowledge-base/application/architecture-and-dataflow]] — .NET architecture this integrates into
