namespace WP05TestRunner;

/// <summary>
/// Tick-level rounding functions for ASE spread prices.
/// Tick size = 0.5 (ASE spread tick on SR3|SR1 and SR3|ZQ instruments).
/// 
/// Hard rounding = always defensive (buy down, sell up).
/// Timer rounding = evidence-conditioned: rounds toward market when
/// the raw price is within [expansion] of the aggressive tick.
/// 
/// Ref: price-formulas-complete §6, §9; timer-logic §3.
/// </summary>
public static class TimerRounding
{
    public const decimal TickSize = 0.5m;

    /// <summary>Hard round DOWN to nearest valid tick (defensive buy).</summary>
    public static decimal HardRD(decimal x)
        => Math.Floor(x / TickSize) * TickSize;

    /// <summary>Hard round UP to nearest valid tick (defensive sell).</summary>
    public static decimal HardRU(decimal x)
        => Math.Ceiling(x / TickSize) * TickSize;

    /// <summary>
    /// Timer-conditioned round for BUYS.
    /// If distance from raw price to ceiling tick ≤ expansion → round UP (toward market).
    /// Else → round DOWN (defensive).
    /// Ref: timer-logic §3, TimerRD definition.
    /// </summary>
    public static decimal TimerRD(decimal x, decimal expansion)
    {
        decimal floor = HardRD(x);
        decimal ceil  = HardRU(x);

        if (ceil == floor)
            return floor; // exactly on tick

        if ((ceil - x) <= expansion)
            return ceil;  // close enough → round toward market

        return floor;     // defensive
    }

    /// <summary>
    /// Timer-conditioned round for SELLS.
    /// If distance from raw price to floor tick ≤ expansion → round DOWN (toward market).
    /// Else → round UP (defensive).
    /// Ref: timer-logic §3, TimerRU definition.
    /// </summary>
    public static decimal TimerRU(decimal x, decimal expansion)
    {
        decimal floor = HardRD(x);
        decimal ceil  = HardRU(x);

        if (ceil == floor)
            return ceil; // exactly on tick

        if ((x - floor) <= expansion)
            return floor; // close enough → round toward market

        return ceil;      // defensive
    }

    /// <summary>
    /// Compute maximum safe expansion before crossed markets become possible.
    /// Ref: WP-04 verification-report Part 4, "Recommendation".
    /// 
    /// For Legs 1 &amp; 2:
    ///   per_leg_raw_spread = (O_Sell - O_Buy)/2 + 2*Av_ZQ - |BS_ZQ|
    ///   max_safe = (per_leg_raw_spread - 0.5) / 2    (0.5 tick safety margin)
    /// 
    /// For Legs 3 &amp; 4: adds Av_FF and BS_FF buffer:
    ///   per_leg_raw_spread += 2*Av_FF - |BS_FF|
    /// </summary>
    public static decimal MaxSafeExpansionLegs12(
        decimal oSell, decimal oBuy,
        decimal avZQ, decimal bsZQ)
    {
        decimal rawSpread = (oSell - oBuy) / 2m + 2m * avZQ - Math.Abs(bsZQ);
        decimal maxSafe   = (rawSpread - TickSize) / 2m;
        return Math.Max(maxSafe, 0m); // never negative
    }

    public static decimal MaxSafeExpansionLegs34(
        decimal oSell, decimal oBuy,
        decimal avZQ, decimal bsZQ,
        decimal avFF, decimal bsFF)
    {
        decimal rawSpread = (oSell - oBuy) / 2m
                          + 2m * avZQ - Math.Abs(bsZQ)
                          + 2m * avFF - Math.Abs(bsFF);
        decimal maxSafe   = (rawSpread - TickSize) / 2m;
        return Math.Max(maxSafe, 0m);
    }

    /// <summary>Clamp expansion to the safe boundary.</summary>
    public static decimal ClampExpansion(decimal expansion, decimal maxSafe)
        => Math.Min(expansion, maxSafe);
}
