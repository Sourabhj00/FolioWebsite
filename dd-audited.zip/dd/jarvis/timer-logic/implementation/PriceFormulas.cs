namespace WP05TestRunner;

/// <summary>
/// Forward and reverse pricing formulas for the quad-leg arbitrage.
/// 
/// SOURCE OF TRUTH: price-formulas-complete.md §4–9, §13.
/// Compact forms derived in WP-04 verification-report Part 2.
/// 
/// CRITICAL (WP-04 Issue 1): Leg 3/4 base formulas include −BS_FF.
///   Do NOT use execution-modifiers §5 — it is missing the −BS_FF term.
/// 
/// CRITICAL (WP-04 Issue 2): Cross-check identity includes |BS_ZQ|.
///   L1_Buy_Raw + L2_Buy_Raw  = O_Buy  − 2*Av_ZQ + |BS_ZQ|
///   L1_Sell_Raw + L2_Sell_Raw = O_Sell + 2*Av_ZQ − |BS_ZQ|
/// </summary>
public static class PriceFormulas
{
    // ────────────────────────────────────────────────────────
    //  ForwardRaw — compute raw leg price before rounding
    //  Ref: price-formulas-complete §4–8, WP-04 Part 2 compact forms
    // ────────────────────────────────────────────────────────

    public static decimal ForwardRaw(
        int leg, Side side,
        decimal O, decimal diff,
        decimal avZQ, decimal bsZQ,
        decimal avFF, decimal bsFF,
        decimal v1, decimal v2)
    {
        // Legs 1 & 2 — direct from O
        decimal raw;

        switch (leg)
        {
            case 1 when side == Side.Buy:
                raw = (O + diff) / 2m - avZQ + Math.Max(bsZQ, 0m);
                return raw;

            case 1 when side == Side.Sell:
                raw = (O + diff) / 2m + avZQ + Math.Min(bsZQ, 0m);
                return raw;

            case 2 when side == Side.Buy:
                raw = (O - diff) / 2m - avZQ - Math.Min(bsZQ, 0m);
                return raw;

            case 2 when side == Side.Sell:
                raw = (O - diff) / 2m + avZQ - Math.Max(bsZQ, 0m);
                return raw;

            // Legs 3 & 4 — chain through Legs 1 & 2
            // Compact form: −BS_FF + max(BS_FF,0) = −min(BS_FF,0)
            //               −BS_FF + min(BS_FF,0) = −max(BS_FF,0)
            case 3 when side == Side.Buy:
            {
                decimal l1Raw = ForwardRaw(1, Side.Buy, O, diff, avZQ, bsZQ, 0, 0, 0, 0);
                return l1Raw - v1 - avFF - Math.Min(bsFF, 0m);
            }
            case 3 when side == Side.Sell:
            {
                decimal l1Raw = ForwardRaw(1, Side.Sell, O, diff, avZQ, bsZQ, 0, 0, 0, 0);
                return l1Raw - v1 + avFF - Math.Max(bsFF, 0m);
            }
            case 4 when side == Side.Buy:
            {
                decimal l2Raw = ForwardRaw(2, Side.Buy, O, diff, avZQ, bsZQ, 0, 0, 0, 0);
                return l2Raw - v2 - avFF - Math.Min(bsFF, 0m);
            }
            case 4 when side == Side.Sell:
            {
                decimal l2Raw = ForwardRaw(2, Side.Sell, O, diff, avZQ, bsZQ, 0, 0, 0, 0);
                return l2Raw - v2 + avFF - Math.Max(bsFF, 0m);
            }
            default:
                throw new ArgumentException($"Invalid leg={leg} side={side}");
        }
    }

    // ────────────────────────────────────────────────────────
    //  ReverseToO — given fill price, recover implied O
    //  Ref: accuracy-measurement §2–3, WP-04 Part 2 reverse derivations
    // ────────────────────────────────────────────────────────

    public static decimal ReverseToO(
        int leg, Side side,
        decimal price, decimal diff,
        decimal avZQ, decimal bsZQ,
        decimal avFF, decimal bsFF,
        decimal v1, decimal v2)
    {
        decimal P = price;

        // Legs 3/4: first reverse to intermediate L1/L2 raw
        if (leg == 3)
        {
            P = side == Side.Buy
                ? P + v1 + avFF + Math.Min(bsFF, 0m)
                : P + v1 - avFF + Math.Max(bsFF, 0m);
            leg = 1; // now reverse as Leg 1
        }
        else if (leg == 4)
        {
            P = side == Side.Buy
                ? P + v2 + avFF + Math.Min(bsFF, 0m)
                : P + v2 - avFF + Math.Max(bsFF, 0m);
            leg = 2; // now reverse as Leg 2
        }

        // Legs 1/2: reverse to O
        return leg switch
        {
            1 when side == Side.Buy  => 2m * (P + avZQ - Math.Max(bsZQ, 0m)) - diff,
            1 when side == Side.Sell => 2m * (P - avZQ - Math.Min(bsZQ, 0m)) - diff,
            2 when side == Side.Buy  => 2m * (P + avZQ + Math.Min(bsZQ, 0m)) + diff,
            2 when side == Side.Sell => 2m * (P - avZQ + Math.Max(bsZQ, 0m)) + diff,
            _ => throw new ArgumentException($"Invalid leg={leg} side={side}")
        };
    }

    // ────────────────────────────────────────────────────────
    //  Cross-check identity (CORRECTED per WP-04 Issue 2)
    //  L1_Buy_Raw + L2_Buy_Raw  = O_Buy  − 2*Av_ZQ + |BS_ZQ|
    //  L1_Sell_Raw + L2_Sell_Raw = O_Sell + 2*Av_ZQ − |BS_ZQ|
    // ────────────────────────────────────────────────────────

    public static (decimal expectedSum, decimal actualSum, decimal error) CrossCheckLegs12(
        Side side,
        decimal O, decimal diff,
        decimal avZQ, decimal bsZQ)
    {
        decimal l1Raw = ForwardRaw(1, side, O, diff, avZQ, bsZQ, 0, 0, 0, 0);
        decimal l2Raw = ForwardRaw(2, side, O, diff, avZQ, bsZQ, 0, 0, 0, 0);
        decimal actualSum = l1Raw + l2Raw;

        decimal expectedSum = side == Side.Buy
            ? O - 2m * avZQ + Math.Abs(bsZQ)
            : O + 2m * avZQ - Math.Abs(bsZQ);

        return (expectedSum, actualSum, Math.Abs(expectedSum - actualSum));
    }

    // ────────────────────────────────────────────────────────
    //  Apply rounding (hard or timer) to a raw price
    // ────────────────────────────────────────────────────────

    public static decimal ApplyRounding(decimal raw, Side side, decimal expansion)
    {
        if (expansion <= 0m)
        {
            return side == Side.Buy
                ? TimerRounding.HardRD(raw)
                : TimerRounding.HardRU(raw);
        }

        return side == Side.Buy
            ? TimerRounding.TimerRD(raw, expansion)
            : TimerRounding.TimerRU(raw, expansion);
    }
}

public enum Side { Buy, Sell }
