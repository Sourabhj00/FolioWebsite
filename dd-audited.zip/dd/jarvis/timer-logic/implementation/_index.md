---
title: Timer Logic Implementation — Map of Content
wp: WP-05
status: complete
last-updated: 2026-03-31
lines: 31
---

# Timer Logic Implementation — Map of Content

WP-05 C# implementation of Timer Logic formulas with test runner.
151/152 tests passing; TC-15 failure is a test-case expected-value bug
(3.5 → 3.0), not an implementation defect. No markdown analysis in this
folder — see [[timer-logic/verification-report]] for the audit that
validated this code.

## Files

- [[timer-logic/implementation/README]] — Test runner documentation: 151/152 results, TC-15 analysis, build instructions, design decisions (decimal precision, branchless compact form). (~79 lines)

## Non-Markdown Assets

- `PriceFormulas.cs` — Forward/reverse pricing formulas for quad-leg arbitrage. Implements price-formulas-complete.md §4–9, §13. Includes −BS_FF correction. (~161 lines)
- `TimerRounding.cs` — Hard and timer-conditioned rounding. Ref: price-formulas-complete §6, §9; timer-logic §3. (~100 lines)
- `Program.cs` — Test runner harness: loads test-cases.json, runs 20 TCs across 6 categories. (~593 lines)
- `WP05TestRunner.csproj` — .NET 8.0 project file. (~16 lines)
- `test-results.txt` — Execution log: 151 passed, 1 failed (TC-15). (~172 lines)

## KB Dependencies

- [[knowledge-base/strategy/price-formulas-complete]] — Formula definitions this code implements
- [[knowledge-base/strategy/timer-logic]] — Timer Logic specification
- [[knowledge-base/application/architecture-and-dataflow]] — .NET architecture this code integrates into

## Related Folders

- [[timer-logic/_index|Timer Logic (parent)]] — Verification report and test case definitions
- [[knowledge-base/application/_index|KB: Application]] — .NET application this code extends
