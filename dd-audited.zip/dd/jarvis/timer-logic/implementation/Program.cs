using System.Text.Json;
using WP05TestRunner;

// ═══════════════════════════════════════════════════════════════
//  WP-05 Test Runner — Validates Timer Logic + Accuracy formulas
//  against WP-04 verification-report test cases (TC-01 .. TC-20)
//  and the three critical findings.
// ═══════════════════════════════════════════════════════════════

const decimal Tolerance = 0.0001m; // rounding comparison tolerance
int passed = 0, failed = 0;
var failures = new List<string>();

Console.WriteLine("══════════════════════════════════════════════════");
Console.WriteLine("  WP-05 Test Runner — Timer Logic & Accuracy Math");
Console.WriteLine("══════════════════════════════════════════════════");
Console.WriteLine();

// ── Load test cases ──────────────────────────────────────────
var json = File.ReadAllText("test-cases.json");
var testCases = JsonSerializer.Deserialize<JsonElement>(json);

foreach (var tc in testCases.EnumerateArray())
{
    string id = tc.GetProperty("id").GetString()!;
    string category = tc.GetProperty("category").GetString()!;
    var inputs = tc.GetProperty("inputs");
    var expected = tc.GetProperty("expected");

    switch (category)
    {
        case "forward-reverse-identity":
            RunForwardReverseTest(id, tc, inputs, expected);
            break;
        case "execution-state":
            RunExecutionStateTest(id, tc, inputs, expected);
            break;
        case "crossed-market":
            RunCrossedMarketTest(id, tc, inputs, expected);
            break;
        case "expansion-classification":
            RunExpansionClassificationTest(id, tc, inputs, expected);
            break;
        case "fed-window":
            RunFedWindowTest(id, tc, inputs, expected);
            break;
        case "edge-case":
            RunEdgeCaseTest(id, tc, inputs, expected);
            break;
        default:
            Console.WriteLine($"  [{id}] SKIP — unknown category '{category}'");
            break;
    }
}

Console.WriteLine();
Console.WriteLine("──────────────────────────────────────────────────");
Console.WriteLine("  Supplementary: WP-04 Critical Findings");
Console.WriteLine("──────────────────────────────────────────────────");
Console.WriteLine();

RunCriticalFinding1_BSFF();
RunCriticalFinding2_CrossCheckIdentity();
RunCriticalFinding3_SafetyClamp();

// ── Final summary ────────────────────────────────────────────
Console.WriteLine();
Console.WriteLine("══════════════════════════════════════════════════");
Console.WriteLine($"  RESULTS: {passed} passed, {failed} failed");
Console.WriteLine("══════════════════════════════════════════════════");

if (failures.Count > 0)
{
    Console.WriteLine();
    Console.WriteLine("  FAILURES:");
    foreach (var f in failures)
        Console.WriteLine($"    ✗ {f}");
}

Console.WriteLine();
return failed > 0 ? 1 : 0;


// ════════════════════════════════════════════════════════════════
//  TEST CATEGORY HANDLERS
// ════════════════════════════════════════════════════════════════

void RunForwardReverseTest(string id, JsonElement tc, JsonElement inputs, JsonElement expected)
{
    int leg   = tc.GetProperty("leg").GetInt32();
    Side side = tc.GetProperty("side").GetString() == "Buy" ? Side.Buy : Side.Sell;

    decimal O     = inputs.GetProperty("O").GetDecimal();
    decimal diff  = inputs.GetProperty("diff").GetDecimal();
    decimal avZQ  = inputs.GetProperty("Av_ZQ").GetDecimal();
    decimal bsZQ  = inputs.GetProperty("BS_ZQ").GetDecimal();
    decimal avFF  = inputs.GetProperty("Av_FF").GetDecimal();
    decimal bsFF  = inputs.GetProperty("BS_FF").GetDecimal();
    decimal v1    = inputs.GetProperty("v1").GetDecimal();
    decimal v2    = inputs.GetProperty("v2").GetDecimal();

    // Forward
    decimal raw = PriceFormulas.ForwardRaw(leg, side, O, diff, avZQ, bsZQ, avFF, bsFF, v1, v2);

    // Check intermediate values if present (Legs 3/4 have L1/L2 raw)
    if (leg == 3)
    {
        decimal parentRaw = PriceFormulas.ForwardRaw(1, side, O, diff, avZQ, bsZQ, 0, 0, 0, 0);
        CheckOptional(id, "L1_Buy_Raw", expected, parentRaw);
    }
    else if (leg == 4)
    {
        decimal parentRaw = PriceFormulas.ForwardRaw(2, side, O, diff, avZQ, bsZQ, 0, 0, 0, 0);
        CheckOptional(id, "L2_Sell_Raw", expected, parentRaw);
    }

    // Check forward_raw or leg-specific raw
    string rawKey = leg <= 2 ? "forward_raw" : $"L{leg}_{side}_Raw";
    if (expected.TryGetProperty(rawKey, out var expectedRaw))
        AssertClose(id, rawKey, raw, expectedRaw.GetDecimal());

    // Reverse
    decimal reverseO = PriceFormulas.ReverseToO(leg, side, raw, diff, avZQ, bsZQ, avFF, bsFF, v1, v2);
    decimal expectedO = expected.GetProperty("reverse_O").GetDecimal();
    AssertClose(id, "reverse_O (identity)", reverseO, expectedO);

    // Identity check
    bool identityHolds = expected.GetProperty("identity_holds").GetBoolean();
    bool actualIdentity = Math.Abs(reverseO - O) < Tolerance;
    AssertBool(id, "identity_holds", actualIdentity, identityHolds);
}

void RunExecutionStateTest(string id, JsonElement tc, JsonElement inputs, JsonElement expected)
{
    decimal oBuy  = inputs.GetProperty("O_Buy").GetDecimal();
    decimal oSell = inputs.GetProperty("O_Sell").GetDecimal();
    decimal diff  = inputs.GetProperty("diff").GetDecimal();
    decimal avZQ  = inputs.GetProperty("Av_ZQ").GetDecimal();
    decimal bsZQ  = inputs.GetProperty("BS_ZQ").GetDecimal();
    decimal exp   = inputs.GetProperty("expansion").GetDecimal();

    // Compute raw prices for Legs 1 & 2
    decimal l1BuyRaw  = PriceFormulas.ForwardRaw(1, Side.Buy,  oBuy,  diff, avZQ, bsZQ, 0, 0, 0, 0);
    decimal l1SellRaw = PriceFormulas.ForwardRaw(1, Side.Sell, oSell, diff, avZQ, bsZQ, 0, 0, 0, 0);
    decimal l2BuyRaw  = PriceFormulas.ForwardRaw(2, Side.Buy,  oBuy,  diff, avZQ, bsZQ, 0, 0, 0, 0);
    decimal l2SellRaw = PriceFormulas.ForwardRaw(2, Side.Sell, oSell, diff, avZQ, bsZQ, 0, 0, 0, 0);

    // Check raw prices where expected
    CheckOptional(id, "L1_Buy_Raw",  expected, l1BuyRaw);
    CheckOptional(id, "L1_Sell_Raw", expected, l1SellRaw);
    CheckOptional(id, "L2_Buy_Raw",  expected, l2BuyRaw);
    CheckOptional(id, "L2_Sell_Raw", expected, l2SellRaw);

    // Apply rounding
    decimal l1BuyFinal  = PriceFormulas.ApplyRounding(l1BuyRaw,  Side.Buy,  exp);
    decimal l1SellFinal = PriceFormulas.ApplyRounding(l1SellRaw, Side.Sell, exp);
    decimal l2BuyFinal  = PriceFormulas.ApplyRounding(l2BuyRaw,  Side.Buy,  exp);
    decimal l2SellFinal = PriceFormulas.ApplyRounding(l2SellRaw, Side.Sell, exp);

    CheckOptional(id, "L1_Buy_Final",  expected, l1BuyFinal);
    CheckOptional(id, "L1_Sell_Final", expected, l1SellFinal);
    CheckOptional(id, "L2_Buy_Final",  expected, l2BuyFinal);
    CheckOptional(id, "L2_Sell_Final", expected, l2SellFinal);

    // Expansion count
    int expansionCount = 0;
    if (l1BuyFinal  != TimerRounding.HardRD(l1BuyRaw))  expansionCount++;
    if (l1SellFinal != TimerRounding.HardRU(l1SellRaw)) expansionCount++;
    if (l2BuyFinal  != TimerRounding.HardRD(l2BuyRaw))  expansionCount++;
    if (l2SellFinal != TimerRounding.HardRU(l2SellRaw)) expansionCount++;

    if (expected.TryGetProperty("expansion_count", out var expCount))
        AssertEqual(id, "expansion_count", expansionCount, expCount.GetInt32());

    // Per-leg expansion counts
    if (expected.TryGetProperty("expansion_count_L1", out var l1Count))
    {
        int l1Exp = 0;
        if (l1BuyFinal  != TimerRounding.HardRD(l1BuyRaw))  l1Exp++;
        if (l1SellFinal != TimerRounding.HardRU(l1SellRaw)) l1Exp++;
        AssertEqual(id, "expansion_count_L1", l1Exp, l1Count.GetInt32());
    }

    // Crossed market check
    bool l1Crossed = l1BuyFinal >= l1SellFinal;
    bool l2Crossed = l2BuyFinal >= l2SellFinal;
    CheckOptionalBool(id, "L1_crossed", expected, l1Crossed);
    CheckOptionalBool(id, "L2_crossed", expected, l2Crossed);

    // Distances
    CheckOptional(id, "L1_Buy_dist_to_ceil", expected,
        TimerRounding.HardRU(l1BuyRaw) == TimerRounding.HardRD(l1BuyRaw) ? 0m : TimerRounding.HardRU(l1BuyRaw) - l1BuyRaw);
    CheckOptional(id, "L1_Sell_dist_to_floor", expected,
        TimerRounding.HardRU(l1SellRaw) == TimerRounding.HardRD(l1SellRaw) ? 0m : l1SellRaw - TimerRounding.HardRD(l1SellRaw));
    CheckOptional(id, "L1_Buy_dist", expected,
        TimerRounding.HardRU(l1BuyRaw) == TimerRounding.HardRD(l1BuyRaw) ? 0m : TimerRounding.HardRU(l1BuyRaw) - l1BuyRaw);
    CheckOptional(id, "L1_Sell_dist", expected,
        TimerRounding.HardRU(l1SellRaw) == TimerRounding.HardRD(l1SellRaw) ? 0m : l1SellRaw - TimerRounding.HardRD(l1SellRaw));

    // Spread checks
    if (expected.TryGetProperty("L1_spread_final", out var l1Spread))
        AssertClose(id, "L1_spread_final", l1SellFinal - l1BuyFinal, l1Spread.GetDecimal());
}

void RunCrossedMarketTest(string id, JsonElement tc, JsonElement inputs, JsonElement expected)
{
    decimal oBuy  = inputs.GetProperty("O_Buy").GetDecimal();
    decimal oSell = inputs.GetProperty("O_Sell").GetDecimal();
    decimal diff  = inputs.GetProperty("diff").GetDecimal();
    decimal avZQ  = inputs.GetProperty("Av_ZQ").GetDecimal();
    decimal bsZQ  = inputs.GetProperty("BS_ZQ").GetDecimal();
    decimal exp   = inputs.GetProperty("expansion").GetDecimal();

    decimal l1BuyRaw  = PriceFormulas.ForwardRaw(1, Side.Buy,  oBuy,  diff, avZQ, bsZQ, 0, 0, 0, 0);
    decimal l1SellRaw = PriceFormulas.ForwardRaw(1, Side.Sell, oSell, diff, avZQ, bsZQ, 0, 0, 0, 0);

    CheckOptional(id, "L1_Buy_Raw",  expected, l1BuyRaw);
    CheckOptional(id, "L1_Sell_Raw", expected, l1SellRaw);

    decimal l1BuyFinal  = PriceFormulas.ApplyRounding(l1BuyRaw,  Side.Buy,  exp);
    decimal l1SellFinal = PriceFormulas.ApplyRounding(l1SellRaw, Side.Sell, exp);

    CheckOptional(id, "L1_Buy_Final",  expected, l1BuyFinal);
    CheckOptional(id, "L1_Sell_Final", expected, l1SellFinal);

    bool crossed = l1BuyFinal >= l1SellFinal;
    if (expected.TryGetProperty("L1_buy_geq_sell", out var expCrossed))
        AssertBool(id, "L1_buy_geq_sell (crossed)", crossed, expCrossed.GetBoolean());

    if (expected.TryGetProperty("action", out var action))
    {
        string expectedAction = action.GetString()!;
        string actualAction = crossed ? "PAUSE" : "OK";
        AssertStringEqual(id, "action", actualAction, expectedAction);
    }

    if (expected.TryGetProperty("raw_spread", out var rawSpread))
        AssertClose(id, "raw_spread", l1SellRaw - l1BuyRaw, rawSpread.GetDecimal());
}

void RunExpansionClassificationTest(string id, JsonElement tc, JsonElement inputs, JsonElement expected)
{
    decimal oBuy  = inputs.GetProperty("O_Buy").GetDecimal();
    decimal oSell = inputs.GetProperty("O_Sell").GetDecimal();
    decimal diff  = inputs.GetProperty("diff").GetDecimal();
    decimal avZQ  = inputs.GetProperty("Av_ZQ").GetDecimal();
    decimal bsZQ  = inputs.GetProperty("BS_ZQ").GetDecimal();
    decimal exp   = inputs.GetProperty("expansion").GetDecimal();

    // Legs 1 & 2
    decimal l1BuyRaw  = PriceFormulas.ForwardRaw(1, Side.Buy,  oBuy,  diff, avZQ, bsZQ, 0, 0, 0, 0);
    decimal l1SellRaw = PriceFormulas.ForwardRaw(1, Side.Sell, oSell, diff, avZQ, bsZQ, 0, 0, 0, 0);
    decimal l2BuyRaw  = PriceFormulas.ForwardRaw(2, Side.Buy,  oBuy,  diff, avZQ, bsZQ, 0, 0, 0, 0);
    decimal l2SellRaw = PriceFormulas.ForwardRaw(2, Side.Sell, oSell, diff, avZQ, bsZQ, 0, 0, 0, 0);

    CheckOptional(id, "L1_Buy_Raw",  expected, l1BuyRaw);
    CheckOptional(id, "L1_Sell_Raw", expected, l1SellRaw);
    CheckOptional(id, "L2_Buy_Raw",  expected, l2BuyRaw);
    CheckOptional(id, "L2_Sell_Raw", expected, l2SellRaw);

    int expCount12 = 0;
    decimal l1BuyFinal  = PriceFormulas.ApplyRounding(l1BuyRaw,  Side.Buy,  exp);
    decimal l1SellFinal = PriceFormulas.ApplyRounding(l1SellRaw, Side.Sell, exp);
    decimal l2BuyFinal  = PriceFormulas.ApplyRounding(l2BuyRaw,  Side.Buy,  exp);
    decimal l2SellFinal = PriceFormulas.ApplyRounding(l2SellRaw, Side.Sell, exp);

    if (l1BuyFinal  != TimerRounding.HardRD(l1BuyRaw))  expCount12++;
    if (l1SellFinal != TimerRounding.HardRU(l1SellRaw)) expCount12++;
    if (l2BuyFinal  != TimerRounding.HardRD(l2BuyRaw))  expCount12++;
    if (l2SellFinal != TimerRounding.HardRU(l2SellRaw)) expCount12++;

    if (expected.TryGetProperty("expansion_count", out var ec))
        AssertEqual(id, "expansion_count (L1+L2)", expCount12, ec.GetInt32());

    // Legs 3 & 4 if inputs available
    if (inputs.TryGetProperty("Av_FF", out _))
    {
        decimal avFF = inputs.GetProperty("Av_FF").GetDecimal();
        decimal bsFF = inputs.GetProperty("BS_FF").GetDecimal();
        decimal v1   = inputs.GetProperty("v1").GetDecimal();
        decimal v2   = inputs.GetProperty("v2").GetDecimal();

        decimal l3BuyRaw  = PriceFormulas.ForwardRaw(3, Side.Buy,  oBuy,  diff, avZQ, bsZQ, avFF, bsFF, v1, v2);
        decimal l3SellRaw = PriceFormulas.ForwardRaw(3, Side.Sell, oSell, diff, avZQ, bsZQ, avFF, bsFF, v1, v2);
        decimal l4BuyRaw  = PriceFormulas.ForwardRaw(4, Side.Buy,  oBuy,  diff, avZQ, bsZQ, avFF, bsFF, v1, v2);
        decimal l4SellRaw = PriceFormulas.ForwardRaw(4, Side.Sell, oSell, diff, avZQ, bsZQ, avFF, bsFF, v1, v2);

        CheckOptional(id, "L3_Buy_Raw",  expected, l3BuyRaw);
        CheckOptional(id, "L3_Sell_Raw", expected, l3SellRaw);
        CheckOptional(id, "L4_Buy_Raw",  expected, l4BuyRaw);
        CheckOptional(id, "L4_Sell_Raw", expected, l4SellRaw);

        // Distances — for buys, distance to ceil; for sells, distance to floor
        CheckOptional(id, "L3_Buy_dist",  expected,
            TimerRounding.HardRU(l3BuyRaw) == TimerRounding.HardRD(l3BuyRaw) ? 0m : TimerRounding.HardRU(l3BuyRaw) - l3BuyRaw);
        CheckOptional(id, "L3_Sell_dist", expected,
            TimerRounding.HardRU(l3SellRaw) == TimerRounding.HardRD(l3SellRaw) ? 0m : l3SellRaw - TimerRounding.HardRD(l3SellRaw));
        CheckOptional(id, "L4_Buy_dist",  expected,
            TimerRounding.HardRU(l4BuyRaw) == TimerRounding.HardRD(l4BuyRaw) ? 0m : TimerRounding.HardRU(l4BuyRaw) - l4BuyRaw);
        CheckOptional(id, "L4_Sell_dist", expected,
            TimerRounding.HardRU(l4SellRaw) == TimerRounding.HardRD(l4SellRaw) ? 0m : l4SellRaw - TimerRounding.HardRD(l4SellRaw));

        // Finals
        decimal l3BuyFinal  = PriceFormulas.ApplyRounding(l3BuyRaw,  Side.Buy,  exp);
        decimal l3SellFinal = PriceFormulas.ApplyRounding(l3SellRaw, Side.Sell, exp);
        decimal l4BuyFinal  = PriceFormulas.ApplyRounding(l4BuyRaw,  Side.Buy,  exp);
        decimal l4SellFinal = PriceFormulas.ApplyRounding(l4SellRaw, Side.Sell, exp);

        CheckOptional(id, "L3_Buy_Final",  expected, l3BuyFinal);
        CheckOptional(id, "L3_Sell_Final", expected, l3SellFinal);
        CheckOptional(id, "L4_Buy_Final",  expected, l4BuyFinal);
        CheckOptional(id, "L4_Sell_Final", expected, l4SellFinal);

        int l3Exp = 0, l4Exp = 0;
        if (l3BuyFinal  != TimerRounding.HardRD(l3BuyRaw))  l3Exp++;
        if (l3SellFinal != TimerRounding.HardRU(l3SellRaw)) l3Exp++;
        if (l4BuyFinal  != TimerRounding.HardRD(l4BuyRaw))  l4Exp++;
        if (l4SellFinal != TimerRounding.HardRU(l4SellRaw)) l4Exp++;

        if (expected.TryGetProperty("L3_expansion_count", out var l3ec))
            AssertEqual(id, "L3_expansion_count", l3Exp, l3ec.GetInt32());
        if (expected.TryGetProperty("L4_expansion_count", out var l4ec))
            AssertEqual(id, "L4_expansion_count", l4Exp, l4ec.GetInt32());
    }
}

void RunFedWindowTest(string id, JsonElement tc, JsonElement inputs, JsonElement expected)
{
    decimal oBuy  = inputs.GetProperty("O_Buy").GetDecimal();
    decimal diff  = inputs.GetProperty("diff").GetDecimal();
    decimal avZQ  = inputs.GetProperty("Av_ZQ").GetDecimal();
    decimal bsZQ  = inputs.GetProperty("BS_ZQ").GetDecimal();
    decimal exp   = inputs.GetProperty("expansion").GetDecimal();
    decimal v1    = inputs.GetProperty("v1").GetDecimal();
    decimal avFFNormal = inputs.GetProperty("Av_FF_normal").GetDecimal();
    decimal avFFWindow = inputs.GetProperty("Av_FF_fed_window").GetDecimal();

    // Pre-window
    var preWindow = expected.GetProperty("pre_window");
    decimal l1BuyRaw = PriceFormulas.ForwardRaw(1, Side.Buy, oBuy, diff, avZQ, bsZQ, 0, 0, 0, 0);
    decimal l3BuyRawPre = l1BuyRaw - v1 - avFFNormal; // BS_FF=0

    AssertClose(id, "pre_window.L3_Buy_Raw", l3BuyRawPre, preWindow.GetProperty("L3_Buy_Raw").GetDecimal());
    AssertClose(id, "pre_window.L3_Buy_Hard", TimerRounding.HardRD(l3BuyRawPre),
        preWindow.GetProperty("L3_Buy_Hard").GetDecimal());
    AssertClose(id, "pre_window.L3_Buy_Timer", TimerRounding.TimerRD(l3BuyRawPre, exp),
        preWindow.GetProperty("L3_Buy_Timer").GetDecimal());

    // During window
    var duringWindow = expected.GetProperty("during_window");
    decimal l3BuyRawDuring = l1BuyRaw - v1 - avFFWindow; // BS_FF=0

    AssertClose(id, "during_window.L3_Buy_Raw", l3BuyRawDuring,
        duringWindow.GetProperty("L3_Buy_Raw").GetDecimal());
    AssertClose(id, "during_window.L3_Buy_Hard", TimerRounding.HardRD(l3BuyRawDuring),
        duringWindow.GetProperty("L3_Buy_Hard").GetDecimal());
    AssertClose(id, "during_window.L3_Buy_Timer", TimerRounding.TimerRD(l3BuyRawDuring, exp),
        duringWindow.GetProperty("L3_Buy_Timer").GetDecimal());
}

void RunEdgeCaseTest(string id, JsonElement tc, JsonElement inputs, JsonElement expected)
{
    string desc = tc.GetProperty("description").GetString()!;

    if (desc.Contains("Wide spread guard"))
    {
        // TC-19: Conceptual — verify guard fires when spread > threshold
        if (expected.TryGetProperty("contract_paused", out var paused))
        {
            decimal spread = inputs.GetProperty("monitoring_instrument_spread").GetDecimal();
            decimal threshold = inputs.GetProperty("guard_threshold").GetDecimal();
            bool shouldPause = spread > threshold;
            AssertBool(id, "contract_paused", shouldPause, paused.GetBoolean());
        }
        return;
    }

    if (desc.Contains("Zero expansion"))
    {
        // TC-20: expansion=0 ≡ hard rounding
        decimal oBuy  = inputs.GetProperty("O_Buy").GetDecimal();
        decimal oSell = inputs.GetProperty("O_Sell").GetDecimal();
        decimal diff  = inputs.GetProperty("diff").GetDecimal();
        decimal avZQ  = inputs.GetProperty("Av_ZQ").GetDecimal();
        decimal bsZQ  = inputs.GetProperty("BS_ZQ").GetDecimal();
        decimal exp   = inputs.GetProperty("expansion").GetDecimal(); // 0.0

        decimal l1BuyRaw  = PriceFormulas.ForwardRaw(1, Side.Buy,  oBuy,  diff, avZQ, bsZQ, 0, 0, 0, 0);
        decimal l1SellRaw = PriceFormulas.ForwardRaw(1, Side.Sell, oSell, diff, avZQ, bsZQ, 0, 0, 0, 0);
        decimal l2BuyRaw  = PriceFormulas.ForwardRaw(2, Side.Buy,  oBuy,  diff, avZQ, bsZQ, 0, 0, 0, 0);
        decimal l2SellRaw = PriceFormulas.ForwardRaw(2, Side.Sell, oSell, diff, avZQ, bsZQ, 0, 0, 0, 0);

        // Timer(0) must equal Hard
        AssertClose(id, "L1_Buy  Timer==Hard", TimerRounding.TimerRD(l1BuyRaw,  exp), TimerRounding.HardRD(l1BuyRaw));
        AssertClose(id, "L1_Sell Timer==Hard", TimerRounding.TimerRU(l1SellRaw, exp), TimerRounding.HardRU(l1SellRaw));
        AssertClose(id, "L2_Buy  Timer==Hard", TimerRounding.TimerRD(l2BuyRaw,  exp), TimerRounding.HardRD(l2BuyRaw));
        AssertClose(id, "L2_Sell Timer==Hard", TimerRounding.TimerRU(l2SellRaw, exp), TimerRounding.HardRU(l2SellRaw));

        // Check expected values
        CheckOptional(id, "L1_Buy_TimerRD",  expected, TimerRounding.TimerRD(l1BuyRaw, exp));
        CheckOptional(id, "L1_Buy_HardRD",   expected, TimerRounding.HardRD(l1BuyRaw));
        CheckOptional(id, "L1_Sell_TimerRU",  expected, TimerRounding.TimerRU(l1SellRaw, exp));
        CheckOptional(id, "L1_Sell_HardRU",   expected, TimerRounding.HardRU(l1SellRaw));
        CheckOptional(id, "L2_Buy_TimerRD",   expected, TimerRounding.TimerRD(l2BuyRaw, exp));
        CheckOptional(id, "L2_Buy_HardRD",    expected, TimerRounding.HardRD(l2BuyRaw));
        CheckOptional(id, "L2_Sell_TimerRU",  expected, TimerRounding.TimerRU(l2SellRaw, exp));
        CheckOptional(id, "L2_Sell_HardRU",   expected, TimerRounding.HardRU(l2SellRaw));

        if (expected.TryGetProperty("all_match", out var allMatch))
            AssertBool(id, "all_match", true, allMatch.GetBoolean());
    }
}


// ════════════════════════════════════════════════════════════════
//  SUPPLEMENTARY: WP-04 Critical Findings
// ════════════════════════════════════════════════════════════════

void RunCriticalFinding1_BSFF()
{
    // WP-04 Issue 1: BS_FF cancellation mechanism.
    // +BS_FF (sell bias) → sells shift by −BS_FF, buys unaffected.
    // −BS_FF (buy bias)  → buys shift by −BS_FF (positive), sells unaffected.

    Console.WriteLine("  CF-1: BS_FF cancellation (price-formulas vs execution-modifiers)");

    decimal O = 4.0m, diff = 1.0m, avZQ = 0.1m, bsZQ = 0m;
    decimal avFF = 0.05m, v1 = 0.3m, v2 = 0.2m;

    // Without BS_FF
    decimal l3Buy_noBias  = PriceFormulas.ForwardRaw(3, Side.Buy,  O, diff, avZQ, bsZQ, avFF, 0m, v1, v2);
    decimal l3Sell_noBias = PriceFormulas.ForwardRaw(3, Side.Sell, O + 2m, diff, avZQ, bsZQ, avFF, 0m, v1, v2);

    // BS_FF = +0.1 (sell bias → sells more aggressive, buys unaffected)
    decimal bsFF = 0.1m;
    decimal l3Buy_bias  = PriceFormulas.ForwardRaw(3, Side.Buy,  O, diff, avZQ, bsZQ, avFF, bsFF, v1, v2);
    decimal l3Sell_bias = PriceFormulas.ForwardRaw(3, Side.Sell, O + 2m, diff, avZQ, bsZQ, avFF, bsFF, v1, v2);

    AssertClose("CF-1a", "L3_Buy unchanged by +BS_FF", l3Buy_bias, l3Buy_noBias);
    AssertClose("CF-1b", "L3_Sell shifted by -BS_FF", l3Sell_bias, l3Sell_noBias - bsFF);

    // BS_FF = -0.15 (buy bias → buys more aggressive, sells unaffected)
    bsFF = -0.15m;
    decimal l3Buy_negBias  = PriceFormulas.ForwardRaw(3, Side.Buy,  O, diff, avZQ, bsZQ, avFF, bsFF, v1, v2);
    decimal l3Sell_negBias = PriceFormulas.ForwardRaw(3, Side.Sell, O + 2m, diff, avZQ, bsZQ, avFF, bsFF, v1, v2);

    AssertClose("CF-1c", "L3_Sell unchanged by -BS_FF", l3Sell_negBias, l3Sell_noBias);
    AssertClose("CF-1d", "L3_Buy shifted by -BS_FF (+0.15)", l3Buy_negBias, l3Buy_noBias - bsFF);
}

void RunCriticalFinding2_CrossCheckIdentity()
{
    Console.WriteLine("  CF-2: Cross-check identity with |BS_ZQ|");

    decimal diff = 1.0m, avZQ = 0.1m;

    // BS_ZQ = 0 (original identity happens to work)
    var (expA, actA, _) = PriceFormulas.CrossCheckLegs12(Side.Buy, 4.0m, diff, avZQ, 0m);
    AssertClose("CF-2a", "Buy sum (BS_ZQ=0)", actA, expA);

    // BS_ZQ = +0.1 — corrected identity includes |BS_ZQ|
    var (expB, actB, _) = PriceFormulas.CrossCheckLegs12(Side.Buy, 4.0m, diff, avZQ, 0.1m);
    AssertClose("CF-2b", "Buy sum (BS_ZQ=+0.1)", actB, expB);

    // Verify the WRONG identity (without |BS_ZQ|) fails
    decimal wrongSum = 4.0m - 2m * 0.1m; // 3.8
    bool wrongDiverges = Math.Abs(actB - wrongSum) > Tolerance;
    AssertBool("CF-2c", "Old identity diverges when BS_ZQ≠0", wrongDiverges, true);

    // BS_ZQ = -0.1
    var (expC, actC, _) = PriceFormulas.CrossCheckLegs12(Side.Buy, 4.0m, diff, avZQ, -0.1m);
    AssertClose("CF-2d", "Buy sum (BS_ZQ=-0.1)", actC, expC);

    // Sells
    var (expD, actD, _) = PriceFormulas.CrossCheckLegs12(Side.Sell, 6.0m, diff, avZQ, 0.1m);
    AssertClose("CF-2e", "Sell sum (BS_ZQ=+0.1)", actD, expD);
}

void RunCriticalFinding3_SafetyClamp()
{
    Console.WriteLine("  CF-3: Safety clamp prevents crossed markets");

    // TC-14 scenario: narrow O spread, expansion would cross without clamp
    decimal maxSafe14 = TimerRounding.MaxSafeExpansionLegs12(6.0m, 5.5m, 0m, 0m);
    decimal clamped14 = TimerRounding.ClampExpansion(0.30m, maxSafe14);

    decimal l1BuyRaw14  = PriceFormulas.ForwardRaw(1, Side.Buy,  5.5m, 0.9m, 0m, 0m, 0, 0, 0, 0);
    decimal l1SellRaw14 = PriceFormulas.ForwardRaw(1, Side.Sell, 6.0m, 0.9m, 0m, 0m, 0, 0, 0, 0);
    decimal l1BuyF14  = PriceFormulas.ApplyRounding(l1BuyRaw14,  Side.Buy,  clamped14);
    decimal l1SellF14 = PriceFormulas.ApplyRounding(l1SellRaw14, Side.Sell, clamped14);

    AssertBool("CF-3a", $"Clamped exp={clamped14:F3} prevents cross (maxSafe={maxSafe14:F3})",
        l1BuyF14 < l1SellF14, true);

    // TC-15 scenario: large BS_ZQ compresses raw spread
    decimal maxSafe15 = TimerRounding.MaxSafeExpansionLegs12(6.0m, 4.0m, 0m, 0.8m);
    decimal clamped15 = TimerRounding.ClampExpansion(0.45m, maxSafe15);

    decimal l1BuyRaw15  = PriceFormulas.ForwardRaw(1, Side.Buy,  4.0m, 0.6m, 0m, 0.8m, 0, 0, 0, 0);
    decimal l1SellRaw15 = PriceFormulas.ForwardRaw(1, Side.Sell, 6.0m, 0.6m, 0m, 0.8m, 0, 0, 0, 0);
    decimal l1BuyF15  = PriceFormulas.ApplyRounding(l1BuyRaw15,  Side.Buy,  clamped15);
    decimal l1SellF15 = PriceFormulas.ApplyRounding(l1SellRaw15, Side.Sell, clamped15);

    AssertBool("CF-3b", $"Clamped exp={clamped15:F3} prevents cross with BS_ZQ=0.8 (maxSafe={maxSafe15:F3})",
        l1BuyF15 < l1SellF15, true);

    // Verify the UNCLAMPED expansion WOULD have crossed
    decimal l1BuyUnclamped  = PriceFormulas.ApplyRounding(l1BuyRaw15,  Side.Buy,  0.45m);
    decimal l1SellUnclamped = PriceFormulas.ApplyRounding(l1SellRaw15, Side.Sell, 0.45m);
    AssertBool("CF-3c", "Unclamped 0.45 WOULD cross with BS_ZQ=0.8",
        l1BuyUnclamped >= l1SellUnclamped, true);
}


// ════════════════════════════════════════════════════════════════
//  ASSERTION HELPERS
// ════════════════════════════════════════════════════════════════

void AssertClose(string testId, string label, decimal actual, decimal expected)
{
    if (Math.Abs(actual - expected) < Tolerance)
    {
        passed++;
        Console.WriteLine($"  [{testId}] ✓ {label} = {actual}");
    }
    else
    {
        failed++;
        string msg = $"[{testId}] {label}: expected {expected}, got {actual} (Δ={actual - expected})";
        failures.Add(msg);
        Console.WriteLine($"  [{testId}] ✗ {label}: expected {expected}, got {actual}");
    }
}

void AssertEqual(string testId, string label, int actual, int expected)
{
    if (actual == expected)
    {
        passed++;
        Console.WriteLine($"  [{testId}] ✓ {label} = {actual}");
    }
    else
    {
        failed++;
        string msg = $"[{testId}] {label}: expected {expected}, got {actual}";
        failures.Add(msg);
        Console.WriteLine($"  [{testId}] ✗ {label}: expected {expected}, got {actual}");
    }
}

void AssertBool(string testId, string label, bool actual, bool expected)
{
    if (actual == expected)
    {
        passed++;
        Console.WriteLine($"  [{testId}] ✓ {label} = {actual}");
    }
    else
    {
        failed++;
        string msg = $"[{testId}] {label}: expected {expected}, got {actual}";
        failures.Add(msg);
        Console.WriteLine($"  [{testId}] ✗ {label}: expected {expected}, got {actual}");
    }
}

void AssertStringEqual(string testId, string label, string actual, string expected)
{
    if (actual == expected)
    {
        passed++;
        Console.WriteLine($"  [{testId}] ✓ {label} = {actual}");
    }
    else
    {
        failed++;
        string msg = $"[{testId}] {label}: expected '{expected}', got '{actual}'";
        failures.Add(msg);
        Console.WriteLine($"  [{testId}] ✗ {label}: expected '{expected}', got '{actual}'");
    }
}

void CheckOptional(string testId, string key, JsonElement expected, decimal actual)
{
    if (expected.TryGetProperty(key, out var val))
        AssertClose(testId, key, actual, val.GetDecimal());
}

void CheckOptionalBool(string testId, string key, JsonElement expected, bool actual)
{
    if (expected.TryGetProperty(key, out var val))
        AssertBool(testId, key, actual, val.GetBoolean());
}
