---
title: Timer Logic — Map of Content
wp: WP-04, WP-05
status: complete
last-updated: 2026-03-31
lines: 40
---

# Timer Logic — Map of Content

WP-04 pre-implementation verification (formula audit across 9 KB documents,
20 test cases, crossed-market analysis) plus WP-05 .NET implementation
(C# code, 151/152 tests passing). Critical finding: execution-modifiers.md §5
is MISSING the −BS_FF term in Leg 3/4 base formulas — use
price-formulas-complete.md as sole formula source.
(~1,438 lines of markdown + ~854 lines of C# + ~515 lines of test data)

## Files

- [[verification-report]] — Pre-implementation formula audit: 4 severity-ranked cross-document issues (CRITICAL: execution-modifiers §5 missing −BS_FF, HIGH: BS_ZQ identity wrong when ≠ 0, HIGH: timer-logic §4 expansion bounds, MEDIUM: three-way decomposition gap), algebraic proofs, impact analysis. (~1,359 lines)
- [[implementation/README]] — WP-05 test runner documentation: 151/152 pass results, TC-15 failure analysis (expected value bug: 3.5 → 3.0), build instructions, key design decisions. (~79 lines)

## Non-Markdown Assets

- `test-cases.json` — 20 WP-04 verification test cases across 6 categories: forward-reverse identity, execution-state, crossed-market, expansion-classification, fed-window, edge-case. (~515 lines)
- `implementation/PriceFormulas.cs` — Forward and reverse pricing formulas implementing price-formulas-complete.md §4–9, §13. Includes −BS_FF correction absent from execution-modifiers. (~161 lines)
- `implementation/TimerRounding.cs` — Tick-level rounding: hard rounding (defensive) and timer-conditioned rounding (evidence-based). Ref: price-formulas-complete §6, §9. (~100 lines)
- `implementation/Program.cs` — WP-05 test runner harness: loads test-cases.json, executes 20 TCs, validates Timer Logic + accuracy math. (~593 lines)
- `implementation/WP05TestRunner.csproj` — .NET 8.0 project file.
- `implementation/test-results.txt` — Latest test execution log: 151 passed, 1 failed (TC-15). (~172 lines)

## KB Dependencies

- [[knowledge-base/strategy/timer-logic]] — Authoritative Timer Logic specification this code implements
- [[knowledge-base/strategy/price-formulas-complete]] — Sole authoritative formula source (overrides execution-modifiers §5)
- [[knowledge-base/strategy/execution-modifiers]] — Document with CRITICAL §5 error found by WP-04 audit
- [[knowledge-base/application/safety-mechanisms]] — Safety layers the implementation must respect
- [[knowledge-base/execution-analysis/accuracy-measurement]] — Accuracy methodology audited by WP-04 (HIGH: BS_ZQ identity issue)
- [[knowledge-base/ase-rules/custom-rules-production]] — Production rules interacting with Timer Logic rounding

## Related Folders

- [[fill-analysis/_index|Fill Analysis]] — Accuracy data potentially explained by formula corrections found here
- [[fair-value/_index|Fair Value]] — Pricing methodology that feeds Timer Logic inputs
- [[market-profiling/_index|Market Profiling]] — Contract groups with different accuracy patterns
- [[plan/_index|Plan]] — WP-04/05 completion status and TC-15 blocker tracking
- [[knowledge-base/strategy/_index|KB: Strategy]] — Authoritative strategy specs this implements
