---
title: ORE Class Map — Library Structure
wp: n/a
status: reference
created: unknown
last-updated: 2026-03-31
lines: 92
kb-depends: []
jarvis-depends: []
---

# ORE Class Map — Detail

## ORE Library Structure
```
ORE/
├── QuantExt/qle/     — Pricing extensions to QuantLib
├── OREData/ored/     — Data management, XML trades, market config
├── OREAnalytics/orea/ — Risk analytics, XVA, simulation
└── App/              — Command-line ORE application
```

## QuantExt Instruments (`qle/instruments/`)
### Cross-Currency
`CrossCcySwap` → `CrossCcyBasisSwap`, `CrossCcyBasisMtMResetSwap`, `CrossCcyFixFloatSwap`, `CrossCcyFixFloatMtMResetSwap`

### Rate
`AverageOIS`, `SubPeriodsSwap`, `TenorBasisSwap`, `FlexiSwap`, `BalanceGuaranteedSwap`, `Deposit`, `BRLCdiSwap`

### Bond/Repo
`BondTRS`, `ForwardBond`, `BondRepo`, `BondFuture`, `BondOption`, `CallableBond`, `ConvertibleBond2`, `Ascot`

### Credit
`IndexCreditDefaultSwap`, `CdsOption`, `IndexCdsOption`, `CreditLinkedSwap`, `SyntheticCDO`, `CBO`, `RiskParticipationAgreement`

### Equity/Commodity
`EquityForward`, `CommodityForward`, `CommodityAveragePriceOption`, `CommoditySpreadOption`, `OutperformanceOption`

### Other
`FxForward`, `CurrencySwap`, `GenericSwaption`, `Payment`, `MultiLegOption`, `CashPosition`, `NullInstrument`

## QuantExt Term Structures (`qle/termstructures/`)
### Yield Curve Helpers
`CrossCcyBasisSwapHelper`, `CrossCcyBasisMtMResetSwapHelper`, `AverageOISRateHelper`, `OISCapFloorHelper`, `TenorBasisSwapHelper`

### Vol Surfaces
`ProxySwaptionVolatility`, `DynamicSwaptionVolatilityMatrix`, `DynamicBlackVolTermStructure`, `BlackVolatilityWithATM`, `SpreadedSmileSection2`, `StrippedOptionletAdapter2`, `PiecewiseAtmOptionletCurve`, `PiecewiseOptionletCurve`

### Credit/Commodity/Correlation
`CreditVolCurve`, `CreditCurve`, `CorrelationTermStructure`, `FlatCorrelation`, `SpreadedCorrelationCurve`
`CommodityBasisPriceCurve`, `CommodityAverageBasisPriceCurve`, `InterpolatedPriceCurve`

## QuantExt Models (`qle/models/`)
| Class | Purpose |
|---|---|
| `CrossAssetModel` | Multi-factor: IR (LGM) + FX (BS) + EQ + INF + CR. Base: `LinkableCalibratedModel` |
| `LGM` / `IrLgm1fParametrization` | Linear Gaussian Markov for IR |
| `FxBsParametrization` | FX Black-Scholes parametrization |
| `CrLgm1fParametrization` | Credit LGM |
| `InfDkParametrization` | Inflation Dodgson-Kainth |
| `HwModel` | Hull-White wrapper |
| `CrossAssetModelBuilder` | Calibrates CrossAssetModel from market data |

## OREData Trade Types (`ored/portfolio/`)
Full list of XML trade types with their C++ class:
`Swap`, `Swaption`, `CapFloor`, `Bond`, `FxForward`, `FxSwap`, `FxOption`, `CreditDefaultSwap`, `IndexCreditDefaultSwap`, `CreditDefaultSwapOption`, `EquityForward`, `EquityOption`, `VanillaOption`, `BarrierOption`, `AsianOption`, `BondOption`, `ForwardBond`, `BondTRS`, `CallableBond`, `ConvertibleBond`, `BondRepo`, `BondFuture`, `CommodityForward`, `CommodityOption`, `SyntheticCDO`, `ScriptedTrade`, `MultiLegOption`, `Ascot`, `CompositeTrade`, `TRS`

## OREData Market (`ored/marketdata/`)
| Class | Purpose |
|---|---|
| `Market` | Abstract interface to all market data |
| `TodaysMarket` | Live market from loader + config |
| `MarketImpl` | Base implementation with curve/vol caches |
| `Loader` | Abstract data loader interface |
| `CsvLoader` | Load from CSV files |
| `InMemoryLoader` | Programmatic data injection |
| `CurveSpec` | Identifies a specific curve (currency, type, name) |

## OREData Engine Builders (`ored/portfolio/builders/`)
One builder per trade type. Key builders:
`SwapEngineBuilder`, `SwaptionEngineBuilder`, `CapFloorEngineBuilder`, `BondEngineBuilder`, `FxForwardEngineBuilder`, `CreditDefaultSwapEngineBuilder`

## OREAnalytics Pipeline (`orea/`)
```
Market Data (Loader)
  → TodaysMarket (build curves, vols)
    → ScenarioGenerator (CrossAssetModel MC or Historical)
      → ScenarioSimMarket (reprice per scenario)
        → Portfolio valuation per scenario
          → Cube (store NPV paths)
            → Aggregation (netting, collateral)
              → XVA (CVA, DVA, FVA, KVA, MVA)
```

## ORE Examples
| Example | Content |
|---|---|
| Example_1 | Vanilla swap NPV, cash flows |
| Example_5 | Exposure simulation, XVA |
| Example_13 | Sensitivity analysis (delta, gamma, cross-gamma) |
| Example_14 | Stress testing |
| Example_16 | SIMM |
