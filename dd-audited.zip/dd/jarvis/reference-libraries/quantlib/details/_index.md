---
title: QuantLib Details — Map of Content
wp: n/a
status: reference
last-updated: 2026-03-31
lines: 16
---

# QuantLib Details — Map of Content

Deep-dive files with complete Python recipes, class hierarchies, and
implementation guides. Load after reading the relevant topic file.
(~724 lines total)

## Files

- [[quantlib_sofr_implementation]] — SOFR/OIS classes with full signatures, complete bootstrap Python code, OvernightIndexedSwapIndex, daily compounding coupon mechanics. (~148 lines)
- [[curve_bootstrapping_recipes]] — 4 complete Python recipes: SOFR OIS, dual-curve, bond-fitted, ORE XML; plus debugging tips. (~115 lines)
- [[swap_construction_recipes]] — 5 swap recipes: SOFR OIS Python, vanilla IRS, multi-leg, cash flow inspection, ORE XML + quantraserver JSON. (~139 lines)
- [[quantlib_class_map]] — Hierarchies for Instrument, TermStructure, Index, Model; ql/ directory map with class organization. (~126 lines)
- [[ore_class_map]] — ORE library structure (QuantExt, OREData, OREAnalytics), instrument/rate/credit class lists, pipeline. (~92 lines)
- [[python_cookbook_index]] — Chapter mapping from quantlibguide.com to topic files with key content per topic. (~55 lines)
- [[quantraserver_schemas]] — FlatBuffer schemas for 13 instruments, REST endpoints, Docker deployment. (~56 lines)
