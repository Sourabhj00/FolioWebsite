---
title: Python Cookbook Index — QuantLib
wp: n/a
status: reference
created: unknown
last-updated: 2026-03-31
lines: 55
kb-depends: []
jarvis-depends: []
---

# QuantLib Guide & Python Cookbook — Chapter Index

## quantlibguide.com (Luigi Ballabio, 2025 edition)
URL: https://www.quantlibguide.com
Also available as PDF on Leanpub.

### Chapter Mapping to Topics

| Chapter | URL Slug | Relevant Topic File |
|---|---|---|
| A taste of QuantLib | `A taste of QuantLib` | `topics/bonds_and_fixed_income.md`, `topics/design_patterns.md` |
| Calendars and holidays | `Calendars and holidays` | `topics/calendars_dates_conventions.md` |
| Dates, periods and schedules | (various) | `topics/calendars_dates_conventions.md` |
| Interest rates | (various) | `topics/calendars_dates_conventions.md` |
| Term structures and their reference dates | `Term structures` | `topics/yield_curves.md`, `topics/design_patterns.md` |
| Kinds of interest-rate term structures | `Kinds of interest-rate term structures` | `topics/yield_curves.md` |
| Bootstrapping a yield curve | (various) | `topics/yield_curves.md` |
| Instruments and pricing engines | `Instruments and pricing engines` | `topics/design_patterns.md`, `topics/options_and_volatility.md` |
| Different kinds of swaps | `Different kinds of swaps` | `topics/swaps_and_irs.md`, `topics/sofr_and_ois.md` |
| Pricing over a range of days | `Pricing over a range of days` | `topics/bonds_and_fixed_income.md` |
| The Observer pattern | `The Observer pattern` | `topics/design_patterns.md` |

### Key Content by Topic

**SOFR & OIS**: "Different kinds of swaps" chapter has full worked examples of:
- SOFR OIS construction with `MakeOIS`
- Fair rate and fair spread calculation
- Annual and quarterly payment frequency
- Telescopic value dates optimization
- Custom OIS with separate legs

**Curve Building**: "Kinds of interest-rate term structures" covers:
- `FlatForward`, `DiscountCurve`, `ZeroCurve` construction
- Reference date mechanics (moving vs fixed)
- Handle relinking for curve updates
- `ZeroSpreadedTermStructure` for credit spreads

**Design**: "The Observer pattern" provides deep C++ analysis of:
- Notification chain performance
- LazyObject dirty-bit pattern
- Thread safety concerns (why QuantLib is single-threaded)
- Real-world notification graph complexity

## QuantLib Python Cookbook (Balaraman & Ballabio)
URL: https://leanpub.com/quantlibpythoncookbook
Older but still relevant for practical patterns.

### Key Sections
- Date/Period/Calendar basics
- Schedule construction for bonds and swaps
- OIS bootstrapping with DepositRateHelper + OISRateHelper
- European option pricing with multiple engines
- Bond pricing and yield calculation
- Duration, convexity, BPS
