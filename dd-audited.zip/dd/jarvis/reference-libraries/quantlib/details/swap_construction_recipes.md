---
title: Swap Construction Recipes — QuantLib
wp: n/a
status: reference
created: unknown
last-updated: 2026-03-31
lines: 139
kb-depends: []
jarvis-depends: []
---

# Swap Construction Recipes — Detail

## Recipe 1: SOFR OIS (Python)
```python
import QuantLib as ql
today = ql.Date(15, 10, 2023)
ql.Settings.instance().evaluationDate = today

# Curve (assumed already built)
sofr_handle = ql.YieldTermStructureHandle(sofr_curve)
sofr = ql.Sofr(sofr_handle)

# Method A: MakeOIS builder (simplest)
swap = ql.MakeOIS(
    swapTenor=ql.Period(5, ql.Years),
    overnightIndex=sofr,
    fixedRate=0.04,
    paymentFrequency=ql.Annual,
    fixedLegDayCount=ql.Actual360(),
    telescopicValueDates=True
)
swap.setPricingEngine(ql.DiscountingSwapEngine(sofr_handle))

print(f"NPV: {swap.NPV():.2f}")
print(f"Fair rate: {swap.fairRate():.6f}")
print(f"Fixed leg BPS: {swap.fixedLegBPS():.2f}")

# Method B: Full constructor (more control)
schedule = ql.MakeSchedule(
    effectiveDate=today + ql.Period(2, ql.Days),
    terminationDate=today + ql.Period(5, ql.Years),
    frequency=ql.Annual,
    calendar=ql.UnitedStates(ql.UnitedStates.GovernmentBond),
    convention=ql.ModifiedFollowing,
    backwards=True)

swap2 = ql.OvernightIndexedSwap(
    ql.Swap.Payer, 1_000_000, schedule,
    0.04, ql.Actual360(), sofr)
swap2.setPricingEngine(ql.DiscountingSwapEngine(sofr_handle))
```

## Recipe 2: Vanilla IRS — Fixed vs IBOR (Python)
```python
ibor = ql.USDLibor(ql.Period(3, ql.Months), forecast_handle)

swap = ql.MakeVanillaSwap(
    ql.Period(10, ql.Years), ibor, 0.04,
    effectiveDate=today + ql.Period(2, ql.Days),
    fixedLegDayCount=ql.Thirty360(ql.Thirty360.BondBasis),
    floatingLegSpread=0.0)

swap.setPricingEngine(ql.DiscountingSwapEngine(discount_handle))
```

## Recipe 3: Custom Multi-Leg Swap (Python)
Build legs separately for non-standard swaps (amortizing, step coupon, etc.).

```python
fixed_schedule = ql.MakeSchedule(...)
float_schedule = ql.MakeSchedule(...)

fixed_leg = ql.FixedRateLeg(fixed_schedule, ql.Actual360(), [1e6], [0.04])
float_leg = ql.OvernightLeg([1e6], float_schedule, sofr)

swap = ql.Swap(fixed_leg, float_leg)
swap.setPricingEngine(ql.DiscountingSwapEngine(sofr_handle))
```

## Recipe 4: Inspect Cash Flows
```python
# Fixed leg
for cf in swap.fixedLeg():
    print(f"{cf.date()} | {cf.amount():.2f}")

# Floating leg (need to cast to get rate info)
for cf in swap.overnightLeg():
    coupon = ql.as_floating_rate_coupon(cf)
    print(f"{coupon.date()} | rate={coupon.rate():.6f} | amount={coupon.amount():.2f}")
```

## Recipe 5: ORE Swap XML
```xml
<Trade id="Swap_1">
  <TradeType>Swap</TradeType>
  <Envelope><CounterParty>CPTY</CounterParty></Envelope>
  <SwapData>
    <LegData>
      <LegType>Fixed</LegType>
      <Payer>true</Payer>
      <Currency>USD</Currency>
      <Notionals><Notional>1000000</Notional></Notionals>
      <ScheduleData>
        <Rules>
          <StartDate>20231017</StartDate>
          <EndDate>20281017</EndDate>
          <Tenor>1Y</Tenor>
          <Calendar>US-GovtBond</Calendar>
          <Convention>MF</Convention>
          <Rule>Backward</Rule>
        </Rules>
      </ScheduleData>
      <FixedLegData><Rates><Rate>0.04</Rate></Rates></FixedLegData>
      <DayCounter>A360</DayCounter>
    </LegData>
    <LegData>
      <LegType>Floating</LegType>
      <Payer>false</Payer>
      <Currency>USD</Currency>
      <Notionals><Notional>1000000</Notional></Notionals>
      <FloatingLegData>
        <Index>USD-SOFR</Index>
        <IsAveraged>false</IsAveraged>
      </FloatingLegData>
      <DayCounter>A360</DayCounter>
    </LegData>
  </SwapData>
</Trade>
```

## quantraserver JSON Request (OIS Swap)
```json
{
  "pricing": {
    "as_of_date": "2023-10-15",
    "curves": [{"id": "sofr", "day_counter": "Actual365Fixed",
                "interpolator": "LogLinear", "bootstrap_trait": "Discount",
                "points": [...]}]
  },
  "ois_swap": {
    "type": "Payer", "nominal": 1000000,
    "start_date": "2023-10-17", "maturity": "5Y",
    "fixed_rate": 0.04, "overnight_index": "Sofr",
    "payment_frequency": "Annual",
    "discounting_curve": "sofr", "forecasting_curve": "sofr"
  }
}
```
