---
title: SOFR Implementation Details — QuantLib
wp: n/a
status: reference
created: unknown
last-updated: 2026-03-31
lines: 148
kb-depends: []
jarvis-depends: []
---

# QuantLib SOFR Implementation — Detail

## Class: `ql::Sofr`
- **File**: `ql/indexes/ibor/sofr.hpp` / `sofr.cpp`
- **Inherits**: `OvernightIndex`
- **Constructor**: `Sofr(const Handle<YieldTermStructure>& h = {})`
- **Calendar**: `UnitedStates(UnitedStates::SOFR)`
- **Day counter**: `Actual360`
- **Fixing days**: 0 (T+0 — rate published for same day)
- **Currency**: `USDCurrency`

## Class: `ql::OvernightIndex` (base)
- **File**: `ql/indexes/iborindex.hpp`
- **Key methods**:
  - `fixing(Date, forecastTodaysFixing)` — returns published or forecasted rate
  - `fixingCalendar()` — calendar for valid fixing dates
  - `addFixing(Date, rate)` — store historical fixing
  - `pastFixing(Date)` — retrieve stored fixing
  - `forecastFixing(Date)` — project rate from term structure

## Class: `ql::OvernightIndexedSwap`
- **File**: `ql/instruments/overnightindexedswap.hpp`
- **Inherits**: `FixedVsFloatingSwap` → `Swap` → `Instrument`
- **Constructor**: `OvernightIndexedSwap(type, nominal, schedule, fixedRate, fixedDC, overnightIndex, spread, paymentLag, paymentAdjustment, paymentCalendar, telescopicValueDates, averagingMethod)`
- **Key methods**:
  - `fairRate()` — par fixed rate
  - `fairSpread()` — par floating spread
  - `fixedLegBPS()` — basis point sensitivity
  - `fixedLegNPV()`, `overnightLegNPV()` — leg NPVs
  - `overnightLeg()` — vector of `OvernightIndexedCoupon`
- **Averaging**: `RateAveraging::Compound` (default) or `RateAveraging::Simple`

## Class: `ql::MakeOIS` (builder)
- **File**: `ql/instruments/makeois.hpp`
- **Fluent API**:
```cpp
MakeOIS(swapTenor, overnightIndex, fixedRate)
  .withEffectiveDate(d)
  .withTerminationDate(d)
  .withPaymentFrequency(Annual)
  .withFixedLegDayCount(Actual365Fixed)
  .withNominal(1e6)
  .withTelescopicValueDates(true)
  .withAveragingMethod(RateAveraging::Compound)
  .withPaymentLag(2)
  .withPricingEngine(engine)
```

## Class: `ql::OISRateHelper`
- **File**: `ql/termstructures/yield/oisratehelper.hpp`
- **Inherits**: `RelativeDateRateHelper`
- **Constructor**: `OISRateHelper(settlementDays, tenor, fixedRate, overnightIndex, discountingCurve, telescopicValueDates, paymentLag, paymentConvention, paymentFrequency, paymentCalendar, forwardStart, overnightSpread, pillarChoice, lastRecentPeriod, lastRecentPeriodCalendar)`
- **Common usage**: `OISRateHelper(2, Period(5, Years), QuoteHandle(SimpleQuote(0.04)), sofr)`

## Class: `ql::OvernightIndexFutureRateHelper`
- **File**: `ql/termstructures/yield/overnightindexfutureratehelper.hpp`
- **Constructor**: `OvernightIndexFutureRateHelper(price, valueDate, maturityDate, overnightIndex, convexityAdjustment, type)`
- **Type**: `Futures::IMM` (3M) or `Futures::Custom`
- **For 1M SOFR futures**: Use custom dates matching CME 1M SOFR contract
- **For 3M SOFR futures**: Use IMM dates (third Wednesday)

## Class: `ql::OvernightIndexedCoupon`
- **File**: `ql/cashflows/overnightindexedcoupon.hpp`
- **Inherits**: `FloatingRateCoupon`
- **Key**: Computes compounded (or averaged) daily overnight rate over accrual period
- **Methods**:
  - `fixingDates()` — all daily fixing dates in the period
  - `dt()` — day count fractions for each fixing
  - `indexFixings()` — actual/projected fixings
  - `rate()` — compounded/averaged rate for the period
  - `effectiveSpread()`, `effectiveIndexFixing()`

## Full SOFR Curve Bootstrap (Python)
```python
import QuantLib as ql

today = ql.Date(15, 10, 2023)
ql.Settings.instance().evaluationDate = today

sofr = ql.Sofr()

# Deposit helper for very short end
dep_helper = ql.DepositRateHelper(
    ql.QuoteHandle(ql.SimpleQuote(0.053)),
    ql.Period(1, ql.Days), 0,
    ql.UnitedStates(ql.UnitedStates.SOFR),
    ql.Following, False, ql.Actual360()
)

# OIS helpers for the curve
ois_tenors = [(1, ql.Months), (3, ql.Months), (6, ql.Months),
              (1, ql.Years), (2, ql.Years), (3, ql.Years),
              (5, ql.Years), (7, ql.Years), (10, ql.Years)]
ois_rates = [0.0530, 0.0535, 0.0525, 0.0480, 0.0445, 0.0430, 0.0415, 0.0410, 0.0405]

ois_helpers = [
    ql.OISRateHelper(2, ql.Period(t, u),
                     ql.QuoteHandle(ql.SimpleQuote(r)), sofr)
    for (t, u), r in zip(ois_tenors, ois_rates)
]

helpers = [dep_helper] + ois_helpers
curve = ql.PiecewiseLogCubicDiscount(today, helpers, ql.Actual365Fixed())
curve.enableExtrapolation()

# Use the curve
sofr_handle = ql.YieldTermStructureHandle(curve)
sofr_with_curve = ql.Sofr(sofr_handle)

# Price an OIS
swap = ql.MakeOIS(
    swapTenor=ql.Period(5, ql.Years),
    overnightIndex=sofr_with_curve,
    fixedRate=0.04
)
swap.setPricingEngine(ql.DiscountingSwapEngine(sofr_handle))
print(f"NPV: {swap.NPV():.2f}")
print(f"Fair rate: {swap.fairRate():.6f}")
```

## Class: `ql::OvernightIndexedSwapIndex`
- **File**: `ql/indexes/swapindex.hpp`
- **Inherits**: `SwapIndex`
- **Purpose**: Required for SOFR swaption construction — defines the underlying OIS swap
- **Constructor**: `OvernightIndexedSwapIndex(familyName, tenor, settlementDays, currency, overnightIndex, paymentFrequency, paymentLag, pillarChoice)`
- **Usage**: Pass to `MakeSwaption` or `SwaptionHelper` when building SOFR-based swaptions

```python
# Create SOFR swap index for swaption pricing
sofr_swap_index = ql.OvernightIndexedSwapIndex(
    "SOFR-OIS", ql.Period(5, ql.Years), 2,
    ql.USDCurrency(), sofr_with_curve)
```

## Related Files (Quick Reference)
| File | Content |
|---|---|
| `ql/indexes/ibor/sofr.hpp` | SOFR index definition |
| `ql/indexes/ibor/fedfunds.hpp` | Fed Funds (EFFR) — similar pattern |
| `ql/indexes/swapindex.hpp` | SwapIndex + OvernightIndexedSwapIndex |
| `ql/instruments/overnightindexedswap.hpp` | OIS instrument |
| `ql/instruments/makeois.hpp` | OIS builder |
| `ql/instruments/overnightindexfuture.hpp` | SOFR futures instrument |
| `ql/termstructures/yield/oisratehelper.hpp` | OIS bootstrap helper |
| `ql/termstructures/yield/overnightindexfutureratehelper.hpp` | Futures bootstrap helper |
| `ql/cashflows/overnightindexedcoupon.hpp` | Daily compounding coupon |
| `ql/termstructures/yield/piecewiseyieldcurve.hpp` | Bootstrapped curve template |
