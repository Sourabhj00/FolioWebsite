---
title: QuantLib Class Map — Hierarchies and Directory
wp: n/a
status: reference
created: unknown
last-updated: 2026-03-31
lines: 126
kb-depends: []
jarvis-depends: []
---

# QuantLib Class Map — Detail

## Instrument Hierarchy
```
Instrument (ql/instrument.hpp)
├── Bond (ql/instruments/bond.hpp)
│   ├── FixedRateBond, FloatingRateBond, ZeroCouponBond
│   ├── AmortizingFixedRateBond, AmortizingFloatingRateBond
│   ├── CmsRateBond
│   ├── CallableFixedRateBond [experimental/callablebonds/]
│   └── ConvertibleFixedCouponBond, ConvertibleFloatingRateBond, ConvertibleZeroCouponBond [bonds/convertiblebonds.hpp]
├── Swap (ql/instruments/swap.hpp)
│   ├── FixedVsFloatingSwap
│   │   ├── VanillaSwap
│   │   ├── OvernightIndexedSwap
│   │   └── MultipleResetsSwap
│   ├── NonstandardSwap
│   ├── FloatFloatSwap
│   ├── BMASwap
│   ├── AssetSwap
│   ├── CPISwap, YearOnYearInflationSwap, ZeroCouponInflationSwap, ZeroCouponSwap
│   └── EquityTotalReturnSwap
├── Option (ql/option.hpp)
│   ├── OneAssetOption
│   │   ├── VanillaOption → EuropeanOption
│   │   ├── BarrierOption → QuantoBarrierOption
│   │   ├── AsianOption (Continuous/Discrete Averaging)
│   │   ├── LookbackOption (Continuous/Discrete Floating/Fixed)
│   │   ├── CliquetOption, CompoundOption, SimpleChooserOption, ComplexChooserOption
│   │   └── SoftBarrierOption, PartialTimeBarrierOption, HolderExtensibleOption, WriterExtensibleOption
│   ├── MultiAssetOption → BasketOption, MargrabeOption, TwoAssetCorrelationOption
│   ├── Swaption
│   ├── FloatFloatSwaption, NonstandardSwaption
│   └── TwoAssetBarrierOption
├── CapFloor (ql/instruments/capfloor.hpp)
├── CreditDefaultSwap (ql/instruments/creditdefaultswap.hpp)
├── Forward → BondForward
├── FxForward
├── ForwardRateAgreement
├── OvernightIndexFuture
├── VarianceSwap
├── CPICapFloor, YoYInflationCapFloor
├── CompositeInstrument
├── Stock, PerpetualFutures
└── VanillaStorageOption, VanillaSwingOption
```

## Term Structure Hierarchy
```
TermStructure (ql/termstructure.hpp)
├── YieldTermStructure
│   ├── ZeroYieldStructure
│   │   ├── InterpolatedZeroCurve, InterpolatedForwardCurve
│   │   ├── FlatForward
│   │   ├── ZeroSpreadedTermStructure, ForwardSpreadedTermStructure
│   │   ├── CompositeZeroYieldStructure
│   │   ├── ImpliedTermStructure, QuantoTermStructure
│   │   └── UltimateForwardTermStructure
│   ├── PiecewiseYieldCurve<Trait, Interpolator>  [BOOTSTRAPPED]
│   ├── FittedBondDiscountCurve
│   └── InterpolatedSimpleZeroCurve
├── VolatilityTermStructure
│   ├── BlackVolTermStructure → BlackConstantVol, BlackVarianceSurface, BlackVarianceCurve
│   ├── LocalVolTermStructure → LocalVolSurface, LocalConstantVol, FixedLocalVolSurface
│   ├── SwaptionVolatilityStructure → SwaptionVolatilityMatrix, SwaptionVolatilityCube, ConstantSwaptionVolatility
│   ├── CapFloorTermVolatilityStructure → ConstantCapFloorTermVolatility
│   ├── OptionletVolatilityStructure → ConstantOptionletVolatility, StrippedOptionletAdapter
│   └── CPIVolatilitySurface, YoYOptionletVolatilitySurface
├── DefaultProbabilityTermStructure
│   ├── HazardRateStructure → FlatHazardRate
│   ├── SurvivalProbabilityStructure
│   └── PiecewiseDefaultCurve
└── InflationTermStructure → ZeroInflationTermStructure, YoYInflationTermStructure
```

## Index Hierarchy
```
Index (ql/index.hpp)
├── InterestRateIndex (ql/indexes/interestrateindex.hpp)
│   ├── IborIndex (ql/indexes/iborindex.hpp)
│   │   ├── OvernightIndex → Sofr, FedFunds, Estr, Sonia, Corra, Saron, Tonar, ...
│   │   ├── Euribor, USDLibor, GBPLibor, JPYLibor, ...
│   │   └── Libor (generic tenor)
│   ├── SwapIndex (ql/indexes/swapindex.hpp)
│   │   ├── OvernightIndexedSwapIndex  [for SOFR/OIS swaptions]
│   │   ├── EuriborSwapIsdaFixA/B (ql/indexes/swap/euriborswap.hpp)
│   │   └── UsdLiborSwapIsdaFixAm/Pm (ql/indexes/swap/usdliborswap.hpp)
│   └── SwapSpreadIndex
├── InflationIndex → ZeroInflationIndex, YoYInflationIndex
└── EquityIndex, CommodityIndex (QuantExt)
```

## Model Hierarchy
```
CalibratedModel (ql/models/model.hpp)
├── ShortRateModel
│   ├── OneFactorModel → OneFactorAffineModel
│   │   ├── Vasicek → HullWhite
│   │   ├── CoxIngersollRoss → ExtendedCoxIngersollRoss
│   │   ├── BlackKarasinski
│   │   └── Gaussian1dModel → Gsr, MarkovFunctional
│   └── TwoFactorModel → G2
├── HestonModel → BatesModel
├── PiecewiseTimeDependentHestonModel
└── GJRGARCHModel
```

## QuantLib Directory Map (`ql/`)
| Directory | Content |
|---|---|
| `cashflows/` | Coupon types: Fixed, Ibor, Overnight, CMS, CPI, Digital, Capped/Floored |
| `currencies/` | Currency definitions (USD, EUR, GBP, JPY, etc.) |
| `indexes/` | Rate indexes: `ibor/` (SOFR, LIBOR, EURIBOR, etc.), `inflation/`, `swap/` |
| `instruments/` | All financial instruments + builders (Make*) |
| `math/` | Interpolation, distributions, optimization, random numbers, statistics |
| `methods/` | Monte Carlo, finite differences, lattice methods |
| `models/` | Short-rate models, equity models (Heston, Bates), market models (LMM) |
| `patterns/` | Observer, LazyObject, Singleton, Visitor |
| `pricingengines/` | Engines organized by instrument type |
| `processes/` | Stochastic processes: BlackScholes, Heston, HullWhite, G2 |
| `quotes/` | SimpleQuote, DerivedQuote, CompositeQuote, ForwardValueQuote |
| `termstructures/` | `yield/`, `volatility/`, `credit/`, `inflation/` |
| `time/` | Date, Period, Calendar, Schedule, DayCounter, IMM, ASX, ECB |
| `utilities/` | Null, DataFormatters, Disposable |
| `experimental/` | Features under development (may move to main) |
