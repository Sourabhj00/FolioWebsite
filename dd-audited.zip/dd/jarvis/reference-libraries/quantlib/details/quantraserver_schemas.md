---
title: Quantraserver Schemas — FlatBuffer and REST
wp: n/a
status: reference
created: unknown
last-updated: 2026-03-31
lines: 56
kb-depends: []
jarvis-depends: []
---

# Quantraserver Schemas & API — Detail

## Supported Instruments (from FlatBuffer schemas in `flatbuffers/fbs/`)

| Instrument | Request Schema | Response Schema |
|---|---|---|
| Fixed Rate Bond | `price_fixed_rate_bond_request.fbs` | `fixed_rate_bond_response.fbs` |
| Floating Rate Bond | `price_floating_rate_bond_request.fbs` | `floating_rate_bond_response.fbs` |
| Vanilla Swap | `price_vanilla_swap_request.fbs` | `vanilla_swap_response.fbs` |
| OIS Swap | `price_ois_swap_request.fbs` | `ois_swap_response.fbs` |
| Basis Swap | `price_basis_swap_request.fbs` | `basis_swap_response.fbs` |
| FRA | `price_fra_request.fbs` | `fra_response.fbs` |
| Cap/Floor | `price_cap_floor_request.fbs` | `cap_floor_response.fbs` |
| Swaption | `price_swaption_request.fbs` | `swaption_response.fbs` |
| Equity Option | `price_equity_option_request.fbs` | `equity_option_response.fbs` |
| CDS | `price_cds_request.fbs` | `cds_response.fbs` |
| YoY Inflation Swap | `price_year_on_year_inflation_swap_request.fbs` | `year_on_year_inflation_swap_response.fbs` |
| Zero Coupon Inflation Swap | `price_zero_coupon_inflation_swap_request.fbs` | `zero_coupon_inflation_swap_response.fbs` |

## Curve Bootstrapping
- `bootstrap_curves_request.fbs` / `bootstrap_curves_response.fbs`
- `bootstrap_inflation_curves_request.fbs` / `bootstrap_inflation_curves_response.fbs`

## Model Calibration
- `calibrate_swaption_model_request.fbs` / `calibrate_swaption_model_response.fbs`

## Utility Schemas
- `calendar_advance_request.fbs` — Date arithmetic
- `calendar_business_days_request.fbs` — Business day counting
- `calendar_holidays_request.fbs` — Holiday listing
- `sample_vol_surfaces_request.fbs` — Vol surface generation

## Common Types (`common.fbs`, `enums.fbs`)
Enums: `DayCounter`, `BusinessDayConvention`, `Compounding`, `Frequency`, `Calendar`, `DateGenerationRule`, `SwapType` (Payer/Receiver), `OptionType` (Call/Put), `BarrierType`

## Curve Point Types (`term_structure.fbs`)
`DepositHelper`, `FRAHelper`, `FuturesHelper`, `SwapHelper`, `OISHelper`, `BondHelper`

## REST Endpoints (JSON server at `jsonserver/`)
All requests via `POST http://host:8080/price/<instrument-type>` with JSON body.
JSON schemas mirror FlatBuffer schemas — see `flatbuffers/json/` for examples.

OpenAPI spec at `jsonserver/openapi/`

## Example JSON Requests (`examples/data/`)
`fixed_rate_bond_request.json`, `vanilla_swap_request.json`, `ois_swap_request.json`, `fra_request.json`, `cap_floor_request.json`, `swaption_request.json`

## Docker
```bash
docker build -t quantra .
docker run -p 50051:50051 -p 8080:8080 quantra
curl -X POST http://localhost:8080/price/fixed-rate-bond \
  -H "Content-Type: application/json" \
  -d @examples/data/fixed_rate_bond_request.json
```
