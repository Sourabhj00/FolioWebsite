---
title: Curve Bootstrapping Recipes — QuantLib
wp: n/a
status: reference
created: unknown
last-updated: 2026-03-31
lines: 115
kb-depends: []
jarvis-depends: []
---

# Curve Bootstrapping Recipes — Detail

## Recipe 1: SOFR OIS Curve (Python)
The most common STIR curve. Single-curve framework (forecast = discount).

```python
import QuantLib as ql
today = ql.Date(15, 10, 2023)
ql.Settings.instance().evaluationDate = today

sofr = ql.Sofr()
helpers = []

# Short end: overnight deposit
helpers.append(ql.DepositRateHelper(
    ql.QuoteHandle(ql.SimpleQuote(0.053)),
    ql.Period(1, ql.Days), 0,
    ql.UnitedStates(ql.UnitedStates.SOFR),
    ql.Following, False, ql.Actual360()))

# SOFR futures (1M and 3M)
# helpers.append(ql.OvernightIndexFutureRateHelper(
#     ql.QuoteHandle(ql.SimpleQuote(94.70)),  # price = 100 - rate
#     valueDate, maturityDate, sofr))

# OIS swaps
for tenor, rate in [(ql.Period(1,ql.Months), 0.0530), (ql.Period(3,ql.Months), 0.0535),
                    (ql.Period(6,ql.Months), 0.0525), (ql.Period(1,ql.Years), 0.0480),
                    (ql.Period(2,ql.Years), 0.0445), (ql.Period(3,ql.Years), 0.0430),
                    (ql.Period(5,ql.Years), 0.0415), (ql.Period(10,ql.Years), 0.0405),
                    (ql.Period(30,ql.Years), 0.0395)]:
    helpers.append(ql.OISRateHelper(2, tenor,
        ql.QuoteHandle(ql.SimpleQuote(rate)), sofr))

curve = ql.PiecewiseLogCubicDiscount(today, helpers, ql.Actual365Fixed())
curve.enableExtrapolation()
```

**Key choices**: `PiecewiseLogCubicDiscount` = `Discount` trait + `LogCubic` interpolation.
Alternative: `PiecewiseLinearZero` for simpler but less smooth curve.

## Recipe 2: Dual-Curve (IBOR forecast + OIS discount) — Python
For legacy IBOR swaps where forecast curve ≠ discount curve.

```python
# Step 1: Build discount curve (SOFR OIS) as above
discount_curve = ...  # from Recipe 1
discount_handle = ql.YieldTermStructureHandle(discount_curve)

# Step 2: Build IBOR forecast curve using swap helpers with exogenous discount
ibor_index = ql.USDLibor(ql.Period(3, ql.Months))
swap_helpers = []
for tenor, rate in [(ql.Period(2,ql.Years), 0.048), (ql.Period(5,ql.Years), 0.044),
                    (ql.Period(10,ql.Years), 0.042)]:
    swap_helpers.append(ql.SwapRateHelper(
        ql.QuoteHandle(ql.SimpleQuote(rate)),
        tenor, ql.TARGET(), ql.Annual, ql.ModifiedFollowing,
        ql.Thirty360(ql.Thirty360.BondBasis), ibor_index,
        ql.QuoteHandle(), ql.Period(0, ql.Days),
        discount_handle))  # <-- exogenous discount curve

forecast_curve = ql.PiecewiseLogCubicDiscount(today, swap_helpers, ql.Actual365Fixed())
```

## Recipe 3: Bond-Fitted Curve — Python
Nelson-Siegel or Svensson fit to bond prices.

```python
bond_helpers = []
for maturity, coupon, price in bond_data:
    schedule = ql.Schedule(...)
    helper = ql.FixedRateBondHelper(
        ql.QuoteHandle(ql.SimpleQuote(price)),
        settlementDays, faceAmount, schedule,
        [coupon], dayCounter)
    bond_helpers.append(helper)

# Nelson-Siegel fitting
fitted_curve = ql.FittedBondDiscountCurve(
    today, bond_helpers, dayCounter,
    ql.NelsonSiegelFitting(),
    tolerance, maxIterations)
```

## Recipe 4: ORE Multi-Curve Setup (XML)
```xml
<YieldCurves>
  <YieldCurve>
    <CurveId>Yield/USD/USD-SOFR</CurveId>
    <CurveDescription>USD SOFR OIS Curve</CurveDescription>
    <Currency>USD</Currency>
    <DiscountCurve>Yield/USD/USD-SOFR</DiscountCurve>
    <Segments>
      <OIS>
        <Convention>USD-OIS-SOFR</Convention>
        <Quotes>
          <Quote>IR_SWAP/RATE/USD/2D/1D/1M</Quote>
          <Quote>IR_SWAP/RATE/USD/2D/1D/3M</Quote>
          <!-- ... more tenors ... -->
        </Quotes>
      </OIS>
    </Segments>
    <InterpolationVariable>Discount</InterpolationVariable>
    <InterpolationMethod>LogLinear</InterpolationMethod>
  </YieldCurve>
</YieldCurves>
```

## Bootstrap Debugging Tips
1. **Failure to converge**: Check that helpers are in strictly increasing maturity order
2. **Negative rates**: Use `PiecewiseLinearZero` instead of log-based methods
3. **Jumps at instrument boundaries**: Try `MonotonicCubic` interpolation
4. **Pillar dates**: Access via `curve.dates()` to verify bootstrap nodes
5. **Inspect zero rates**: `curve.zeroRate(date, dayCounter, compounding).rate()`
