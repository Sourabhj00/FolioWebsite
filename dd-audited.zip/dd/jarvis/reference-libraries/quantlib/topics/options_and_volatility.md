---
title: Options and Volatility — QuantLib Reference
wp: n/a
status: reference
created: unknown
last-updated: 2026-03-31
lines: 71
kb-depends: []
jarvis-depends: []
---

# Options & Volatility — Topic Index

## QuantLib Option Instruments
| Class | File | Purpose |
|---|---|---|
| `Swaption` | `ql/instruments/swaption.hpp` | European/Bermudan swaption: `impliedVolatility()`, `vega()` |
| `CapFloor` | `ql/instruments/capfloor.hpp` | IR cap, floor, collar: `impliedVolatility()`, `vega()` |
| `MakeSwaption` | `ql/instruments/makeswaption.hpp` | Fluent swaption builder |
| `MakeCapFloor` | `ql/instruments/makecapfloor.hpp` | Fluent cap/floor builder |

## Swap Indexes (required for swaption construction)
| Class | File | Purpose |
|---|---|---|
| `SwapIndex` | `ql/indexes/swapindex.hpp` | Links swaption to underlying swap definition (tenor, fixed freq, float index) |
| `OvernightIndexedSwapIndex` | `ql/indexes/swapindex.hpp` | SwapIndex for OIS — **required for SOFR swaptions** |
| `EuriborSwapIsdaFixA` | `ql/indexes/swap/euriborswap.hpp` | Pre-built EUR swap index |
| `UsdLiborSwapIsdaFixAm/Pm` | `ql/indexes/swap/usdliborswap.hpp` | Pre-built USD LIBOR swap indexes |

## Equity/Vanilla Options
| Class | File | Purpose |
|---|---|---|
| `EuropeanOption` | `ql/instruments/europeanoption.hpp` | Vanilla European option |
| `VanillaOption` | `ql/instruments/vanillaoption.hpp` | Base: `NPV()`, `delta()`, `gamma()`, `vega()`, `theta()`, `rho()` |
| `BarrierOption` | `ql/instruments/barrieroption.hpp` | Knock-in/knock-out barriers |
| `FloatFloatSwaption` | `ql/instruments/floatfloatswaption.hpp` | Swaption on basis swap |
| `NonstandardSwaption` | `ql/instruments/nonstandardswaption.hpp` | Swaption on nonstandard swap |

## Swaption Engines
| Engine | File | Method |
|---|---|---|
| `BlackSwaptionEngine` | `pricingengines/swaption/blackswaptionengine.hpp` | Black-76 (lognormal or normal) |
| `BachelierSwaptionEngine` | `pricingengines/swaption/blackswaptionengine.hpp` | Normal (Bachelier) model |
| `G2SwaptionEngine` | `pricingengines/swaption/g2swaptionengine.hpp` | G2++ model |
| `Gaussian1dSwaptionEngine` | `pricingengines/swaption/gaussian1dswaptionengine.hpp` | GSR/Markov functional |
| `TreeSwaptionEngine` | `pricingengines/swaption/treeswaptionengine.hpp` | Short-rate tree |
| `FdHullWhiteSwaptionEngine` | `pricingengines/swaption/fdhullwhiteswaptionengine.hpp` | FD with Hull-White |

## Cap/Floor Engines
`BlackCapFloorEngine` (pricingengines/capfloor/blackcapfloorengine.hpp), `BachelierCapFloorEngine`, `AnalyticCapFloorEngine`

## Volatility Term Structures
| Class | File | Purpose |
|---|---|---|
| `SwaptionVolatilityStructure` | `volatility/swaption/swaptionvolstructure.hpp` | Base swaption vol surface |
| `SwaptionVolatilityMatrix` | `volatility/swaption/swaptionvolmatrix.hpp` | Expiry × tenor vol matrix |
| `SwaptionVolatilityCube` | `volatility/swaption/swaptionvolcube.hpp` | With strike dimension (smile) |
| `ConstantSwaptionVolatility` | `volatility/swaption/swaptionconstantvol.hpp` | Flat swaption vol |
| `CapFloorTermVolatilityStructure` | `volatility/capfloor/capfloortermvolatilitystructure.hpp` | Base capfloor vol |
| `CapFloorTermVolSurface` | `volatility/capfloor/capfloortermvolsurface.hpp` | Cap/floor vol surface |
| `OptionletVolatilityStructure` | `volatility/optionlet/optionletvolatilitystructure.hpp` | Per-caplet vol |
| `OptionletStripper1` / `OptionletStripper2` | `volatility/optionlet/` | Strip caplet vols from cap vols |
| `BlackVolTermStructure` | `volatility/equityfx/blackvoltermstructure.hpp` | Equity/FX vol surface base |
| `BlackConstantVol` | `volatility/equityfx/blackconstantvol.hpp` | Flat Black vol |
| `BlackVarianceSurface` | `volatility/equityfx/blackvariancesurface.hpp` | Discrete equity vol surface |
| `LocalVolSurface` | `volatility/equityfx/localvolsurface.hpp` | Dupire local vol |
| `SabrSmileSection` | `volatility/sabrsmilesection.hpp` | SABR smile parameterization |

## ORE Extensions
- `GenericSwaption` → `qle/instruments/genericswaption.hpp` — Swaption on any swap type
- `CdsOption` → `qle/instruments/cdsoption.hpp` — CDS option
- `ProxySwaptionVolatility` → `qle/termstructures/` — Vol proxy across currencies
- `DynamicSwaptionVolatilityMatrix` → `qle/termstructures/` — Time-evolving vol surface

## quantra.io API
- `POST /price-swaption` — European swaption pricing with vol surface
- `POST /price-cap-floor` — Caps/floors with caplet/floorlet detail
- `POST /calibrate-swaption-model` — Model calibration to swaption vols

## quantlibguide.com
- "Instruments and pricing engines" — European option with multiple engines (analytic, MC, binomial)
