---
title: Calendars, Dates, Conventions — QuantLib Reference
wp: n/a
status: reference
created: unknown
last-updated: 2026-03-31
lines: 47
kb-depends: []
jarvis-depends: []
---

# Calendars, Dates & Conventions — Topic Index

## Date Arithmetic
| Class/Function | File | Purpose |
|---|---|---|
| `Date` | `ql/time/date.hpp` | Core date: `Date(d, m, y)`, arithmetic (`+Period`), `weekday()`, `serialNumber()` |
| `Period` | `ql/time/period.hpp` | Duration: `Period(6, Months)`, `Period("3Y")` |
| `Schedule` | `ql/time/schedule.hpp` | Coupon/payment date sequences |
| `MakeSchedule` | `ql/time/schedule.hpp` | Fluent builder: `.from()`, `.to()`, `.withFrequency()`, `.withCalendar()`, `.backwards()` |
| `IMM` | `ql/time/imm.hpp` | IMM dates: `nextDate()`, `isIMMdate()`, `code()` |
| `ASX` | `ql/time/asx.hpp` | ASX dates |
| `ECB` | `ql/time/ecb.hpp` | ECB meeting dates |

## Calendars
All in `ql/time/calendars/`: `UnitedStates` (GovernmentBond, NYSE, FederalReserve, SOFR, NERC), `UnitedKingdom`, `TARGET`, `Japan`, `Canada`, `Australia`, `Germany`, `France`, `SouthAfrica`, `Brazil`, `China`, `India`, `Mexico`, `SouthKorea`, `WeekendsOnly`, `NullCalendar`, `JointCalendar`, `BespokeCalendar`

**Key for SOFR**: `UnitedStates(UnitedStates::SOFR)` — this is the SOFR fixing calendar. Note: `GovernmentBond` calendar is for bond settlement, not SOFR fixing.

**Runtime customization**: `cal.addHoliday(date)`, `cal.removeHoliday(date)`, `JointCalendar(cal1, cal2)`
**Bespoke**: `BespokeCalendar` for custom calendars from external data.

## Day Counters
All in `ql/time/daycounters/`: `Actual360`, `Actual365Fixed`, `ActualActual` (ISMA, ISDA, AFB, Bond), `Thirty360` (USA, BondBasis, European, Italian, German), `Business252`, `SimpleDayCounter`

**SOFR uses**: `Actual360` for the index, `Actual365Fixed` for curve building (convention-dependent).

## Business Day Conventions
`Following`, `ModifiedFollowing`, `Preceding`, `ModifiedPreceding`, `Unadjusted`, `HalfMonthModifiedFollowing`, `Nearest` → `ql/time/businessdayconvention.hpp`

## Date Generation Rules
`DateGeneration::Backward`, `Forward`, `Zero`, `ThirdWednesday`, `Twentieth`, `TwentiethIMM`, `OldCDS`, `CDS`, `CDS2015` → `ql/time/dategenerationrule.hpp`

## Compounding & Frequency
`Simple`, `Compounded`, `Continuous`, `SimpleThenCompounded` → `ql/compounding.hpp`
`Annual`, `Semiannual`, `Quarterly`, `Monthly`, `Weekly`, `Daily`, `Once`, `NoFrequency` → `ql/time/frequency.hpp`

## InterestRate
`InterestRate(rate, dayCounter, compounding, frequency)` → `ql/interestrate.hpp`
Methods: `discountFactor(t)`, `compoundFactor(t)`, `equivalentRate(...)`, `impliedRate(...)`

## ORE Calendar Extensions
`QuantExt/qle/calendars/` — additional calendars not in core QuantLib (various minor markets)

## quantlibguide.com
- "Calendars and holidays" — Full tutorial on calendar usage, BespokeCalendar, holiday customization
- "Dates, periods and schedules" — Date arithmetic, schedule construction
