---
title: Risk Analytics and XVA — ORE Reference
wp: n/a
status: reference
created: unknown
last-updated: 2026-03-31
lines: 56
kb-depends: []
jarvis-depends: []
---

# Risk Analytics & XVA — Topic Index (ORE-Focused)

## ORE Architecture
ORE = QuantExt (pricing extensions) + OREData (data/config layer) + OREAnalytics (simulation/aggregation)
Pipeline: Market Data → Scenario Generation → Portfolio Pricing → Aggregation → XVA

## OREAnalytics — Scenario Generation (`orea/scenario/`)
| Class | File | Purpose |
|---|---|---|
| `Scenario` | `scenario.hpp` | Single market state (rates, vols, FX at one time step) |
| `ScenarioSimMarket` | `scenariosimmarket.hpp` | Simulated market built from scenarios |
| `CrossAssetModelScenarioGenerator` | `crossassetmodelscenariogenerator.hpp` | Monte Carlo scenario generation from cross-asset model |
| `HistoricalScenarioGenerator` | `historicalscenariogenerator.hpp` | Scenarios from historical market data |
| `SensitivityScenarioGenerator` | `sensitivityscenariogenerator.hpp` | Bump-and-reval scenarios |
| `StressScenarioGenerator` | `stressscenariogenerator.hpp` | Stress testing scenarios |
| `ShiftScenarioGenerator` | `shiftscenariogenerator.hpp` | Shift-based scenarios |
| `DeltaScenario` | `deltascenario.hpp` | Stores difference from base scenario |

## OREAnalytics — Aggregation (`orea/aggregation/`)
Exposure aggregation, netting set management, CVA/DVA/FVA/MVA/KVA calculation, collateral modeling

## OREAnalytics — Simulation (`orea/simulation/`)
- `SimMarket` → Simulated market for re-pricing under scenarios
- `FixingManager` → Manages fixings during simulation

## OREAnalytics — SIMM (`orea/simm/`)
ISDA Standard Initial Margin Model implementation

## OREAnalytics — Engine (`orea/engine/`)
Orchestrates the analytics pipeline: sensitivity, stress, VaR, exposure, XVA

## ORE Models (`QuantExt/qle/models/`)
| Class | Purpose |
|---|---|
| `CrossAssetModel` | Multi-factor model: IR (LGM) + FX + EQ + INF + CR |
| `LGM` | Linear Gaussian Markov model for IR |
| `FxBsModel` | Black-Scholes FX model |
| `CrLGM1F` | Credit LGM |
| `InfDkModel` | Inflation Dodgson-Kainth |
| `HwModel` | Hull-White model |
| `IrLgm1fParametrization` | LGM parametrization (piecewise constant alpha, kappa) |

## ORE Data Configuration (`OREData/ored/configuration/`)
Market data configuration (curve specs, vol surface specs), conventions, ibor fallback config

## Workflow: Running ORE
```
ore --input ore.xml
```
`ore.xml` references: `market.xml` (market data config), `portfolio.xml` (trade definitions), `simulation.xml` (MC settings), `pricing.xml` (engine config)

## ORE Examples
`ORE/Examples/` — Contains worked examples: Example_1 (vanilla swap), Example_5 (XVA), etc.

## Deep Dive → `details/ore_class_map.md`
