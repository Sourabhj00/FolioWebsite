---
title: QuantLib Topics — Map of Content
wp: n/a
status: reference
last-updated: 2026-03-31
lines: 22
---

# QuantLib Topics — Map of Content

Overview-level topic files (~50–70 lines each) covering QuantLib/ORE
instrument classes, curve construction, risk analytics, and deployment.
Load a topic first, then follow references to details/ for recipes and
class maps. (~681 lines total)

## Files

- [[sofr_and_ois]] — SOFR index, OIS instruments, OvernightIndexedSwapIndex, bootstrap helpers, ORE extensions, SOFR swaption construction. (~53 lines)
- [[yield_curves]] — Yield curve hierarchy, PiecewiseYieldCurve, bootstrap helpers, interpolation, spread curves, ORE extensions. (~63 lines)
- [[swaps_and_irs]] — Swap/VanillaSwap/OIS, builders (MakeVanillaSwap, MakeOIS), leg construction, cross-currency. (~58 lines)
- [[futures_and_forwards]] — SOFR/Fed Funds futures, FRAs, bond forwards, IMM dates, convexity adjustment. (~43 lines)
- [[bonds_and_fixed_income]] — Bond instruments (Fixed, Floating, Zero, Amortizing, Callable), cash flows, pricing engines. (~48 lines)
- [[options_and_volatility]] — Swaptions, caps/floors, equity options, vol surfaces, swaption engines. (~71 lines)
- [[calendars_dates_conventions]] — Date arithmetic, calendars, schedules, day counters, business day conventions. (~47 lines)
- [[design_patterns]] — Observer pattern, Handle/Quote, LazyObject, Instrument/Engine, Settings singleton. (~54 lines)
- [[numerical_methods]] — Interpolation, solvers, optimization, Monte Carlo, FD, lattice methods. (~57 lines)
- [[risk_analytics_xva]] — ORE scenario generation, XVA aggregation, LGM/crossasset models, SIMM. (~56 lines)
- [[ore_trade_and_config]] — ORE XML trade representation, market/conventions/pricing configs, OREData classes. (~74 lines)
- [[api_and_deployment]] — quantraserver (gRPC/REST), ql_rest microservices, quantra.io API, .NET integration. (~69 lines)
