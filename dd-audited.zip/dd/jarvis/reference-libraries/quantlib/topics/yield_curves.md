---
title: Yield Curves — QuantLib Reference
wp: n/a
status: reference
created: unknown
last-updated: 2026-03-31
lines: 63
kb-depends: []
jarvis-depends: []
---

# Yield Curves & Term Structures — Topic Index

## QuantLib Core Classes

### Base Hierarchy
- `TermStructure` → `ql/termstructure.hpp` — Abstract base for all term structures
- `YieldTermStructure` → `ql/termstructures/yield/zeroyieldstructure.hpp` — Base yield curve
- `ZeroYieldStructure` : `YieldTermStructure` — Implements discount from zero rates

### Concrete Curves
| Class | File | Use Case |
|---|---|---|
| `FlatForward` | `yield/flatforward.hpp` | Constant forward rate (testing, quick calcs) |
| `InterpolatedZeroCurve` | `yield/zerocurve.hpp` | Zero curve from (date, rate) pairs + interpolation |
| `InterpolatedForwardCurve` | `yield/forwardcurve.hpp` | Instantaneous forward curve from points |
| `InterpolatedSimpleZeroCurve` | `yield/interpolatedsimplezerocurve.hpp` | Simplified zero curve |
| `PiecewiseYieldCurve` | `yield/piecewiseyieldcurve.hpp` | **Bootstrapped curve** — most common production use |
| `FittedBondDiscountCurve` | `yield/fittedbonddiscountcurve.hpp` | Fit discount curve to bond prices (Nelson-Siegel, Svensson, etc.) |

### Bootstrap Helpers (feed into PiecewiseYieldCurve)
| Helper | File | Instrument |
|---|---|---|
| `DepositRateHelper` | `yield/ratehelpers.hpp` | Money market deposits |
| `FuturesRateHelper` | `yield/ratehelpers.hpp` | Eurodollar/SOFR futures |
| `SwapRateHelper` | `yield/ratehelpers.hpp` | Vanilla IRS quotes |
| `OISRateHelper` | `yield/oisratehelper.hpp` | OIS quotes (SOFR, ESTR, etc.) |
| `OvernightIndexFutureRateHelper` | `yield/overnightindexfutureratehelper.hpp` | SOFR futures |
| `BondHelper` / `FixedRateBondHelper` | `yield/bondhelpers.hpp` | Bond prices |
| `MultipleResetsSwapRateHelper` | `yield/multipleresetsswaphelper.hpp` | Sub-period swaps |

### Interpolation Methods (template parameter for PiecewiseYieldCurve)
Bootstrap trait × interpolation: e.g., `PiecewiseYieldCurve<Discount, LogLinear>`.
Traits: `Discount`, `ZeroYield`, `ForwardRate`, `SimpleZeroYield`
Interpolations: `Linear`, `LogLinear`, `Cubic`, `LogCubic`, `MonotonicCubic`, `SplineCubic`
Python shorthand: `ql.PiecewiseLogCubicDiscount(...)`, `ql.PiecewiseLinearZero(...)`

### Spread Curves
| Class | File | Purpose |
|---|---|---|
| `ZeroSpreadedTermStructure` | `yield/zerospreadedtermstructure.hpp` | Add constant/quote spread to zero rates |
| `ForwardSpreadedTermStructure` | `yield/forwardspreadedtermstructure.hpp` | Add spread to forward rates |
| `ImpliedTermStructure` | `yield/impliedtermstructure.hpp` | Implied curve from a given curve starting at a future date |
| `CompositeZeroYieldStructure` | `yield/compositezeroyieldstructure.hpp` | Combine two curves via operation |

### Fitting Methods (for FittedBondDiscountCurve)
`NelsonSiegelFitting`, `SvenssonFitting`, `ExponentialSplinesFitting`, `CubicBSplinesFitting`, `SimplePolynomialFitting`, `NaturalCubicFitting`, `SpreadFitting` → `yield/nonlinearfittingmethods.hpp`

## ORE Extensions
- `CrossCcyBasisSwapHelper`, `CrossCcyBasisMtMResetSwapHelper` → Cross-currency curve bootstrap
- `AverageOISRateHelper` → Averaged OIS curve bootstrap
- `YieldPlusDefaultYieldTermStructure` → Yield + credit spread composite

## quantra.io API
- `POST /bootstrap-curves` — Bootstraps yield curve from deposit + swap + futures helpers
- Returns: discount factors, zero rates, forward rates at specified tenors

## quantlibguide.com
- "Kinds of interest-rate term structures" — FlatForward, DiscountCurve, ZeroCurve examples
- "Term structures and their reference dates" — Moving vs fixed reference date mechanics
- "Bootstrapping a yield curve" — Full OIS bootstrap with helpers

## Deep Dive → `details/curve_bootstrapping_recipes.md`
