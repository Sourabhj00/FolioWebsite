---
title: API and Deployment — QuantLib Reference
wp: n/a
status: reference
created: unknown
last-updated: 2026-03-31
lines: 69
kb-depends: []
jarvis-depends: []
---

# API & Deployment — Topic Index

## quantraserver (joseprupi/quantraserver)
High-performance distributed QuantLib pricing via gRPC + REST.

**Architecture**: Multiple QuantLib worker processes → Envoy load balancer → gRPC/REST clients
Solves: QuantLib is single-threaded (global `Settings::instance().evaluationDate()`) — quantraserver runs separate processes.

**Directory**: `quantraserver/`
- `server/` — gRPC server (C++)
- `jsonserver/` — REST server (Crow framework), `openapi/` has API spec
- `client/cpp/` — C++ client library
- `quantra-python/` — Python client package
- `flatbuffers/fbs/` — All FlatBuffer schema definitions
- `parser/` — FlatBuffers → QuantLib object converters
- `examples/data/` — Sample JSON requests for all instruments
- `envoy/` — Envoy proxy configuration
- `scripts/` — `build.sh`, `quantra start --workers N`

**Supported Instruments** (from FlatBuffer schemas):
Fixed-rate bond, floating-rate bond, vanilla swap, OIS swap, basis swap, FRA, cap/floor, swaption, equity option, CDS, zero-coupon/YoY inflation swaps

**Quick Start**: `docker build -t quantra . && docker run -p 50051:50051 -p 8080:8080 quantra`

## ql_rest (mkipnis/ql_rest)
REST microservices for QuantLib via QuantLibAddin/C++.

**Directory**: `ql_rest/`
- `qlrest/` — Core: JSON→QuantLibAddin conversion classes
- `qlrest/python_package/` — Python REST helpers
- `gensrc/` — Code generator (metadata → conversion stubs)
- `Examples/bond_pricer/`, `Examples/swap_designer/`, `Examples/options_monitor/` — Working demos
- `docker/` — Docker compose for full stack

**Pattern**: JSON request (boost::json) → extract fields → QuantLibAddinCpp function call → result
Auto-generated `_reader` classes in `qlrest/`: `bonds_reader`, `vanillaswap_reader`, etc.
Example: `bonds::qlFixedRateBond(json_obj)` calls `QuantLibAddinCpp::qlFixedRateBond(...)`

## quantra.io API (Managed Service)
Production REST API at `https://api.quantra.io`. Same engine as quantraserver, hosted.

**Endpoints** (from quantra.io/docs):
| Endpoint | Purpose |
|---|---|
| `POST /price-fixed-rate-bond` | Bond NPV, yield, duration, convexity, cash flows |
| `POST /price-floating-rate-bond` | FRN pricing |
| `POST /price-vanilla-swap` | IRS pricing with full leg analytics |
| `POST /price-ois-swap` | OIS pricing |
| `POST /price-basis-swap` | Basis swap |
| `POST /price-fra` | FRA pricing |
| `POST /price-cap-floor` | Caps/floors with caplet detail |
| `POST /price-swaption` | European swaption |
| `POST /price-equity-option` | Equity option |
| `POST /bootstrap-curves` | Yield curve bootstrapping |
| `POST /calibrate-swaption-model` | Model calibration |

**Auth**: API key via `X-API-Key` header. Portal at quantra.io for interactive use.

## .NET Integration Patterns
QuantLib has no native .NET binding, but integration paths exist:
1. **QuantLib-SWIG → C#** — SWIG generates C# wrapper (lballabio/QuantLib-SWIG)
2. **QLNet** — Pure C# port of QuantLib (separate project, may lag features)
3. **REST/gRPC client** — Call quantraserver from .NET via HTTP/gRPC client
4. **P/Invoke** — Call QuantLib C++ via native interop (complex, not recommended)

**Recommended for STIR trading app**: Option 3 (REST/gRPC) for pricing, Option 1 (SWIG C#) for embedded use.

## Deep Dive → `details/quantra_api_reference.md`, `details/quantraserver_schemas.md`
