---
title: ORE Trade and Config — Reference
wp: n/a
status: reference
created: unknown
last-updated: 2026-03-31
lines: 74
kb-depends: []
jarvis-depends: []
---

# ORE Trade & Configuration — Topic Index

## Trade XML Representation (`OREData/ored/portfolio/`)
ORE represents trades as XML. Each trade type maps to a C++ class derived from `Trade`.

### Interest Rate Trades
| XML Type | C++ Class | File | Notes |
|---|---|---|---|
| `Swap` | `ore::data::Swap` | `swap.hpp` | Vanilla IRS, OIS, basis — configured via XML legs |
| `Swaption` | `ore::data::Swaption` | `swaption.hpp` | European/Bermudan swaption |
| `CapFloor` | `ore::data::CapFloor` | `capfloor.hpp` | IR caps, floors, collars |
| `Bond` | `ore::data::Bond` | `bond.hpp` | Fixed/floating/zero bonds |

### Cross-Currency
`FxForward`, `FxSwap`, `CrossCurrencySwap` (implied from Swap with different leg currencies)

### Credit
`CreditDefaultSwap`, `IndexCreditDefaultSwap`, `CreditDefaultSwapOption`, `SyntheticCDO`

### Other
`ForwardRateAgreement`, `BondForward`, `BondOption`, `EquityForward`, `VanillaOption`, `BondTRS`, `CallableBond`, `ConvertibleBond`, `BondRepo`, `CommodityForward`, `ScriptedTrade` (user-defined payoffs)

### Leg Types (for Swap XML)
Fixed, Floating (IBOR), OIS, CMS, CMS Spread, Digital, CPI, YoY, Equity, Commodity

## Configuration Files

### `market.xml` — Market Data Configuration
Defines which curves, vol surfaces, and market data to build:
- `YieldCurves` — curve IDs, segments (deposits, FRAs, futures, swaps, OIS, cross-currency basis)
- `FXVolatilities`, `SwaptionVolatilities`, `CapFloorVolatilities`
- `DefaultCurves` — CDS curves
- `InflationCurves`, `CommodityCurves`

### `conventions.xml` — Market Conventions
Day counters, business day conventions, fixing calendars, settlement lags per currency/index.

### `todaysmarket.xml` — Market Data Mapping
Maps curve IDs to actual market quotes (e.g., "USD-SOFR-OIS" → specific quote handles).

### `pricing.xml` — Engine Configuration
Maps trade types to pricing engines:
```xml
<Product type="Swap">
  <Model>DiscountedCashflows</Model>
  <Engine>DiscountingSwapEngine</Engine>
</Product>
```

### `simulation.xml` — Monte Carlo Settings
Number of paths, time grid, model calibration settings, exposure output config.

### `ore.xml` — Top-Level Config
References all other config files, sets analytics to run (NPV, cashflows, sensitivity, stress, XVA).

## OREData Key Classes
| Class | File | Purpose |
|---|---|---|
| `Portfolio` | `ored/portfolio/portfolio.hpp` | Container for Trade objects, loads from XML |
| `Trade` | `ored/portfolio/trade.hpp` | Abstract trade base |
| `TradeFactory` | `ored/portfolio/tradefactory.hpp` | Creates Trade from XML type string |
| `EngineFactory` | `ored/portfolio/enginefactory.hpp` | Maps trades to pricing engines |
| `EngineBuilder` | `ored/portfolio/builders/` | One per trade type — builds engine from config |
| `Market` | `ored/marketdata/market.hpp` | Abstract market data interface |
| `TodaysMarket` | `ored/marketdata/todaysmarket.hpp` | Concrete market from live data |
| `InMemoryLoader` | `ored/marketdata/inmemoryloader.hpp` | Load market data from memory |
| `CsvLoader` | `ored/marketdata/csvloader.hpp` | Load market data from CSV files |

## ORE Examples Directory
`ORE/Examples/` — Numbered examples with complete XML configs:
Example_1 (vanilla swap NPV), Example_5 (XVA), Example_13 (sensitivity), etc.

## Deep Dive → `details/ore_class_map.md`
