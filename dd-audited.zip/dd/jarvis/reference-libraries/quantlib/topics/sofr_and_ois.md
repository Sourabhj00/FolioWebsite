---
title: SOFR and OIS — QuantLib Reference
wp: n/a
status: reference
created: unknown
last-updated: 2026-03-31
lines: 53
kb-depends: []
jarvis-depends: []
---

# SOFR & OIS — Topic Index

## QuantLib Core Classes

| Class | Base | File | Purpose |
|---|---|---|---|
| `Sofr` | `OvernightIndex` | `ql/indexes/ibor/sofr.hpp` | SOFR overnight index (Actual360, UnitedStates::SOFR calendar, 0 fixing days) |
| `OvernightIndex` | `IborIndex` | `ql/indexes/iborindex.hpp` | Base class for all overnight rate indexes |
| `OvernightIndexedSwap` | `FixedVsFloatingSwap` | `ql/instruments/overnightindexedswap.hpp` | OIS instrument: `fairRate()`, `fairSpread()`, `fixedLegBPS()` |
| `MakeOIS` | (builder) | `ql/instruments/makeois.hpp` | Fluent builder for OIS (tenor, index, fixedRate, telescopicValueDates) |
| `OISRateHelper` | `RelativeDateRateHelper` | `ql/termstructures/yield/oisratehelper.hpp` | Bootstrap helper for OIS quotes |
| `SofrFutureRateHelper` | `RateHelper` | `ql/termstructures/yield/overnightindexfutureratehelper.hpp` | Bootstrap from SOFR futures (1M and 3M) |
| `OvernightIndexFuture` | `Instrument` | `ql/instruments/overnightindexfuture.hpp` | SOFR futures pricing instrument |
| `OvernightIndexedCoupon` | `FloatingRateCoupon` | `ql/cashflows/overnightindexedcoupon.hpp` | Compounded overnight coupon (daily compounding logic) |

## Other Overnight Indexes (same pattern as SOFR)
`FedFunds` (ql/indexes/ibor/fedfunds.hpp), `Estr` (estr.hpp), `Sonia` (sonia.hpp), `Corra` (corra.hpp), `Aonia` (aonia.hpp), `Tonar` (tonar.hpp), `Saron` (saron.hpp), `Kofr` (kofr.hpp), `Destr` (destr.hpp), `Swestr` (swestr.hpp), `Nzocr` (nzocr.hpp)

## Swap Indexes for OIS (required for swaptions)
| Class | File | Purpose |
|---|---|---|
| `SwapIndex` | `ql/indexes/swapindex.hpp` | Base class linking a swap definition to a fixing |
| `OvernightIndexedSwapIndex` | `ql/indexes/swapindex.hpp` | SwapIndex specialized for OIS — **required for SOFR swaption construction** |

## ORE Extensions
- `AverageOIS` : `Swap` → `QuantExt/qle/instruments/averageois.hpp` — Averaged OIS (arithmetic avg vs compounded)
- `BRLCdiSwap` : `OvernightIndexedSwap` → `qle/instruments/brlcdiswap.hpp` — Brazil CDI overnight swap
- `AverageOISRateHelper` → `qle/termstructures/averageoisratehelper.hpp` — Bootstrap from averaged OIS
- `OISCapFloorHelper` → `qle/termstructures/oiscapfloorhelper.hpp` — OIS cap/floor bootstrap helper
- `SubPeriodsSwap` : `Swap` → `qle/instruments/subperiodsswap.hpp` — Sub-period swap legs

## Key Patterns

**SOFR curve bootstrapping (Python):**
```
sofr = ql.Sofr(ql.YieldTermStructureHandle())
helpers = [ql.OISRateHelper(2, Period, QuoteHandle(SimpleQuote(rate)), sofr) ...]
curve = ql.PiecewiseLogCubicDiscount(today, helpers, ql.Actual365Fixed())
```

**Single-curve OIS pricing:** Same curve for forecast + discount.
**Telescopic value dates:** Set `telescopicValueDates=True` in MakeOIS to optimize floating leg calc.
**SOFR futures:** Use `OvernightIndexFutureRateHelper` for 1M/3M SOFR futures in bootstrap.

## quantra.io API
- `POST /price-ois-swap` — Prices OIS swaps with SOFR as overnight index

## quantlibguide.com
- "Different kinds of swaps" chapter → OIS section with SOFR curve + swap construction
- "Bootstrapping a yield curve" → OISRateHelper usage examples

## Deep Dive → `details/quantlib_sofr_implementation.md`
