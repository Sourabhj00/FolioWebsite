---
title: Swaps and IRS — QuantLib Reference
wp: n/a
status: reference
created: unknown
last-updated: 2026-03-31
lines: 58
kb-depends: []
jarvis-depends: []
---

# Swaps & Interest Rate Swaps — Topic Index

## QuantLib Instruments
| Class | Base | File | Purpose |
|---|---|---|---|
| `Swap` | `Instrument` | `ql/instruments/swap.hpp` | Generic multi-leg swap: `NPV()`, `legNPV(i)`, `legBPS(i)` |
| `VanillaSwap` | `FixedVsFloatingSwap` | `ql/instruments/vanillaswap.hpp` | Fixed-vs-IBOR swap: `fairRate()`, `fairSpread()` |
| `FixedVsFloatingSwap` | `Swap` | `ql/instruments/fixedvsfloatingswap.hpp` | Base for fixed-vs-float swaps |
| `OvernightIndexedSwap` | `FixedVsFloatingSwap` | `ql/instruments/overnightindexedswap.hpp` | OIS (see `topics/sofr_and_ois.md`) |
| `BMASwap` | `Swap` | `ql/instruments/bmaswap.hpp` | BMA/SIFMA municipal swap |
| `MultipleResetsSwap` | `FixedVsFloatingSwap` | `ql/instruments/multipleresetsswap.hpp` | Sub-period swap (multiple resets per period) |
| `NonstandardSwap` | `Swap` | `ql/instruments/nonstandardswap.hpp` | Amortizing/accreting notional, step coupons |
| `FloatFloatSwap` | `Swap` | `ql/instruments/floatfloatswap.hpp` | Basis swap (float vs float) |
| `CPISwap` | `Swap` | `ql/instruments/cpiswap.hpp` | CPI inflation swap |
| `YearOnYearInflationSwap` | `Swap` | `ql/instruments/yearonyearinflationswap.hpp` | YoY inflation swap |
| `ZeroCouponSwap` | `Swap` | `ql/instruments/zerocouponswap.hpp` | Zero-coupon vs floating |
| `EquityTotalReturnSwap` | `Swap` | `ql/instruments/equitytotalreturnswap.hpp` | Equity TRS |

## Builders
- `MakeVanillaSwap` → `ql/instruments/makevanillaswap.hpp` — Fluent builder for vanilla IRS
- `MakeOIS` → `ql/instruments/makeois.hpp` — Fluent builder for OIS
- `MakeCms` → `ql/instruments/makecms.hpp` — CMS swap builder

## Pricing Engines
| Engine | File | Method |
|---|---|---|
| `DiscountingSwapEngine` | `pricingengines/swap/discountingswapengine.hpp` | Standard discounted cash flow |
| `CounterpartyAdjSwapEngine` | `pricingengines/swap/cvaswapengine.hpp` | With CVA adjustment |

## Leg Construction
`ql/cashflows/`: `FixedRateLeg`, `IborLeg`, `OvernightLeg`, `CmsLeg`, `DigitalIborLeg`
`ql/experimental/coupons/`: `CmsSpreadCoupon` (CMS spread leg — **experimental**)
Legs are built from `Schedule` + index + spread/gearing and attached to `Swap`.

## ORE Extensions
| Class | File | Purpose |
|---|---|---|
| `CrossCcySwap` | `qle/instruments/crossccyswap.hpp` | Cross-currency swap base |
| `CrossCcyBasisSwap` | `qle/instruments/crossccybasisswap.hpp` | Cross-currency basis swap |
| `CrossCcyBasisMtMResetSwap` | `qle/instruments/crossccybasismtmresetswap.hpp` | With MtM reset notional |
| `CrossCcyFixFloatSwap` | `qle/instruments/crossccyfixfloatswap.hpp` | Cross-currency fixed-float |
| `TenorBasisSwap` | `qle/instruments/tenorbasisswap.hpp` | Single-currency tenor basis |
| `SubPeriodsSwap` | `qle/instruments/subperiodsswap.hpp` | Sub-period compounding/averaging |
| `FlexiSwap` | `qle/instruments/flexiswap.hpp` | Flexi swap (exercise into swap) |
| `BalanceGuaranteedSwap` | `qle/instruments/balanceguaranteedswap.hpp` | Balance guaranteed swap |
| `CurrencySwap` | `qle/instruments/currencyswap.hpp` | Generic multi-currency swap |

## quantra.io API
- `POST /price-vanilla-swap` — Fixed-for-floating, full leg analytics + fair rate
- `POST /price-ois-swap` — OIS pricing
- `POST /price-basis-swap` — Basis swap pricing

## quantlibguide.com
- "Different kinds of swaps" — OIS, vanilla, basis swap examples with SOFR
- "Instruments and pricing engines" — Engine attachment pattern

## Deep Dive → `details/swap_construction_recipes.md`
