---
title: Design Patterns — QuantLib Reference
wp: n/a
status: reference
created: unknown
last-updated: 2026-03-31
lines: 54
kb-depends: []
jarvis-depends: []
---

# Design Patterns — Topic Index

## Observer / Observable Pattern
**The most important pattern in QuantLib.** All market data, term structures, and instruments are linked via Observer/Observable so that changes propagate automatically.

| Class | File | Role |
|---|---|---|
| `Observable` | `ql/patterns/observable.hpp` | Base: broadcasts changes to registered observers |
| `Observer` | `ql/patterns/observable.hpp` | Base: receives notifications, calls `update()` |
| `LazyObject` | `ql/patterns/lazyobject.hpp` | Observer that defers recalculation until `NPV()` or similar is called (dirty bit pattern) |

**Chain**: `SimpleQuote` (Observable) → `YieldTermStructure` (Observer + Observable) → `Instrument` (Observer)
When quote changes → curve marks itself dirty → instrument marks itself dirty → next `NPV()` call triggers full recalculation.

## Handle / Quote Pattern
| Class | File | Purpose |
|---|---|---|
| `Quote` | `ql/quote.hpp` | Abstract: `value()` returns current market value |
| `SimpleQuote` | `ql/quotes/simplequote.hpp` | Mutable quote: `setValue(x)` triggers notification chain |
| `Handle<T>` | `ql/handle.hpp` | Smart reference to an Observable; can be relinked to a different object |
| `RelinkableHandle<T>` | `ql/handle.hpp` | Handle that can be pointed to a new underlying object |
| `QuoteHandle` | (typedef) | `Handle<Quote>` |
| `YieldTermStructureHandle` | (typedef) | `Handle<YieldTermStructure>` |

**Pattern**: Build instruments with Handles → relink handles to new data → instruments auto-update.
This is how QuantLib supports "what-if" analysis and live repricing without rebuilding objects.

## Instrument / PricingEngine Pattern
| Class | File | Role |
|---|---|---|
| `Instrument` | `ql/instrument.hpp` | Abstract: holds results, delegates to engine via `performCalculations()` |
| `PricingEngine` | `ql/pricingengine.hpp` | Abstract: `calculate()` method, accesses instrument's Arguments, fills Results |
| `GenericEngine<Args, Results>` | `ql/pricingengine.hpp` | Template engine base |

**Usage**: `instrument.setPricingEngine(engine)` — decouples instrument specification from pricing method.
Same `VanillaOption` can use `AnalyticEuropeanEngine`, `MCEuropeanEngine`, or `BinomialVanillaEngine`.

## Settings Singleton
`Settings::instance().evaluationDate()` → `ql/settings.hpp`
Global evaluation date. **Thread-unsafe** — this is why quantraserver uses multiple processes.
`Settings::instance().includeReferenceDateEvents` — controls expired instrument behavior.

## Key Architectural Choices
- **Notification graph** can be expensive with many objects. `LazyObject` mitigates by deferring.
- **Handles** allow relinking without rebuilding the dependency graph.
- **Piecewise curves** are `LazyObject` — bootstrap only triggers when a value is requested after inputs change.
- ORE's `ScenarioSimMarket` builds an entire market from `Handle` relinking per scenario.

## quantlibguide.com
- "The Observer pattern" — Deep dive with C++ code, notification cost analysis, threading discussion
- "Instruments and pricing engines" — Engine attachment, recalculation mechanics
- "Term structures and their reference dates" — Handle relinking for moving reference dates
- "A taste of QuantLib" — Practical Handle/Quote usage with bonds
