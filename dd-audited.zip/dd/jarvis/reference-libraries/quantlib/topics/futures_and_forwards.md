---
title: Futures and Forwards — QuantLib Reference
wp: n/a
status: reference
created: unknown
last-updated: 2026-03-31
lines: 43
kb-depends: []
jarvis-depends: []
---

# Futures & Forwards — Topic Index

## QuantLib Instruments
| Class | File | Purpose |
|---|---|---|
| `OvernightIndexFuture` | `ql/instruments/overnightindexfuture.hpp` | SOFR futures (1M/3M), compounded rate over delivery period |
| `ForwardRateAgreement` | `ql/instruments/forwardrateagreement.hpp` | FRA: `forwardRate()`, `spotValue()` |
| `BondForward` | `ql/instruments/bondforward.hpp` | Forward on a bond |
| `FxForward` | `ql/instruments/fxforward.hpp` | FX forward contract |
| `Forward` | `ql/instruments/forward.hpp` | Abstract forward base class |
| `Futures` | `ql/instruments/futures.hpp` | Enum: `Futures::IMM`, `Futures::ASX`, `Futures::Custom` |

## Bootstrap Helpers for Futures
| Helper | File | Use |
|---|---|---|
| `FuturesRateHelper` | `ql/termstructures/yield/ratehelpers.hpp` | Eurodollar/STIR futures → curve bootstrap |
| `OvernightIndexFutureRateHelper` | `ql/termstructures/yield/overnightindexfutureratehelper.hpp` | SOFR 1M/3M futures → curve bootstrap |
| `FedFundsFutureRateHelper` | (in ratehelpers.hpp) | Fed Funds futures |

## IMM Dates
`IMM::date()`, `IMM::nextDate()`, `IMM::isIMMdate()` → `ql/time/imm.hpp`
`ASX::date()`, `ASX::nextDate()`, `ASX::isASXdate()` → `ql/time/asx.hpp`

## Convexity Adjustment
Futures vs forwards: `FuturesRateHelper` accepts optional convexity adjustment quote.
For SOFR futures: The `OvernightIndexFutureRateHelper` handles the compounding period correctly — no separate convexity adjustment needed for short-dated futures, but may need adjustment for deferred contracts.

## ORE Extensions
- `BondFuture` → `qle/instruments/bondfuture.hpp` — Bond futures pricing with CTD basket
- `FxForward` → `qle/instruments/fxforward.hpp` — Extended FX forward with settlement conventions
- `EquityForward` → `qle/instruments/equityforward.hpp` — Equity forward
- `CommodityForward` → `qle/instruments/commodityforward.hpp` — Commodity forward

## quantra.io API
- `POST /price-fra` — FRA pricing with implied forward rates and settlement

## quantraserver FlatBuffers
- `fra.fbs` / `price_fra_request.fbs` — FRA request/response schema
- `ois_swap.fbs` — OIS (includes futures-based pricing)

## quantlibguide.com
- "A taste of QuantLib" — Schedule construction relevant for futures delivery periods
