---
title: Bonds and Fixed Income — QuantLib Reference
wp: n/a
status: reference
created: unknown
last-updated: 2026-03-31
lines: 48
kb-depends: []
jarvis-depends: []
---

# Bonds & Fixed Income — Topic Index

## QuantLib Instruments
| Class | Base | File | Purpose |
|---|---|---|---|
| `Bond` | `Instrument` | `ql/instruments/bond.hpp` | Abstract base: `cleanPrice()`, `dirtyPrice()`, `yield()`, `duration()`, `convexity()`, `accruedAmount()` |
| `FixedRateBond` | `Bond` | `ql/instruments/bonds/fixedratebond.hpp` | Standard fixed-coupon bond |
| `FloatingRateBond` | `Bond` | `ql/instruments/bonds/floatingratebond.hpp` | IBOR/overnight-linked floating bond |
| `ZeroCouponBond` | `Bond` | `ql/instruments/bonds/zerocouponbond.hpp` | Discount bond |
| `AmortizingFixedRateBond` | `Bond` | `ql/instruments/bonds/amortizingfixedratebond.hpp` | Amortizing schedule |
| `ConvertibleFixedCouponBond` etc. | `Bond` | `ql/instruments/bonds/convertiblebonds.hpp` | Convertible bonds (fixed, floating, zero) |
| `CallableFixedRateBond` | `Bond` | `ql/experimental/callablebonds/callablebond.hpp` | Callable bond (**experimental**) |
| `CmsRateBond` | `Bond` | `ql/instruments/bonds/cmsratebond.hpp` | CMS-linked bond |
| `AssetSwap` | `Swap` | `ql/instruments/assetswap.hpp` | Par/market asset swap |
| `BondForward` | `Forward` | `ql/instruments/bondforward.hpp` | Bond forward contract |

## Pricing Engines
| Engine | File | Method |
|---|---|---|
| `DiscountingBondEngine` | `pricingengines/bond/discountingbondengine.hpp` | Discount cash flows (standard) |
| `RiskyBondEngine` | `pricingengines/bond/riskybondengine.hpp` | With default probability |
| `BinomialConvertibleEngine` | `pricingengines/bond/binomialconvertibleengine.hpp` | Tree-based convertible pricing |
| `TreeCallableFixedRateBondEngine` | `experimental/callablebonds/treecallablebondengine.hpp` | Short-rate tree for callables (**experimental**) |

## Cash Flow Classes
All in `ql/cashflows/`: `FixedRateCoupon` (fixedratecoupon.hpp), `IborCoupon` (iborcoupon.hpp), `OvernightIndexedCoupon` (overnightindexedcoupon.hpp), `CmsRateCoupon`, `CappedFlooredCoupon`, `Redemption`, `AmortizingPayment`

## ORE Extensions
- `CallableBond` → `qle/instruments/callablebond.hpp` — Extended callable bond
- `BondTRS` → `qle/instruments/bondtotalreturnswap.hpp` — Bond total return swap
- `ForwardBond` → `qle/instruments/forwardbond.hpp` — Forward bond contract
- `BondRepo` → `qle/instruments/bondrepo.hpp` — Bond repo instrument
- `BondFuture` → `qle/instruments/bondfuture.hpp` — Bond futures
- `ConvertibleBond2` → `qle/instruments/convertiblebond2.hpp` — Enhanced convertible

## ORE Trade XML Types
`Bond`, `ForwardBond`, `BondOption`, `BondTRS`, `CallableBond`, `ConvertibleBond`, `BondRepo`, `BondFuture`, `BondPosition` → `OREData/ored/portfolio/`

## quantra.io API
- `POST /price-fixed-rate-bond` — NPV, clean/dirty price, yield, duration, convexity, cash flows
- `POST /price-floating-rate-bond` — Floating rate note pricing

## quantlibguide.com
- "A taste of QuantLib" — Fixed-rate bond construction, yield solver (Brent), zero-spreaded curve
- "Pricing over a range of days" — Re-pricing bonds across dates with curve updates

## Deep Dive → `details/quantlib_class_map.md` (full instrument hierarchy)
