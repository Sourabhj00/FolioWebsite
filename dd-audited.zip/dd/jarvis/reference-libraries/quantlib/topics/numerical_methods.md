---
title: Numerical Methods — QuantLib Reference
wp: n/a
status: reference
created: unknown
last-updated: 2026-03-31
lines: 57
kb-depends: []
jarvis-depends: []
---

# Numerical Methods — Topic Index

## Interpolation (`ql/math/interpolations/`)
| Class | File | Use |
|---|---|---|
| `LinearInterpolation` | `linearinterpolation.hpp` | Piecewise linear |
| `LogLinearInterpolation` | `loginterpolation.hpp` | Log-linear (for discount factors) |
| `CubicInterpolation` | `cubicinterpolation.hpp` | Cubic spline (Kruger, Spline, etc.) |
| `LogCubicInterpolation` | `loginterpolation.hpp` | Log-cubic (smooth discounts) |
| `SABRInterpolation` | `sabrinterpolation.hpp` | SABR vol smile fitting |
| `BackwardFlatInterpolation` | `backwardflatinterpolation.hpp` | Piecewise constant (hazard rates) |
| `BilinearInterpolation` | `bilinearinterpolation.hpp` | 2D bilinear |
| `BicubicSpline` | `bicubicsplineinterpolation.hpp` | 2D bicubic |
| `MultiCubicSpline` | `multicubicspline.hpp` | N-dimensional cubic |

## Solvers (`ql/math/solvers1d/`)
`Brent`, `Bisection`, `Newton`, `Secant`, `FalsePosition`, `Ridder`, `FiniteDifferenceNewtonSafe`
Usage: `solver.solve(f, accuracy, guess, step)` or `solver.solve(f, accuracy, xMin, xMax)`

## Optimization (`ql/math/optimization/`)
| Class | File | Purpose |
|---|---|---|
| `LevenbergMarquardt` | `levenbergmarquardt.hpp` | Least-squares fitting (vol calibration) |
| `Simplex` | `simplex.hpp` | Nelder-Mead |
| `ConjugateGradient` | `conjugategradient.hpp` | CG optimization |
| `SteepestDescent` | `steepestdescent.hpp` | Gradient descent |
| `DifferentialEvolution` | `differentialevolution.hpp` | Global optimizer |
| `EndCriteria` | `endcriteria.hpp` | Convergence criteria (maxIterations, tolerance) |
| `Constraint` | `constraint.hpp` | `NoConstraint`, `BoundaryConstraint`, `PositiveConstraint` |

## Monte Carlo (`ql/methods/montecarlo/`)
| Class | File | Purpose |
|---|---|---|
| `MonteCarloModel` | `montecarlomodel.hpp` | Template MC framework |
| `PathGenerator` | `pathgenerator.hpp` | Generates sample paths from stochastic process |
| `Path` | `path.hpp` | Single simulated path |
| `MultiPath` | `multipath.hpp` | Multi-dimensional paths |
| `MCSimulation` | `mcsimulation.hpp` | Orchestrates MC simulation with convergence |
| `LongstaffSchwartzPathPricer` | `longstaffschwartzpathpricer.hpp` | American option MC (LSM) |

## Random Number Generation (`ql/math/randomnumbers/`)
`MersenneTwisterUniformRng`, `SobolRsg` (quasi-random), `InverseCumulativeNormal`, `BoxMullerGaussianRng`

## Finite Difference (`ql/methods/finitedifferences/`)
`FdmBlackScholesOp`, `FdmHullWhiteOp`, `FdmHestonOp`, `FdmMesher`, `Fdm1dMesher`, `FdmLinearOpComposite`
Schemes: `CrankNicolson`, `Douglas`, `ExplicitEuler`, `ImplicitEuler`, `HundsdorferScheme`, `ModifiedCraigSneyd`

## Lattice Methods (`ql/methods/lattices/`)
`BinomialTree` (CRR, JR, Tian, LR, Joshi4), `TrinomialTree`, `TreeLattice`, `BSMLattice`

## Distributions (`ql/math/distributions/`)
`NormalDistribution`, `CumulativeNormalDistribution`, `InverseCumulativeNormal`, `BivariateCumulativeNormalDistribution`, `PoissonDistribution`, `ChiSquareDistribution`

## ORE Extensions
- `QuantExt/qle/math/` — Additional math utilities for risk analytics
- `QuantExt/qle/methods/` — Extended numerical methods for exotic pricing
