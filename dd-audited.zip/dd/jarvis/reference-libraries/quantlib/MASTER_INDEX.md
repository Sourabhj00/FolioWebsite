---
title: QuantLib Ecosystem — Master Index
wp: n/a
status: reference
created: unknown
last-updated: 2026-03-31
lines: 38
kb-depends: []
jarvis-depends: []
---

# QuantLib Ecosystem — Master Directory Index

## Quick Routing Table

| If you need... | Load this file |
|---|---|
| SOFR rates, OIS swaps, overnight indexes | `topics/sofr_and_ois.md` |
| Yield curve bootstrapping, interpolation, term structures | `topics/yield_curves.md` |
| Bond pricing, duration, convexity, cash flows | `topics/bonds_and_fixed_income.md` |
| Interest rate swaps (vanilla, basis, cross-currency) | `topics/swaps_and_irs.md` |
| Swaptions, caps, floors, vol surfaces | `topics/options_and_volatility.md` |
| Rate futures, FRAs, convexity adjustments | `topics/futures_and_forwards.md` |
| Date arithmetic, calendars, schedules, day counters | `topics/calendars_dates_conventions.md` |
| Solvers, interpolation, optimization, Monte Carlo, FD methods | `topics/numerical_methods.md` |
| XVA, exposure simulation, scenarios, risk analytics (ORE) | `topics/risk_analytics_xva.md` |
| REST/gRPC APIs, distributed QuantLib, .NET integration | `topics/api_and_deployment.md` |
| Observer pattern, Handle/Quote, LazyObject, Instrument/Engine | `topics/design_patterns.md` |
| ORE trade XML, portfolio representation, market data config | `topics/ore_trade_and_config.md` |

## Sources Covered

| Source | Version/Date | What It Provides |
|---|---|---|
| QuantLib (`lballabio/QuantLib`) | v1.39+ / master 2026-03 | Core C++ library: instruments, curves, engines, models |
| ORE (`OpenSourceRisk/Engine`) | master 2026-03 | QuantExt (extensions), OREData (XML trades), OREAnalytics (XVA/simulation) |
| ql_rest (`mkipnis/ql_rest`) | master | JSON↔QuantLibAddin REST microservices |
| quantraserver (`joseprupi/quantraserver`) | master | gRPC/REST server, FlatBuffers schemas, distributed pricing |
| quantra.io | API docs | Production REST API: bonds, swaps, swaptions, caps/floors, FRAs |
| quantlibguide.com | 2025 edition | Luigi Ballabio's authoritative usage guide (Python + C++) |

## How to Use

1. Read the routing table above
2. Load ONE relevant topic file from `topics/`
3. If you need exact signatures, code patterns, or deep class maps, the topic file will point you to a `details/` file
4. **Never pre-load directory files into trading strategy context**
5. Maximum load: Master + 1 topic + 1 detail (~5K tokens)
