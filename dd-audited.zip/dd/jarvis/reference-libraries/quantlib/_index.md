---
title: QuantLib Ecosystem — Map of Content
wp: n/a
status: reference
last-updated: 2026-03-31
lines: 22
---

# QuantLib Ecosystem — Map of Content

QuantLib v1.39+, ORE v1.8.15.0, quantraserver, ql_rest, and related
Python/C++ tools for interest rate curve construction, instrument pricing,
risk analytics, and deployment. Two-tier structure: topics/ for overviews
(~50–70 lines each), details/ for recipes and class maps (~55–148 lines each).
(~1,497 lines across 21 files)

## Files

- [[quantlib/MASTER_INDEX]] — Routing table: maps problem domains to topic and detail files with version metadata. (~38 lines)
- [[quantlib/SOURCE_MANIFEST]] — Version tracking: 6 git repos with commit hashes and refresh instructions. (~35 lines)

## Subfolders

- [[reference-libraries/quantlib/topics/_index|Topics]] — 12 topic overviews covering SOFR/OIS, yield curves, swaps, futures, bonds, options, risk analytics, design patterns, API deployment. (~693 lines)
- [[reference-libraries/quantlib/details/_index|Details]] — 7 deep-dive files with Python recipes, class hierarchies, and implementation guides. (~731 lines)

## Related Folders

- [[fair-value/_index|Fair Value]] — SOFR bootstrap methodology uses QuantLib classes for curve construction
