---
title: QuantLib Ecosystem — Source Manifest
wp: n/a
status: reference
created: unknown
last-updated: 2026-03-31
lines: 35
kb-depends: []
jarvis-depends: []
---

# Source Manifest

**Directory generated**: 2026-03-30
**Generator**: Claude (Opus 4.6) — automated extraction from cloned repos + web sources

## Git Repositories

| Source | URL | Commit | Date |
|---|---|---|---|
| QuantLib | https://github.com/lballabio/QuantLib | `17534a9` | 2026-03 |
| ORE | https://github.com/OpenSourceRisk/Engine | `0b2fc17` (v1.8.15.0 merge) | 2026-03 |
| ql_rest | https://github.com/mkipnis/ql_rest | `4f1ae99` | 2026-03 |
| quantraserver | https://github.com/joseprupi/quantraserver | `694c55c` | 2026-03 |

## Web Sources

| Source | URL | Last Fetched |
|---|---|---|
| quantra.io | https://quantra.io / https://apidocs.quantra.io | 2026-03-30 |
| quantlibguide.com | https://www.quantlibguide.com | 2026-03-30 |

## Version Notes
- QuantLib: v1.39+ (master, post-1.39 release). C++17 required. Default `ext::any`/`ext::optional` = std.
- ORE: v1.8.15.0. Depends on patched QuantLib (bundled as git submodule in ORE repo).
- ql_rest: Depends on QuantLibAddin (legacy C++ interface). Less actively maintained.
- quantraserver: Active. Docker-based deployment. FlatBuffers + gRPC + REST (Crow).

## Refresh Instructions
To update this directory after a new QuantLib/ORE release:
1. Re-clone repos with new tags
2. Re-run class extraction (grep for `class X : public Y` in `.hpp` files)
3. Update affected topic and detail files
4. Update this manifest with new commit hashes
5. Spot-check 2-3 topic files against actual repo to verify accuracy
