---
title: Portfolio & Risk — Source Manifest
wp: n/a
status: reference
created: unknown
last-updated: 2026-03-31
lines: 33
kb-depends: []
jarvis-depends: []
---

# Source Manifest — Portfolio & Risk Libraries

## Processing Date
2026-03-30

## Repositories

| Library | Source | Commit/Version | Clone Method |
|---|---|---|---|
| Riskfolio-Lib | https://github.com/dcajasn/Riskfolio-Lib | 7bda1cd | git clone --depth 1 |
| PyPortfolioOpt | https://pypi.org/project/pyportfolioopt/ | 1.6.0 | pip install |
| QuantStats | https://github.com/ranaroussi/quantstats | fbd10da | git clone --depth 1 |
| Alphalens | https://github.com/quantopian/alphalens | 77084f1 | git clone --depth 1 |
| EigenLedger | https://github.com/santoshlite/EigenLedger | 0f965f9 | git clone --depth 1 |
| QFRM | https://pypi.org/project/qfrm/ | 0.2.0.27 | pip install |

## Notes
- **Alphalens**: Archived Quantopian repo. No longer maintained. Widely used, stable API.
- **QFRM**: Has import error in v0.2.0.27 (`ModuleNotFoundError: No module named 'qfrm.Options'`). Source files are intact and classes are usable individually.
- **EigenLedger**: Wraps PyPortfolioOpt internally for optimization. Bundles a vendored copy of `empyrical` for stats.
- **PyPortfolioOpt**: Installed via pip; source at `site-packages/pypfopt/`. Import as `from pypfopt import ...`.
- **Riskfolio-Lib**: Most comprehensive library. Import as `import riskfolio as rp`.

## File Path Reference
| Library | Source Root |
|---|---|
| Riskfolio-Lib | `riskfolio/src/` (7 core modules) |
| PyPortfolioOpt | `pypfopt/` (12 modules + efficient_frontier subpackage) |
| QuantStats | `quantstats/` (stats.py, reports.py, plots.py, utils.py) |
| Alphalens | `alphalens/` (performance.py, plotting.py, tears.py, utils.py) |
| EigenLedger | `EigenLedger/` (main.py contains all classes/functions) |
| QFRM | `qfrm/` (OptionValuation.py base + 20 exotic option modules) |
