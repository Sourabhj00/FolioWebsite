---
title: Portfolio & Risk — Master Index
wp: n/a
status: reference
created: unknown
last-updated: 2026-03-31
lines: 37
kb-depends: []
jarvis-depends: []
---

# Portfolio & Risk Libraries — Master Directory Index

## Quick Routing Table
| If you need... | Load this file |
|---|---|
| Mean-variance, efficient frontier, max Sharpe, min vol | `topics/portfolio_optimization.md` |
| Black-Litterman views, bayesian BL, factor BL | `topics/black_litterman.md` |
| HRP, HERC, hierarchical clustering portfolios | `topics/hierarchical_methods.md` |
| VaR, CVaR, EVaR, drawdown, volatility, risk measures | `topics/risk_metrics.md` |
| Sharpe, Sortino, Calmar, performance ratios | `topics/performance_ratios.md` |
| Expected returns, covariance estimation, shrinkage | `topics/returns_and_covariance.md` |
| Weight constraints, sector limits, turnover, cardinality | `topics/constraints_and_objectives.md` |
| Factor analysis, IC, factor returns, quantile analysis | `topics/factor_analysis.md` |
| Tear sheets, HTML reports, Excel reports | `topics/reporting.md` |
| Plotting: frontier, pie, bar, drawdown, dendrogram | `topics/plotting.md` |
| Backtesting portfolios, rebalancing schedules | `topics/backtesting.md` |
| Option pricing (European, American, exotic), Greeks | `topics/options_pricing.md` |
| Data prep, returns conversion, utilities | `topics/data_preparation.md` |

## Sources Covered
| Library | Version | Language | Primary Focus |
|---|---|---|---|
| Riskfolio-Lib | 6.4.2 (commit 7bda1cd) | Python | Full portfolio optimization & risk |
| PyPortfolioOpt | 1.6.0 (pip) | Python | Efficient frontier & allocation |
| QuantStats | 0.0.81 (commit fbd10da) | Python | Performance analytics & reporting |
| Alphalens | 0.4.0 (commit 77084f1) | Python | Factor analysis (archived) |
| EigenLedger | latest (commit 0f965f9) | Python | Backtest & rebalancing |
| QFRM | 0.2.0.27 (pip) | Python | Option pricing & derivatives |

## How to Use
1. Read routing table above → identify topic
2. Load ONE topic file (~500–1,200 tokens)
3. Optionally load ONE detail file for exact signatures (~1,000–3,000 tokens)
4. Max load per query: Master + 1 topic + 1 detail ≈ 5K tokens

Never pre-load this directory into trading strategy context. Reference on-demand only.
