---
title: Portfolio & Risk Analytics — Map of Content
wp: n/a
status: reference
last-updated: 2026-03-31
lines: 18
---

# Portfolio & Risk Analytics — Map of Content

Riskfolio-Lib, PyPortfolioOpt, QuantStats, Alphalens, EigenLedger, and
QFRM: portfolio optimization, risk metrics, factor analysis, Black-Litterman,
hierarchical methods, backtesting, and reporting. Two-tier structure:
topics/ for overviews (~32–74 lines each), details/ for API-level reference
(~111–144 lines each). (~1,969 lines across 24 files)

## Files

- [[portfolio-risk/MASTER_INDEX]] — Routing table: maps problem domains to topic and detail files with library version metadata. (~37 lines)
- [[portfolio-risk/SOURCE_MANIFEST]] — Processing metadata, repo URLs, commit hashes, install methods. (~33 lines)

## Subfolders

- [[reference-libraries/portfolio-risk/topics/_index|Topics]] — 13 topic overviews covering optimization, risk, BL, HRP, factor analysis, backtesting, reporting, plotting. (~733 lines)
- [[reference-libraries/portfolio-risk/details/_index|Details]] — 9 API-level detail files with signatures, recipes, library comparison. (~1,166 lines)
