---
title: Portfolio Optimization — Reference
wp: n/a
status: reference
created: unknown
last-updated: 2026-03-31
lines: 54
kb-depends: []
jarvis-depends: []
---

# Portfolio Optimization — Topic Index

## Riskfolio-Lib (`riskfolio/src/Portfolio.py`)
| Method | Purpose |
|---|---|
| `Portfolio.optimization(model, rm, obj, rf, l, hist)` | Core optimizer. model: Classic/BL/FM/BLFM/WC. rm: 30+ risk measures. obj: MinRisk/MaxRet/Utility/Sharpe |
| `Portfolio.rp_optimization(model, rm, rf, b, hist)` | Risk parity optimization. Equal risk contribution across assets |
| `Portfolio.rrp_optimization(model, version, l, b, hist)` | Relaxed risk parity (versions A/B/C) |
| `Portfolio.wc_optimization(obj, rf, l, Umu, Ucov)` | Worst-case optimization with uncertainty sets (box/ellip) |
| `Portfolio.frc_optimization(model, rm, obj, rf, l, hist)` | Factor risk contribution optimization |
| `Portfolio.owa_optimization(obj, owa_w, kelly, rf, l)` | OWA (Ordered Weighted Average) risk optimization |
| `Portfolio.efficient_frontier(model, rm, points, rf, hist)` | Trace efficient frontier (returns list of weights) |
| `Portfolio.frontier_limits(model, rm, kelly, rf, hist)` | Get min-risk and max-return boundary points |

## PyPortfolioOpt (`pypfopt/efficient_frontier/efficient_frontier.py`)
| Class/Method | Purpose |
|---|---|
| `EfficientFrontier(expected_returns, cov_matrix, weight_bounds)` | Main optimizer. Inherits BaseConvexOptimizer |
| `EfficientFrontier.min_volatility()` | Minimum variance portfolio |
| `EfficientFrontier.max_sharpe(risk_free_rate)` | Tangency portfolio |
| `EfficientFrontier.max_quadratic_utility(risk_aversion)` | Max quadratic utility |
| `EfficientFrontier.efficient_risk(target_volatility)` | Target vol on efficient frontier |
| `EfficientFrontier.efficient_return(target_return)` | Target return on efficient frontier |
| `EfficientFrontier.portfolio_performance(verbose, risk_free_rate)` | Returns (ret, vol, sharpe) |
| `EfficientCVaR` (`efficient_frontier/efficient_cvar.py`) | CVaR-optimized frontier. `min_cvar()`, `efficient_risk(target_cvar)` |
| `EfficientCDaR` (`efficient_frontier/efficient_cdar.py`) | CDaR-optimized frontier. `min_cdar()`, `efficient_risk(target_cdar)` |
| `EfficientSemivariance` (`efficient_frontier/efficient_semivariance.py`) | Semivariance frontier. `min_semivariance()` |
| `CLA` (`pypfopt/cla.py`) | Critical Line Algorithm. `max_sharpe()`, `min_volatility()`, `efficient_frontier(points)` |

## PyPortfolioOpt — Constraints & Objectives (`pypfopt/base_optimizer.py`)
| Method | Purpose |
|---|---|
| `BaseConvexOptimizer.add_constraint(new_constraint)` | Lambda constraint, e.g. `lambda w: w[0] >= 0.1` |
| `BaseConvexOptimizer.add_sector_constraints(sector_mapper, sector_lower, sector_upper)` | Sector weight bounds |
| `BaseConvexOptimizer.add_objective(new_objective)` | Add regularization or custom objective |
| `BaseConvexOptimizer.convex_objective(custom_objective)` | Fully custom convex objective |
| `BaseConvexOptimizer.nonconvex_objective(custom_objective)` | Non-convex with scipy minimize |

## EigenLedger (`EigenLedger/main.py`)
| Function | Purpose |
|---|---|
| `efficient_frontier(my_portfolio, perf)` | Efficient frontier via PyPortfolioOpt wrapper |
| `mean_var(my_portfolio, vol_max, perf)` | Mean-variance with max vol constraint |
| `min_var(my_portfolio, perf)` | Minimum variance portfolio |
| `equal_weighting(my_portfolio)` | Equal weight allocation |
| `optimize_portfolio(my_portfolio, vol_max)` | Combined optimization with visualization |

## Key Patterns
- **Riskfolio**: `port = rp.Portfolio(returns=df)` → `port.assets_stats()` → `w = port.optimization(model="Classic", rm="MV", obj="Sharpe")`
- **PyPortfolioOpt**: `ef = EfficientFrontier(mu, S)` → `ef.max_sharpe()` → `ef.clean_weights()` → `ef.portfolio_performance()`
- **EigenLedger**: `engine = Engine(start_date, portfolio=["AAPL","MSFT"], optimizer="EF")` → runs internally

## Deep Dive → `details/portfolio_optimization_detail.md`
