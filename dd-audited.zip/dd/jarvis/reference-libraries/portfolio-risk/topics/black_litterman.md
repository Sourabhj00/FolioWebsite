---
title: Black-Litterman — Reference
wp: n/a
status: reference
created: unknown
last-updated: 2026-03-31
lines: 37
kb-depends: []
jarvis-depends: []
---

# Black-Litterman — Topic Index

## Riskfolio-Lib (`riskfolio/src/Portfolio.py`, `riskfolio/src/ParamsEstimation.py`)
| Method/Function | Purpose |
|---|---|
| `Portfolio.blacklitterman_stats(P, Q, delta, rf, eq, method, q)` | Set BL-adjusted mu/cov on Portfolio object. method: 0=classic, 1=BL-Bayesian |
| `Portfolio.blfactors_stats(B, P_f, Q_f, delta, rf, eq, method, q)` | BL with factor views (combines factor model + BL) |
| `ParamsEstimation.black_litterman(X, w, P, Q, delta, rf, eq, method, q)` | Standalone BL. Returns (mu_bl, cov_bl). method 0=Theil mixed, 1=BLB |
| `ParamsEstimation.augmented_black_litterman(X, w, F, B, P, Q, P_f, Q_f, delta, rf, eq, const, method, q)` | Augmented BL with both asset and factor views |
| `ParamsEstimation.black_litterman_bayesian(X, w, P, Q, delta, rf, eq, q)` | Full Bayesian BL (Meucci approach) |

## Riskfolio-Lib — Views Construction (`riskfolio/src/ConstraintsFunctions.py`)
| Function | Purpose |
|---|---|
| `assets_views(views, asset_classes)` | Build P, Q matrices from human-readable view strings |
| `factors_views(views, loadings, const)` | Build factor-level P, Q from view strings |

## PyPortfolioOpt (`pypfopt/black_litterman.py`)
| Class/Method | Purpose |
|---|---|
| `BlackLittermanModel(cov_matrix, pi, absolute_views, Q, P, omega, view_confidences, tau, risk_aversion)` | BL constructor. pi=prior (CAPM equilibrium or custom) |
| `BlackLittermanModel.bl_returns()` | Posterior expected returns |
| `BlackLittermanModel.bl_cov()` | Posterior covariance matrix |
| `BlackLittermanModel.bl_weights(risk_aversion)` | Implied optimal weights from posterior |
| `BlackLittermanModel.optimize(risk_aversion)` | Set weights via bl_weights, return OrderedDict |
| `BlackLittermanModel.portfolio_performance(verbose, risk_free_rate)` | (return, vol, sharpe) of BL portfolio |
| `BlackLittermanModel.default_omega(cov_matrix, P, tau)` | Static: proportional-to-variance omega |
| `BlackLittermanModel.idzorek_method(view_confidences, cov_matrix, pi, Q, P, tau, risk_aversion)` | Static: Idzorek confidence-based omega |

## Key Patterns
- **Riskfolio (classic)**: `port.blacklitterman_stats(P=P, Q=Q, delta=delta, eq=True)` → `port.optimization(model="BL", rm="MV", obj="Sharpe")`
- **Riskfolio (views helper)**: `views = {"AAPL >= 0.10": 1, "MSFT - GOOG >= 0.03": 1}` → `P, Q = rp.assets_views(views, asset_classes)`
- **PyPortfolioOpt**: `bl = BlackLittermanModel(S, pi="market", absolute_views=viewdict, omega="idzorek", view_confidences=[0.8,0.6])` → `bl.bl_returns()` → feed into `EfficientFrontier`
- **PyPortfolioOpt market-implied prior**: `from pypfopt import black_litterman` → `pi = black_litterman.market_implied_prior_returns(mcaps, delta, S)` (function in module scope)

## Deep Dive → `details/black_litterman_detail.md`
