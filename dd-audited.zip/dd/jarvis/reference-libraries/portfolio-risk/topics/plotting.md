---
title: Plotting — Reference
wp: n/a
status: reference
created: unknown
last-updated: 2026-03-31
lines: 55
kb-depends: []
jarvis-depends: []
---

# Plotting & Visualization — Topic Index

## Riskfolio-Lib (`riskfolio/src/PlotFunctions.py`)
All return matplotlib Axes objects. Common params: `cmap`, `height`, `width`, `ax`.

| Function | Purpose |
|---|---|
| `plot_series(returns, w, cmap, height, width, ax)` | Cumulative return series (portfolio vs assets) |
| `plot_frontier(w_frontier, mu, cov, returns, rm, rf, alpha, cmap, w, label, marker, s, ...)` | Efficient frontier with optional portfolio point |
| `plot_pie(w, title, others, nrow, cmap, height, width, ax)` | Portfolio weights pie chart |
| `plot_bar(w, title, kind, others, nrow, cmap, height, width, ax)` | Portfolio weights bar chart. kind: v/h |
| `plot_frontier_area(w_frontier, nrow, cmap, height, width, ax)` | Stacked area chart of frontier weights |
| `plot_risk_con(w, cov, returns, rm, rf, alpha, a_sim, beta, b_sim, ...)` | Risk contribution per asset (bar) |
| `plot_factor_risk_con(w, cov, returns, rm, rf, B, ...)` | Factor risk contribution |
| `plot_hist(returns, w, alpha, bins, height, width, ax)` | Return distribution histogram with VaR/CVaR markers |
| `plot_range(returns, w, alpha, a_sim, beta, bins, height, width, ax)` | Range risk measures visualization |
| `plot_drawdown(returns, w, alpha, height, width, ax)` | Drawdown chart with DaR/CDaR bands |
| `plot_table(returns, w, MAR, alpha, height, width, t_factor, ini_days, days_per_year, ax)` | Summary statistics table as figure |
| `plot_clusters(returns, codependence, linkage, k, max_k, ...)` | Cluster heatmap with dendrogram |
| `plot_dendrogram(returns, codependence, linkage, k, max_k, ...)` | Standalone dendrogram |
| `plot_network(returns, codependence, graph, threshold, ...)` | Asset network graph |
| `plot_network_allocation(returns, w, codependence, graph, ...)` | Network graph with allocation overlay |
| `plot_clusters_network(returns, codependence, linkage, k, ...)` | Cluster-colored network |
| `plot_clusters_network_allocation(returns, w, codependence, ...)` | Cluster network with allocation |
| `plot_BrinsonAttribution(w, bench_w, returns, bench_returns, ...)` | Brinson attribution bar chart |

## PyPortfolioOpt (`pypfopt/plotting.py`)
| Function | Purpose |
|---|---|
| `plot_covariance(cov_matrix, plot_correlation, show_tickers)` | Covariance/correlation heatmap |
| `plot_dendrogram(hrp, show_tickers)` | HRP dendrogram |
| `plot_efficient_frontier(opt, ef_param, ef_param_range, show_assets, show_tickers)` | Frontier curve. opt: EfficientFrontier or CLA instance |
| `plot_weights(weights)` | Horizontal bar chart of weights |

## QuantStats — Plots (`quantstats/plots.py`)
Thin wrappers calling `quantstats/_plotting/wrappers.py`. Use via `qs.plots.*` or auto-generated in tear sheets.

| Function | Purpose |
|---|---|
| `snapshot(returns, title, grayscale)` | Multi-panel overview: cumulative, drawdown, monthly, returns dist |
| `returns(returns, benchmark, ...)` | Cumulative returns vs benchmark |
| `monthly_heatmap(returns, ...)` | Monthly returns calendar heatmap |
| `drawdown(returns)` | Drawdown time series |
| `drawdowns_periods(returns)` | Top N drawdown periods highlighted |
| `rolling_sharpe(returns, ...)` | Rolling Sharpe ratio |
| `rolling_volatility(returns, ...)` | Rolling volatility |
| `rolling_beta(returns, benchmark)` | Rolling beta vs benchmark |
| `histogram(returns, ...)` | Return distribution histogram |
| `yearly_returns(returns, ...)` | Annual returns bar chart |

## Key Patterns
- **Riskfolio frontier**: `ax = rp.plot_frontier(w_frontier, mu=port.mu, cov=port.cov, returns=port.returns, rm="MV", w=w)`
- **Riskfolio risk decomposition**: `ax = rp.plot_risk_con(w, cov=port.cov, returns=port.returns, rm="CVaR")`
- **PyPortfolioOpt frontier**: `from pypfopt import plotting` → `plotting.plot_efficient_frontier(ef, show_assets=True)`
