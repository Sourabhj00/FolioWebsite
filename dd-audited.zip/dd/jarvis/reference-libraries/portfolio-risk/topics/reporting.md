---
title: Reporting — Reference
wp: n/a
status: reference
created: unknown
last-updated: 2026-03-31
lines: 33
kb-depends: []
jarvis-depends: []
---

# Reporting & Tear Sheets — Topic Index

## QuantStats (`quantstats/reports.py`) — PRIMARY for tear sheets
| Function | Key Params | Output |
|---|---|---|
| `html(returns, benchmark, rf, title, output, download_filename)` | Full HTML tear sheet | HTML file or display |
| `full(returns, benchmark, rf, display, compounded)` | Print full stats to console | Text |
| `basic(returns, benchmark, rf, display, compounded)` | Print basic stats subset | Text |
| `metrics(returns, benchmark, rf, display, mode, compounded, periods_per_year)` | Metrics table. mode: basic/full | DataFrame or text |
| `plots(returns, benchmark, rf, compounded, mode, display)` | Generate all plots | Matplotlib figures |

### QuantStats Report Modes
- `mode="basic"`: Core metrics (Sharpe, Sortino, MaxDD, CAGR, Volatility, etc.)
- `mode="full"`: All metrics including win/loss, ratios, drawdown details

## Riskfolio-Lib (`riskfolio/src/Reports.py`)
| Function | Purpose |
|---|---|
| `jupyter_report(returns, w, rm, rf, alpha, others, nrow, cmap, height, width, t_factor, ini_days, days_per_year)` | Display comprehensive report in Jupyter: composition pie, risk contributions, frontier, drawdowns |
| `excel_report(returns, w, rm, rf, alpha, others, nrow, cmap, height, width, t_factor, ini_days, days_per_year, filename)` | Export full report to Excel workbook |

## EigenLedger (`EigenLedger/main.py`)
| Function | Purpose |
|---|---|
| `portfolio_analysis(my_portfolio, rf, sigma_value, confidence_value, report, filename)` | Full portfolio report. If report=True, generates PDF |

## Key Patterns
- **QuantStats HTML**: `qs.reports.html(returns, benchmark="SPY", output="report.html")`
- **QuantStats metrics table**: `qs.reports.metrics(returns, benchmark, mode="full")` → DataFrame
- **Riskfolio Jupyter**: `rp.jupyter_report(returns, w, rm="MV", rf=0, alpha=0.05)`
- **Riskfolio Excel**: `rp.excel_report(returns, w, rm="MV", rf=0, alpha=0.05, filename="report.xlsx")`
- **QuantStats extends pandas**: `returns.vbt` not needed — use `qs.reports.full(returns)`
