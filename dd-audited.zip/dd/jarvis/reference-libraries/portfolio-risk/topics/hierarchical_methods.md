---
title: Hierarchical Methods — Reference
wp: n/a
status: reference
created: unknown
last-updated: 2026-03-31
lines: 43
kb-depends: []
jarvis-depends: []
---

# Hierarchical Methods — Topic Index

## Riskfolio-Lib (`riskfolio/src/HCPortfolio.py`)
| Method | Purpose |
|---|---|
| `HCPortfolio(returns, alpha, kappa, w_max, w_min)` | Constructor. Supports HRP, HERC, NCO, and custom methods |
| `HCPortfolio.optimization(model, codependence, covariance, obj, rm, rf, l, custom_cov, custom_mu, linkage, k, max_k, leaf_order, d, w_max, w_min)` | Main method. model: HRP/HERC/NCO. codependence: pearson/spearman/distance/mutual_info/tail/custom. obj: MinRisk/MaxRet/Utility/Sharpe/ERC (HERC/NCO only). rm: 30+ risk measures |

## Riskfolio-Lib — Clustering Helpers (`riskfolio/src/AuxFunctions.py`)
| Function | Purpose |
|---|---|
| `codep_dist(X, codependence, bins_info)` | Compute codependence matrix + distance matrix for clustering |
| `two_diff_gap_stat(dist, clustering, max_k)` | Optimal k clusters via two-difference gap statistic |
| `std_silhouette_score(dist, clustering, max_k)` | Optimal k via standardized silhouette score |
| `dcorr(X, Y)` | Distance correlation between two series |
| `dcorr_matrix(X)` | Full distance correlation matrix |
| `mutual_info_matrix(X, bins_info, normalize)` | Mutual information codependence matrix |
| `var_info_matrix(X, bins_info, normalize)` | Variation of information matrix |
| `ltdi_matrix(X, alpha)` | Lower tail dependence index matrix |

## Riskfolio-Lib — Constraint Helpers for HC (`riskfolio/src/ConstraintsFunctions.py`)
| Function | Purpose |
|---|---|
| `assets_clusters(asset_classes, cols_col, k, max_k, linkage, codependence, returns)` | Build cluster assignments for hierarchical methods |
| `hrp_constraints(constraints, asset_classes)` | Build w_max/w_min vectors for HC from constraint table |

## PyPortfolioOpt (`pypfopt/hierarchical_portfolio.py`)
| Class/Method | Purpose |
|---|---|
| `HRPOpt(returns, cov_matrix)` | HRP optimizer. Uses scipy hierarchical clustering |
| `HRPOpt.optimize(linkage_method)` | Run HRP. linkage_method: single/complete/average/ward |
| `HRPOpt.portfolio_performance(verbose, risk_free_rate, frequency)` | (return, vol, sharpe) |

## Riskfolio-Lib — DBHT (`riskfolio/src/DBHT.py`)
Direct Bubble Hierarchical Tree module — advanced clustering for codependence structures.

## Key Patterns
- **Riskfolio HRP**: `hc = rp.HCPortfolio(returns=df)` → `w = hc.optimization(model="HRP", codependence="pearson", rm="MV")`
- **Riskfolio HERC**: `w = hc.optimization(model="HERC", codependence="spearman", rm="CVaR", obj="ERC", k=None)` (auto-selects k)
- **PyPortfolioOpt HRP**: `hrp = HRPOpt(returns)` → `hrp.optimize(linkage_method="single")` → `hrp.clean_weights()`

## Deep Dive → `details/hierarchical_detail.md`
