---
title: Portfolio-Risk Topics — Map of Content
wp: n/a
status: reference
last-updated: 2026-03-31
lines: 23
---

# Portfolio-Risk Topics — Map of Content

Overview-level topic files covering portfolio optimization, risk metrics,
factor analysis, and supporting utilities. Each topic links to a
corresponding detail file for API signatures and recipes.
(~720 lines total)

## Files

- [[portfolio_optimization]] — Riskfolio Portfolio.optimization (model/rm/obj codes), risk parity, worst-case, factor, OWA; PyPortfolioOpt EfficientFrontier, CLA, CVaR. (~54 lines)
- [[risk_metrics]] — Riskfolio 30+ risk measures (MV/MAD/CVaR/VaR/EVaR/RLVaR/MDD/CDaR), QuantStats VaR/CVaR/drawdown, PyPortfolioOpt objectives. (~74 lines)
- [[returns_and_covariance]] — Riskfolio mean_vector/covar_matrix/factor models/bootstrap, PyPortfolioOpt expected_returns/risk_models, shrinkage. (~72 lines)
- [[black_litterman]] — Riskfolio BL methods, view construction, PyPortfolioOpt BlackLittermanModel, Idzorek, factor BL. (~37 lines)
- [[hierarchical_methods]] — Riskfolio HCPortfolio (HRP/HERC/NCO), codependence, PyPortfolioOpt HRPOpt, DBHT. (~43 lines)
- [[constraints_and_objectives]] — Riskfolio constraints builders, PyPortfolioOpt add_constraint/sector_constraints, discrete allocation. (~68 lines)
- [[factor_analysis]] — Alphalens entry point, IC, factor returns, tear sheets, plotting; archived repo warning. (~62 lines)
- [[performance_ratios]] — QuantStats Sharpe/Sortino/Calmar/Omega/Treynor/IR, rolling ratios, EigenLedger stats. (~66 lines)
- [[data_preparation]] — QuantStats conversion, PyPortfolioOpt discrete allocation, Riskfolio discretization, Alphalens prep. (~60 lines)
- [[options_pricing]] — QFRM class hierarchy, European/exotic pricing (BS/LT/MC/FD), 20 exotic types, visualization. (~71 lines)
- [[backtesting]] — EigenLedger engine, rebalancing, QuantStats Monte Carlo, Empyrical vendored stats. (~38 lines)
- [[plotting]] — Riskfolio plot_* functions, PyPortfolioOpt frontier/dendrogram, QuantStats snapshots/heatmaps. (~55 lines)
- [[reporting]] — QuantStats HTML/full/basic reports, Riskfolio jupyter/excel_report, EigenLedger PDF export. (~33 lines)
