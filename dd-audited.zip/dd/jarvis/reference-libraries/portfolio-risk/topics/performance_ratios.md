---
title: Performance Ratios — Reference
wp: n/a
status: reference
created: unknown
last-updated: 2026-03-31
lines: 66
kb-depends: []
jarvis-depends: []
---

# Performance Ratios — Topic Index

## QuantStats (`quantstats/stats.py`)
| Function | Key Params | Metric |
|---|---|---|
| `sharpe(returns, rf, periods, annualize)` | rf=0, periods=252 | Sharpe Ratio |
| `smart_sharpe(returns, rf, periods)` | — | Autocorrelation-adjusted Sharpe |
| `sortino(returns, rf, periods, annualize)` | rf=0, periods=252 | Sortino Ratio |
| `smart_sortino(returns, rf, periods)` | — | Autocorrelation-adjusted Sortino |
| `adjusted_sortino(returns, rf, periods)` | — | Adjusted Sortino |
| `calmar(returns)` | — | Calmar Ratio (CAGR / MaxDD) |
| `omega(returns, rf, required_return, periods)` | — | Omega Ratio |
| `treynor_ratio(returns, benchmark, periods, rf)` | — | Treynor Ratio |
| `information_ratio(returns, benchmark)` | — | Information Ratio |
| `cagr(returns, rf, compounded)` | — | Compound Annual Growth Rate |
| `gain_to_pain_ratio(returns, rf, resolution)` | — | Gain-to-Pain |
| `kelly_criterion(returns)` | — | Kelly Criterion |
| `probabilistic_sharpe_ratio(returns, sr_benchmark, periods)` | — | Probabilistic Sharpe |
| `probabilistic_sortino_ratio(returns, sr_benchmark, periods)` | — | Probabilistic Sortino |
| `risk_of_ruin(returns)` | — | Risk of Ruin |
| `r_squared(returns, benchmark)` | — | R² vs benchmark |
| `greeks(returns, benchmark, periods)` | — | Alpha, Beta of portfolio |
| `rolling_greeks(returns, benchmark, periods)` | — | Rolling Alpha, Beta |
| `rolling_sharpe(returns, rf, period, periods_per_year)` | — | Rolling Sharpe |
| `rolling_sortino(returns, rf, period, periods_per_year)` | — | Rolling Sortino |

## QuantStats — Win/Loss Metrics
| Function | Metric |
|---|---|
| `win_rate(returns)` | Percentage of positive periods |
| `avg_win(returns)` | Average winning return |
| `avg_loss(returns)` | Average losing return |
| `payoff_ratio(returns)` | avg_win / avg_loss |
| `profit_ratio(returns)` | Profit factor variant |
| `profit_factor(returns)` | Sum(wins) / Sum(losses) |
| `cpc_index(returns)` | CPC Index |
| `common_sense_ratio(returns)` | Profit factor × tail ratio |
| `outlier_win_ratio(returns, quantile)` | Outlier wins analysis |
| `outlier_loss_ratio(returns, quantile)` | Outlier losses analysis |
| `consecutive_wins(returns)` | Max consecutive wins |
| `consecutive_losses(returns)` | Max consecutive losses |

## QuantStats — Other
| Function | Metric |
|---|---|
| `skew(returns)` | Return skewness |
| `kurtosis(returns)` | Return kurtosis |
| `serenity_index(returns, rf)` | Ulcer Performance Index variant |
| `recovery_factor(returns, rf)` | Net profit / MaxDD |
| `monthly_returns(returns, eoy, compounded)` | Monthly returns table |
| `drawdown_details(drawdown)` | DD start/end/valley/duration table |
| `compare(returns, benchmark)` | Side-by-side comparison dict |

## EigenLedger (`EigenLedger/main.py`)
| Function | Metric |
|---|---|
| `calculate_information_ratio(returns, benchmark_returns, days)` | IR calculation |
| `portfolio_analysis(my_portfolio, rf, sigma_value, confidence_value)` | Full stats suite (Sharpe, Sortino, VaR, CVaR, drawdown, etc.) |

## Key Patterns
- **QuantStats**: `qs.stats.sharpe(returns)`, `qs.stats.sortino(returns, rf=0.02)`
- **QuantStats compare**: `qs.stats.compare(returns, benchmark)` → dict of side-by-side stats
- **EigenLedger**: `portfolio_analysis(engine)` → prints full report with all ratios

## Deep Dive → `details/performance_ratios_detail.md`
