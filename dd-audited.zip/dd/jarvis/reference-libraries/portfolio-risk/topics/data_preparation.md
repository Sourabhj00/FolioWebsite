---
title: Data Preparation — Reference
wp: n/a
status: reference
created: unknown
last-updated: 2026-03-31
lines: 60
kb-depends: []
jarvis-depends: []
---

# Data Preparation & Utilities — Topic Index

## QuantStats (`quantstats/utils.py`)
| Function | Purpose |
|---|---|
| `to_returns(prices, rf)` | Convert prices → simple returns |
| `to_prices(returns, base)` | Convert returns → price series (base=1e5 default) |
| `log_returns(returns, rf, nperiods)` | Convert to log returns |
| `to_excess_returns(returns, rf, nperiods)` | Subtract risk-free rate |
| `download_returns(ticker, period, proxy)` | Download returns from Yahoo Finance |
| `make_index(ticker_weights, rebalance, period)` | Build custom index from ticker weights |
| `make_portfolio(returns, start_balance, mode, round_to)` | Simulate portfolio equity curve |
| `rebase(prices, base)` | Rebase price series to given starting value |
| `group_returns(returns, groupby, compounded)` | Group returns by period |
| `aggregate_returns(returns, period, compounded)` | Aggregate to monthly/quarterly/yearly |
| `multi_shift(df, shift)` | Create lagged DataFrame |
| `exponential_stdev(returns, window, is_halflife)` | Exponentially weighted stdev |

## PyPortfolioOpt (`pypfopt/expected_returns.py`)
| Function | Purpose |
|---|---|
| `returns_from_prices(prices, log_returns)` | Prices → returns |
| `prices_from_returns(returns, log_returns)` | Returns → prices |

## PyPortfolioOpt (`pypfopt/discrete_allocation.py`)
| Class/Function | Purpose |
|---|---|
| `get_latest_prices(prices)` | Extract most recent price row |
| `DiscreteAllocation(weights, latest_prices, total_portfolio_value, short_ratio)` | Convert continuous weights → integer share counts + leftover cash |
| `DiscreteAllocation.greedy_portfolio()` | Greedy rounding allocation |
| `DiscreteAllocation.lp_portfolio()` | LP-optimized integer allocation |

## Riskfolio-Lib (`riskfolio/src/AuxFunctions.py`)
| Function | Purpose |
|---|---|
| `round_values(data, decimals, wider)` | Round portfolio weights with budget preservation |
| `weights_discretizetion(w, prices, budget, method)` | Discretize continuous weights to integer shares |

## Alphalens (`alphalens/utils.py`)
| Function | Purpose |
|---|---|
| `get_clean_factor_and_forward_returns(factor, prices, ...)` | Main data prep for factor analysis |
| `compute_forward_returns(factor, prices, periods, filter_zscore)` | Compute forward returns |
| `quantize_factor(factor_data, quantiles, bins, by_group)` | Bin factor values into quantiles |

## Data Format Requirements
| Library | Expected Input | Index | Columns |
|---|---|---|---|
| Riskfolio-Lib | Returns DataFrame | DatetimeIndex | Asset tickers |
| PyPortfolioOpt | Prices DataFrame (most methods) | DatetimeIndex | Asset tickers |
| QuantStats | Returns Series/DataFrame | DatetimeIndex | Single or multi |
| Alphalens | Factor: MultiIndex Series (date, asset) | (date, asset) | float values |
| EigenLedger | Ticker list (auto-downloads) | — | — |

## Key Patterns
- **QuantStats download**: `returns = qs.utils.download_returns("SPY")` → returns Series
- **Price→Return**: `qs.utils.to_returns(prices)` or `pypfopt.expected_returns.returns_from_prices(prices)`
- **Riskfolio expects returns**: Always convert prices to returns before passing to `rp.Portfolio(returns=df)`
- **PyPortfolioOpt mostly expects prices**: `EfficientFrontier` takes mu/cov computed from prices; `risk_models.*` and `expected_returns.*` take prices directly
