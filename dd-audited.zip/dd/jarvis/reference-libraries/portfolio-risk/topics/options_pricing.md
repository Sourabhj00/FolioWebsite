---
title: Options Pricing — QFRM Reference
wp: n/a
status: reference
created: unknown
last-updated: 2026-03-31
lines: 71
kb-depends: []
jarvis-depends: []
---

# Options Pricing — Topic Index

## QFRM (`qfrm/`) — All option classes
**Note**: QFRM v0.2.0.27 has import error at package level. Individual modules importable directly.

### Class Hierarchy
`SpecPrinter` → `OptionSeries` → `OptionValuation` → `European` → all exotic types

### Core Classes (`qfrm/OptionValuation.py`)
| Class | Constructor Params | Purpose |
|---|---|---|
| `Stock(S0, vol, q, curr, tkr)` | S0=spot, vol=volatility, q=div yield | Underlying asset specification |
| `OptionSeries(ref=Stock, right, K, T, clone)` | ref=Stock obj, right=call/put, K=strike, T=time to expiry | Option contract specification |
| `OptionValuation(rf_r, frf_r, *args, **kwargs)` | rf_r=risk-free rate, frf_r=foreign rf rate | Adds rates, inherits OptionSeries |

### Pricing Methods (on `European` and all subclasses)
| Method | Purpose |
|---|---|
| `calc_px(method, nsteps, npaths, keep_hist, rng_seed)` | Main pricer dispatcher |
| `pxBS(**kwargs)` | Black-Scholes closed-form |
| `pxLT(**kwargs)` | Lattice/binomial tree |
| `pxMC(**kwargs)` | Monte Carlo simulation |
| `pxFD(**kwargs)` | Finite difference |

### Visualization (`OptionValuation`)
| Method | Purpose |
|---|---|
| `plot_bt(bt, ax, title)` | Plot binomial tree |
| `plot_px_convergence(nsteps_max, ax)` | Convergence of LT price vs BS |
| `plot(nsteps_max)` | Combined convergence + tree plot |

### Option Types (each in own file, inherits `European`)
| Class | File | Type |
|---|---|---|
| `European` | `European.py` | Vanilla European |
| `American` | `American.py` | Early exercise |
| `Asian` | `Asian.py` | Average price/strike |
| `Barrier` | `Barrier.py` | Knock-in/knock-out |
| `Basket` | `Basket.py` | Multi-asset |
| `Bermudan` | `Bermudan.py` | Discrete exercise dates |
| `Binary` | `Binary.py` | Cash-or-nothing / asset-or-nothing |
| `Boston` | `Boston.py` | Deferred premium |
| `Chooser` | `Chooser.py` | Choose call or put later |
| `Compound` | `Compound.py` | Option on option |
| `ContingentPremium` | `ContingentPremium.py` | Premium contingent on ITM |
| `Exchange` | `Exchange.py` | Exchange one asset for another |
| `ForwardStart` | `ForwardStart.py` | Strike set at future date |
| `Gap` | `Gap.py` | Gap options |
| `Ladder` | `Ladder.py` | Lock-in profits at rungs |
| `Lookback` | `Lookback.py` | Floating/fixed strike lookback |
| `LowExercisePrice` | `LowExercisePrice.py` | LEPO |
| `PerpetualAmerican` | `PerpetualAmerican.py` | No expiry |
| `Quanto` | `Quanto.py` | Currency-protected |
| `Rainbow` | `Rainbow.py` | Multi-asset payoff |
| `Shout` | `Shout.py` | Lock-in minimum |
| `Spread` | `Spread.py` | Spread options |
| `VarianceSwap` | `VarianceSwap.py` | Variance swap |

### Utility (`qfrm/Util.py`)
| Class | Purpose |
|---|---|
| `Util` | Static helpers: `d1`, `d2` (BS intermediates), `nCr`, `normpdf`, `normcdf`, option plot utilities |

## Key Patterns
- **European BS**: `s = Stock(S0=50, vol=.3); o = European(ref=s, right='call', K=52, T=2, rf_r=.05); o.pxBS()` → returns PriceSpec with price
- **American LT**: `American(ref=s, right='put', K=52, T=2, rf_r=.05).pxLT(nsteps=100)`
- **Asian MC**: `Asian(ref=s, right='call', K=50, T=1, rf_r=.05).pxMC(npaths=10000)`
- **Note**: Due to package import error, use `from qfrm.European import European` (direct module import)

## Deep Dive → `details/options_pricing_detail.md`
