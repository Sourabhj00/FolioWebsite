---
title: Risk Metrics — Reference
wp: n/a
status: reference
created: unknown
last-updated: 2026-03-31
lines: 74
kb-depends: []
jarvis-depends: []
---

# Risk Metrics — Topic Index

## Riskfolio-Lib (`riskfolio/src/RiskFunctions.py`)
All functions take returns array `X` as first argument.

| Function | Parameters | Risk Measure |
|---|---|---|
| `MAD(X)` | — | Mean Absolute Deviation |
| `SemiDeviation(X)` | — | Semi-Deviation (downside) |
| `Kurtosis(X)` | — | Square-root Kurtosis |
| `SemiKurtosis(X)` | — | Square-root Semi-Kurtosis |
| `VaR_Hist(X, alpha)` | alpha=0.05 | Historical Value at Risk |
| `CVaR_Hist(X, alpha)` | alpha=0.05 | Conditional VaR (Expected Shortfall) |
| `EVaR_Hist(X, alpha, solver)` | alpha=0.05 | Entropic VaR |
| `RLVaR_Hist(X, alpha, kappa, solver)` | alpha=0.05, kappa=0.3 | Relativistic VaR |
| `WR(X)` | — | Worst Realization |
| `LPM(X, MAR, p)` | MAR=0, p=1 | Lower Partial Moment |
| `GMD(X)` | — | Gini Mean Difference |
| `TG(X, alpha, a_sim)` | alpha=0.05 | Tail Gini |
| `RG(X)` | — | Range |
| `VRG(X, alpha, beta)` | — | CVaR Range |
| `CVRG(X, alpha, beta)` | — | Conditional VaR Range |
| `TGRG(X, alpha, a_sim, beta, b_sim)` | — | Tail Gini Range |
| `EVRG(X, alpha, beta, solver)` | — | Entropic VaR Range |
| `RVRG(X, alpha, beta, kappa, kappa_g, solver)` | — | Relativistic VaR Range |
| `L_Moment(X, k)` | k=2 | L-Moment of order k |
| `L_Moment_CRM(X, k, method, g, max_phi, solver)` | — | L-Moment Convex Risk Measure |

### Drawdown-Based (Absolute `_Abs` / Relative `_Rel` variants)
| Function | Risk Measure |
|---|---|
| `MDD_Abs(X)` / `MDD_Rel(X)` | Maximum Drawdown |
| `ADD_Abs(X)` / `ADD_Rel(X)` | Average Drawdown |
| `DaR_Abs(X, alpha)` / `DaR_Rel(X, alpha)` | Drawdown at Risk |
| `CDaR_Abs(X, alpha)` / `CDaR_Rel(X, alpha)` | Conditional DaR |
| `EDaR_Abs(X, alpha, solver)` / `EDaR_Rel(X, alpha, solver)` | Entropic DaR |
| `RLDaR_Abs(X, alpha, kappa, solver)` / `RLDaR_Rel(X, alpha, kappa, solver)` | Relativistic DaR |
| `UCI_Abs(X)` / `UCI_Rel(X)` | Ulcer Index |

### Composite Functions
| Function | Purpose |
|---|---|
| `Sharpe_Risk(w, cov, returns, rm, ...)` | Risk value for a given rm code |
| `Sharpe(w, mu, cov, returns, rm, rf, ...)` | Sharpe-like ratio for any risk measure |
| `Risk_Contribution(w, cov, returns, rm, ...)` | Per-asset risk contribution |
| `Factors_Risk_Contribution(w, cov, returns, rm, ...)` | Per-factor risk contribution |
| `BrinsonAttribution(w, bench_w, returns, bench_returns)` | Brinson performance attribution |

## QuantStats (`quantstats/stats.py`)
| Function | Purpose |
|---|---|
| `value_at_risk(returns, sigma, confidence)` | Parametric VaR |
| `conditional_value_at_risk(returns, sigma, confidence)` | Parametric CVaR |
| `max_drawdown(prices)` | Max drawdown from price series |
| `to_drawdown_series(returns)` | Full drawdown time series |
| `volatility(returns, periods, annualize)` | Annualized volatility |
| `rolling_volatility(returns, period, periods_per_year)` | Rolling vol window |
| `ulcer_index(returns)` | Ulcer Index |
| `tail_ratio(returns, cutoff)` | Right tail / left tail ratio |

## PyPortfolioOpt (`pypfopt/objective_functions.py`)
| Function | Purpose |
|---|---|
| `portfolio_variance(w, cov_matrix)` | Portfolio variance (scalar) |
| `portfolio_return(w, expected_returns)` | Portfolio expected return |
| `ex_ante_tracking_error(w, cov_matrix, benchmark_weights)` | Tracking error vs benchmark |
| `ex_post_tracking_error(w, historic_returns, benchmark_returns)` | Realized tracking error |

## Key Patterns
- **Riskfolio risk measure codes**: MV, MAD, MSV, FLPM, SLPM, CVaR, TG, EVaR, RLVaR, WR, MDD, ADD, CDaR, EDaR, RLDaR, UCI, and range variants (_Rg suffix)
- **QuantStats**: `qs.stats.value_at_risk(returns)`, `qs.stats.max_drawdown(prices)`

## Deep Dive → `details/risk_metrics_detail.md`
