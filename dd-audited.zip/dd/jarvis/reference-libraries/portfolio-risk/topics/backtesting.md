---
title: Backtesting — Reference
wp: n/a
status: reference
created: unknown
last-updated: 2026-03-31
lines: 38
kb-depends: []
jarvis-depends: []
---

# Backtesting & Rebalancing — Topic Index

## EigenLedger (`EigenLedger/main.py`) — PRIMARY for backtesting
| Class/Function | Purpose |
|---|---|
| `Engine(start_date, portfolio, weights, rebalance, benchmark, end_date, optimizer, max_vol, min_weights, max_weights, risk_manager, data, benchmark_data)` | Main backtest engine. portfolio: list of tickers. optimizer: "EF"/"MV"/"HRP" or None (use weights). rebalance: "monthly"/"quarterly"/"annually" |
| `Engine.fetch_benchmark_data()` | Download benchmark price data |
| `get_returns(stocks, wts, start_date, end_date)` | Compute weighted portfolio returns from tickers |
| `get_returns_from_data(data, wts, stocks)` | Compute returns from pre-loaded price data |
| `make_rebalance(my_portfolio, optimizer, rebalance, start_date, end_date)` | Execute rolling rebalance backtest |
| `get_date_range(start_date, end_date, rebalance)` | Generate rebalancing date schedule |
| `valid_range(start_date, end_date, rebalance)` | Validate date range supports rebalance frequency |
| `check_schedule(rebalance)` | Validate rebalance string |

## EigenLedger — Portfolio Analysis
| Function | Purpose |
|---|---|
| `portfolio_analysis(my_portfolio, rf, sigma_value, confidence_value, report, filename)` | Full backtest analysis: returns, Sharpe, Sortino, VaR, CVaR, drawdown, comparison vs benchmark |
| `graph_allocation(my_portfolio)` | Plot portfolio allocation pie |
| `graph_opt(my_portfolio, my_weights, pie_size, font_size)` | Plot optimized weights |

## EigenLedger — Empyrical Stats (vendored at `EigenLedger/modules/empyrical/stats.py`)
Used internally for performance calculations. Functions include: `annual_return`, `annual_volatility`, `sharpe_ratio`, `max_drawdown`, `alpha_beta`, `stability_of_timeseries`, `tail_ratio`, `capture`, `up_capture`, `down_capture`.

## QuantStats — Simulation (`quantstats/stats.py`)
| Function | Purpose |
|---|---|
| `montecarlo(returns, sims, bust, goal, seed)` | Monte Carlo simulation of portfolio paths |
| `montecarlo_sharpe(returns, sims, rf, periods, seed)` | MC distribution of Sharpe ratio |
| `montecarlo_drawdown(returns, sims, seed)` | MC distribution of max drawdown |
| `montecarlo_cagr(returns, sims, seed)` | MC distribution of CAGR |

## Key Patterns
- **EigenLedger basic**: `engine = Engine("2020-01-01", portfolio=["AAPL","MSFT","GOOG"], weights=[0.4,0.3,0.3], benchmark=["SPY"])` → `portfolio_analysis(engine)`
- **EigenLedger rebalance**: `engine = Engine("2020-01-01", portfolio=tickers, optimizer="EF", rebalance="quarterly", max_vol=0.15)`
- **EigenLedger optimizers**: `"EF"` (efficient frontier), `"MV"` (mean-variance/min-vol), `"HRP"` (hierarchical risk parity)
- **QuantStats MC**: `qs.stats.montecarlo(returns, sims=1000)`
