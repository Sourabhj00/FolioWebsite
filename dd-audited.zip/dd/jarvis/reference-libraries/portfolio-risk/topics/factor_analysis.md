---
title: Factor Analysis — Reference
wp: n/a
status: reference
created: unknown
last-updated: 2026-03-31
lines: 62
kb-depends: []
jarvis-depends: []
---

# Factor Analysis — Topic Index

## Alphalens (`alphalens/`) — PRIMARY for factor analysis
**Note**: Archived Quantopian repo. Stable API, widely used. Import: `import alphalens`

### Data Preparation (`alphalens/utils.py`)
| Function | Purpose |
|---|---|
| `get_clean_factor_and_forward_returns(factor, prices, groupby, quantiles, bins, periods, max_loss)` | Main entry point. Merges factor values with forward returns, creates quantile bins. Returns MultiIndex DataFrame |
| `get_clean_factor(factor, forward_returns, groupby, quantiles, bins, max_loss)` | Clean factor data without computing forward returns |
| `compute_forward_returns(factor, prices, periods, filter_zscore, cumulative_returns)` | Compute N-period forward returns aligned to factor dates |
| `quantize_factor(factor_data, quantiles, bins, by_group, no_raise)` | Assign quantile/bin labels to factor values |

### Performance (`alphalens/performance.py`)
| Function | Purpose |
|---|---|
| `factor_information_coefficient(factor_data, group_adjust, by_group)` | IC (Spearman rank correlation) per period |
| `mean_information_coefficient(factor_data, group_adjust, by_group, by_time)` | Mean IC, optionally grouped by month/week |
| `factor_returns(factor_data, demeaned, group_adjust, equal_weight)` | Factor-weighted portfolio returns per period |
| `factor_alpha_beta(factor_data, returns, demeaned, group_adjust, equal_weight)` | Alpha/beta of factor portfolio vs benchmark |
| `cumulative_returns(returns)` | Cumulative factor returns |
| `mean_return_by_quantile(factor_data, by_date, by_group, demeaned, group_adjust)` | Mean return per quantile bin |
| `compute_mean_returns_spread(mean_returns, upper_quant, lower_quant, std_err)` | Long-short spread (top quantile − bottom quantile) |
| `quantile_turnover(quantile_factor, quantile, period)` | Turnover within a quantile |
| `factor_rank_autocorrelation(factor_data, period)` | Autocorrelation of factor ranks |
| `average_cumulative_return_by_quantile(factor_data, prices, periods_before, periods_after, demeaned)` | Event-study style cumulative returns |
| `factor_cumulative_returns(factor_data, period, long_short, group_neutral)` | Cumulative returns of factor strategy |
| `create_pyfolio_input(factor_data, period, capital, long_short, group_neutral, equal_weight)` | Generate pyfolio-compatible returns/positions/benchmark |

### Tear Sheets (`alphalens/tears.py`)
| Function | Purpose |
|---|---|
| `create_full_tear_sheet(factor_data, long_short, group_neutral, by_group)` | Complete factor analysis report |
| `create_summary_tear_sheet(factor_data, long_short, group_neutral)` | Condensed summary |
| `create_returns_tear_sheet(factor_data, long_short, group_neutral, by_group)` | Returns-focused tear sheet |
| `create_information_tear_sheet(factor_data, group_neutral, by_group)` | IC-focused tear sheet |
| `create_turnover_tear_sheet(factor_data, turnover_periods)` | Turnover analysis |
| `create_event_returns_tear_sheet(factor_data, returns, by_group)` | Event study tear sheet |
| `create_event_study_tear_sheet(factor_data, commerce)` | Event study analysis |

### Plotting (`alphalens/plotting.py`)
| Function | Purpose |
|---|---|
| `plot_ic_ts(ic)` | IC time series |
| `plot_ic_hist(ic)` | IC histogram |
| `plot_ic_qq(ic, theoretical_dist)` | IC Q-Q plot |
| `plot_quantile_returns_bar(mean_ret_by_q)` | Bar chart of returns by quantile |
| `plot_quantile_returns_violin(return_by_q)` | Violin plot of return distributions |
| `plot_mean_quantile_returns_spread_time_series(mean_returns_spread)` | Long-short spread over time |
| `plot_ic_by_group(ic_group)` | IC broken down by sector/group |
| `plot_factor_rank_auto_correlation(factor_autocorrelation)` | Factor rank autocorrelation |
| `plot_top_bottom_quantile_turnover(quantile_turnover, period)` | Turnover in extreme quantiles |
| `plot_cumulative_returns(factor_returns, period)` | Cumulative factor returns |
| `plot_cumulative_returns_by_quantile(quantile_returns)` | Cumulative returns per quantile |

## Key Patterns
- **Standard workflow**: `factor_data = alphalens.utils.get_clean_factor_and_forward_returns(factor, prices, quantiles=5, periods=(1,5,10))` → `alphalens.tears.create_full_tear_sheet(factor_data)`
- **Custom IC**: `ic = alphalens.performance.factor_information_coefficient(factor_data)` → `alphalens.plotting.plot_ic_ts(ic)`
- **Factor must be**: MultiIndex Series with (date, asset) index and float values

## Deep Dive → `details/factor_analysis_detail.md`
