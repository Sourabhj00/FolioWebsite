---
title: Returns and Covariance — Reference
wp: n/a
status: reference
created: unknown
last-updated: 2026-03-31
lines: 72
kb-depends: []
jarvis-depends: []
---

# Expected Returns & Covariance Estimation — Topic Index

## Riskfolio-Lib (`riskfolio/src/ParamsEstimation.py`)
### Return Estimation
| Function | Purpose |
|---|---|
| `mean_vector(X, method, d, target)` | Expected returns. method: hist/ewma1/ewma2/JS/BS/BOP. d=decay (ewma). target=b1/b2/b3 (shrinkage) |

### Covariance Estimation
| Function | Purpose |
|---|---|
| `covar_matrix(X, method, d, **kwargs)` | Covariance. method: hist/ewma1/ewma2/ledoit_wolf/oracle_approx/shrunk_covariance/gl/jlogo/fixed/spectral/shrink/gerber0/gerber1/gerber2/custom_cov |
| `cokurt_matrix(X, method, **kwargs)` | Co-kurtosis matrix (for kurtosis-based optimization) |

### Factor Models
| Function | Purpose |
|---|---|
| `forward_regression(X, y, criterion, threshold)` | Stepwise forward regression for factor selection |
| `backward_regression(X, y, criterion, threshold)` | Stepwise backward regression |
| `PCR(X, y, n_components)` | Principal Component Regression |
| `loadings_matrix(X, Y, feature_selection, **kwargs)` | Build factor loadings matrix B |
| `risk_factors(X, Y, B, method_mu, method_cov, **kwargs)` | Factor model: returns mu and cov estimated via factor structure |

### Bootstrap / Simulation
| Function | Purpose |
|---|---|
| `bootstrapping(X, kind, q, n_sim, window, seed)` | Bootstrap returns (stationary/circular/moving block) |
| `normal_simulation(X, q, n_sim, diag, threshold, seed)` | Simulate returns from fitted normal |

## Riskfolio-Lib — Portfolio Methods
| Method | Purpose |
|---|---|
| `Portfolio.assets_stats(method_mu, method_cov, dict_mu, dict_cov, d)` | Set mu/cov on portfolio from returns |
| `Portfolio.factors_stats(B, method_mu, method_cov, dict_mu, dict_cov)` | Set mu/cov via factor model |
| `Portfolio.wc_stats(box, ellip, q, n_sim, window, dmu, dcov, seed)` | Worst-case uncertainty sets for robust optimization |

## PyPortfolioOpt — Expected Returns (`pypfopt/expected_returns.py`)
| Function | Purpose |
|---|---|
| `mean_historical_return(prices, returns_data, compounding, frequency, log_returns)` | Annualized mean returns |
| `ema_historical_return(prices, returns_data, compounding, span, frequency, log_returns)` | EMA-weighted returns |
| `capm_return(prices, market_prices, returns_data, risk_free_rate, compounding, frequency, log_returns)` | CAPM expected returns |
| `return_model(prices, method, **kwargs)` | Dispatcher: method=mean_historical_return/ema_historical_return/capm_return |

## PyPortfolioOpt — Risk Models (`pypfopt/risk_models.py`)
| Function/Class | Purpose |
|---|---|
| `sample_cov(prices, returns_data, frequency, log_returns)` | Sample covariance matrix |
| `semicovariance(prices, returns_data, benchmark, frequency, log_returns)` | Semicovariance matrix |
| `exp_cov(prices, returns_data, span, frequency, log_returns)` | Exponentially weighted covariance |
| `min_cov_determinant(prices, returns_data, frequency, random_state)` | Minimum covariance determinant (robust) |
| `risk_matrix(prices, method, **kwargs)` | Dispatcher: sample_cov/semicovariance/exp_cov/ledoit_wolf/... |
| `CovarianceShrinkage(prices, returns_data, frequency, log_returns)` | Ledoit-Wolf shrinkage. Methods: `.ledoit_wolf()`, `.oracle_approximating()`, `.shrunk_covariance(delta)` |
| `fix_nonpositive_semidefinite(matrix, fix_method)` | Fix non-PSD matrices. fix_method: spectral/diag |
| `cov_to_corr(cov_matrix)` | Convert covariance → correlation |
| `corr_to_cov(corr_matrix, stdevs)` | Convert correlation → covariance |

## Riskfolio-Lib — Matrix Utilities (`riskfolio/src/AuxFunctions.py`)
| Function | Purpose |
|---|---|
| `is_pos_def(cov, threshold)` | Check positive definiteness |
| `cov2corr(cov)` | Covariance → correlation |
| `corr2cov(corr, std)` | Correlation → covariance |
| `cov_fix(cov, method, threshold)` | Fix non-PD matrices (clipped/spectral) |
| `denoiseCov(cov, q, kind, bWidth, detone, mkt_comp, alpha)` | Random Matrix Theory denoising |

## Key Patterns
- **Riskfolio**: `port.assets_stats(method_mu="hist", method_cov="ledoit_wolf")` — sets port.mu, port.cov
- **PyPortfolioOpt**: `mu = expected_returns.mean_historical_return(prices)` then `S = risk_models.CovarianceShrinkage(prices).ledoit_wolf()`

## Deep Dive → `details/covariance_estimation_detail.md`
