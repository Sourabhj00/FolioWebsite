---
title: Constraints and Objectives — Reference
wp: n/a
status: reference
created: unknown
last-updated: 2026-03-31
lines: 68
kb-depends: []
jarvis-depends: []
---

# Constraints & Objectives — Topic Index

## Riskfolio-Lib — Portfolio Constructor Constraints
Set directly on `Portfolio(...)` or via properties after construction:

| Parameter | Type | Purpose |
|---|---|---|
| `sht` / `uppersht` | bool / float | Allow short selling, max short weight |
| `upperlng` / `lowerlng` | float | Max/min long weight per asset |
| `budget` / `budgetsht` | float | Budget constraint (sum of weights) |
| `nea` | int | Max number of effective assets |
| `card` | int | Cardinality constraint (max assets) |
| `allowTO` / `turnover` | bool / float | Turnover constraint |
| `allowTE` / `TE` | bool / float | Tracking error constraint |
| `benchindex` / `benchweights` | — | Benchmark for TE |
| `ainequality` / `binequality` | ndarray | Linear inequality Aw ≤ b |
| `arcinequality` / `brcinequality` | ndarray | Risk contribution inequality |
| `network_sdp` / `cluster_sdp` | ndarray | Network/cluster SDP constraints |
| `network_ip` / `cluster_ip` | ndarray | Network/cluster IP constraints |
| `acentrality` / `bcentrality` | ndarray | Centrality constraints |
| `lowerret` | float | Minimum return constraint |
| `upper*` (upperdev, upperCVaR, etc.) | float | Upper bound on specific risk measures |

## Riskfolio-Lib — Constraint Builders (`riskfolio/src/ConstraintsFunctions.py`)
| Function | Purpose |
|---|---|
| `assets_constraints(constraints, asset_classes)` | Build A, b matrices from human-readable constraint DataFrame |
| `factors_constraints(constraints, loadings)` | Factor-level constraints → asset-level A, b |
| `integer_constraints(constraints, asset_classes)` | Build integer constraint matrices for cardinality |
| `risk_constraint(asset_classes, kind, classes_col)` | Build risk contribution constraint matrices |
| `connection_matrix(returns, codependence, graph, threshold)` | Adjacency matrix for network constraints |
| `centrality_vector(returns, codependence, graph, kind)` | Centrality scores for centrality constraints |
| `clusters_matrix(returns, codependence, linkage, k, max_k)` | Cluster membership for cluster constraints |
| `related_assets(asset_classes, col, name)` | Filter related assets for group constraints |

## PyPortfolioOpt — Constraints (`pypfopt/base_optimizer.py`)
| Method | Purpose |
|---|---|
| `add_constraint(new_constraint)` | Lambda: `ef.add_constraint(lambda w: w[0] >= 0.1)` |
| `add_sector_constraints(sector_mapper, sector_lower, sector_upper)` | Dict-based sector bounds |
| `add_objective(new_objective, **kwargs)` | Add regularization (e.g., L2_reg) |

## PyPortfolioOpt — Objective Functions (`pypfopt/objective_functions.py`)
| Function | Purpose |
|---|---|
| `portfolio_variance(w, cov_matrix)` | Variance objective |
| `portfolio_return(w, expected_returns, negative)` | Return objective |
| `sharpe_ratio(w, expected_returns, cov_matrix, risk_free_rate, negative)` | Sharpe objective |
| `L2_reg(w, gamma)` | L2 regularization (diversification) |
| `quadratic_utility(w, expected_returns, cov_matrix, risk_aversion, negative)` | Quadratic utility |
| `transaction_cost(w, w_prev, k)` | Transaction cost penalty |
| `ex_ante_tracking_error(w, cov_matrix, benchmark_weights)` | TE objective |

## PyPortfolioOpt — Discrete Allocation (`pypfopt/discrete_allocation.py`)
| Class/Function | Purpose |
|---|---|
| `DiscreteAllocation(weights, latest_prices, total_portfolio_value, short_ratio)` | Convert continuous weights → integer shares |
| `DiscreteAllocation.greedy_portfolio()` | Greedy rounding allocation |
| `DiscreteAllocation.lp_portfolio()` | LP-based optimal rounding |
| `get_latest_prices(prices)` | Helper to extract latest row |

## Key Patterns
- **Riskfolio constraint DataFrame**: columns = [Type, Set, Position, Sign, Weight, Factor] → `A, b = rp.assets_constraints(constraints_df, asset_classes_df)` → `port.ainequality = A; port.binequality = b`
- **PyPortfolioOpt sector**: `ef.add_sector_constraints({"AAPL":"Tech","MSFT":"Tech"}, {"Tech":0.1}, {"Tech":0.4})`
- **PyPortfolioOpt discrete**: `da = DiscreteAllocation(weights, prices, total_portfolio_value=10000)` → `allocation, leftover = da.lp_portfolio()`

## Deep Dive → `details/constraints_detail.md`
