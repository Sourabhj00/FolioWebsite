---
title: Constraints — Detail
wp: n/a
status: reference
created: unknown
last-updated: 2026-03-31
lines: 140
kb-depends: []
jarvis-depends: []
---

# Constraints & Objectives — Detail File

## Riskfolio-Lib: Constraints DataFrame Format
The `assets_constraints()` function takes a DataFrame with these columns:
```
| Disabled | Type    | Set        | Position | Sign | Weight | Type Relative | Relative Set | Relative |
|----------|---------|------------|----------|------|--------|---------------|--------------|----------|
| False    | Assets  | AAPL       |          | <=   | 0.10   |               |              |          |
| False    | Classes | Sector     | Tech     | <=   | 0.30   |               |              |          |
| False    | All Assets |         |          | >=   | 0.01   |               |              |          |
| False    | Each asset in Class | Sector | Energy | <= | 0.05 |             |              |          |
```

### Type values:
- `"Assets"` — constraint on a single named asset
- `"Classes"` — constraint on sum of a class (e.g. all Tech stocks)
- `"All Assets"` — constraint applied to every asset individually
- `"Each asset in Class"` — per-asset constraint within a class

### Sign values: `">="`, `"<="`, `"=="`

## Riskfolio-Lib: Building Constraints
```python
import riskfolio as rp

# Define asset classes
asset_classes = pd.DataFrame({
    'Assets': ['AAPL', 'MSFT', 'XOM', 'CVX'],
    'Sector': ['Tech', 'Tech', 'Energy', 'Energy'],
    'Country': ['US', 'US', 'US', 'US'],
})

# Define constraints
constraints = pd.DataFrame({
    'Disabled': [False, False],
    'Type': ['Classes', 'All Assets'],
    'Set': ['Sector', ''],
    'Position': ['Tech', ''],
    'Sign': ['<=', '>='],
    'Weight': [0.4, 0.02],
    'Type Relative': ['', ''],
    'Relative Set': ['', ''],
    'Relative': ['', ''],
})

A, B = rp.assets_constraints(constraints, asset_classes)
port.ainequality = A
port.binequality = B
```

## Riskfolio-Lib: Risk Constraints (Portfolio Constructor)
```python
port = rp.Portfolio(returns=df)
port.upperCVaR = 0.05    # Max CVaR
port.uppermdd = 0.15      # Max drawdown
port.lowerret = 0.001     # Min daily return
port.upperdev = 0.02      # Max std dev
# All upper* params: upperdev, upperkt, uppermad, uppergmd, uppersdev,
# upperskt, upperflpm, upperslpm, upperCVaR, uppertg, upperEVaR,
# upperRLVaR, upperwr, uppercvrg, uppertgrg, upperevrg, upperrvrg,
# upperrg, uppermdd, upperadd, upperCDaR, upperEDaR, upperRLDaR, upperuci
```

## Riskfolio-Lib: Turnover & Tracking Error
```python
port.allowTO = True
port.turnover = 0.05           # Max turnover per rebalance
port.allowTE = True
port.TE = 0.05                 # Max tracking error
port.benchweights = bench_w    # DataFrame of benchmark weights
```

## Riskfolio-Lib: Cardinality & Integer
```python
port.card = 10                 # Max 10 assets in portfolio
port.nea = 8                   # Max number of effective assets

# Integer constraints DataFrame
int_constraints = pd.DataFrame({
    'Disabled': [False],
    'Type': ['Assets'],
    'Set': [''],
    'Position': ['AAPL'],
    'Sign': ['Positive'],      # "Positive" or "Negative"
    'Weight': [1],
})
A_int, B_int, C_int, D_int, E_int, F_int = rp.integer_constraints(int_constraints, asset_classes)
port.aintinequality = A_int
port.bintinequality = B_int
# ... etc for C through F
```

## PyPortfolioOpt: Constraints
```python
from pypfopt import EfficientFrontier, objective_functions

ef = EfficientFrontier(mu, S, weight_bounds=(0, 1))

# Weight bounds per asset
ef = EfficientFrontier(mu, S, weight_bounds=[(0, 0.1), (0, 0.2), ...])

# Sector constraints
sector_mapper = {"AAPL": "Tech", "MSFT": "Tech", "XOM": "Energy"}
sector_lower = {"Tech": 0.1, "Energy": 0.05}
sector_upper = {"Tech": 0.4, "Energy": 0.3}
ef.add_sector_constraints(sector_mapper, sector_lower, sector_upper)

# Custom lambda constraint
ef.add_constraint(lambda w: w[0] >= 0.05)         # AAPL >= 5%
ef.add_constraint(lambda w: w.sum() == 1)          # Already default

# Add regularization
ef.add_objective(objective_functions.L2_reg, gamma=0.1)

# Transaction cost
ef.add_objective(objective_functions.transaction_cost, w_prev=old_weights, k=0.001)

# Tracking error
ef.add_objective(objective_functions.ex_ante_tracking_error,
                 cov_matrix=S, benchmark_weights=bench_w)

ef.max_sharpe()
```

## PyPortfolioOpt: Discrete Allocation
```python
from pypfopt.discrete_allocation import DiscreteAllocation, get_latest_prices

latest_prices = get_latest_prices(prices)
da = DiscreteAllocation(
    weights,                    # Dict of continuous weights
    latest_prices,
    total_portfolio_value=100000,
    short_ratio=0.3,           # For long-short portfolios
)
allocation, leftover = da.greedy_portfolio()  # or da.lp_portfolio()
# allocation = {"AAPL": 12, "MSFT": 8, ...}
# leftover = 342.50  (unallocated cash)
```
