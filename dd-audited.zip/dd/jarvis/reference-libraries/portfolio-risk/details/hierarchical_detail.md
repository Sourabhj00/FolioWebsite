---
title: Hierarchical Methods — Detail
wp: n/a
status: reference
created: unknown
last-updated: 2026-03-31
lines: 128
kb-depends: []
jarvis-depends: []
---

# Hierarchical Methods — Detail File

## Riskfolio-Lib: `HCPortfolio.__init__` Signature
```python
rp.HCPortfolio(
    returns=None,       # DataFrame of asset returns
    alpha=0.05,         # Significance for tail risk measures
    a_sim=100,          # Simulations for tail Gini
    beta=None,          # Significance for range risk measures
    b_sim=None,         # Simulations for range tail Gini
    kappa=0.30,         # Deformation for RLVaR/RLDaR
    kappa_g=None,       # Deformation for range RLVaR
    solver_rl="CLARABEL",
    solvers=["CLARABEL", "SCS", "ECOS"],
    w_max=None,         # Max weight per asset (float or Series)
    w_min=None,         # Min weight per asset (float or Series)
)
```

## Riskfolio-Lib: `HCPortfolio.optimization` Signature
```python
hc.optimization(
    model="HRP",            # HRP | HERC | NCO
    codependence="pearson",  # pearson | spearman | abs_pearson | abs_spearman |
                             # distance | mutual_info | tail | custom_cov
    obj="MinRisk",          # MinRisk | MaxRet | Utility | Sharpe | ERC
                            # (ERC only for HERC/NCO)
    rm="MV",                # Any risk measure code
    rf=0,
    l=2,                    # Risk aversion (Utility obj)
    method_mu="hist",
    method_cov="hist",
    custom_mu=None,         # pd.Series: custom expected returns
    custom_cov=None,        # pd.DataFrame: custom covariance
    linkage="single",       # single | complete | average | weighted | ward | DBHT
    opt_k_method="twodiff", # twodiff | stdsil (cluster count selection)
    k=None,                 # Fixed cluster count (None = auto)
    max_k=10,               # Max clusters for auto selection
    bins_info="KN",         # Binning for mutual info: KN | FD | SC
    alpha_tail=0.05,        # Tail dependence alpha
    gs_threshold=0.5,       # Gerber statistic threshold
    leaf_order=True,        # Optimal leaf ordering
    dict_mu={},
    dict_cov={},
)
# Returns: DataFrame of weights (n_assets × 1)
```

### Model Differences
- **HRP**: Hierarchical Risk Parity. Allocates by inverse-variance within cluster tree. No optimization. obj parameter ignored.
- **HERC**: Hierarchical Equal Risk Contribution. Flat clusters, then optimize within/between clusters. Supports obj parameter.
- **NCO**: Nested Cluster Optimization. Two-level optimization: within clusters, then across clusters. Supports obj parameter.

### Codependence Options
| Code | Method |
|---|---|
| `pearson` | Pearson correlation |
| `spearman` | Spearman rank correlation |
| `abs_pearson` | Absolute Pearson |
| `abs_spearman` | Absolute Spearman |
| `distance` | Distance correlation |
| `mutual_info` | Mutual information |
| `tail` | Lower tail dependence |
| `custom_cov` | User-provided via custom_cov param |

## Riskfolio-Lib: HRP Recipe
```python
import riskfolio as rp

hc = rp.HCPortfolio(returns=returns_df)
w = hc.optimization(
    model="HRP",
    codependence="pearson",
    rm="MV",
    linkage="ward",
)
# Plot dendrogram
ax = rp.plot_dendrogram(returns=returns_df, codependence="pearson", linkage="ward")
```

## Riskfolio-Lib: HERC with Constraints
```python
hc = rp.HCPortfolio(returns=returns_df)

# Weight constraints from DataFrame
w_max, w_min = rp.hrp_constraints(constraints_df, asset_classes_df)
hc.w_max = w_max
hc.w_min = w_min

w = hc.optimization(
    model="HERC",
    codependence="spearman",
    rm="CVaR",
    obj="ERC",           # Equal Risk Contribution within clusters
    linkage="ward",
    k=None,              # Auto-detect number of clusters
    max_k=10,
)
```

## PyPortfolioOpt: `HRPOpt` Signature
```python
from pypfopt import HRPOpt

hrp = HRPOpt(
    returns,         # pd.DataFrame of returns (not prices)
    cov_matrix=None, # Optional: custom covariance (default: sample cov from returns)
)

hrp.optimize(linkage_method="single")  # single | complete | average | ward
weights = hrp.clean_weights()
ret, vol, sharpe = hrp.portfolio_performance(verbose=True, risk_free_rate=0.02)
```

## PyPortfolioOpt: HRP Recipe
```python
from pypfopt import HRPOpt, expected_returns
from pypfopt.plotting import plot_dendrogram

returns = expected_returns.returns_from_prices(prices)
hrp = HRPOpt(returns)
hrp.optimize(linkage_method="ward")
weights = hrp.clean_weights()

# Visualize
plot_dendrogram(hrp, show_tickers=True)
```
