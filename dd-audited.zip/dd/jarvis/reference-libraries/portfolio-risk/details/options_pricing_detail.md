---
title: Options Pricing — Detail
wp: n/a
status: reference
created: unknown
last-updated: 2026-03-31
lines: 121
kb-depends: []
jarvis-depends: []
---

# Options Pricing (QFRM) — Detail File

## Core Class Hierarchy
```
SpecPrinter → PriceSpec (result container)
SpecPrinter → Stock (underlying asset)
SpecPrinter → OptionSeries → OptionValuation → European → [all exotic types]
```

## `Stock` Constructor
```python
from qfrm.OptionValuation import Stock
s = Stock(
    S0=50.0,       # Current stock price (required)
    vol=0.3,       # Annualized volatility as decimal (required)
    q=0.0,         # Continuous dividend yield
    curr=None,     # Currency string (informational)
    tkr=None,      # Ticker symbol (informational)
)
```

## `OptionSeries` Constructor
```python
OptionSeries(
    ref=Stock(...),    # Underlying asset object (required)
    right='call',      # 'call', 'put', or 'other' (for exotics)
    K=52.0,            # Strike price (required)
    T=2.0,             # Time to maturity in years (required)
    clone=None,        # Copy specs from another option object
)
```

## `OptionValuation` Constructor (adds rates)
```python
OptionValuation(
    rf_r=0.05,     # Risk-free rate (required)
    frf_r=0.0,     # Foreign risk-free rate (for Quanto/FX options)
    # All OptionSeries params passed through via **kwargs
    ref=Stock(...), right='call', K=52, T=2,
)
```

## `European.calc_px` — Main Pricing Method
```python
from qfrm.European import European

o = European(ref=Stock(S0=50, vol=0.3), right='call', K=52, T=2, rf_r=0.05)

# Black-Scholes
result = o.calc_px(method='BS')
price = result.px_spec.px       # Option price
# result.px_spec.BS_specs contains d1, d2, N_d1, N_d2

# Binomial tree
result = o.calc_px(method='LT', nsteps=100)

# Monte Carlo
result = o.calc_px(method='MC', nsteps=100, npaths=10000, rng_seed=42)

# Finite difference
result = o.calc_px(method='FD', nsteps=100, npaths=100)
```

### Shortcut Methods
```python
o.pxBS()                       # Equivalent to calc_px(method='BS')
o.pxLT(nsteps=100)             # Lattice tree
o.pxMC(nsteps=100, npaths=10000)  # Monte Carlo
o.pxFD(nsteps=100, npaths=100)    # Finite difference
```

### `calc_px` Parameters
| Param | Type | Purpose |
|---|---|---|
| `method` | str | 'BS', 'LT', 'MC', 'FD' |
| `nsteps` | int | Time steps (LT/MC/FD) |
| `npaths` | int | Simulation paths (MC/FD) |
| `keep_hist` | bool | Save trees/grids in px_spec |
| `rng_seed` | int/None | Seed for MC reproducibility |

## Exotic Option Classes — All Inherit from European
Each overrides `_calc_BS`, `_calc_LT`, `_calc_MC`, `_calc_FD` as applicable.

```python
from qfrm.American import American
o = American(ref=Stock(S0=50, vol=0.3), right='put', K=52, T=2, rf_r=0.05)
o.calc_px(method='LT', nsteps=200)  # BS not available for American

from qfrm.Asian import Asian
o = Asian(ref=Stock(S0=50, vol=0.3), right='call', K=52, T=2, rf_r=0.05)
o.calc_px(method='BS')  # Geometric average Asian has BS solution

from qfrm.Barrier import Barrier
o = Barrier(ref=Stock(S0=50, vol=0.3), right='call', K=52, T=2, rf_r=0.05)
# Additional params via calc_px kwargs for barrier level, type, etc.

from qfrm.Lookback import Lookback
o = Lookback(ref=Stock(S0=50, vol=0.3), right='call', K=52, T=2, rf_r=0.05)
o.calc_px(method='BS')
```

## Visualization Methods
```python
o.calc_px(method='LT', nsteps=4, keep_hist=True)
o.plot_bt()                    # Plot binomial tree (requires keep_hist=True)
o.plot_px_convergence(nsteps_max=50)  # Price convergence plot as nsteps increases
```

## `PriceSpec` Result Object
After `calc_px`, access `o.px_spec`:
- `o.px_spec.px` — computed option price (float)
- `o.px_spec.method` — pricing method used
- `o.px_spec.nsteps` — number of steps
- `o.px_spec.LT_specs` — lattice parameters (u, d, p, dt, df_dt, a)
- `o.px_spec.BS_specs` — BS parameters (d1, d2, N_d1, N_d2)

## Notes
- QFRM v0.2.0.27 has a broken top-level `__init__.py` — import classes directly from submodules.
- Not all pricing methods are implemented for every exotic type. If unsupported, raises error or returns None.
- For Greeks: some are computed automatically in BS_specs; others require finite-difference bumping manually.
