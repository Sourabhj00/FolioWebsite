---
title: Portfolio Optimization — Detail
wp: n/a
status: reference
created: unknown
last-updated: 2026-03-31
lines: 133
kb-depends: []
jarvis-depends: []
---

# Portfolio Optimization — Detail File

## Riskfolio-Lib: `Portfolio.__init__` Key Parameters
```python
rp.Portfolio(
    returns=None,         # DataFrame of asset returns (DatetimeIndex, tickers as cols)
    sht=False,            # Allow short selling
    uppersht=0.2,         # Max short weight per asset
    upperlng=1,           # Max long weight per asset
    lowerlng=0,           # Min long weight per asset
    budget=1,             # Sum of weights = budget
    nea=None,             # Max number of effective assets (int)
    card=None,            # Cardinality constraint (max # assets, int)
    alpha=0.05,           # Significance level for CVaR/VaR/etc.
    kappa=0.30,           # Deformation param for RLVaR/RLDaR
    allowTO=False,        # Enable turnover constraint
    turnover=0.05,        # Max turnover
    allowTE=False,        # Enable tracking error constraint
    TE=0.05,              # Max tracking error
    benchweights=None,    # Benchmark weights (Series)
)
```

## Riskfolio-Lib: `Portfolio.optimization` Signature
```python
port.optimization(
    model="Classic",  # Classic | BL | FM | BLFM | WC
    rm="MV",          # Risk measure code (see below)
    obj="Sharpe",     # MinRisk | MaxRet | Utility | Sharpe
    kelly=None,       # None | "exact" | "approx" (Kelly criterion)
    rf=0,             # Risk-free rate
    l=2,              # Risk aversion (for Utility obj)
    hist=True,        # Use historical scenarios (True) or parametric (False)
)
# Returns: DataFrame of weights (n_assets × 1)
```

### Risk Measure Codes (rm parameter)
Variance: `MV`. Downside: `MAD`, `MSV`, `FLPM`, `SLPM`. Tail: `CVaR`, `TG`, `EVaR`, `RLVaR`, `WR`.
Drawdown: `MDD`, `ADD`, `CDaR`, `EDaR`, `RLDaR`, `UCI`. Range: `CVRG`, `TGRG`, `EVRG`, `RVRG`, `RG`.
L-moments: `Skew`, `Kurt`, `SSkew`, `SKurt`. Gini: `GMD`. OWA: use `owa_optimization` instead.

## Riskfolio-Lib: Complete Workflow Recipe
```python
import riskfolio as rp
import pandas as pd

# 1. Build portfolio
port = rp.Portfolio(returns=returns_df)

# 2. Estimate parameters
port.assets_stats(method_mu="hist", method_cov="ledoit_wolf")

# 3. Optimize
w = port.optimization(model="Classic", rm="CVaR", obj="Sharpe", rf=0.02)

# 4. With constraints
constraints_df = pd.DataFrame({
    "Disabled": [False, False],
    "Type": ["All Assets", "Classes"],
    "Set": ["", "Sector"],
    "Position": ["", "Tech"],
    "Sign": ["<=", "<="],
    "Weight": [0.10, 0.30],
    "Type Relative": ["", ""],
    "Relative Set": ["", ""],
    "Relative": ["", ""],
    "Factor": ["", ""]
})
A, b = rp.assets_constraints(constraints_df, asset_classes_df)
port.ainequality = A
port.binequality = b
w = port.optimization(model="Classic", rm="CVaR", obj="Sharpe")
```

## PyPortfolioOpt: `EfficientFrontier.__init__` Signature
```python
EfficientFrontier(
    expected_returns,      # pd.Series or array of expected returns
    cov_matrix,            # pd.DataFrame or array (covariance)
    weight_bounds=(0, 1),  # (min, max) per asset, or list of tuples
    solver=None,           # cvxpy solver
    verbose=False,
    solver_options=None,
)
```

## PyPortfolioOpt: Complete Workflow Recipe
```python
from pypfopt import EfficientFrontier, risk_models, expected_returns
from pypfopt.discrete_allocation import DiscreteAllocation, get_latest_prices

# 1. Estimate params from prices
mu = expected_returns.mean_historical_return(prices_df)
S = risk_models.CovarianceShrinkage(prices_df).ledoit_wolf()

# 2. Optimize
ef = EfficientFrontier(mu, S)
ef.add_sector_constraints(sector_map, sector_lower, sector_upper)
ef.max_sharpe(risk_free_rate=0.02)
weights = ef.clean_weights()
ret, vol, sharpe = ef.portfolio_performance(verbose=True)

# 3. Discrete allocation
latest_prices = get_latest_prices(prices_df)
da = DiscreteAllocation(weights, latest_prices, total_portfolio_value=100000)
allocation, leftover = da.lp_portfolio()
```

## PyPortfolioOpt: EfficientCVaR Recipe
```python
from pypfopt.efficient_frontier import EfficientCVaR

ef_cvar = EfficientCVaR(mu, S, returns_df)  # needs returns for CVaR
ef_cvar.min_cvar()
weights = ef_cvar.clean_weights()
```

## EigenLedger: Quick Backtest Recipe
```python
from EigenLedger import Engine, portfolio_analysis, efficient_frontier

engine = Engine(
    start_date="2020-01-01",
    portfolio=["AAPL", "MSFT", "GOOG", "AMZN"],
    optimizer="EF",
    benchmark=["SPY"],
    rebalance="quarterly",
    max_vol=0.15,
)
portfolio_analysis(engine)
```
