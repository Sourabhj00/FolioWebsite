---
title: Factor Analysis — Detail
wp: n/a
status: reference
created: unknown
last-updated: 2026-03-31
lines: 144
kb-depends: []
jarvis-depends: []
---

# Factor Analysis — Detail File

## Alphalens: `get_clean_factor_and_forward_returns` Signature
```python
import alphalens as al

factor_data = al.utils.get_clean_factor_and_forward_returns(
    factor,                # pd.Series with MultiIndex (date, asset) → float
    prices,                # pd.DataFrame: date × assets (wide form)
    groupby=None,          # pd.Series (date, asset) → group label (e.g. sector)
    binning_by_group=False,# Bin within each group separately
    quantiles=5,           # Number of equal-sized quantile bins (int)
    bins=None,             # Custom bin edges (list) — overrides quantiles
    periods=(1, 5, 10),    # Forward return periods in trading days
    filter_zscore=20,      # Remove outlier factor values beyond N std
    groupby_labels=None,   # Dict mapping group codes → labels
    max_loss=0.35,         # Max fraction of factor data lost during cleaning
    zero_aware=False,      # Separate positive/negative factor values
    cumulative_returns=True,# Use cumulative returns (vs per-period)
)
# Returns: pd.DataFrame with columns: factor, factor_quantile, 1D, 5D, 10D (forward rets)
#          Index: MultiIndex (date, asset)
```

## Alphalens: Input Data Format Requirements
- **factor**: `pd.Series` with 2-level MultiIndex `(datetime, asset_id)`. Values are raw factor scores.
- **prices**: `pd.DataFrame` with `DatetimeIndex` rows and asset tickers as columns. Must extend beyond factor dates by `max(periods)` trading days.
- **groupby**: Optional `pd.Series` same index as factor, mapping each (date, asset) to a sector/group string.

## Alphalens: Performance Functions
```python
# Information Coefficient (Spearman rank correlation)
ic = al.performance.factor_information_coefficient(
    factor_data,
    group_adjust=False,    # Demean by group
    by_group=False,        # Return IC per group
)
# Returns: pd.DataFrame, columns = periods, rows = dates

# Mean IC (averaged over time)
mean_ic = al.performance.mean_information_coefficient(
    factor_data,
    group_adjust=False,
    by_group=False,
    by_time=None,          # None, "W", "M", "Y" for time grouping
)

# Factor returns (long-short portfolio returns)
factor_ret = al.performance.factor_returns(
    factor_data,
    demeaned=True,         # Long-short (True) or long-only (False)
    group_adjust=False,
    equal_weight=False,    # Equal weight or factor-weighted
)

# Alpha & Beta vs benchmark
alpha_beta = al.performance.factor_alpha_beta(
    factor_data,
    returns=None,          # Benchmark returns (optional)
    demeaned=True,
    group_adjust=False,
    equal_weight=False,
)
# Returns: pd.DataFrame with alpha, beta per period

# Quantile returns
mean_quant_ret, std_err = al.performance.mean_return_by_quantile(
    factor_data,
    by_date=False,         # Return per-date or overall
    by_group=False,
    demeaned=True,
)

# Turnover within quantiles
turnover = al.performance.quantile_turnover(
    factor_data['factor_quantile'], quantile=1, period=1,
)

# Factor persistence
autocorr = al.performance.factor_rank_autocorrelation(factor_data, period=1)
```

## Alphalens: Tear Sheets
```python
# Full analysis (all plots)
al.tears.create_full_tear_sheet(
    factor_data,
    long_short=True,       # Show long-short or long-only
    group_neutral=False,   # Neutralize by group
    by_group=False,        # Break down plots by group
)

# Just summary tables
al.tears.create_summary_tear_sheet(factor_data, long_short=True, group_neutral=False)

# Subset tear sheets
al.tears.create_returns_tear_sheet(factor_data, ...)
al.tears.create_information_tear_sheet(factor_data, ...)
al.tears.create_turnover_tear_sheet(factor_data, turnover_periods=None)

# Event study
al.tears.create_event_returns_tear_sheet(
    factor_data,
    returns,               # Benchmark/market returns
    avgretplot=(5, 15),    # (before, after) periods for event window
    long_short=True,
    group_neutral=False,
    by_group=False,
)
```

## Recipe: End-to-End Factor Analysis
```python
import alphalens as al
import pandas as pd

# 1. Prepare factor signal (MultiIndex Series)
factor = my_signal_df.stack()  # (date, asset) → value
factor.index.names = ['date', 'asset']

# 2. Prepare prices (wide DataFrame)
prices = price_df  # date × assets

# 3. Optional: sector groupings
sectors = sector_df.stack()  # (date, asset) → "Tech"/"Energy"/...

# 4. Clean and align
factor_data = al.utils.get_clean_factor_and_forward_returns(
    factor, prices, groupby=sectors, quantiles=5, periods=(1, 5, 21)
)

# 5. Run tear sheet
al.tears.create_full_tear_sheet(factor_data, long_short=True, by_group=True)

# 6. Extract specific metrics
ic = al.performance.factor_information_coefficient(factor_data)
mean_ic = al.performance.mean_information_coefficient(factor_data, by_time="M")
```

## Notes
- Alphalens is **archived** (Quantopian shutdown). API stable but may break with pandas >= 2.0.
- Known fork: `alphalens-reloaded` (pip install alphalens-reloaded) — maintained community fork.
- Factor data must not contain NaN/Inf after cleaning, or tear sheets will fail silently.
