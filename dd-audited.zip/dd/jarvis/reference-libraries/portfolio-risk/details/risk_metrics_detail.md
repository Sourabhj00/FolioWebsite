---
title: Risk Metrics — Detail
wp: n/a
status: reference
created: unknown
last-updated: 2026-03-31
lines: 137
kb-depends: []
jarvis-depends: []
---

# Risk Metrics — Detail File

## Riskfolio-Lib Risk Function Signatures

### Value-at-Risk Family
```python
# All in riskfolio.RiskFunctions (import as rp)
# X: pd.Series or 1D array of returns

rp.VaR_Hist(X, alpha=0.05)
# Returns: float. Historical VaR at alpha confidence.

rp.CVaR_Hist(X, alpha=0.05)
# Returns: float. Expected shortfall (average of losses beyond VaR).

rp.EVaR_Hist(X, alpha=0.05, solver="CLARABEL")
# Returns: (EVaR_value, z_parameter). Entropic VaR (tightest upper bound on CVaR).

rp.RLVaR_Hist(X, alpha=0.05, kappa=0.3, solver="CLARABEL")
# Returns: (RLVaR_value, z_parameter, v_parameter). Relativistic VaR.
# kappa ∈ (0,1): deformation parameter. kappa→0 = CVaR, kappa→1 = EVaR.

rp.WR(X)
# Returns: float. Worst realization (maximum loss).

rp.TG(X, alpha=0.05, a_sim=100)
# Returns: float. Tail Gini range.

rp.LPM(X, MAR=0, p=1)
# Returns: float. Lower Partial Moment of order p relative to MAR.
```

### Drawdown Functions (Absolute variants shown; _Rel variants identical signatures)
```python
rp.MDD_Abs(X)        # Maximum Drawdown
rp.ADD_Abs(X)        # Average Drawdown
rp.DaR_Abs(X, alpha=0.05)    # Drawdown at Risk
rp.CDaR_Abs(X, alpha=0.05)   # Conditional DaR
rp.EDaR_Abs(X, alpha=0.05, solver="CLARABEL")   # Entropic DaR → (value, z)
rp.RLDaR_Abs(X, alpha=0.05, kappa=0.3, solver="CLARABEL")  # Relativistic DaR → (value, z, v)
rp.UCI_Abs(X)        # Ulcer Index
```

### Composite Risk Functions
```python
rp.Sharpe_Risk(
    w,          # weights array
    cov,        # covariance matrix
    returns,    # returns DataFrame
    rm="MV",    # risk measure code
    rf=0,       # risk-free rate
    alpha=0.05,
    a_sim=100,
    beta=None,
    b_sim=None,
    kappa=0.3,
    solver="CLARABEL",
)
# Returns: float. The risk value for the portfolio given rm.

rp.Risk_Contribution(
    w, cov, returns, rm="MV", rf=0, alpha=0.05, ...
)
# Returns: array. Per-asset marginal risk contribution.
```

## QuantStats Risk Function Signatures
```python
import quantstats as qs

qs.stats.value_at_risk(returns, sigma=1, confidence=0.95, prepare_returns=True)
# Returns: float. Parametric VaR (Gaussian).

qs.stats.conditional_value_at_risk(returns, sigma=1, confidence=0.95, prepare_returns=True)
# Returns: float. Parametric CVaR (Gaussian).

qs.stats.max_drawdown(prices)
# Returns: float (negative). Max peak-to-trough drawdown.

qs.stats.to_drawdown_series(returns)
# Returns: Series. Running drawdown at each date.

qs.stats.drawdown_details(drawdown)
# Returns: DataFrame with columns: start, valley, end, days, max drawdown, 99% max drawdown

qs.stats.volatility(returns, periods=252, annualize=True, prepare_returns=True)
# Returns: float. Annualized volatility.

qs.stats.ulcer_index(returns)
# Returns: float.

qs.stats.tail_ratio(returns, cutoff=0.95, prepare_returns=True)
# Returns: float. 95th percentile / abs(5th percentile).
```

## Risk Measure Code → Function Mapping (Riskfolio-Lib)
| Code | Function | Full Name |
|---|---|---|
| MV | portfolio variance | Mean-Variance |
| MAD | MAD() | Mean Absolute Deviation |
| MSV | SemiDeviation() | Mean Semi-Variance |
| FLPM | LPM(p=1) | First Lower Partial Moment |
| SLPM | LPM(p=2) | Second Lower Partial Moment |
| CVaR | CVaR_Hist() | Conditional Value at Risk |
| TG | TG() | Tail Gini |
| EVaR | EVaR_Hist() | Entropic Value at Risk |
| RLVaR | RLVaR_Hist() | Relativistic Value at Risk |
| WR | WR() | Worst Realization |
| MDD | MDD_Abs/Rel() | Maximum Drawdown |
| ADD | ADD_Abs/Rel() | Average Drawdown |
| CDaR | CDaR_Abs/Rel() | Conditional Drawdown at Risk |
| EDaR | EDaR_Abs/Rel() | Entropic Drawdown at Risk |
| RLDaR | RLDaR_Abs/Rel() | Relativistic Drawdown at Risk |
| UCI | UCI_Abs/Rel() | Ulcer Index |
| GMD | GMD() | Gini Mean Difference |
| RG | RG() | Range |
| CVRG | CVRG() | CVaR Range |
| TGRG | TGRG() | Tail Gini Range |
| EVRG | EVRG() | Entropic VaR Range |
| RVRG | RVRG() | Relativistic VaR Range |

## Recipe: Compare VaR Across Libraries
```python
import riskfolio as rp
import quantstats as qs

returns = ...  # pd.Series of daily returns

# Riskfolio (historical)
var_rf = rp.VaR_Hist(returns.values, alpha=0.05)
cvar_rf = rp.CVaR_Hist(returns.values, alpha=0.05)

# QuantStats (parametric Gaussian)
var_qs = qs.stats.value_at_risk(returns, confidence=0.95)
cvar_qs = qs.stats.conditional_value_at_risk(returns, confidence=0.95)
```
