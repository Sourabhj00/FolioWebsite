---
title: Performance Ratios — Detail
wp: n/a
status: reference
created: unknown
last-updated: 2026-03-31
lines: 112
kb-depends: []
jarvis-depends: []
---

# Performance Ratios — Detail File

## QuantStats Key Signatures (`quantstats/stats.py`)

### Core Ratios
```python
import quantstats as qs

qs.stats.sharpe(returns, rf=0, periods=252, annualize=True, smart=False)
# Returns: float. Annualized Sharpe ratio.

qs.stats.sortino(returns, rf=0, periods=252, annualize=True, smart=False)
# Returns: float. Sortino ratio (downside deviation denominator).

qs.stats.calmar(returns)
# Returns: float. CAGR / MaxDrawdown.

qs.stats.omega(returns, rf=0, required_return=0.0, periods=252)
# Returns: float. Omega ratio.

qs.stats.treynor_ratio(returns, benchmark, periods=252, rf=0.0)
# Returns: float. (return - rf) / beta.

qs.stats.information_ratio(returns, benchmark, prepare_returns=True)
# Returns: float. Active return / tracking error.

qs.stats.cagr(returns, rf=0.0, compounded=True)
# Returns: float. Compound Annual Growth Rate.
```

### Probabilistic Ratios
```python
qs.stats.probabilistic_sharpe_ratio(returns, sr_benchmark=0, periods=252)
# Returns: float. Probability that true Sharpe > benchmark Sharpe.

qs.stats.probabilistic_sortino_ratio(returns, sr_benchmark=0, periods=252)
# Returns: float. Same concept for Sortino.
```

### Rolling Metrics
```python
qs.stats.rolling_sharpe(returns, rf=0, period=126, periods_per_year=252)
# Returns: Series. Rolling Sharpe over trailing window.

qs.stats.rolling_sortino(returns, rf=0, period=126, periods_per_year=252)
# Returns: Series. Rolling Sortino.

qs.stats.rolling_volatility(returns, period=126, periods_per_year=252)
# Returns: Series. Rolling annualized volatility.
```

### Greeks & Regression
```python
qs.stats.greeks(returns, benchmark, periods=252, prepare_returns=True)
# Returns: dict with keys 'alpha', 'beta'.

qs.stats.rolling_greeks(returns, benchmark, periods=252, prepare_returns=True)
# Returns: dict of rolling alpha and beta Series.

qs.stats.r_squared(returns, benchmark, prepare_returns=True)
# Returns: float. R² of returns vs benchmark.
```

### Drawdown Analysis
```python
qs.stats.max_drawdown(prices)
# Returns: float (negative). Input is prices, not returns.

qs.stats.to_drawdown_series(returns)
# Returns: Series of running drawdown values.

qs.stats.drawdown_details(drawdown)
# Input: output of to_drawdown_series()
# Returns: DataFrame with columns:
#   start, valley, end, days, max drawdown, 99% max drawdown
```

### Win/Loss Statistics
```python
qs.stats.win_rate(returns, aggregate=None, compounded=True)
# Returns: float. Fraction of positive periods.

qs.stats.avg_win(returns)   # Average positive return
qs.stats.avg_loss(returns)  # Average negative return
qs.stats.payoff_ratio(returns)     # avg_win / abs(avg_loss)
qs.stats.profit_factor(returns)    # sum(wins) / abs(sum(losses))
qs.stats.kelly_criterion(returns)  # Optimal Kelly fraction
```

## Recipe: Full Comparison Report
```python
import quantstats as qs

returns = qs.utils.download_returns("AAPL")
benchmark = qs.utils.download_returns("SPY")

# Console report
qs.reports.full(returns, benchmark)

# HTML tear sheet
qs.reports.html(returns, benchmark, title="AAPL Analysis", output="tearsheet.html")

# Just metrics DataFrame
metrics = qs.reports.metrics(returns, benchmark, mode="full")
```

## Recipe: Side-by-Side Comparison
```python
comparison = qs.stats.compare(returns, benchmark)
# Returns dict with both sets of metrics for easy comparison
```
