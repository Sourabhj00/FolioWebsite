---
title: Covariance Estimation — Detail
wp: n/a
status: reference
created: unknown
last-updated: 2026-03-31
lines: 124
kb-depends: []
jarvis-depends: []
---

# Covariance & Expected Returns Estimation — Detail File

## Riskfolio-Lib: `Portfolio.assets_stats` Signature
```python
port.assets_stats(
    method_mu="hist",      # "hist", "ewma1", "ewma2"
    method_cov="hist",     # "hist", "ewma1", "ewma2", "ledoit", "oas", "shrunk",
                           # "gl", "jlogo", "fixed", "spectral", "shrink",
                           # "gerber1", "gerber2"
    method_kurt=None,      # None, "hist", "semi", "fixed", "spectral", "shrink"
    dict_mu={},            # Extra params: {"d": 0.94} for EWMA decay
    dict_cov={},           # Extra params: {"d": 0.94} for EWMA, etc.
    dict_kurt={},
)
```
After calling, `port.mu` and `port.cov` are set. Then call `port.optimization(...)`.

## Riskfolio-Lib: `Portfolio.factors_stats` Signature
```python
port.factors_stats(
    method_mu="hist",
    method_cov="hist",
    method_kurt=None,
    feature_selection="stepwise",  # "stepwise" or "PCR"
    stepwise="Forward",            # "Forward" or "Backward"
    criterion="pvalue",            # "pvalue", "AIC", "SIC", "R2", "R2_A"
    threshold=0.05,
    n_components=0.95,             # For PCR: int or float (variance %)
    dict_mu={}, dict_cov={}, dict_kurt={},
)
```
Requires `port.factors = factor_df` and `port.B = loadings_matrix` (or auto-estimated).

## Riskfolio-Lib: `ParamsEstimation.covar_matrix` Signature
```python
rp.covar_matrix(
    X,                     # DataFrame of returns
    method="hist",         # Same options as method_cov above
    d=0.94,                # Decay factor for EWMA
    **kwargs               # Passed to underlying estimator
)
# Returns: pd.DataFrame (n × n covariance matrix)
```

## Riskfolio-Lib: Random Matrix Theory Denoising
```python
from riskfolio.src.AuxFunctions import denoiseCov
cov_denoised = denoiseCov(
    cov,                   # Input covariance matrix
    q,                     # T/N ratio (observations/assets)
    kind="fixed",          # "fixed" or "spectral"
    bWidth=0.01,           # KDE bandwidth
    detone=False,          # Remove market component
    mkt_comp=1,            # Number of market components to remove
    alpha=0.1,             # Shrinkage alpha (for kind="shrink")
)
```

## PyPortfolioOpt: Expected Returns
```python
from pypfopt import expected_returns

# Arithmetic mean (default)
mu = expected_returns.mean_historical_return(
    prices,                # DataFrame of prices (date × assets)
    frequency=252,         # Annualization factor
    compounding=True,      # Geometric mean if True
    log_returns=False,
)

# Exponentially-weighted
mu = expected_returns.ema_historical_return(
    prices, frequency=252, span=500, compounding=True, log_returns=False,
)

# CAPM-implied
mu = expected_returns.capm_return(
    prices, market_prices=None, risk_free_rate=0.02, frequency=252,
)
```

## PyPortfolioOpt: Covariance Models
```python
from pypfopt import risk_models

# Sample covariance
S = risk_models.sample_cov(prices, frequency=252)

# Exponentially-weighted
S = risk_models.exp_cov(prices, span=180, frequency=252)

# Semicovariance (downside only)
S = risk_models.semicovariance(prices, benchmark=0, frequency=252)

# Robust (Minimum Covariance Determinant)
S = risk_models.min_cov_determinant(prices, frequency=252)

# Shrinkage estimators
cs = risk_models.CovarianceShrinkage(prices, frequency=252)
S = cs.ledoit_wolf()                  # Ledoit-Wolf shrinkage
S = cs.oracle_approximating()         # Oracle Approximating Shrinkage
S = cs.shrunk_covariance(delta=0.2)   # Manual shrinkage intensity

# Fix non-PSD
S = risk_models.fix_nonpositive_semidefinite(S, fix_method="spectral")  # or "diag"
```

## Recipe: Full Pipeline
```python
# Riskfolio-Lib
import riskfolio as rp
port = rp.Portfolio(returns=returns_df)
port.assets_stats(method_mu="hist", method_cov="ledoit")
w = port.optimization(model="Classic", rm="CVaR", obj="Sharpe")

# PyPortfolioOpt
from pypfopt import expected_returns, risk_models, EfficientFrontier
mu = expected_returns.ema_historical_return(prices, span=500)
S = risk_models.CovarianceShrinkage(prices).ledoit_wolf()
ef = EfficientFrontier(mu, S)
ef.max_sharpe()
weights = ef.clean_weights()
```
