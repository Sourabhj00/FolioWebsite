---
title: Black-Litterman — Detail
wp: n/a
status: reference
created: unknown
last-updated: 2026-03-31
lines: 127
kb-depends: []
jarvis-depends: []
---

# Black-Litterman — Detail File

## Riskfolio-Lib: `Portfolio.blacklitterman_stats` Signature
```python
port.blacklitterman_stats(
    P,                  # DataFrame (n_views × n_assets): views matrix
    Q,                  # DataFrame (n_views × 1): expected returns per view
    rf=0,               # Risk-free rate
    w=None,             # Equilibrium weights (Series). None = equal weight
    delta=None,         # Risk aversion. None = auto-calculate
    eq=True,            # True = equilibrium prior, False = historical mean
    method_mu="hist",   # Method for base mu estimation
    method_cov="hist",  # Method for base cov estimation
    dict_mu={},         # Extra params for mean_vector
    dict_cov={},        # Extra params for covar_matrix
)
# Sets port.mu_bl, port.cov_bl internally. Then use model="BL" in optimization.
```

## Riskfolio-Lib: Views Helper
```python
import riskfolio as rp
import pandas as pd

# asset_classes: DataFrame with columns like 'Assets', 'Sector', etc.
# Index must have asset names matching returns columns

# Absolute view: "AAPL will return 10%"
# Relative view: "AAPL will outperform GOOG by 3%"
views = {
    "AAPL": 0.10,                    # absolute
    "AAPL - GOOG >= 0.03": None,     # relative (sign & value in key)
}

# Build P, Q matrices from views dict
P, Q = rp.assets_views(views, asset_classes)
# P: DataFrame (n_views × n_assets)
# Q: DataFrame (n_views × 1)
```

## Riskfolio-Lib: Complete BL Recipe
```python
import riskfolio as rp

port = rp.Portfolio(returns=returns_df)
port.assets_stats(method_mu="hist", method_cov="ledoit_wolf")

# Define views
P = pd.DataFrame(...)  # views matrix
Q = pd.DataFrame(...)  # view returns

# Apply Black-Litterman
port.blacklitterman_stats(P=P, Q=Q, eq=True)

# Optimize with BL model
w = port.optimization(model="BL", rm="CVaR", obj="Sharpe", rf=0.02)
```

## Riskfolio-Lib: Augmented BL (asset + factor views)
```python
rp.augmented_black_litterman(
    X,          # Returns DataFrame
    w,          # Equilibrium weights
    F,          # Factor returns DataFrame
    B,          # Loadings matrix
    P,          # Asset views matrix (or None)
    Q,          # Asset view returns (or None)
    P_f,        # Factor views matrix (or None)
    Q_f,        # Factor view returns (or None)
    delta=1, rf=0, eq=True, const=True, method="0", q=0.05,
)
# Returns: (mu_bl, cov_bl)
```

## PyPortfolioOpt: `BlackLittermanModel` Constructor
```python
from pypfopt import BlackLittermanModel

bl = BlackLittermanModel(
    cov_matrix,                # pd.DataFrame: covariance matrix
    pi=None,                   # Prior returns. "market" for CAPM, or pd.Series, or None
    absolute_views=None,       # dict: {"AAPL": 0.10, "MSFT": 0.05}
    Q=None,                    # array/Series: view returns (alternative to absolute_views)
    P=None,                    # array/DataFrame: picking matrix (for relative views)
    omega=None,                # Uncertainty of views. "default" | "idzorek" | matrix
    view_confidences=None,     # List of floats in (0,1) for Idzorek method
    tau=0.05,                  # Scalar: uncertainty of prior
    risk_aversion=1,           # Market risk aversion (for "market" pi)
    market_caps=None,          # dict of market caps (for "market" pi)
    risk_free_rate=0.0,
)
```

## PyPortfolioOpt: Complete BL Recipe
```python
from pypfopt import BlackLittermanModel, black_litterman, EfficientFrontier
from pypfopt import risk_models

S = risk_models.CovarianceShrinkage(prices).ledoit_wolf()

# Market-implied prior
delta = black_litterman.market_implied_risk_aversion(prices)
pi = black_litterman.market_implied_prior_returns(market_caps, delta, S)

# Views with Idzorek confidences
views = {"AAPL": 0.12, "MSFT": 0.08}
bl = BlackLittermanModel(S, pi=pi, absolute_views=views,
                         omega="idzorek", view_confidences=[0.8, 0.6])

# Get posterior
bl_returns = bl.bl_returns()
bl_cov = bl.bl_cov()

# Feed into optimizer
ef = EfficientFrontier(bl_returns, bl_cov)
ef.max_sharpe()
weights = ef.clean_weights()
```

## PyPortfolioOpt: Relative Views
```python
# "AAPL will outperform GOOG by 5%"
P = np.array([[1, 0, -1, 0]])  # picking matrix (AAPL=1, GOOG=-1)
Q = np.array([0.05])
bl = BlackLittermanModel(S, pi=pi, Q=Q, P=P)
```
