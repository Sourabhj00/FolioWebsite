---
title: Portfolio-Risk Details — Map of Content
wp: n/a
status: reference
last-updated: 2026-03-31
lines: 18
---

# Portfolio-Risk Details — Map of Content

API-level reference with function signatures, constructor parameters,
complete workflow recipes, and library comparison tables. Load after
reading the corresponding topic file. (~1,057 lines total)

## Files

- [[portfolio_optimization_detail]] — Riskfolio Portfolio.__init__ + optimization signature, complete workflow, PyPortfolioOpt EfficientFrontier recipe, EigenLedger backtest. (~133 lines)
- [[risk_metrics_detail]] — Riskfolio risk function signatures (VaR/CVaR/EVaR/drawdown), composite functions, QuantStats risk signatures, code mapping table. (~137 lines)
- [[covariance_estimation_detail]] — Riskfolio assets_stats/factors_stats, RMT denoising, PyPortfolioOpt mean_historical_return/risk_models, Ledoit-Wolf/OAS, pipeline recipe. (~124 lines)
- [[black_litterman_detail]] — Riskfolio blacklitterman_stats, views helper, augmented BL, PyPortfolioOpt BL constructor, market-implied prior recipes. (~127 lines)
- [[hierarchical_detail]] — Riskfolio HCPortfolio.__init__/optimization, model differences (HRP/HERC/NCO), codependence, PyPortfolioOpt HRPOpt. (~128 lines)
- [[constraints_detail]] — Riskfolio constraints DataFrame format, asset_constraints builder, turnover/TE/cardinality, PyPortfolioOpt sector/lambda. (~140 lines)
- [[factor_analysis_detail]] — Alphalens get_clean_factor_and_forward_returns, input format, performance functions, tear sheets, end-to-end recipe. (~144 lines)
- [[performance_ratios_detail]] — QuantStats key signatures, probabilistic ratios, rolling metrics, greeks/regression, drawdown analysis, comparison recipe. (~112 lines)
- [[options_pricing_detail]] — QFRM Stock/OptionSeries/OptionValuation constructors, calc_px parameters, shortcuts, exotic imports, visualization. (~121 lines)
