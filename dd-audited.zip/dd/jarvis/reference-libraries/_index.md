---
title: Reference Libraries — Map of Content
wp: n/a
status: reference
last-updated: 2026-03-31
lines: 21
---

# Reference Libraries — Map of Content

External library reference material for QuantLib ecosystem (SOFR curve
construction, instrument pricing, ORE extensions) and portfolio/risk
analytics (optimization, factor analysis, risk metrics). Each library has
a MASTER_INDEX.md routing table — load that first, then drill into
topics/ and details/ as needed.

**Never pre-load these.** They are reference material consumed by other
Jarvis work, not trading-specific outputs.

## Subfolders

- [[reference-libraries/quantlib/_index|QuantLib Ecosystem]] — QuantLib v1.39+, ORE v1.8.15.0, quantraserver: SOFR/OIS curves, swaps, futures, bonds, options, risk analytics, deployment. (~1,497 lines across 21 files)
- [[reference-libraries/portfolio-risk/_index|Portfolio & Risk]] — Riskfolio-Lib, PyPortfolioOpt, QuantStats, Alphalens, EigenLedger, QFRM: optimization, risk metrics, factor analysis, BL, HRP, backtesting. (~1,969 lines across 24 files)

## Related Folders

- [[fair-value/_index|Fair Value]] — SOFR bootstrap uses QuantLib classes documented here
- [[strategy-research/_index|Strategy Research]] — Future signal models may use portfolio analytics
