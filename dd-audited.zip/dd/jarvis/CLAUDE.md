---
title: CLAUDE.md — Jarvis Navigation Manifest
wp: n/a
status: complete
last-updated: 2026-03-31
lines: 138
---

# CLAUDE.md — Jarvis Navigation Manifest

Jarvis is the **analysis and output layer** for the STIR futures trading system.
It contains WP deliverables, models, research, and reference libraries produced
from the 3-month execution plan.

The **knowledge-base/** folder remains the source of truth for system design,
strategy logic, instrument specs, ASE rules, and application architecture.
Jarvis never duplicates or overrides KB content — it extends it with results.

---

## Navigation Protocol

- **Always read `_index.md`** in each folder before loading individual files.
  The MOC tells you what's in the folder so you can load selectively.
- **Use line counts** to budget context window. Line counts appear in
  parentheses after each file description in `_index.md` files and in the
  `lines:` frontmatter field of every markdown file.
- **Follow wikilinks** for dependencies rather than loading entire folders.
  Each file's YAML frontmatter lists `kb-depends` and `jarvis-depends`.
- **For KB context**, load `knowledge-base/core/` first (~170 lines), then
  only the specific KB files listed in a file's `kb-depends` frontmatter.

---

## How KB and Jarvis Work Together

| Need | Load from |
|------|-----------|
| What is the O spread? How do legs work? | `knowledge-base/strategy/` |
| What are the pricing formulas? | `knowledge-base/strategy/price-formulas-complete.md` |
| What did WP-04 find wrong in those formulas? | `jarvis/timer-logic/verification-report.md` |
| How does the .NET app work? | `knowledge-base/application/` |
| What .NET code was written for Timer Logic? | `jarvis/timer-logic/implementation/` |
| What are the ASE rules? | `knowledge-base/ase-rules/` |
| How accurate are fills in production? | `jarvis/fill-analysis/analysis_summary.json` |
| What is the SOFR bootstrap methodology? | `jarvis/fair-value/sofr-bootstrap-methodology.md` |
| What contracts should get different params? | `jarvis/market-profiling/contract-segmentation.md` |
| QuantLib class for SOFR curve construction? | `jarvis/reference-libraries/quantlib/MASTER_INDEX.md` |

**Rule**: KB defines *what the system is*. Jarvis documents *what we've built,
tested, found, and plan to build next*.

---

## Authority Hierarchy

1. **knowledge-base/core/** — Absolute truth. Glossary and instrument specs.
2. **knowledge-base/ domain folders** — Authoritative for system design.
3. **jarvis/ WP outputs** — Authoritative for analysis results and verified findings.
   Where a jarvis finding contradicts a KB doc (e.g., WP-04 found formula errors
   in execution-modifiers.md), the jarvis finding is correct and the KB doc is
   pending correction.
4. **jarvis/ reference-libraries/** — External library reference. Not trading-specific.

---

## Folder Index

### plan/ (~955 lines) — Load when reviewing priorities or WP status
The 3-month execution plan and WP completion tracker. Start here to understand
the overall program structure, dependencies, and what's done vs pending.

### fill-analysis/ (~121 lines md, ~1,011 lines Python, ~4K rows data) — Load for execution quality discussion
WP-01 output: Python pipeline + real production fill data (3,225 fills, Mar 1–13 2026).
Contains per-alias accuracy, expiry group summaries, degradation rankings, P&L.
Grand accuracy: 56.32% combined (buy 56.16%, sell 56.44%).

**KB dependencies**: `methodology-and-framework`, `instruments-and-platform`, `core-quad-leg-arbitrage`

### timer-logic/ (~1,438 lines md, ~854 lines C#, ~515 lines test data) — Load for Timer Logic discussion
WP-04 verification report (formula audit, 20 test cases, crossed-market analysis)
plus WP-05 .NET implementation (C# code, 151/152 tests passing).

**Critical finding**: `execution-modifiers.md` §5 is MISSING the −BS_FF term in
Leg 3/4 base formulas. Use `price-formulas-complete.md` as sole formula source.

**KB dependencies**: `timer-logic`, `price-formulas-complete`, `execution-modifiers`, `safety-mechanisms`

### fair-value/ (~1,029 lines md, ~1,677 lines Python) — Load for pricing/valuation discussion
WP-02 SOFR bootstrap (methodology + Python script) plus the Network Valuation
Engine (5-phase plan, implementation prompt, working Python engine). This is the
path from judgment-based O_target to curve-derived fair value.

**KB dependencies**: `core-quad-leg-arbitrage`, `price-formulas-complete`, `instruments-and-platform`

### market-profiling/ (~764 lines) — Load for parameter tuning or calendar events
WP-03 contract segmentation (4 groups with parameter recommendations) and
WP-12 event calendar (Fed meetings, rolls, FOMC, payrolls through 2027).

**KB dependencies**: `execution-modifiers`, `custom-rules-production`, `instruments-and-platform`

### strategy-research/ (~1,260 lines) — Load for future strategy work
Directional bias model (Treasury ZN/ZT lead-lag signal for SR3 execution).
Phase 1 scope defined but not yet implemented. Use for forward planning.

**KB dependencies**: `core-quad-leg-arbitrage`, `ase-mechanics-and-parameters`

### reference-libraries/ (~3,466 lines across 45 files) — Load on-demand only
QuantLib ecosystem directory (SOFR curve construction, instrument pricing,
ORE extensions) and Portfolio/Risk library directory (optimization, factor
analysis, risk metrics). Each has its own MASTER_INDEX.md — load that first,
then drill into topics/ and details/ as needed.

**Never pre-load these.** They are reference material, not trading context.

---

## Loading Protocol for Common Tasks

| Task | Load (KB) | Load (Jarvis) |
|------|-----------|---------------|
| "Is Timer Logic ready for production?" | `strategy/timer-logic.md` | `timer-logic/_index.md` → selectively |
| "Why is Sep26 accuracy bad?" | `core/`, `execution-analysis/` | `fill-analysis/_index.md`, `market-profiling/contract-segmentation.md` |
| "What should we work on next?" | — | `plan/_index.md` → `wp-status.md` |
| "How does the valuation engine work?" | `strategy/price-formulas-complete.md` | `fair-value/_index.md` → selectively |
| "Tune HitMan for Dec26 group" | `ase-rules/custom-rules-production.md` | `market-profiling/contract-segmentation.md`, `fill-analysis/alias_summary.csv` |
| "Bootstrap a SOFR curve in QuantLib" | — | `fair-value/sofr-bootstrap-methodology.md`, `reference-libraries/quantlib/MASTER_INDEX.md` |
| "What events affect trading this month?" | — | `market-profiling/event-calendar-2026-2027.md` |
| "Plan the directional bias model build" | `core/`, `strategy/` | `strategy-research/_index.md` → `directional-bias-model.md` |

---

## Collaboration Rules

1. **Never be a yes-man.** Push back on flawed reasoning. Name risks. Challenge
   assumptions against KB data and jarvis results.
2. **Ground claims in evidence.** Cite specific files and sections. If reasoning
   beyond what's documented, label it: "[Beyond KB/Jarvis — first-principles]".
3. **Cross-reference.** When discussing a topic, check both KB (design intent)
   and jarvis (actual results). Divergence between intent and results is signal.
4. **Flag gaps.** If a discussion requires data from an incomplete WP (WP-06,
   WP-07, WP-08, WP-09, WP-10, WP-11, WP-13, WP-14), say so explicitly.
5. **Respect the hierarchy.** KB core/ > KB domain/ > jarvis findings > external refs.
   Exception: when jarvis explicitly documents a KB error (e.g., WP-04 formula
   corrections), jarvis is authoritative for that specific finding.
