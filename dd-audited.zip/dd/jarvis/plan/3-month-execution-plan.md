---
title: 3-Month Execution Plan — STIR Futures Trading System
wp: n/a
status: complete
created: 2026-03-15
last-updated: 2026-03-31
lines: 838
kb-depends: []
jarvis-depends:
  - jarvis/plan/wp-status.md
---

# STIR Futures Quant Upgrade — 3-Month Execution Plan

**Created**: 2026-03-30
**For**: Solo STIR futures trader, quad-leg SR3|SR1|ZQ arbitrage system
**Constraint**: 2-3 concurrent Claude chats max, live trading continues during execution

---

## Plan Overview

### Month Themes

**Month 1 — Measure and Model the Edge**
Instrument the existing system to understand where you're losing edge, then build the first quant model (SOFR bootstrap) that computes fair value from curves rather than judgment. Simultaneously, run the market profiling exercise that determines which contracts get which parameters. Everything this month is about converting manual trader judgment into measurable, auditable signals.

**Month 2 — Deploy Intelligence to Execution**
Ship Timer Logic with evidence-conditioned expansion. Deploy the fill analysis pipeline that runs daily. Implement dynamic avoidance driven by realized vol rather than static parameters. Begin regime detection research. Everything this month is about making the .NET system smarter at the microstructure level.

**Month 3 — Expand and Optimize**
Lot sizing optimization based on fill quality data. Pricing engine prototype that formalizes the junction/interchange logic. Research signals for new markets (correlated contracts, seasonality calendar). Begin converting the best-performing Month 2 improvements into permanent .NET components.

### Critical Path

```
WP-01 (Fill Analysis) ──→ WP-06 (Accuracy Patterns) ──→ WP-10 (Lot Sizing)
                     ╲
WP-02 (SOFR Bootstrap) ──→ WP-07 (Dynamic Avoidance) ──→ WP-13 (Pricing Engine)
                          ╲
WP-03 (Market Profiling) ──→ WP-08 (Parameter Optimization)
                          
WP-04 (Timer Logic Docs) ──→ WP-05 (Timer Logic .NET) ──→ WP-09 (Timer Logic Tuning)

WP-11 (Regime Detection Research) ──→ WP-14 (Regime-Based Rules)

WP-12 (Seasonality Calendar) — standalone, immediate value
```

### Budget Allocation (First $800)

| Spend | WPs | Why first |
|-------|-----|-----------|
| $150 | WP-01 (Fill Analysis Pipeline) | Immediately actionable — you need this data daily |
| $150 | WP-02 (SOFR Bootstrap Documentation + Validation) | Foundation for all pricing improvements |
| $100 | WP-03 (Market Profiling Phase 1) | Quick win, informs all parameter decisions |
| $100 | WP-04 (Timer Logic Documentation + Test Cases) | Unblocks the highest-impact .NET change |
| $100 | WP-12 (Seasonality Calendar) | Immediate trading alpha, no dependencies |
| $100 | WP-05 (Timer Logic .NET Implementation) | Deploy first quant improvement to live |
| $100 | Reserve for rework / unexpected issues | |

---

## Quick Wins (First 2 Days)

These can each be completed in a single Claude chat and deliver immediate value:

1. **WP-01: Fill Analysis Pipeline** — Automated daily report from your JSON fill files. You have the methodology documented; this is pure implementation. Day 1, first chat. Output: Python script + first 30-day historical report.

2. **WP-03: Market Profiling Phase 1** — Profile your current contracts into 3-4 groups using the framework already in staging. Produces a concrete parameter table per group. Day 1, second chat.

3. **WP-12: Seasonality Calendar** — Build the master list of time-sensitive trades (roll dynamics, quarterly expiry patterns). Immediate trading alpha. Day 2, first chat.

4. **WP-04: Timer Logic Documentation** — Verify the timer-logic.md and accuracy-measurement.md against your understanding. Produce test cases for SIM validation. Day 2, second chat.

---

## Work Package Table

| ID | Title | Month/Week | Priority | Depends On | Can Parallel With | Output | Destination | Est. Chats | Validation |
|----|-------|-----------|----------|------------|-------------------|--------|-------------|------------|------------|
| WP-01 | Fill Analysis Pipeline | M1/W1 | P0 | None | WP-02, WP-03 | Python script + 30-day report | Python Backtesting | 1-2 | Report matches manual analysis for known dates |
| WP-02 | SOFR Bootstrap Documentation | M1/W1 | P0 | None | WP-01, WP-03 | Documented bootstrap logic + QuantLib mapping | Knowledge Base | 1-2 | Bootstrap output matches your current fair values ±0.5 tick |
| WP-03 | Market Profiling Phase 1 | M1/W1 | P0 | None | WP-01, WP-02 | Contract group table + parameter recommendations | Knowledge Base + .NET params | 1 | Groups validated against fill accuracy by group |
| WP-04 | Timer Logic Verification | M1/W2 | P0 | None | WP-01 | Verified timer-logic.md + 20 test cases | Knowledge Base | 1-2 | Forward-reverse identity holds for all 4 legs |
| WP-05 | Timer Logic .NET Implementation | M1/W3-4 | P1 | WP-04 | WP-06 | .NET code: static expansion + accuracy measurement | .NET Live (SIM first) | 2-3 | SIM fill attribution: incremental fills >25% of Timer-affected |
| WP-06 | Fill Accuracy Pattern Analysis | M2/W1 | P1 | WP-01 | WP-07 | Segregation study: <60% vs >70% accuracy causes | Knowledge Base | 1-2 | Root causes identified for Sep26 underperformance |
| WP-07 | Dynamic Avoidance Model | M2/W2 | P1 | WP-02, WP-06 | WP-08 | Realized vol → avoidance mapping + backtest | Python Backtesting → .NET | 2 | Backtest shows accuracy improvement vs static avoidance |
| WP-08 | Parameter Optimization by Profile | M2/W3 | P1 | WP-03, WP-06 | WP-09 | Optimized param set per contract group | .NET Live | 1-2 | Accuracy improves on worst-performing groups |
| WP-09 | Timer Logic Tuning + Dynamic Expansion | M2/W4 | P1 | WP-05, WP-06 | WP-10 | Evidence-conditioned expansion (signals 1-3) | .NET Live | 2-3 | Net P&L from incremental fills exceeds rounding cost |
| WP-10 | Lot Sizing Optimization | M3/W1 | P2 | WP-06 | WP-11 | Fill-quality-based lot allocation model | Python → .NET | 1-2 | Lot sizing correlates with accuracy: more lots in clean conditions |
| WP-11 | Regime Detection Research | M2/W3 | P2 | WP-01 | WP-08 | Decision doc: which regime model, with evidence | Knowledge Base | 1-2 | Kill: if no regime signal achieves >60% accuracy on historical fills |
| WP-12 | Seasonality Calendar | M1/W1 | P0 | None | Any | Master calendar with alerts + entry rules | Knowledge Base + Trading | 1 | Calendar covers all SR3 quarterly expiries for next 12 months |
| WP-13 | Pricing Engine Prototype | M3/W2 | P2 | WP-02, WP-07 | WP-14 | Standalone pricing engine spec + prototype | Python | 2-3 | Prototype matches .NET output for 100 historical price snapshots |
| WP-14 | Regime-Based Rule Activation | M3/W3-4 | P2 | WP-11, WP-08 | None | Conditional rule activation logic | .NET Live | 2 | Kill: if regime detection didn't pass WP-11 |
| WP-15 | Quant KB Navigation Prompt | M1/W2 | P1 | WP-02 | Any | Master system prompt for Claude Project | Claude Project | 1 | Claude correctly routes 10 test queries to right directory |

---

## Work Package Specs

### WP-01: Fill Analysis Pipeline

**Objective**: Build an automated daily fill analysis that ingests JSON fill files and produces the report defined in methodology-and-framework.md. This replaces manual analysis and provides the data foundation for every accuracy-improvement WP downstream. Without this, you're guessing at what to optimize.

**Context This Chat Needs**:
```
Upload: methodology-and-framework.md (execution analysis)
Upload: instruments-and-platform.md (DV01, tick sizes for DPP calc)
Upload: core-quad-leg-arbitrage.md (for alias → expiry group mapping)
Upload: 2-3 sample daily JSON fill files (for testing)
Paste: WP-01 spec from this plan (objective + done criteria)
```

**Prompt Skeleton**:
```
Role: Python data engineer building a trading analytics pipeline.
Task: Build a daily fill analysis script that ingests JSON fill files
and produces the complete report defined in methodology-and-framework.md,
including: TD per fill, weighted accuracy, per-alias summary, matched P&L,
expiry group summary, ASE type summary, and day-over-day comparison.
Constraints: Must handle missing data gracefully. DPP range ($75-$125) 
reported as conservative/midpoint/aggressive. Output as both console 
summary and CSV/JSON for downstream analysis.
Output: Single Python script + requirements.txt. Run historical analysis 
on all provided fill files. Produce the 8 structural patterns report.
Questions to answer:
- Which aliases have degraded most over the 30-day window?
- What's the buy-side vs sell-side accuracy split at different volume levels?
- Which expiry group should I reduce exposure to?
```

**Key Decisions**:
1. **Output format**: CSV tables vs interactive HTML report vs both. Default: CSV + console summary (simplest, feeds downstream WPs).
2. **DPP treatment**: Use $100 midpoint for main report, show $75/$125 range in sensitivity section. 
3. **Historical depth**: Start with available data (Mar 5-19, 2026). Extend as more days accumulate.
4. **Automation**: Cron-style daily run vs manual trigger. Default: manual trigger with date parameter.

**Risk**: Low technical risk. Main risk is data quality issues in JSON files (missing fields, inconsistent aliases). Mitigate: build validation step that flags bad records.

**Done Criteria**:
- [ ] Script runs on all provided fill files without errors
- [ ] Output matches manual calculations for 2 known anchor dates
- [ ] Per-alias, per-group, per-ASE-type summaries all generated
- [ ] Matched P&L calculated with DPP sensitivity range
- [ ] 8 structural patterns evaluated against data
- [ ] Day-over-day comparison for multi-day datasets

---

### WP-02: SOFR Bootstrap Documentation and Validation

**Objective**: Document your existing SOFR bootstrap logic and map it to QuantLib's curve construction classes. This is the fair value anchor for the entire system — buyBiased/sellBiased should be computable from the curve, not just from judgment. Even a rough bootstrap validated against QuantLib gives you a reference price that's independent of market noise.

**Context This Chat Needs**:
```
Upload: quantlib_directory/MASTER_INDEX.md
Upload: quantlib_directory/topics/sofr_and_ois.md
Upload: quantlib_directory/topics/yield_curves.md
Upload: quantlib_directory/details/curve_bootstrapping_recipes.md
Upload: quantlib_directory/details/quantlib_sofr_implementation.md
Upload: instruments-and-platform.md (SR3/SR1/ZQ specs)
Upload: core-quad-leg-arbitrage.md (what the bootstrap prices)
Upload: price-formulas-complete.md (how fair value feeds into leg prices)
Paste: Your current bootstrap logic (notes, Excel formulas, whatever exists)
Paste: WP-02 spec from this plan
```

**Prompt Skeleton**:
```
Role: Quantitative analyst specializing in SOFR curve construction.
Task: (1) Document the trader's existing SOFR bootstrap methodology.
(2) Map each step to QuantLib classes (OvernightIndexedSwap, 
PiecewiseYieldCurve, SOFRNode helpers). (3) Identify gaps between
the current approach and best practice. (4) Produce a Python script
using QuantLib that replicates the trader's bootstrap and outputs
fair value for the O spread across all 4 quarterly expiry groups.
Constraints: The output must be actionable for a .NET trader — show
the math, not just the code. Must handle the SR3→SR1 decomposition
and the SR1-ZQ basis. Must explain where the 1-2 tick edge comes from
in terms of curve mispricing.
Output: (1) Bootstrap methodology document for KB. (2) Python script.
(3) Comparison: bootstrap fair value vs trader's recent buyBiased/sellBiased.
```

**Key Decisions**:
1. **Interpolation method**: Log-linear on discount factors vs monotone convex vs flat forward. Default: log-linear (simplest, QuantLib default). Document sensitivity to choice.
2. **Input instruments**: Which market instruments anchor the curve? SOFR futures, OIS swaps, or both? Resolve with: use what's available in your data.
3. **Basis modeling**: Model SOFR-FF basis explicitly or as a fixed spread? Default: fixed spread initially, flag as refinement for later.
4. **Update frequency**: Static daily bootstrap vs real-time. Default: daily (pre-session), real-time is a Month 3 ambition.

**Risk**: If your current bootstrap is purely judgment-based (no mathematical model), this WP becomes "build a bootstrap from scratch" rather than "document and validate." That's a bigger lift — split into WP-02a (research: which instruments, which curve) and WP-02b (implementation). Cascade: every downstream WP that uses fair value is delayed by 1 week.

**Done Criteria**:
- [ ] Bootstrap methodology documented in KB-compatible format
- [ ] QuantLib mapping complete (class names, constructor args, helper objects)
- [ ] Python script produces O fair value for all 4 expiry groups
- [ ] Fair values compared against recent buyBiased/sellBiased — deviations explained
- [ ] Sensitivity analysis: ±1bp input shock → O fair value change quantified

---

### WP-03: Market Profiling Phase 1

**Objective**: Profile your currently traded contracts into 3-4 groups using the framework in staging/proposed-additions.md. Output a concrete parameter recommendation table: for each group, which ASE rules, which avoidance values, which reload clips, which lot sizes. This replaces "same parameters everywhere" with profile-aware configuration.

**Context This Chat Needs**:
```
Upload: proposed-additions.md (market profiling framework section)
Upload: methodology-and-framework.md (fill patterns by expiry group)
Upload: custom-rules-production.md (current rule parameters)
Upload: execution-modifiers.md (avoidance/bias parameters)
Upload: WP-01 output (fill analysis report, if available)
Paste: Your observations on which contracts behave differently (from brain dump: front spreads directional, mid spreads range-bound, etc.)
Paste: WP-03 spec from this plan
```

**Prompt Skeleton**:
```
Role: Quantitative execution analyst profiling STIR futures contracts.
Task: Using fill quality data and contract characteristics, segment
the current SR3|SR1|ZQ complex into 3-4 contract groups. For each
group, recommend: avoidance parameters, B/S bias ranges, reload clip
sizes, HitMan/ASM thresholds, and lot allocation weight.
Constraints: Groups must be validated against fill accuracy data — 
don't group by intuition alone. Parameters must be conservative 
(improve accuracy first, then increase volume).
Output: (1) Group definitions with membership criteria. (2) Parameter
table per group. (3) Specific changes to apply to current .NET config.
```

**Key Decisions**:
1. **Number of groups**: 3 (simple) vs 4-5 (granular). Default: start with 3, split if data shows clear sub-clusters.
2. **Grouping criteria**: Volume-based vs volatility-based vs accuracy-based. Resolve: use accuracy data from WP-01 as primary discriminator, volume/vol as secondary.
3. **Dec26 vs Sep26 treatment**: Dec26 is cleanest, Sep26 is worst. Do they need fundamentally different rules or just different parameters? Resolve: start with parameter differences only.

**Risk**: Low. Worst case: profiling doesn't reveal clear groups, in which case you maintain current parameters. No cascade.

**Done Criteria**:
- [ ] 3-4 groups defined with clear membership criteria
- [ ] Parameter table produced for each group
- [ ] Recommendations validated against historical fill accuracy by group
- [ ] Specific .NET config changes documented (which parameters to change, to what values)
- [ ] "Markets to avoid" list produced

---

### WP-04: Timer Logic Verification and Test Cases

**Objective**: Verify the timer-logic.md and accuracy-measurement.md documents against your understanding of the system. Produce 20 concrete test cases that cover all 9 execution states, the forward-reverse identity, and edge cases (crossed markets, quad expansion, Fed window interaction). These test cases are the validation gate for WP-05 (.NET implementation).

**Context This Chat Needs**:
```
Upload: timer-logic.md (full document)
Upload: accuracy-measurement.md (full document)
Upload: case-distribution.md (20-case decision framework)
Upload: price-formulas-complete.md (forward pipeline to reverse)
Upload: execution-modifiers.md (avoidance/bias interaction)
Upload: custom-rules-production.md (HitMan/ASM/Backoff interaction)
Upload: safety-mechanisms.md (cross-validation guard)
Paste: WP-04 spec from this plan
```

**Prompt Skeleton**:
```
Role: QA engineer for a live trading system. Zero tolerance for errors.
Task: (1) Verify internal consistency of Timer Logic and Accuracy
Measurement documents. (2) Check all reverse formulas algebraically.
(3) Produce 20 test cases covering: all 9 execution states, forward-
reverse identity for Legs 1-4, crossed market detection, double/quad
expansion classification, Fed window interaction, and edge cases.
Constraints: Each test case must have concrete numeric inputs and 
expected outputs. Flag any ambiguity or contradiction between documents.
Output: (1) Verification report with any issues found. (2) Test case
document in structured format. (3) Decision: ready for .NET implementation?
```

**Key Decisions**:
1. **Reverse formula sign conventions**: The min/max handling in the BS_FF conditional adjustment is the highest-risk area. Algebraic verification required.
2. **Crossed market boundary**: At what expansion + O spread width does crossed market occur? Compute the exact boundary.
3. **Phase 1 vs Phase 2 scope**: Ship with Legs 1&2 reverse only (as accuracy-measurement.md suggests) or all 4 legs? Default: Legs 1&2 first.

**Risk**: If verification reveals formula errors, WP-05 is blocked until fixed. This is intentional — better to catch errors here than in live trading.

**Done Criteria**:
- [ ] All reverse formulas algebraically verified for Legs 1-4
- [ ] Forward-reverse identity confirmed: reverse(forward(O_target)) = O_target for all legs
- [ ] 20 test cases with concrete inputs and expected outputs
- [ ] Crossed market boundary computed for typical parameter ranges
- [ ] Interaction with HitMan/ASM/Backoff documented with examples
- [ ] GO/NO-GO decision for WP-05

---

### WP-05: Timer Logic .NET Implementation

**Objective**: Implement static-expansion Timer Logic in the .NET trading engine. Phase 1: fixed expansion value per contract (no dynamic signals yet). Plus: implement the accuracy measurement pipeline (snapshot capture at QuoteFill and HedgeFill, reverse-implied O computation, CSV output). Deploy to SIM first, then production after validation.

**Context This Chat Needs**:
```
Upload: timer-logic.md
Upload: accuracy-measurement.md  
Upload: architecture-and-dataflow.md (.NET pipeline architecture)
Upload: order-management.md (fill events, reload, deduplication)
Upload: WP-04 output (verified test cases, any corrections)
Paste: Relevant .NET source file snippets (PriceCalculation.cs, 
       VWAPCalculator.cs, FillSubscription handler)
Paste: WP-05 spec from this plan
```

**Prompt Skeleton**:
```
Role: Senior .NET developer working on a live trading system.
Task: Implement Timer Logic rounding (TimerRD/TimerRU) in the 
PriceCalculator pipeline and the accuracy measurement snapshot 
system hooking into FillSubscription. Phase 1 = static expansion.
Constraints: Must not break existing pipeline. Must work within 56ms 
quote throttle. Must preserve cross-validation guard. Accuracy 
measurement must capture v1, v2, v3, diff, all parameters at fill time.
All code paths must have null/error guards — this runs in live markets.
Output: (1) Modified PriceCalculation.cs with Timer Logic. (2) New
AccuracyMeasurement.cs with snapshot capture and reverse formulas.
(3) SIM deployment checklist. (4) Production deployment checklist.
```

**Key Decisions**:
1. **Initial expansion values**: 0.10 for all contracts (conservative) vs profile-based values from WP-03. Default: 0.10 uniform to isolate Timer Logic effect.
2. **Accuracy measurement scope**: Legs 1&2 only (Phase 1) vs all 4 legs. Default: Legs 1&2 per the accuracy-measurement.md recommendation.
3. **SIM duration**: How many sessions before promoting to production? Default: 3 full trading sessions with >200 fills total.
4. **Rollback plan**: Feature flag to disable Timer Logic instantly? Default: yes, via UI toggle (reuse existing `dynamic` flag pattern).

**Risk**: Highest-risk WP in the plan. Code runs in live markets. Mitigation: SIM-only deployment, feature flag, cross-validation guard catches crossed markets. If Timer Logic causes crossed-market pauses more than 2% of the time in SIM, abort and review expansion values.

**Done Criteria**:
- [ ] Timer Logic rounding passes all 20 test cases from WP-04
- [ ] Accuracy measurement captures snapshots for all SIM fills
- [ ] Forward-reverse identity holds within 0.01 ticks for 95% of fills
- [ ] No Timer-Logic-caused crossed-market pauses in 3 SIM sessions
- [ ] Fill attribution: incremental fills identified and counted
- [ ] Feature flag tested: toggle on/off without restart
- [ ] GO/NO-GO decision for production deployment

---

### WP-06: Fill Accuracy Pattern Analysis

**Objective**: Using 30+ days of fill analysis data from WP-01, perform the segregation study defined in staging/proposed-additions.md: batch fills into <60% and >70% accuracy groups, identify root causes for each, and convert causes into actionable parameter changes. This is the analytical foundation for WP-07 (dynamic avoidance), WP-08 (parameter optimization), and WP-10 (lot sizing).

**Context This Chat Needs**:
```
Upload: WP-01 output (30-day fill analysis CSV/JSON)
Upload: methodology-and-framework.md (8 structural patterns)
Upload: proposed-additions.md (accuracy improvement framework section)
Upload: execution-modifiers.md (current avoidance/bias settings)
Upload: custom-rules-production.md (rule parameters)
Paste: WP-06 spec from this plan
```

**Prompt Skeleton**:
```
Role: Quantitative analyst performing execution quality forensics.
Task: Segregate 30 days of fills into accuracy buckets. For each 
bucket, identify the market conditions (bid-offer, volume, momentum,
time of day) that distinguish good fills from bad fills. Produce
a factor importance ranking: which conditions most predict poor accuracy?
Constraints: Use the accuracy formula from methodology-and-framework.md.
Don't propose solutions yet — just diagnose. Solutions come in WP-07/08.
Output: (1) Segregation report with accuracy distributions. (2) Factor
analysis: top 5 predictors of poor accuracy. (3) Sep26 deep dive: 
why is it structurally worst? (4) Volume sensitivity curve.
```

**Key Decisions**:
1. **Accuracy threshold**: <60% vs >70% as documented, or adjust based on actual distribution? Resolve: use actual percentiles (bottom quartile vs top quartile).
2. **Factor candidates**: Which market conditions to test. Start with: bid-offer spread, volume, time-of-day, momentum (3-min rolling), avoidance level in effect, HitMan fire rate.

**Risk**: Low. Worst case: no clear pattern emerges, which means the system is already well-tuned. More likely: clear patterns emerge for Sep26 and buy-side degradation.

**Done Criteria**:
- [ ] Fills segmented into accuracy buckets with counts and distributions
- [ ] Top 5 accuracy predictors identified with statistical support
- [ ] Sep26 root cause analysis complete
- [ ] Buy-side volume degradation curve plotted
- [ ] Recommendations formatted for consumption by WP-07, WP-08, WP-10

---

### WP-07: Dynamic Avoidance Model

**Objective**: Replace static avoidance parameters with a realized-vol-driven model. When SR1-ZQ basis volatility increases, Av_FF should widen automatically — not just during the 12:55-13:05 window, but continuously. This is the first quant model that directly feeds the .NET execution pipeline.

**Context This Chat Needs**:
```
Upload: execution-modifiers.md (current avoidance mechanics)
Upload: price-formulas-complete.md (where avoidance enters the pipeline)
Upload: WP-06 output (accuracy pattern analysis — vol as predictor)
Upload: quantlib_directory/topics/risk_analytics_xva.md (vol estimation methods)
Upload: portfolio_risk_directory/topics/risk_metrics.md (realized vol methods)
Paste: WP-07 spec from this plan
```

**Prompt Skeleton**:
```
Role: Quant researcher designing an adaptive spread-widening model.
Task: Build a model that maps realized volatility of the SR1-ZQ basis
and ZQ calendar to avoidance parameter values. Backtest against 
historical fill data: would dynamic avoidance have improved accuracy
compared to static avoidance?
Constraints: Must be computationally cheap (runs per market tick in .NET).
Must degrade gracefully to static value if vol computation fails.
Output: (1) Vol estimation method and window. (2) Vol → avoidance
mapping function with calibrated parameters. (3) Backtest results.
(4) .NET implementation spec if backtest passes.
Kill criterion: If dynamic avoidance doesn't improve weighted accuracy
by at least 3 percentage points vs static, abandon and keep static.
```

**Key Decisions**:
1. **Vol estimator**: Realized vol (rolling window) vs exponentially weighted vs Parkinson/Garman-Klass. Default: EWMA (simple, common, fast).
2. **Window length**: 5-minute vs 15-minute vs 1-hour. Resolve: test all three in backtest.
3. **Mapping function**: Linear (vol × coefficient) vs quantile-based (if vol > 80th percentile, use high avoidance). Default: quantile-based (more robust to regime changes).

**Risk**: Moderate. If vol signal is too noisy, dynamic avoidance could whipsaw the spread width. Kill criterion protects against deploying a harmful model.

**Done Criteria**:
- [ ] Vol estimator selected with rationale
- [ ] Mapping function calibrated on training data
- [ ] Backtest on out-of-sample data shows ≥3pp accuracy improvement
- [ ] .NET implementation spec produced (or "abandon" decision documented)
- [ ] Interaction with existing dynamic avoidance (12:55-13:05 window) specified

---

### WP-08: Parameter Optimization by Contract Profile

**Objective**: Using WP-03 profiles and WP-06 accuracy patterns, optimize the parameter set for each contract group. This means finding the best HitMan VolRatio, ASM LiqCheck, Backoff QtyThreshold, and WCT Payup parameters per group — not globally.

**Context This Chat Needs**:
```
Upload: WP-03 output (contract group definitions and current params)
Upload: WP-06 output (accuracy patterns by condition)
Upload: custom-rules-production.md (all 8 production rules with params)
Upload: ase-mechanics-and-parameters.md (how params affect the engine)
Paste: WP-08 spec from this plan
```

**Prompt Skeleton**:
```
Role: Execution optimization analyst tuning ASE rule parameters.
Task: For each contract group from WP-03, recommend optimized 
parameter values for all 8 production rules. Base recommendations on
accuracy pattern data from WP-06: e.g., if Group 2 (mid spreads)
has thin quote legs, lower the HitMan LiqCheck threshold.
Constraints: Changes must be conservative — tune one parameter family
at a time, validate in SIM before production. Document expected 
accuracy improvement per change.
Output: Parameter change table per group + deployment sequence.
```

**Key Decisions**:
1. **Optimization approach**: Manual rule-based (if condition X, change param Y) vs grid search on historical data. Default: manual rule-based first (interpretable, auditable).
2. **Deployment sequence**: Change everything at once vs one group at a time. Default: one group at a time, starting with worst-performing (Sep26).

**Risk**: Low-moderate. Worst case: optimized parameters perform similarly to current ones. Mitigation: A/B set architecture enables running old vs new params in parallel.

**Done Criteria**:
- [ ] Parameter recommendations for each contract group
- [ ] Expected accuracy improvement quantified per change
- [ ] SIM validation plan: which parameters to test first
- [ ] A/B testing plan: how to compare old vs new in production
- [ ] Rollback procedure documented

---

### WP-09: Timer Logic Tuning + Dynamic Expansion

**Objective**: Upgrade Timer Logic from static expansion to evidence-conditioned expansion using signals 1-3 from the signal hierarchy (LTP at desired price, microprice position, standing quantity/direct ratio). This is Phase 2 of Timer Logic.

**Context This Chat Needs**:
```
Upload: timer-logic.md (full document, especially §6 signal framework)
Upload: case-distribution.md (20-case decision matrix)
Upload: WP-05 output (Phase 1 accuracy measurement data from SIM/production)
Upload: architecture-and-dataflow.md (where signals are computed)
Paste: WP-09 spec from this plan
```

**Prompt Skeleton**:
```
Role: .NET developer adding real-time signal processing to Timer Logic.
Task: Implement signals 1-3 (LTP at desired price, microprice position,
standing quantity ratio) in the VERSION_V9 engine. Use these signals
to dynamically set expansion per contract per pricing cycle.
Constraints: Must complete within 56ms quote throttle. Use fixed-size
circular buffers. Signal computation must be incremental (per-tick 
update, not full recompute). Must not regress Phase 1 performance.
Output: Modified .NET code + signal validation report.
Kill criterion: If dynamic expansion doesn't improve incremental fill
rate by >5% vs static expansion, keep static.
```

**Key Decisions**:
1. **Signal weighting**: Equal weight vs hierarchical (LTP dominates). Default: hierarchical per timer-logic.md §6.4.
2. **Expansion range**: [0, 0.25] vs [0, 0.4]. Default: cap at 0.25 initially (conservative, avoids crossed market risk).
3. **State detection**: Implement all 9 states or just the 4 core states? Default: 4 core states first, extend later.

**Risk**: High complexity. The interaction between dynamic expansion and existing rules is intricate (§9 of timer-logic.md). Mitigation: A/B testing with Phase 1 (static) on Set B.

**Done Criteria**:
- [ ] Signals 1-3 computed per tick with P99 latency <10ms
- [ ] Dynamic expansion value varies appropriately across market conditions
- [ ] Incremental fill rate ≥5% higher than static expansion
- [ ] No increase in crossed-market pauses vs Phase 1
- [ ] Accuracy measurement decomposition: rounding cost, staleness cost, execution cost all tracked

---

### WP-10: Lot Sizing Optimization

**Objective**: Build a fill-quality-based lot allocation model. Currently reload clips are static per contract. This WP models the relationship between lot size, fill accuracy, and market conditions to recommend dynamic lot sizing. More lots when conditions are clean, fewer when accuracy is degrading.

**Context This Chat Needs**:
```
Upload: WP-01 output (fill analysis with volume data)
Upload: WP-06 output (accuracy patterns, especially volume sensitivity curve)
Upload: order-management.md (current reload system)
Upload: case-distribution.md (clip size column in the 20-case matrix)
Paste: WP-10 spec from this plan
```

**Prompt Skeleton**:
```
Role: Quantitative portfolio manager optimizing position sizing.
Task: Model the relationship between order size and fill accuracy.
Build a lot sizing function: f(accuracy_rolling, volume, market_state)
→ recommended clip size. Backtest against historical data.
Constraints: Must integrate with existing ReloadMgr. Must degrade to
static sizing if inputs are unavailable. Conservative: never size UP
more than 2x current default.
Output: Lot sizing model + backtest report + .NET integration spec.
Kill criterion: If lot sizing doesn't improve risk-adjusted P&L by >5%.
```

**Key Decisions**:
1. **Sizing basis**: Accuracy-weighted (more lots when accurate) vs Kelly-criterion (size proportional to edge/variance). Default: accuracy-weighted (simpler, directly observable).
2. **Update frequency**: Per clip (check accuracy before each reload) vs per session (set lots at session start). Default: per session initially.

**Risk**: Moderate. If the model over-sizes during what appears to be a clean period that then deteriorates, losses compound. Mitigation: hard cap at 2x default, plus existing 100-lot fill threshold circuit breaker.

**Done Criteria**:
- [ ] Model predicts accuracy as a function of lot size + conditions
- [ ] Backtest shows improved risk-adjusted returns
- [ ] .NET integration spec produced
- [ ] Hard limits documented (min/max clip size)
- [ ] Degradation path clear (what happens if model inputs fail)

---

### WP-11: Regime Detection Research

**Objective**: Determine whether a simple regime model (range-bound vs trending) improves execution decisions. This is a research WP — it produces a decision document, not code. If the regime signal doesn't work, don't waste time implementing it.

**Context This Chat Needs**:
```
Upload: WP-01 output (fill data with timestamps)
Upload: portfolio_risk_directory/topics/risk_metrics.md (vol methods)
Upload: methodology-and-framework.md (structural patterns)
Upload: case-distribution.md (market states)
Paste: WP-11 spec from this plan
```

**Prompt Skeleton**:
```
Role: Quantitative researcher evaluating regime detection for STIR markets.
Task: Test 3 simple regime models against historical fill data:
(1) Rolling volatility threshold, (2) Hurst exponent, (3) Volume
profile clustering. For each: does knowing the regime BEFORE the
session improve accuracy prediction?
Constraints: Only use data you realistically have (fill data, intraday
bid-ask). No fantasy signals. Test out-of-sample.
Output: Decision document: which regime model (if any) to implement.
Null hypothesis: "Regime signal adds no predictive power over the
unconditional accuracy baseline."
Kill criterion: If no model achieves >60% regime classification accuracy
on out-of-sample data, abandon regime-based execution.
```

**Key Decisions**:
1. **Regime definition**: What constitutes "range-bound" vs "trending"? Resolve: define operationally using fill accuracy outcomes (high accuracy = range-bound regime for this system).
2. **Which model wins**: Decision based on simplicity × predictive power.

**Risk**: High probability of null result. Many regime detection approaches fail on real data. That's fine — the WP is designed to fail fast and cheaply (1-2 chats).

**Done Criteria**:
- [ ] 3 regime models tested with out-of-sample validation
- [ ] Classification accuracy reported for each
- [ ] Decision: PROCEED (to WP-14) or ABANDON with rationale
- [ ] If PROCEED: model spec and integration plan documented
- [ ] If ABANDON: document why and what alternative to pursue

---

### WP-12: Seasonality Calendar

**Objective**: Build the master list of time-sensitive trades across the SR3/SR1/ZQ complex. Entry timing rules, expected price behavior, calendar alerts. This is immediate trading alpha — you know these patterns exist but haven't systematized them.

**Context This Chat Needs**:
```
Upload: ancillary-strategies.md (roll spreads, Case spreads)
Upload: proposed-additions.md (seasonality section)
Upload: instruments-and-platform.md (expiry dates, contract specs)
Upload: core-quad-leg-arbitrage.md (quad-leg structure affected by rolls)
Paste: Your notes on known seasonality patterns (SR3|SR1 3Leg at rolls example)
Paste: WP-12 spec from this plan
```

**Prompt Skeleton**:
```
Role: STIR rates specialist building a seasonality trading calendar.
Task: Build a comprehensive calendar of time-sensitive trades for the
next 12 months. For each: event date, entry window, expected direction,
historical magnitude, interaction with the quad-leg strategy.
Constraints: Focus on trades driven by known mechanics (rolls, expiries,
FOMC schedule, quarter-end effects) not statistical patterns.
Output: (1) Master calendar (dates, events, trades). (2) Entry rules
per seasonality trade. (3) Alerts to set. (4) KB-format document.
```

**Key Decisions**:
1. **Scope**: SR3/SR1/ZQ only vs include Euribor/SONIA seasonality. Default: SR3/SR1/ZQ only (your active complex).
2. **Historical validation**: How far back to look for pattern confirmation? Default: 2-3 years of roll dates.

**Risk**: Very low. Worst case: calendar is incomplete and you add to it over time.

**Done Criteria**:
- [ ] Calendar covers all SR3 quarterly expiries for next 12 months
- [ ] Roll dynamics documented with expected price behavior
- [ ] FOMC dates mapped with strategy interaction
- [ ] Entry timing rules defined (how far before event to enter)
- [ ] KB-format document ready for strategy/ folder

---

### WP-13: Pricing Engine Prototype

**Objective**: Formalize the junction rules, interchange rules, and residue logic from the KB into a standalone pricing engine prototype. This is the formal specification of how fair value translates into leg prices, decoupled from the .NET implementation. Critical for: auditing the pricing pipeline, detecting bugs, and eventually adding quant model inputs.

**Context This Chat Needs**:
```
Upload: price-formulas-complete.md
Upload: execution-modifiers.md
Upload: residuals-and-convergence.md
Upload: WP-02 output (SOFR bootstrap)
Upload: WP-07 output (dynamic avoidance model, if available)
Paste: WP-13 spec from this plan
```

**Prompt Skeleton**:
```
Role: Quantitative developer building a reference pricing engine.
Task: Build a Python implementation of the complete pricing pipeline:
trader inputs → diff computation → 4-leg prices → avoidance/bias → 
Timer Logic rounding → output. Must match .NET output exactly.
Constraints: Pure Python, no external dependencies beyond numpy.
Must handle all edge cases (wide spreads, crossed markets, dynamic
avoidance windows). Must specify the interface where quant models
plug in later (vol model → avoidance, bootstrap → fair value).
Output: Python module + validation against 100 historical snapshots.
```

**Key Decisions**:
1. **Scope**: Full pipeline or just the mathematical core? Default: full pipeline including deduplication logic.
2. **Quant interface design**: How do external models feed in? Default: dependency injection pattern (pass in a FairValueProvider, VolProvider).

**Risk**: Moderate. Main risk is discovering a discrepancy between the KB documentation and the actual .NET code, which would indicate a KB documentation error. That's actually valuable to find.

**Done Criteria**:
- [ ] Python engine produces identical output to .NET for 100 historical snapshots
- [ ] All edge cases handled (wide spread, crossed market, dynamic avoidance)
- [ ] Quant model interface specified (where bootstrap, vol, regime signals plug in)
- [ ] Documentation: where the KB formulas don't match .NET behavior (if any)

---

### WP-14: Regime-Based Rule Activation

**Objective**: If WP-11 produced a viable regime model, implement conditional rule activation: different HitMan/ASM parameters (or enable/disable) based on detected regime. Only executed if WP-11 verdict is PROCEED.

**Context This Chat Needs**:
```
Upload: WP-11 output (regime detection decision doc + model spec)
Upload: WP-08 output (optimized parameters per profile)
Upload: custom-rules-production.md
Upload: ase-mechanics-and-parameters.md
Paste: WP-14 spec from this plan
```

**Prompt Skeleton**:
```
Role: .NET developer adding regime-conditional execution logic.
Task: Implement regime detection signal in VERSION_V9 and use it to
conditionally adjust ASE rule parameters. In range-bound regime: 
favor ASM (passive joining). In trending regime: favor HitMan 
(aggressive crossing) with tighter conditions.
Constraints: Must fall back to default parameters if regime signal
fails. Must not increase message traffic. A/B testable.
Output: .NET code + validation plan.
```

**Key Decisions**: Deferred to WP-11 output.

**Risk**: Entirely dependent on WP-11. If WP-11 said ABANDON, this WP is cancelled.

**Done Criteria**:
- [ ] Regime signal computed and logged per session
- [ ] Parameter switching implemented with fallback
- [ ] A/B test plan: regime-conditional vs static parameters
- [ ] SIM validation: 3 sessions

---

### WP-15: Quant KB Navigation System Prompt

**Objective**: Build the master system prompt that tells Claude how to use all directories (QuantLib, portfolio risk, STIR KB) together with live web search. This is the navigation layer that makes the entire knowledge infrastructure usable as a single coherent research tool.

**Context This Chat Needs**:
```
Upload: CLAUDE.md (STIR KB navigation manifest)
Upload: stir-kb-master-prompt.md (STIR KB system prompt)
Upload: quantlib_directory/MASTER_INDEX.md
Upload: portfolio_risk_directory/MASTER_INDEX.md
Paste: WP-15 spec from this plan
```

**Prompt Skeleton**:
```
Role: AI system architect designing a knowledge navigation layer.
Task: Write a single master system prompt for a Claude Project that
integrates: (1) the STIR trading KB, (2) the QuantLib code directory,
(3) the portfolio risk directory, and (4) live web search for papers
and current research. The prompt must route queries efficiently:
trading questions → STIR KB, implementation questions → code directories,
research questions → web search, and hybrid questions → combination.
Constraints: Must respect STIR KB's knowledge hierarchy (core/ overrides
everything). Must enforce the "pointers not content" principle for code
directories. Must stay under 4K tokens for the system prompt itself.
Output: Master system prompt (markdown file for Claude Project).
```

**Key Decisions**:
1. **Routing logic**: Keyword-based vs intent-based. Default: intent-based (more flexible).
2. **Code directory loading**: Always load MASTER_INDEX + route to topic, or load on demand? Default: load MASTER_INDEX only, route to topics on demand.

**Risk**: Low. Worst case: the prompt needs iteration over 2-3 chats to tune routing accuracy.

**Done Criteria**:
- [ ] System prompt routes 10 test queries correctly
- [ ] Trading questions stay grounded in STIR KB
- [ ] Code questions reach the right QuantLib/portfolio-risk topic
- [ ] System prompt under 4K tokens
- [ ] Tested in a fresh Claude Project with all directories uploaded

---

## What NOT To Do

1. **Don't build a tick-data backtesting framework.** You correctly identified this as 3+ months out. SIM testing is better for your use case. Tick data backtesting is a massive infrastructure project that delays everything else.

2. **Don't implement dynamic ASE rule parameter modulation via TT SDK (Timer Logic Phase 3 / Open Item O5).** Dynamically changing ASE rule parameters from .NET introduces coupling between systems that is fragile and hard to debug in live markets. Get Phase 1 and 2 working first. Revisit in 6 months.

3. **Don't build a real-time live stats dashboard yet (Goal 7).** This is useful but not edge-generating. It's a time sink that competes with accuracy-improving work. Build it after Month 3 when the analysis pipeline is stable.

4. **Don't try to implement all 9 Timer Logic execution states at once.** States 5-9 (sweep aftershock, book imbalance cascade, iceberg detection, stale book, implied alignment) require signals 4-7 which have higher latency and complexity. Ship with states 1-4, validate, then extend.

5. **Don't research PCA (Goal 8 t8-5) until you have a clear use case.** PCA on rate futures is academically interesting but the connection to your execution parameters is unclear. Defer until regime detection (WP-11) identifies a specific need for dimensionality reduction.

6. **Don't build the cross-LLM orchestrator (Goal 10 t10-5).** Marginal value vs direct Claude usage. The $800 is better spent on focused single-model chats with specific deliverables.

7. **Don't try to optimize Euribor/SONIA/Canada strategies in Month 1-2.** Your core edge is in the SR3|SR1|ZQ complex. Get that optimized first. International strategies are lower-volume, less familiar, and the same effort applied to your core complex generates more P&L.

8. **Don't merge the 9 staging proposals until you've completed WP-03 and WP-06.** The staging items were generated from a brain dump and haven't been validated against data. Complete the analysis WPs first, then merge staging items that are still relevant.

---

## Dependency Graph

```
FOUNDATION (Month 1, Week 1-2)
  WP-01 (Fill Pipeline) ─────────────→ WP-06 (Accuracy Patterns)
  WP-02 (SOFR Bootstrap) ────────────→ WP-07 (Dynamic Avoidance)
  WP-03 (Market Profiling) ──────────→ WP-08 (Param Optimization)
  WP-04 (Timer Logic Verify) ────────→ WP-05 (Timer Logic .NET)
  WP-12 (Seasonality) ───────────────→ [immediate value, no deps]
  WP-15 (Navigation Prompt) ─────────→ [enables efficient research]

INTELLIGENCE (Month 2)
  WP-06 (Accuracy Patterns) ─────────→ WP-08 (Param Optimization)
                           ╲──────────→ WP-10 (Lot Sizing)
  WP-07 (Dynamic Avoidance) ─────────→ WP-13 (Pricing Engine)
  WP-05 (Timer Logic .NET) ──────────→ WP-09 (Dynamic Expansion)
  WP-11 (Regime Research) ───────────→ WP-14 (Regime Rules) [if passes]

OPTIMIZATION (Month 3)
  WP-08 + WP-09 ─────────────────────→ Production tuning cycle
  WP-10 (Lot Sizing) ────────────────→ .NET integration
  WP-13 (Pricing Engine) ────────────→ Reference implementation
  WP-14 (Regime Rules) ──────────────→ SIM validation [if WP-11 passed]
```

---

## Month-by-Month Calendar

### Month 1: Measure and Model

| Week | Primary Chat | Secondary Chat | Notes |
|------|-------------|----------------|-------|
| W1 | **WP-01** Fill Analysis Pipeline | **WP-03** Market Profiling | Quick wins, no dependencies |
| W1 | **WP-12** Seasonality Calendar | **WP-02** SOFR Bootstrap (start) | WP-12 is a single chat |
| W2 | **WP-02** SOFR Bootstrap (complete) | **WP-04** Timer Logic Verification | WP-04 unblocks the critical path |
| W2 | **WP-15** Navigation Prompt | — | Single chat, enables future research |
| W3 | **WP-05** Timer Logic .NET (start) | Review WP-01 output, start collecting 30-day data | WP-05 is 2-3 chats |
| W4 | **WP-05** Timer Logic .NET (SIM testing) | Accumulate fill data for WP-06 | Monitor SIM results daily |

### Month 2: Deploy Intelligence

| Week | Primary Chat | Secondary Chat | Notes |
|------|-------------|----------------|-------|
| W1 | **WP-06** Fill Accuracy Patterns | **WP-05** Timer Logic → production (if SIM passes) | WP-06 needs 30 days of data |
| W2 | **WP-07** Dynamic Avoidance Model | **WP-11** Regime Detection Research | Both are research; can parallel |
| W3 | **WP-08** Parameter Optimization | **WP-09** Dynamic Expansion (start) | WP-08 feeds into WP-09 context |
| W4 | **WP-09** Dynamic Expansion (SIM + deploy) | Accumulate data for Month 3 | Monitor accuracy decomposition |

### Month 3: Expand and Optimize

| Week | Primary Chat | Secondary Chat | Notes |
|------|-------------|----------------|-------|
| W1 | **WP-10** Lot Sizing Optimization | Review all Month 2 results | Data-rich by now |
| W2 | **WP-13** Pricing Engine Prototype | **WP-14** Regime Rules (if WP-11 passed) | WP-13 is 2-3 chats |
| W3 | **WP-13** Pricing Engine (validation) | WP-14 SIM testing | |
| W4 | Integration review, plan Month 4 | Document lessons learned | Full system audit |

## Related

### Within Jarvis
- [[plan/wp-status]] — Current completion status tracking this plan

### Knowledge Base
<!-- No direct KB dependencies — this is a meta-planning document -->
