---
title: Fill Analysis Pipeline — README
wp: WP-01
status: complete
created: 2026-03-14
last-updated: 2026-03-31
lines: 82
kb-depends:
  - knowledge-base/execution-analysis/methodology-and-framework.md
  - knowledge-base/core/instruments-and-platform.md
jarvis-depends:
  - jarvis/market-profiling/contract-segmentation.md
---

# Fill Execution Analysis Pipeline

## Usage

```bash
# All days in data directory
python fill_analysis.py --data-dir ./data

# Date range filter
python fill_analysis.py --data-dir ./data --start 2026-03-05 --end 2026-03-19

# Custom output directory
python fill_analysis.py --data-dir ./data --output-dir ./output
```

No external dependencies — uses only Python standard library.

## Output Files

| File | Contents | Downstream Use |
|------|----------|----------------|
| `fill_detail.csv` | Per-fill TD, classification, alias metadata | Atomic data for any re-aggregation |
| `alias_summary.csv` | Per-alias buy/sell accuracy, lots, avg prices | Alias-level performance tracking |
| `matched_pnl.csv` | Matched P&L at $75/$100/$125 DPP | P&L attribution |
| `expiry_summary.csv` | Per-expiry-group aggregated accuracy | Expiry exposure decisions |
| `ase_type_summary.csv` | SR3\|SR1 vs SR3\|ZQ by side | Instrument-level patterns |
| `volume_accuracy.csv` | Buy vs sell accuracy by daily volume bucket | Volume sensitivity analysis |
| `degradation_ranking.csv` | Aliases ranked by accuracy degradation | Watchlist for deteriorating aliases |
| `pattern_evaluation.csv` | 8 structural patterns: status + detail | Structural risk monitoring |
| `analysis_summary.json` | Master JSON combining all of the above | Programmatic consumption |

## Assumptions — PATCH WHEN REAL DATA ARRIVES

### JSON Schema (lines 28-38 of fill_analysis.py)

```python
FIELD_MAP = {
    "timestamp":   "Timestamp",      # ISO datetime string
    "alias":       "Alias",          # e.g. "SR3|SR1 Mar Apr26"
    "side":        "Side",           # "Buy" or "Sell"
    "qty":         "Qty",            # int, lot count
    "entry_price": "EntryPrice",     # float, trader's intended price
    "match_price": "MatchPrice",     # float, actual fill price
    "rule_type":   None,             # ← SET THIS to enable per-rule summary
    "set_id":      None,             # ← "A"/"B" if present
    "leg_number":  None,             # ← 1-4 if explicitly provided
}
```

### Alias Format

Expected: `"SR3|SR1 Mar Apr26"`, `"SR3|ZQ Sep Oct26"`, `"SR3|SR1 Jun26 X"`

If your aliases use different delimiters, abbreviations, or structures, patch `parse_alias()` (~line 75).

### Open Items

1. **`RuleType` field**: Per-ASE-rule summary (HitMan, ASM, Backoff, WCT) is stubbed but disabled. Set `FIELD_MAP["rule_type"]` to the actual field name to activate.

2. **Volume buckets**: Current thresholds (0-200, 200-500, 500-1000, 1000+) are based on expected lot counts. Adjust `VOLUME_BUCKETS` if your daily volumes are significantly different.

3. **DPP for X/Y fills**: X/Y ASE fills use unknown DPP — reported in spread price units only. If you determine a DPP for these, add handling in `compute_matched_pnl()`.

4. **Pattern thresholds**: Pattern evaluation uses hardcoded thresholds (e.g., Dec26 >= 65% for "cleanest", Sep26 <= 55% for "worst"). These are based on the methodology doc's historical observations. Tune after running against real data.

## Files Included

- `fill_analysis.py` — Main pipeline (single-file, no dependencies)
- `requirements.txt` — Empty; stdlib only
- `generate_test_data.py` — Synthetic data generator (for testing/validation)
- `output/` — Sample output from synthetic data run

## Related

### Within Jarvis
- [[market-profiling/contract-segmentation]] — Contract groups used to aggregate accuracy results
- [[timer-logic/verification-report]] — Formula corrections that may explain accuracy patterns

### Knowledge Base
- [[knowledge-base/execution-analysis/methodology-and-framework]] — Methodology this pipeline implements
- [[knowledge-base/core/instruments-and-platform]] — Contract specs for tick-size interpretation
