"""
Generate realistic synthetic fill data for pipeline testing.
Encodes known patterns from methodology doc so we can verify detection.
"""
import json
import random
import os
from datetime import datetime, timedelta

random.seed(42)

EXPIRY_GROUPS = {
    "Mar26": {"sr3": "Mar", "near": "Apr26", "far": "May26"},
    "Jun26": {"sr3": "Jun", "near": "Jul26", "far": "Aug26"},
    "Sep26": {"sr3": "Sep", "near": "Oct26", "far": "Nov26"},
    "Dec26": {"sr3": "Dec", "near": "Jan26", "far": "Feb26"},  # note: Jan27/Feb27 in prod, simplified here
}

ASE_TYPES = ["SR3|SR1", "SR3|ZQ"]
SIDES = ["Buy", "Sell"]

# Pattern encoding:
# - Dec26: cleanest fills (low TD)
# - Sep26: worst fills (high TD)
# - Buy-side degrades at high volume
# - SR3|ZQ sell-side structurally worse
# - X/Y fills show extreme payup on Jun26/Sep26

def make_alias(ase_type, sr3_month, sub_month, suffix=""):
    """e.g. SR3|SR1 Mar Apr26, SR3|ZQ Sep Oct26, SR3|SR1 Jun26 X"""
    if suffix:
        return f"{ase_type} {sr3_month}26 {suffix}"
    return f"{ase_type} {sr3_month} {sub_month}"


def gen_td(expiry, ase_type, side, is_xy=False, day_volume_level="normal"):
    """Generate a tick deviation reflecting structural patterns."""
    base_td = 0.0

    # Pattern 1: Dec26 cleanest
    if expiry == "Dec26":
        base_td = random.choices([0, 1, 2], weights=[0.65, 0.25, 0.10])[0]
    # Pattern 2: Sep26 worst
    elif expiry == "Sep26":
        base_td = random.choices([0, 1, 2, 3, 4], weights=[0.30, 0.25, 0.20, 0.15, 0.10])[0]
    else:
        base_td = random.choices([0, 1, 2, 3], weights=[0.50, 0.30, 0.15, 0.05])[0]

    # Pattern 4: SR3|ZQ sell-side structural payup
    if ase_type == "SR3|ZQ" and side == "Sell":
        base_td += random.choices([0, 1, 2], weights=[0.50, 0.35, 0.15])[0]

    # Pattern 3: Buy-side degrades at volume
    if side == "Buy" and day_volume_level == "high":
        base_td += random.choices([0, 1, 2], weights=[0.40, 0.35, 0.25])[0]

    # Pattern 5: X/Y extreme payup
    if is_xy and expiry in ("Jun26", "Sep26"):
        base_td += random.choices([2, 3, 4, 5], weights=[0.30, 0.30, 0.25, 0.15])[0]

    # Rare backoff
    if random.random() < 0.05 and not is_xy:
        base_td = -1

    return base_td


def generate_day(date, volume_level="normal"):
    records = []
    base_time = datetime.combine(date, datetime.min.time().replace(hour=8, minute=30))

    for exp_name, exp_info in EXPIRY_GROUPS.items():
        sr3_month = exp_info["sr3"]
        for ase_type in ASE_TYPES:
            for sub_key in ["near", "far"]:
                sub_month = exp_info[sub_key]
                alias = make_alias(ase_type, sr3_month, sub_month)

                # Volume varies by expiry and day
                if volume_level == "high":
                    n_fills = random.randint(15, 40)
                elif volume_level == "low":
                    n_fills = random.randint(3, 10)
                else:
                    n_fills = random.randint(8, 20)

                for _ in range(n_fills):
                    side = random.choice(SIDES)
                    qty = random.choice([3, 6, 6, 6])  # mostly 6-lot clips
                    entry_price = round(random.uniform(3.0, 8.0) * 2) / 2  # snap to 0.5 grid
                    td = gen_td(exp_name, ase_type, side, is_xy=False, day_volume_level=volume_level)
                    if side == "Buy":
                        match_price = entry_price + td * 0.5
                    else:
                        match_price = entry_price - td * 0.5

                    ts = base_time + timedelta(seconds=random.randint(0, 23400))  # 6.5 hour window
                    records.append({
                        "Timestamp": ts.isoformat(),
                        "Alias": alias,
                        "Side": side,
                        "Qty": qty,
                        "EntryPrice": round(entry_price, 4),
                        "MatchPrice": round(match_price, 4),
                    })

        # X/Y fills (fewer)
        for suffix in ["X", "Y"]:
            alias = make_alias("SR3|SR1", sr3_month, "", suffix)
            n_fills = random.randint(2, 6)
            for _ in range(n_fills):
                side = random.choice(SIDES)
                qty = random.choice([6, 6, 12])
                entry_price = round(random.uniform(3.0, 8.0) * 2) / 2
                td = gen_td(exp_name, "SR3|SR1", side, is_xy=True, day_volume_level=volume_level)
                if side == "Buy":
                    match_price = entry_price + td * 0.5
                else:
                    match_price = entry_price - td * 0.5

                ts = base_time + timedelta(seconds=random.randint(0, 23400))
                records.append({
                    "Timestamp": ts.isoformat(),
                    "Alias": alias,
                    "Side": side,
                    "Qty": qty,
                    "EntryPrice": round(entry_price, 4),
                    "MatchPrice": round(match_price, 4),
                })

    return records


def main():
    out_dir = "/home/claude/fill_analysis/data"
    # Generate 10 days of data: Mar 5-19 2026 (weekdays)
    start = datetime(2026, 3, 5)
    days_generated = 0
    volume_schedule = ["normal", "normal", "high", "normal", "low",
                       "normal", "high", "normal", "normal", "normal"]

    current = start
    while days_generated < 10:
        if current.weekday() < 5:  # weekdays only
            vol = volume_schedule[days_generated]
            records = generate_day(current.date(), vol)
            fname = f"{current.strftime('%Y-%m-%d')}_cleaned.json"
            path = os.path.join(out_dir, fname)
            with open(path, 'w') as f:
                json.dump(records, f, indent=2)
            print(f"Generated {fname}: {len(records)} records ({vol} volume)")
            days_generated += 1
        current += timedelta(days=1)


if __name__ == "__main__":
    main()
