---
title: Fill Analysis — Map of Content
wp: WP-01
status: complete
last-updated: 2026-03-31
lines: 39
---

# Fill Analysis — Map of Content

WP-01 output: production fill accuracy analysis across 3,225 fills
(Mar 1–13, 2026). Python pipeline reads TT fill exports, computes
tick-deviation accuracy, and generates per-alias/expiry breakdowns,
degradation rankings, matched P&L, and pattern evaluations.
Grand accuracy: 56.32% combined (buy 56.16%, sell 56.44%).
(~121 lines of markdown + ~1,011 lines of Python)

## Files

- [[fill-analysis/README]] — Pipeline usage instructions, output file schemas (9 CSV/JSON outputs), real-data patch points (rule_type, volume buckets, DPP), and assumptions for JSON field mapping. (~82 lines)

## Non-Markdown Assets

- `analysis_summary.json` — Grand accuracy metrics (56.32% combined), per-expiry breakdowns with Zero/Payup/Backoff classification. Primary results file. (~441 lines)
- `alias_summary.csv` — Per-alias aggregate accuracy (68 data rows × 21 cols): alias, ase_type, expiry_group, buy/sell splits, combined_accuracy, classification.
- `expiry_summary.csv` — Expiry group summaries (5 data rows + header): Mar26/Jun26/Sep26/Dec26/Other with lots, fills, buy/sell accuracy.
- `degradation_ranking.csv` — Aliases ranked by accuracy degradation over time (45 rows): first_accuracy, last_accuracy, total_delta.
- `matched_pnl.csv` — Matched-leg P&L analysis (32 rows): avg_buy, avg_sell, spread, pnl_conservative/midpoint/aggressive.
- `pattern_evaluation.csv` — 9 structural pattern validations: Dec26 cleanest, Sep26 worst, buy degradation, SR3|ZQ payup, X/Y extreme payup.
- `fill_detail.csv` — Granular fill-level records (3,225 data rows × 16 cols): individual fills with date, timestamp, alias, ase_type, expiry_group, side, qty, entry/match price, tick deviation, classification, validation.
- `fill_analysis.py` — ETL pipeline: raw TT fills → cleaned CSV → accuracy calculations, degradation ranking, matched P&L. (~854 lines)
- `generate_test_data.py` — Synthetic fill generator with encoded known patterns for pipeline verification. (~157 lines)

## KB Dependencies

- [[knowledge-base/execution-analysis/methodology-and-framework]] — Tick Deviation formula, weighted fill accuracy, and 8-step analysis framework this pipeline implements
- [[knowledge-base/core/instruments-and-platform]] — Contract specs (tick sizes, DV01) for interpreting accuracy in dollar terms
- [[knowledge-base/strategy/core-quad-leg-arbitrage]] — Quad-leg structure defining which aliases exist and how legs interact
- [[knowledge-base/strategy/execution-modifiers]] — Avoidance/bias parameters that drive fill quality patterns

## Related Folders

- [[market-profiling/_index|Market Profiling]] — Contract segmentation groups used to aggregate accuracy results
- [[timer-logic/_index|Timer Logic]] — Formula corrections that may explain accuracy patterns in certain expiries
- [[fair-value/_index|Fair Value]] — Valuation engine that aims to improve on current accuracy baseline
- [[plan/_index|Plan]] — WP status tracking for this and dependent work packages
