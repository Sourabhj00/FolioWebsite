#!/usr/bin/env python3
"""
Fill Execution Analysis Pipeline — Production Version
======================================================
Implements methodology-and-framework.md against real fill data.

Data format: line-delimited [HH:MM:SS] {json} per file (YYYY-MM-DD.json)

Usage:
    python fill_analysis.py --data-dir ./data
    python fill_analysis.py --data-dir ./data --start 2026-03-01 --end 2026-03-13
    python fill_analysis.py --data-dir ./data --output-dir ./output
"""

import argparse
import csv
import glob
import json
import math
import os
import re
import sys
from collections import defaultdict
from datetime import datetime, date
from typing import Any

# =============================================================================
# SCHEMA CONFIG
# =============================================================================

FIELD_MAP = {
    "timestamp":    "Timestamp",
    "alias":        "Alias",
    "side":         "Side",
    "qty":          "FilledQty",
    "entry_price":  "EntryPrice",
    "match_price":  "MatchPrice",
    "result_type":       "ResultType",
    "tick_difference":   "TickDifference",
    "accuracy_pct":      "AccuracyPercentage",
}

FILE_DATE_RE = re.compile(r"(\d{4}-\d{2}-\d{2})\.json$")
TICK_SIZE = 0.5

DPP_SCENARIOS = {
    "conservative": 75.0,
    "midpoint":     100.0,
    "aggressive":   125.0,
}

VOLUME_BUCKETS = [
    (0,    100,  "Light (0-100)"),
    (100,  300,  "Medium (100-300)"),
    (300,  600,  "Heavy (300-600)"),
    (600,  9999, "Very Heavy (600+)"),
]

# =============================================================================
# ALIAS PARSING
# =============================================================================

_SET_SUFFIX_RE = re.compile(r'\s*-\s*([AB])\s*$')
_CORE_LEG_RE = re.compile(
    r'^(SR3\|(?:SR1|ZQ|FF))\s+'
    r'([A-Z][a-z]{2})\s+'
    r'([A-Z][a-z]{2}\d{2,3})'
    r'(?:\s*-\s*([AB]))?$'
)
_XYO_RE = re.compile(
    r'^(SR3\|(?:SR1|ZQ|FF))\s+'
    r'([A-Za-z]{3}\d{2})\s+'
    r'([XYO])$'
)
_QUARTERLY_CAL_RE = re.compile(
    r'^(SR3\|ZQ)\s+'
    r'([A-Z][a-z]{2}\d{2})-([A-Z][a-z]{2}\d{2})'
    r'(?:\s+([AB]))?$'
)

_QUARTER_MAP = {"Mar": "Mar26", "Jun": "Jun26", "Sep": "Sep26", "Dec": "Dec26"}


def normalize_ase_type(raw):
    return raw.replace("SR3|FF", "SR3|ZQ")


def parse_alias(alias):
    result = {
        "raw_alias": alias, "alias_clean": alias, "ase_type": "Other",
        "expiry_group": "Other", "sub_month": None, "suffix": None,
        "set_id": None, "is_xy": False, "is_core_leg": False,
        "is_ancillary": False, "category": "ancillary",
    }
    working = alias.strip()
    set_match = _SET_SUFFIX_RE.search(working)
    if set_match:
        result["set_id"] = set_match.group(1)
        working = working[:set_match.start()].strip()
    result["alias_clean"] = working

    m = _CORE_LEG_RE.match(alias.strip())
    if m:
        raw_type, sr3_month, sub_month, set_id = m.group(1), m.group(2), m.group(3), m.group(4)
        result.update({
            "ase_type": normalize_ase_type(raw_type),
            "expiry_group": _QUARTER_MAP.get(sr3_month, sr3_month + "26"),
            "sub_month": sub_month, "set_id": set_id,
            "is_core_leg": True, "category": "core",
            "alias_clean": f"{normalize_ase_type(raw_type)} {sr3_month} {sub_month}",
        })
        return result

    m = _XYO_RE.match(working)
    if m:
        raw_type, expiry, suffix = m.group(1), m.group(2), m.group(3)
        result.update({
            "ase_type": normalize_ase_type(raw_type),
            "expiry_group": expiry, "suffix": suffix,
            "is_xy": suffix in ("X", "Y"), "category": "xyo",
            "alias_clean": f"{normalize_ase_type(raw_type)} {expiry} {suffix}",
        })
        return result

    m = _QUARTERLY_CAL_RE.match(alias.strip())
    if m:
        result.update({
            "ase_type": "SR3|ZQ", "expiry_group": m.group(2),
            "category": "quarterly_cal",
            "alias_clean": f"SR3|ZQ {m.group(2)}-{m.group(3)}",
        })
        if m.group(4):
            result["set_id"] = m.group(4)
        return result

    result["is_ancillary"] = True
    lower = working.lower()
    if lower.startswith("case"):
        result["ase_type"] = "Case"
    elif lower.startswith("sr1 ff") or lower.startswith("sr1-ff"):
        result["ase_type"] = "SR1-FF"
    elif lower.startswith("zq str") or lower.startswith("zq str"):
        result["ase_type"] = "ZQ Str"
    elif "cra" in lower:
        result["ase_type"] = "CRA"
    elif lower.startswith("sr3"):
        result["ase_type"] = "SR3 Str"
    else:
        result["ase_type"] = "Other"
    return result


# =============================================================================
# DATA LOADING
# =============================================================================

def parse_line(line):
    line = line.strip()
    if not line:
        return None
    m = re.match(r'^\[[\d:]+\]\s*', line)
    if m:
        line = line[m.end():]
    line = line.strip()
    if not line.startswith('{'):
        return None
    try:
        return json.loads(line)
    except json.JSONDecodeError:
        return None


def load_fill_file(path):
    warnings = []
    fname = os.path.basename(path)
    m = FILE_DATE_RE.search(fname)
    if not m:
        return [], [f"{fname}: Cannot parse date"]
    file_date = datetime.strptime(m.group(1), "%Y-%m-%d").date()

    try:
        with open(path, 'r', encoding='utf-8-sig') as f:
            lines = f.readlines()
    except Exception as e:
        return [], [f"{fname}: {e}"]

    records = []
    FM = FIELD_MAP
    for i, line in enumerate(lines):
        raw = parse_line(line)
        if raw is None:
            if line.strip():
                warnings.append(f"{fname}[{i}]: Unparseable")
            continue

        missing = [FM[k] for k in ("alias","side","qty","entry_price","match_price")
                   if FM[k] not in raw]
        if missing:
            warnings.append(f"{fname}[{i}]: Missing {missing}")
            continue

        try:
            alias_raw = str(raw[FM["alias"]])
            side = str(raw[FM["side"]])
            qty = int(raw[FM["qty"]])
            entry = float(raw[FM["entry_price"]])
            match = float(raw[FM["match_price"]])
        except (ValueError, TypeError) as e:
            warnings.append(f"{fname}[{i}]: {e}")
            continue

        if side not in ("Buy", "Sell") or qty <= 0:
            warnings.append(f"{fname}[{i}]: Invalid side={side} qty={qty}")
            continue

        ts_raw = raw.get(FM["timestamp"], "")
        try:
            ts = datetime.fromisoformat(str(ts_raw).rstrip('Z'))
        except (ValueError, TypeError):
            ts = None

        info = parse_alias(alias_raw)
        records.append({
            "timestamp": ts, "file_date": file_date,
            "alias_raw": alias_raw, "alias": info["alias_clean"],
            "side": side, "qty": qty,
            "entry_price": entry, "match_price": match,
            "ase_type": info["ase_type"], "expiry_group": info["expiry_group"],
            "sub_month": info["sub_month"], "suffix": info["suffix"],
            "set_id": info["set_id"], "is_xy": info["is_xy"],
            "is_core_leg": info["is_core_leg"], "is_ancillary": info["is_ancillary"],
            "category": info["category"],
            "result_type_precomp": raw.get(FM["result_type"]),
            "tick_diff_precomp": raw.get(FM["tick_difference"]),
            "acc_pct_precomp": raw.get(FM["accuracy_pct"]),
        })
    return records, warnings


def load_date_range(data_dir, start_date=None, end_date=None):
    files = sorted(glob.glob(os.path.join(data_dir, "*.json")))
    if not files:
        print(f"ERROR: No JSON files in {data_dir}")
        sys.exit(1)
    all_recs, all_warns = [], []
    for fp in files:
        m = FILE_DATE_RE.search(os.path.basename(fp))
        if not m:
            continue
        fd = datetime.strptime(m.group(1), "%Y-%m-%d").date()
        if start_date and fd < start_date:
            continue
        if end_date and fd > end_date:
            continue
        recs, warns = load_fill_file(fp)
        all_recs.extend(recs)
        all_warns.extend(warns)
        print(f"  Loaded {os.path.basename(fp)}: {len(recs)} fills")
    return all_recs, all_warns


# =============================================================================
# TICK DEVIATION
# =============================================================================

def compute_td(rec):
    if rec["side"] == "Buy":
        td = (rec["match_price"] - rec["entry_price"]) / TICK_SIZE
    else:
        td = (rec["entry_price"] - rec["match_price"]) / TICK_SIZE
    rec["td"] = round(td, 6)
    rec["td_class"] = "Zero" if abs(td) < 1e-9 else ("Payup" if td > 0 else "Backoff")
    # Cross-validate
    pre = rec.get("tick_diff_precomp")
    if pre is not None:
        try:
            rec["td_validation"] = "OK" if abs(float(pre) - abs(td)) < 0.01 else "MISMATCH"
        except:
            rec["td_validation"] = "SKIP"
    else:
        rec["td_validation"] = "NO_PRECOMP"
    return rec


# =============================================================================
# AGGREGATION
# =============================================================================

def weighted_accuracy(records):
    s = sum(r["td"] * r["qty"] for r in records)
    q = sum(r["qty"] for r in records)
    return (1.0 - s / q) * 100.0 if q else float('nan')

def avg_wp(records, f="match_price"):
    t = sum(r[f] * r["qty"] for r in records)
    q = sum(r["qty"] for r in records)
    return t / q if q else float('nan')

def lot_count(records):
    return sum(r["qty"] for r in records)

def class_counts(records):
    c = {"Zero": 0, "Payup": 0, "Backoff": 0}
    for r in records:
        c[r["td_class"]] += r["qty"]
    return c


def compute_alias_summary(records):
    by = defaultdict(list)
    for r in records:
        by[r["alias"]].append(r)
    out = []
    for a in sorted(by):
        recs = by[a]
        buys = [r for r in recs if r["side"] == "Buy"]
        sells = [r for r in recs if r["side"] == "Sell"]
        out.append({
            "alias": a, "ase_type": recs[0]["ase_type"],
            "expiry_group": recs[0]["expiry_group"],
            "category": recs[0]["category"], "is_xy": recs[0]["is_xy"],
            "total_lots": lot_count(recs), "total_fills": len(recs),
            "buy_lots": lot_count(buys), "buy_fills": len(buys),
            "buy_accuracy": weighted_accuracy(buys) if buys else None,
            "buy_avg_match": round(avg_wp(buys), 4) if buys else None,
            "buy_avg_entry": round(avg_wp(buys, "entry_price"), 4) if buys else None,
            "sell_lots": lot_count(sells), "sell_fills": len(sells),
            "sell_accuracy": weighted_accuracy(sells) if sells else None,
            "sell_avg_match": round(avg_wp(sells), 4) if sells else None,
            "sell_avg_entry": round(avg_wp(sells, "entry_price"), 4) if sells else None,
            "combined_accuracy": weighted_accuracy(recs),
            "classification": class_counts(recs),
        })
    return out


def compute_matched_pnl(records):
    by = defaultdict(list)
    for r in records:
        by[r["alias"]].append(r)
    rows = []
    for a in sorted(by):
        recs = by[a]
        buys = [r for r in recs if r["side"] == "Buy"]
        sells = [r for r in recs if r["side"] == "Sell"]
        bl, sl = lot_count(buys), lot_count(sells)
        mq = min(bl, sl)
        if mq == 0:
            continue
        ab, asl = avg_wp(buys), avg_wp(sells)
        sp = asl - ab
        is_xy = recs[0]["is_xy"]
        is_anc = recs[0]["is_ancillary"]
        row = {"alias": a, "ase_type": recs[0]["ase_type"],
               "expiry_group": recs[0]["expiry_group"],
               "category": recs[0]["category"], "is_xy": is_xy,
               "buy_lots": bl, "sell_lots": sl, "matched_qty": mq,
               "avg_buy": round(ab, 4), "avg_sell": round(asl, 4),
               "spread": round(sp, 4),
               "pnl_spread_units": round(sp * mq, 4)}
        if is_xy or is_anc:
            for s in DPP_SCENARIOS:
                row[f"pnl_{s}"] = None
        else:
            for s, dpp in DPP_SCENARIOS.items():
                row[f"pnl_{s}"] = round(sp * mq * dpp, 2)
        rows.append(row)
    rows.sort(key=lambda r: -(r.get("pnl_midpoint") or -999999))
    return rows


def compute_expiry_summary(records):
    by = defaultdict(list)
    for r in records:
        by[r["expiry_group"]].append(r)
    out = []
    for g in sorted(by):
        recs = by[g]
        buys = [r for r in recs if r["side"] == "Buy"]
        sells = [r for r in recs if r["side"] == "Sell"]
        out.append({
            "expiry_group": g, "total_lots": lot_count(recs),
            "total_fills": len(recs),
            "buy_lots": lot_count(buys),
            "buy_accuracy": weighted_accuracy(buys) if buys else None,
            "sell_lots": lot_count(sells),
            "sell_accuracy": weighted_accuracy(sells) if sells else None,
            "combined_accuracy": weighted_accuracy(recs),
            "classification": class_counts(recs),
        })
    return out


def compute_ase_type_summary(records):
    by = defaultdict(list)
    for r in records:
        by[(r["ase_type"], r["side"])].append(r)
    out = []
    for (t, s) in sorted(by):
        recs = by[(t, s)]
        out.append({"ase_type": t, "side": s, "total_lots": lot_count(recs),
                     "total_fills": len(recs), "accuracy": weighted_accuracy(recs),
                     "classification": class_counts(recs)})
    return out


def compute_category_summary(records):
    by = defaultdict(list)
    for r in records:
        by[r["category"]].append(r)
    out = []
    for c in sorted(by):
        recs = by[c]
        buys = [r for r in recs if r["side"] == "Buy"]
        sells = [r for r in recs if r["side"] == "Sell"]
        out.append({
            "category": c, "total_lots": lot_count(recs), "total_fills": len(recs),
            "buy_accuracy": weighted_accuracy(buys) if buys else None,
            "sell_accuracy": weighted_accuracy(sells) if sells else None,
            "combined_accuracy": weighted_accuracy(recs),
        })
    return out


def compute_dod(records):
    by = defaultdict(lambda: defaultdict(list))
    for r in records:
        by[r["alias"]][r["file_date"]].append(r)
    out = {}
    for a in sorted(by):
        dates = sorted(by[a])
        daily = []
        for d in dates:
            recs = by[a][d]
            daily.append({"date": d, "accuracy": weighted_accuracy(recs), "lots": lot_count(recs)})
        for i in range(len(daily)):
            if i == 0:
                daily[i].update({"accuracy_delta": None, "lots_delta": None})
            else:
                p, c = daily[i-1], daily[i]
                c["accuracy_delta"] = (c["accuracy"] - p["accuracy"]
                                       if None not in (c["accuracy"], p["accuracy"]) else None)
                c["lots_delta"] = c["lots"] - p["lots"]
        out[a] = daily
    return out


def find_degraded(dod, min_days=2):
    out = []
    for a, daily in dod.items():
        if len(daily) < min_days:
            continue
        f, l = daily[0]["accuracy"], daily[-1]["accuracy"]
        if f is not None and l is not None:
            out.append({"alias": a, "first_accuracy": round(f, 1),
                        "last_accuracy": round(l, 1),
                        "total_delta": round(l - f, 1), "days_active": len(daily)})
    out.sort(key=lambda x: x["total_delta"])
    return out


def compute_vol_bucketed(records):
    by_date = defaultdict(list)
    for r in records:
        by_date[r["file_date"]].append(r)
    out = []
    for lo, hi, label in VOLUME_BUCKETS:
        bb, bs = [], []
        days = 0
        for d, recs in by_date.items():
            dl = lot_count(recs)
            if lo <= dl < hi:
                days += 1
                bb.extend(r for r in recs if r["side"] == "Buy")
                bs.extend(r for r in recs if r["side"] == "Sell")
        if not days:
            continue
        out.append({"volume_bucket": label, "days": days,
                     "buy_lots": lot_count(bb),
                     "buy_accuracy": weighted_accuracy(bb) if bb else None,
                     "sell_lots": lot_count(bs),
                     "sell_accuracy": weighted_accuracy(bs) if bs else None})
    return out


# =============================================================================
# PATTERN EVALUATION
# =============================================================================

def evaluate_patterns(records, alias_sum, pnl_rows, expiry_sum, vol_bkts):
    findings = []
    core = [r for r in records if r["category"] == "core"]
    em = {e["expiry_group"]: e for e in compute_expiry_summary(core)}

    # P1: Dec26 cleanest
    dec = em.get("Dec26")
    if dec and dec["combined_accuracy"] is not None:
        a = dec["combined_accuracy"]
        findings.append({"pattern": 1, "name": "Dec26 — Historically Cleanest",
            "status": "CONFIRMED" if a >= 60 else "WEAKENED" if a >= 45 else "NOT CONFIRMED",
            "detail": f"Dec26 combined: {a:.1f}%",
            "action": "Use Dec26 as quality baseline."})

    # P2: Sep26 worst
    sep = em.get("Sep26")
    if sep and sep["combined_accuracy"] is not None:
        a = sep["combined_accuracy"]
        others = [(g, e["combined_accuracy"]) for g, e in em.items()
                  if e["combined_accuracy"] is not None and g != "Sep26"]
        worst = all(a <= x for _, x in others) if others else False
        findings.append({"pattern": 2, "name": "Sep26 — Consistently Worst",
            "status": "CONFIRMED" if worst and a < 55 else "MONITOR",
            "detail": f"Sep26: {a:.1f}%; " + ", ".join(f"{g}={x:.0f}%" for g, x in sorted(others)),
            "action": "Consider reducing Sep26 exposure."})

    # P3: Buy-side volume degradation
    if vol_bkts:
        parts = []
        light = heavy = None
        for vb in vol_bkts:
            ba = vb["buy_accuracy"]
            if ba is not None:
                parts.append(f"{vb['volume_bucket']}: buy={ba:.1f}%")
                if "Light" in vb["volume_bucket"]:
                    light = ba
                if "Heavy" in vb["volume_bucket"] or "Very" in vb["volume_bucket"]:
                    heavy = ba
        deg = light is not None and heavy is not None and light - heavy > 10
        findings.append({"pattern": 3, "name": "Buy-Side Degradation at Volume",
            "status": "CONFIRMED" if deg else "INCONCLUSIVE",
            "detail": "; ".join(parts),
            "action": "Monitor buy/sell ratio at high volume."})

    # P4: SR3|ZQ sell structural payup
    zqs = [r for r in core if r["ase_type"] == "SR3|ZQ" and r["side"] == "Sell"]
    zqb = [r for r in core if r["ase_type"] == "SR3|ZQ" and r["side"] == "Buy"]
    if zqs and zqb:
        sa, ba = weighted_accuracy(zqs), weighted_accuracy(zqb)
        gap = ba - sa
        findings.append({"pattern": 4, "name": "SR3|ZQ Sell-Side Structural Payup",
            "status": "CONFIRMED" if gap > 3 else "NOT CONFIRMED",
            "detail": f"Buy: {ba:.1f}%, Sell: {sa:.1f}% (gap: {gap:.1f}%)",
            "action": "Accept as structural cost."})

    # P5: X/Y extreme payup
    xy = [r for r in records if r["is_xy"]]
    if xy:
        xa = weighted_accuracy(xy)
        findings.append({"pattern": 5, "name": "X/Y Fills — Extreme Payup",
            "status": "CONFIRMED" if xa < 0 else "MONITOR",
            "detail": f"X/Y accuracy: {xa:.1f}% ({lot_count(xy)} lots)",
            "action": "Review EntryPrice calc for X/Y."})

    # P6: Losses in falling spreads
    cp = [p for p in pnl_rows if p.get("pnl_midpoint") is not None]
    losers = [p for p in cp if p["pnl_midpoint"] < -200]
    if losers:
        parts = [f"{p['alias']}: spread={p['spread']:.4f}, P&L=${p['pnl_midpoint']:.0f}"
                 for p in sorted(losers, key=lambda x: x["pnl_midpoint"])[:3]]
        findings.append({"pattern": 6, "name": "Losses in Falling Spreads",
            "status": "CONFIRMED" if len(losers) >= 2 else "MONITOR",
            "detail": "; ".join(parts), "action": "Implement spread-momentum check."})
    else:
        findings.append({"pattern": 6, "name": "Losses in Falling Spreads",
            "status": "NOT OBSERVED", "detail": "No large losses.", "action": "Continue monitoring."})

    # P7: Low accuracy both sides
    both_low = [s for s in alias_sum
                if s.get("buy_accuracy") is not None and s.get("sell_accuracy") is not None
                and s["buy_accuracy"] < 30 and s["sell_accuracy"] < 30]
    findings.append({"pattern": 7, "name": "Low Accuracy on Both Sides",
        "status": "CONFIRMED" if both_low else "NOT OBSERVED",
        "detail": f"{len(both_low)} aliases" + (": " + ", ".join(s["alias"] for s in both_low[:5]) if both_low else ""),
        "action": "Pause aliases <30% both sides."})

    # P8: Sell below buy
    rev = [p for p in pnl_rows if p["spread"] < 0 and not p["is_xy"] and p["category"] == "core"]
    findings.append({"pattern": 8, "name": "Selling Below Buy Price",
        "status": "CONFIRMED" if len(rev) >= 3 else "MONITOR" if rev else "NOT OBSERVED",
        "detail": f"{len(rev)} core aliases" + (": " + ", ".join(p["alias"] for p in rev[:5]) if rev else ""),
        "action": "Track volume direction."})

    return findings


# =============================================================================
# CONSOLE REPORT
# =============================================================================

def pr_sec(title):
    print(f"\n{'='*80}\n  {title}\n{'='*80}")


def print_report(records, alias_sum, pnl_rows, exp_sum, ase_sum, cat_sum,
                 vol_bkts, patterns, dod, degraded, warnings):
    dates = sorted(set(r["file_date"] for r in records if r["file_date"]))
    core = [r for r in records if r["category"] == "core"]
    xyo = [r for r in records if r["category"] == "xyo"]
    anc = [r for r in records if r["is_ancillary"]]

    pr_sec("FILL EXECUTION ANALYSIS REPORT")
    print(f"  Date range: {dates[0]} to {dates[-1]} ({len(dates)} days)")
    print(f"  Total: {len(records):,} fills / {lot_count(records):,} lots")
    print(f"  Core: {len(core):,} fills / {lot_count(core):,} lots")
    print(f"  X/Y/O: {len(xyo):,} fills / {lot_count(xyo):,} lots")
    print(f"  Ancillary: {len(anc):,} fills / {lot_count(anc):,} lots")
    print(f"  Warnings: {len(warnings)}")
    for w in warnings[:5]:
        print(f"    ! {w}")
    val = defaultdict(int)
    for r in records:
        val[r.get("td_validation", "N/A")] += 1
    mis = val.get("MISMATCH", 0)
    print(f"  TD validation: {val.get('OK',0)} OK, {mis} mismatch, {val.get('NO_PRECOMP',0)} no precomp")

    pr_sec("GRAND ACCURACY (Core)")
    buys = [r for r in core if r["side"] == "Buy"]
    sells = [r for r in core if r["side"] == "Sell"]
    cc = class_counts(core)
    tl = lot_count(core)
    if tl:
        print(f"  Combined: {weighted_accuracy(core):.1f}%")
        print(f"  Buy:  {weighted_accuracy(buys):.1f}% ({lot_count(buys):,} lots)")
        print(f"  Sell: {weighted_accuracy(sells):.1f}% ({lot_count(sells):,} lots)")
        print(f"  Zero={cc['Zero']} ({cc['Zero']/tl*100:.0f}%), "
              f"Payup={cc['Payup']} ({cc['Payup']/tl*100:.0f}%), "
              f"Backoff={cc['Backoff']} ({cc['Backoff']/tl*100:.0f}%)")

    pr_sec("CATEGORY BREAKDOWN")
    print(f"  {'Category':<18} {'Lots':>7} {'Buy Acc':>9} {'Sell Acc':>9} {'Combined':>10}")
    print(f"  {'-'*55}")
    for c in cat_sum:
        ba = f"{c['buy_accuracy']:.1f}%" if c['buy_accuracy'] is not None else "n/a"
        sa = f"{c['sell_accuracy']:.1f}%" if c['sell_accuracy'] is not None else "n/a"
        ca = f"{c['combined_accuracy']:.1f}%" if c['combined_accuracy'] is not None else "n/a"
        print(f"  {c['category']:<18} {c['total_lots']:>7,} {ba:>9} {sa:>9} {ca:>10}")

    pr_sec("EXPIRY GROUP (Core)")
    ce = compute_expiry_summary(core)
    print(f"  {'Group':<12} {'Lots':>7} {'Buy Acc':>9} {'Sell Acc':>9} {'Combined':>10} {'Zero%':>7}")
    print(f"  {'-'*56}")
    for e in sorted(ce, key=lambda x: x["expiry_group"]):
        if not e["total_lots"]:
            continue
        zp = e["classification"]["Zero"] / e["total_lots"] * 100
        ba = f"{e['buy_accuracy']:.1f}%" if e['buy_accuracy'] is not None else "n/a"
        sa = f"{e['sell_accuracy']:.1f}%" if e['sell_accuracy'] is not None else "n/a"
        ca = f"{e['combined_accuracy']:.1f}%" if e['combined_accuracy'] is not None else "n/a"
        print(f"  {e['expiry_group']:<12} {e['total_lots']:>7,} {ba:>9} {sa:>9} {ca:>10} {zp:>6.0f}%")

    pr_sec("ASE TYPE (Core)")
    ca = compute_ase_type_summary(core)
    print(f"  {'Type':<12} {'Side':<6} {'Lots':>7} {'Accuracy':>10}")
    print(f"  {'-'*38}")
    for a in ca:
        print(f"  {a['ase_type']:<12} {a['side']:<6} {a['total_lots']:>7,} {a['accuracy']:>9.1f}%")

    pr_sec("BUY vs SELL BY DAILY VOLUME")
    print(f"  {'Bucket':<24} {'Days':>5} {'BuyLots':>8} {'BuyAcc':>8} {'SellLots':>9} {'SellAcc':>8}")
    print(f"  {'-'*64}")
    for vb in vol_bkts:
        ba = f"{vb['buy_accuracy']:.1f}%" if vb['buy_accuracy'] is not None else "n/a"
        sa = f"{vb['sell_accuracy']:.1f}%" if vb['sell_accuracy'] is not None else "n/a"
        print(f"  {vb['volume_bucket']:<24} {vb['days']:>5} {vb['buy_lots']:>8,} {ba:>8} {vb['sell_lots']:>9,} {sa:>8}")

    cp = [p for p in pnl_rows if p.get("pnl_midpoint") is not None]
    top5 = [p for p in cp if p["pnl_midpoint"] > 0][:5]
    bot5 = sorted([p for p in cp if p["pnl_midpoint"] < 0], key=lambda x: x["pnl_midpoint"])[:5]

    pr_sec("MATCHED P&L — TOP GAINERS (Core)")
    if top5:
        print(f"  {'Alias':<30} {'Spread':>8} {'Qty':>5} {'$75':>9} {'$100':>9} {'$125':>9}")
        print(f"  {'-'*72}")
        for p in top5:
            print(f"  {p['alias']:<30} {p['spread']:>8.4f} {p['matched_qty']:>5} "
                  f"${p['pnl_conservative']:>8,.0f} ${p['pnl_midpoint']:>8,.0f} ${p['pnl_aggressive']:>8,.0f}")
    else:
        print("  None.")

    pr_sec("MATCHED P&L — WORST LOSERS (Core)")
    if bot5:
        print(f"  {'Alias':<30} {'Spread':>8} {'Qty':>5} {'$75':>9} {'$100':>9} {'$125':>9}")
        print(f"  {'-'*72}")
        for p in bot5:
            print(f"  {p['alias']:<30} {p['spread']:>8.4f} {p['matched_qty']:>5} "
                  f"${p['pnl_conservative']:>8,.0f} ${p['pnl_midpoint']:>8,.0f} ${p['pnl_aggressive']:>8,.0f}")

    tp = {s: sum(p.get(f"pnl_{s}", 0) or 0 for p in pnl_rows) for s in DPP_SCENARIOS}
    print(f"\n  Total Matched P&L (core):")
    for s, v in tp.items():
        print(f"    {s:>14}: ${v:>10,.2f}")

    pr_sec("MOST DEGRADED ALIASES")
    for d in degraded[:10]:
        ar = "↓" if d["total_delta"] < 0 else "↑"
        print(f"  {d['alias']:<35} {d['first_accuracy']:>6.1f}% -> {d['last_accuracy']:>6.1f}% "
              f"({ar}{abs(d['total_delta']):.1f}%) {d['days_active']}d")

    pr_sec("STRUCTURAL PATTERNS")
    for p in patterns:
        ic = {"CONFIRMED":"✓","NOT CONFIRMED":"✗","MONITOR":"⚡",
              "INCONCLUSIVE":"?","NOT OBSERVED":"—","WEAKENED":"~"}.get(p["status"],"?")
        print(f"\n  [{ic}] P{p['pattern']}: {p['name']}")
        print(f"      {p['status']}: {p['detail']}")
        print(f"      Action: {p['action']}")

    pr_sec("KEY QUESTIONS")
    print("\n  Q: Most degraded aliases?")
    for d in degraded[:3]:
        print(f"     -> {d['alias']}: {d['total_delta']:+.1f}% over {d['days_active']}d")
    print("\n  Q: Buy vs sell at volume?")
    for vb in vol_bkts:
        ba = f"{vb['buy_accuracy']:.1f}%" if vb['buy_accuracy'] is not None else "n/a"
        sa = f"{vb['sell_accuracy']:.1f}%" if vb['sell_accuracy'] is not None else "n/a"
        print(f"     -> {vb['volume_bucket']}: Buy={ba}, Sell={sa}")
    print("\n  Q: Reduce which expiry?")
    worst = min((e for e in ce if e["combined_accuracy"] is not None and e["total_lots"] > 0),
                key=lambda e: e["combined_accuracy"], default=None)
    if worst:
        print(f"     -> {worst['expiry_group']} at {worst['combined_accuracy']:.1f}%")
    print("\n  Q: Confirmed patterns?")
    for p in patterns:
        if p["status"] == "CONFIRMED":
            print(f"     -> P{p['pattern']}: {p['name']}")
    print()


# =============================================================================
# EXPORT
# =============================================================================

def write_csv(rows, path):
    if not rows:
        return
    flat = []
    for r in rows:
        f = {}
        for k, v in r.items():
            if isinstance(v, dict):
                for sk, sv in v.items():
                    f[f"{k}_{sk}"] = sv
            elif isinstance(v, (date, datetime)):
                f[k] = v.isoformat()
            else:
                f[k] = v
        flat.append(f)
    with open(path, 'w', newline='') as fh:
        w = csv.DictWriter(fh, fieldnames=list(flat[0].keys()), extrasaction='ignore')
        w.writeheader()
        w.writerows(flat)

def write_json(data, path):
    def s(o):
        if isinstance(o, (date, datetime)):
            return o.isoformat()
        if isinstance(o, float) and math.isnan(o):
            return None
        raise TypeError(f"{type(o)}")
    with open(path, 'w') as f:
        json.dump(data, f, indent=2, default=s)

def export(odir, alias_sum, pnl, exp_sum, ase_sum, cat_sum, vol, pat, deg, records):
    os.makedirs(odir, exist_ok=True)
    det = [{"date": r["file_date"], "timestamp": r["timestamp"],
            "alias": r["alias"], "alias_raw": r["alias_raw"],
            "ase_type": r["ase_type"], "expiry_group": r["expiry_group"],
            "category": r["category"], "side": r["side"], "qty": r["qty"],
            "entry_price": r["entry_price"], "match_price": r["match_price"],
            "td": r["td"], "td_class": r["td_class"],
            "is_xy": r["is_xy"], "set_id": r["set_id"],
            "td_validation": r.get("td_validation")} for r in records]
    write_csv(det, os.path.join(odir, "fill_detail.csv"))
    write_csv(alias_sum, os.path.join(odir, "alias_summary.csv"))
    write_csv(pnl, os.path.join(odir, "matched_pnl.csv"))
    write_csv(exp_sum, os.path.join(odir, "expiry_summary.csv"))
    write_csv(ase_sum, os.path.join(odir, "ase_type_summary.csv"))
    write_csv(cat_sum, os.path.join(odir, "category_summary.csv"))
    write_csv(vol, os.path.join(odir, "volume_accuracy.csv"))
    write_csv(deg, os.path.join(odir, "degradation_ranking.csv"))
    write_csv(pat, os.path.join(odir, "pattern_evaluation.csv"))

    core = [r for r in records if r["category"] == "core"]
    master = {
        "meta": {"generated": datetime.now().isoformat(),
                 "total_fills": len(records), "total_lots": lot_count(records),
                 "core_fills": len(core), "core_lots": lot_count(core),
                 "dates": {"start": min(r["file_date"] for r in records), "end": max(r["file_date"] for r in records)},
                 "td_validation": dict(defaultdict(int, {r.get("td_validation","?"): 0 for r in records}))},
        "grand_accuracy_core": {
            "combined": round(weighted_accuracy(core), 2) if core else None,
            "buy": round(weighted_accuracy([r for r in core if r["side"]=="Buy"]), 2) if core else None,
            "sell": round(weighted_accuracy([r for r in core if r["side"]=="Sell"]), 2) if core else None},
        "expiry_summaries": compute_expiry_summary(core),
        "ase_type_summaries": compute_ase_type_summary(core),
        "total_matched_pnl": {s: round(sum(p.get(f"pnl_{s}",0) or 0 for p in pnl), 2) for s in DPP_SCENARIOS},
        "top_gainers": [p for p in pnl if p.get("pnl_midpoint") and p["pnl_midpoint"] > 0][:5],
        "worst_losers": sorted([p for p in pnl if p.get("pnl_midpoint") and p["pnl_midpoint"] < 0],
                               key=lambda x: x["pnl_midpoint"])[:5],
        "patterns": pat, "degraded": deg[:10]}
    # Fix validation counts
    vc = defaultdict(int)
    for r in records:
        vc[r.get("td_validation","?")] += 1
    master["meta"]["td_validation"] = dict(vc)
    write_json(master, os.path.join(odir, "analysis_summary.json"))

    print(f"\n  Output -> {odir}/")
    for fn in sorted(os.listdir(odir)):
        print(f"    {fn:<30} {os.path.getsize(os.path.join(odir,fn)):>8,} bytes")


# =============================================================================
# MAIN
# =============================================================================

def main():
    p = argparse.ArgumentParser(description="Fill Execution Analysis")
    p.add_argument("--data-dir", required=True)
    p.add_argument("--output-dir", default="./output")
    p.add_argument("--start", default=None)
    p.add_argument("--end", default=None)
    args = p.parse_args()
    sd = datetime.strptime(args.start, "%Y-%m-%d").date() if args.start else None
    ed = datetime.strptime(args.end, "%Y-%m-%d").date() if args.end else None

    print("Loading...")
    recs, warns = load_date_range(args.data_dir, sd, ed)
    if not recs:
        print("ERROR: No records."); sys.exit(1)
    print(f"  {len(recs):,} fills loaded")

    print("Computing TD...")
    for r in recs:
        compute_td(r)

    print("Building summaries...")
    a_sum = compute_alias_summary(recs)
    pnl = compute_matched_pnl(recs)
    e_sum = compute_expiry_summary(recs)
    t_sum = compute_ase_type_summary(recs)
    c_sum = compute_category_summary(recs)
    vol = compute_vol_bucketed(recs)
    dod = compute_dod(recs)
    deg = find_degraded(dod)
    pat = evaluate_patterns(recs, a_sum, pnl, e_sum, vol)

    print_report(recs, a_sum, pnl, e_sum, t_sum, c_sum, vol, pat, dod, deg, warns)

    print("Exporting...")
    export(args.output_dir, a_sum, pnl, e_sum, t_sum, c_sum, vol, pat, deg, recs)
    print("\nDone.")

if __name__ == "__main__":
    main()
