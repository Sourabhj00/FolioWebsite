---
title: Strategy Research — Map of Content
wp: WP-11, WP-14
status: planned
last-updated: 2026-03-31
lines: 26
---

# Strategy Research — Map of Content

Forward-looking strategy research. Currently contains the directional bias
model — a Treasury lead-lag signal (ZN 10-Year, ZT 2-Year) for SR3
execution. Phase 1 spec is complete but not yet implemented. Depends on
WP-11 (regime detection) and WP-14 (regime rules), both unblocked.
(~1,260 lines total)

## Files

- [[directional-bias-model]] — Phase 1 specification: ZN/ZT tick-by-tick watching generates short-lived directional bias signals adjusting B/S bias parameters for SR3 execution. Covers core assumption (rate factor co-movement), signal definition, integration into execution-modifiers, methodology, implementation architecture, validation strategy, success criteria, kill criteria. (~1,260 lines)

## KB Dependencies

- [[knowledge-base/strategy/core-quad-leg-arbitrage]] — O-spread thesis this model extends
- [[knowledge-base/strategy/execution-modifiers]] — B/S bias parameters this model would modify
- [[knowledge-base/ase-rules/ase-mechanics-and-parameters]] — ASE pipeline the signal integrates into
- [[knowledge-base/core/instruments-and-platform]] — SR3/ZN/ZT instrument specs

## Related Folders

- [[market-profiling/_index|Market Profiling]] — Contract groups and event calendar affecting bias signals
- [[fair-value/_index|Fair Value]] — Complementary pricing methodology (curve-derived vs lead-lag)
- [[fill-analysis/_index|Fill Analysis]] — Execution quality baseline to measure signal value
- [[plan/_index|Plan]] — WP-11/WP-14 dependency tracking
