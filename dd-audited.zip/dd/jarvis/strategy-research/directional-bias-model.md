---
title: Correlated-Product Directional Bias Model — Phase 1 Specification
wp: WP-11
status: planned
created: 2026-03-30
last-updated: 2026-03-31
lines: 1260
kb-depends:
  - knowledge-base/strategy/core-quad-leg-arbitrage.md
  - knowledge-base/strategy/execution-modifiers.md
  - knowledge-base/ase-rules/ase-mechanics-and-parameters.md
  - knowledge-base/core/instruments-and-platform.md
  - knowledge-base/ase-rules/custom-rules-production.md
jarvis-depends:
  - jarvis/market-profiling/contract-segmentation.md
  - jarvis/market-profiling/event-calendar-2026-2027.md
tags: [strategy, correlation, lead-lag, treasury, directional-bias, phase-1]
domain: strategy
---

# Correlated-Product Directional Bias Model

## What This Is

A data-driven model that watches Treasury futures (ZN, ZT) tick-by-tick and
generates short-lived directional bias signals for SR3 ASE execution. The
signal answers one question: **right now, is it better to enter SR3 on the
buy side, sell side, or neither?**

The exposure window is the ASE fill time (seconds). This is not a spread
trade. No Treasury position is taken. The Treasury is a read-only signal
source.

---

## Core Assumption

SR3 and Treasuries share a dominant common factor (rate expectations). At the
tick level, they co-move with an empirically stable ratio most of the time.
When Treasury moves first, SR3 tends to follow within seconds. This brief
lead-lag window is the edge.

The model does NOT need the relationship to hold forever — only for the
duration of an ASE fill cycle.

---

## Phase 1 Scope

- **Signal instruments**: ZN (10-Year Note), ZT (2-Year Note) — test in
  parallel, pick the better signal
- **Action instrument**: Any single SR3 quoted contract (outright or spread)
  traded via ASE
- **Output**: Directional bias ∈ {BUY, SELL, NEUTRAL} + confidence score
- **Consumers**: ASE routing logic (Buy-Only / Sell-Only / No-Change)

---

## 1. The Ratio

### Definition

Let Z(t) be the Treasury price (ZN or ZT) and S(t) be the SR3 price, both
observed at tick granularity.

The ratio r is defined empirically:

    When Z moves by ΔZ ticks, S is expected to move by ΔS ≈ ΔZ / r ticks

Observed: r ≈ 3 for ZN (ZN moves 3 → SR3 moves 1).
Observed: r ≈ 4.3 for ZT (from PPT: ratio 0.23, i.e., SR3 = 0.23 × ZT).

### Why Not DV01-Derived

DV01 gives a theoretical ratio, but it assumes parallel rate shifts and
ignores curve/credit/basis effects. The empirical ratio already encodes all
of these. Since we only care about short-term co-movement, the empirical
ratio is more useful than the theoretical one.

### Estimation Methods

#### Method A: Flip-Based (Preferred for tick data)

Scan the joint tick stream. Find instances where BOTH instruments changed
their best bid level within a short window (e.g., 5 seconds).

For each co-flip instance i:
    r_i = ΔZ_i / ΔS_i

Ratio estimate:
    r = median(r_i)    [median is robust to outliers]

Confidence in ratio:
    IQR of r_i values — narrow IQR = stable ratio

#### Method B: Regression-Based (For candle data, e.g. 1-min or 5-min)

On rolling window W (e.g., 2 hours of 1-min bars):

    ΔS(t) = α + β · ΔZ(t) + ε(t)

- β is the ratio (in "SR3 change per ZN change" form, so r = 1/β)
- R² is the explanatory power (how much of SR3's movement comes from ZN)
- α should be ~0 in short windows (no drift)

#### Method C: Conditional Probability Table (Simplest, most practical)

For each possible ZN move size (1 tick, 2 ticks, 3 ticks, ...):

    P(SR3 moves up | ZN moved up N ticks within T seconds)
    P(SR3 moves down | ZN moved up N ticks within T seconds)
    P(SR3 unchanged | ZN moved up N ticks within T seconds)

This directly gives the actionable information without assuming a linear
relationship. Build this table from data. It IS the model.

### Ratio Stability Check

The ratio must be re-estimated periodically. Two approaches:

1. **Rolling window**: re-estimate every M minutes using last W minutes of
   data. Typical: M=30, W=120 (recalc every 30 min using 2hr lookback).

2. **Regime detection**: monitor rolling correlation. If corr drops below
   threshold, flag ratio as unreliable → output NEUTRAL until re-stabilised.

Rolling correlation:

    ρ(t) = corr(ΔS, ΔZ) over window [t-W, t]

Threshold: ρ < 0.85 → ratio unreliable → suppress signals.

---

## 2. Lead-Lag Detection

### The Question

When ZN moves, does SR3 follow? And if so, how quickly?

### Cross-Correlation at Tick Level

Compute the cross-correlation function (CCF):

    CCF(k) = corr(ΔS(t), ΔZ(t - k))

for k = 0, ±1, ±2, ... (in seconds or tick-events).

- If CCF peaks at k > 0: ZN leads SR3 by k units (this is what we want)
- If CCF peaks at k < 0: SR3 leads ZN (signal is useless or reversed)
- If CCF peaks at k = 0: simultaneous movement (no lead-lag edge)

### Response Time Distribution

More practical than CCF for our use case:

After each ZN N-tick move, measure:
- t_response = time until SR3 moves in the same direction
- If SR3 doesn't move within T_max (e.g., 60 seconds), classify as "no response"

Build the distribution of t_response. Key statistics:
- **Median response time**: typical lag
- **P25 response time**: fast responses (may already be too late)
- **P75 response time**: slow responses (comfortable window for ASE)
- **No-response rate**: how often ZN moves but SR3 doesn't follow at all

### What We Need From This

The response time distribution tells us the **signal shelf life**. If median
response is 8 seconds and P75 is 20 seconds, then:
- Signal is generated at ZN move
- ASE has ~8-20 seconds to act
- After 30 seconds, signal is stale → revert to NEUTRAL

---

## 3. Signal Generation

### Signal Definition

A signal fires when ALL of the following are true:

#### Condition 1: Treasury Move Threshold

    |ΔZ(t, τ)| ≥ T_min ticks

where ΔZ(t, τ) = Z(t) - Z(t-τ) is the ZN/ZT price change over the
lookback window τ.

Parameters:
- τ (lookback window): e.g., 10 seconds
- T_min (minimum ticks): e.g., 2 ticks for ZN, 3 ticks for ZT

Higher T_min → fewer signals, higher confidence per signal.
Lower T_min → more signals, more noise.

This is the primary tunable parameter.

#### Condition 2: SR3 Has NOT Already Absorbed the Move

    |ΔS(t, τ)| < expected_move

where expected_move = |ΔZ(t, τ)| / r

If SR3 has already moved in the same direction by the expected amount,
there is no remaining edge. The market has already priced it in.

This is critical. Without this check, you enter after the move is done.

#### Condition 3: Ratio is Currently Reliable

    ρ(t) ≥ ρ_min

where ρ(t) is the rolling correlation over window W.

When correlation has dropped, the ratio is suspect and signals should be
suppressed.

#### Condition 4: Volume Confirmation (Optional, Phase 1B)

    Volume(Z, τ) ≥ V_min

The Treasury move should be backed by real traded volume, not just quote
flickering. This filters phantom moves from thin books.

### Signal Output

    signal = {
        direction:  BUY | SELL | NEUTRAL,
        confidence: [0, 1],
        magnitude:  expected SR3 move in ticks,
        shelf_life: seconds until signal expires
    }

Direction = sign(ΔZ(t, τ))  [ZN up → SR3 BUY; ZN down → SR3 SELL]

Confidence is a function of:
- |ΔZ|: bigger move → more confident (look up from conditional probability table)
- Volume: more volume → more confident
- ρ(t): higher current correlation → more confident
- Absorption: less SR3 absorption → more confident

A simple confidence formula:

    confidence = P(SR3 follows | ZN moved N ticks)    [from Method C table]
                 × ρ(t) / ρ_baseline
                 × (1 - absorption_fraction)

where absorption_fraction = |actual ΔS| / |expected ΔS|.

### Signal Expiry

The signal has a shelf life based on the response time distribution:

    shelf_life = P75_response_time    (or a configurable multiple)

After shelf_life seconds, the signal decays to NEUTRAL regardless. This
prevents stale signals from influencing ASE when the expected response
window has passed.

---

## 4. Confidence Calibration: The Conditional Probability Table

This is the most important artifact of the model. It is built entirely from
data and requires no assumptions about why the relationship exists.

### Structure

For each signal instrument (ZN, ZT), build:

    Table[N][D][T] = P(SR3 moves in direction D within T seconds | Z moved N ticks)

Where:
- N = ZN/ZT tick count (1, 2, 3, 4, 5+)
- D = direction (same as ZN move, opposite, unchanged)
- T = response window (5s, 10s, 15s, 30s, 60s)

Example (hypothetical values, to be filled with real data):

    ZN moved +2 ticks in 10s:
    ┌─────────────┬──────┬──────┬──────┬──────┬──────┐
    │ SR3 response │  5s  │ 10s  │ 15s  │ 30s  │ 60s  │
    ├─────────────┼──────┼──────┼──────┼──────┼──────┤
    │ Same dir     │ 35%  │ 52%  │ 61%  │ 68%  │ 72%  │
    │ Opposite     │ 10%  │ 14%  │ 16%  │ 18%  │ 19%  │
    │ Unchanged    │ 55%  │ 34%  │ 23%  │ 14%  │  9%  │
    └─────────────┴──────┴──────┴──────┴──────┴──────┘

    ZN moved +3 ticks in 10s:
    ┌─────────────┬──────┬──────┬──────┬──────┬──────┐
    │ SR3 response │  5s  │ 10s  │ 15s  │ 30s  │ 60s  │
    ├─────────────┼──────┼──────┼──────┼──────┼──────┤
    │ Same dir     │ 55%  │ 70%  │ 78%  │ 84%  │ 87%  │
    │ Opposite     │  5%  │  8%  │ 10%  │ 11%  │ 11%  │
    │ Unchanged    │ 40%  │ 22%  │ 12%  │  5%  │  2%  │
    └─────────────┴──────┴──────┴──────┴──────┴──────┘

### How to Read the Table

If ZN just moved +3 ticks and the table says 70% same-direction within 10s
and only 8% opposite within 10s, then:

- The signal is: BUY SR3
- Confidence: high (70% vs 8% — strong directional edge)
- Shelf life: ~15-30s (by 15s, 78% have responded)

If ZN moved only +1 tick and the table shows 40% same / 25% opposite / 35%
unchanged at 10s:

- The edge is marginal (40% vs 25%)
- Signal: NEUTRAL (not enough edge to act on)

### Key Insight: The Table IS the Model

No regression. No factor decomposition. No assumptions. Just: "historically,
when ZN moved this much, what did SR3 do?" The table directly answers the
trading question. Everything else (ratio, correlation, lead-lag) is
scaffolding to help you understand and debug the table.

### Building the Table

Requirements:
- Synchronized tick data for both instruments
- Sufficient sample size per cell (minimum ~100 instances per N-tick bucket)
- Separate tables for: normal hours, data-release windows, different
  volatility regimes (if the table differs materially)

Steps:
1. Align tick streams by timestamp
2. Detect ZN "moves": consecutive price change of N ticks within τ seconds
3. For each detected move, record SR3 state at: +5s, +10s, +15s, +30s, +60s
4. Classify SR3 response: same direction, opposite, unchanged
5. Aggregate into probability table
6. Compute standard errors (is the sample large enough to trust the cell?)

---

## 5. Correlation Monitoring

### Rolling Correlation

Compute ρ on a rolling window. This is the early warning system for ratio
breaks.

    ρ(t) = pearson_corr(ΔS, ΔZ) over [t-W, t]

Window W: 1-2 hours of 1-min returns is typical.

### Correlation Regimes

Define three regimes:

    HIGH:   ρ ≥ 0.90  → full signal strength
    MEDIUM: 0.75 ≤ ρ < 0.90 → reduced confidence (scale signal by ρ/0.90)
    LOW:    ρ < 0.75  → suppress all signals → NEUTRAL only

### Correlation Break Detection

If ρ drops from HIGH to LOW within 15 minutes, this is a correlation break.
Possible causes (for context, not for modelling):
- Credit event starting
- Curve repricing
- Product-specific supply/demand shock
- Data release causing asymmetric repricing

Action on break: **stop generating signals immediately**. Resume only when ρ
recovers to MEDIUM for at least 15 minutes.

### Why This is Sufficient

We don't need to know WHY correlation broke. We just need to know THAT it
broke. The correlation monitor is a circuit breaker, not a diagnostic tool.
Since our exposure per signal is seconds, we only need to avoid entering
during the break — and the rolling ρ catches this.

---

## 6. Edge Cases and Failure Modes

### EC1: Treasury Spike and Reversal (Fake-Out)

**Scenario**: ZN jumps 4 ticks up, signal fires BUY, then ZN reverses 5
ticks down within 10 seconds.

**Impact**: SR3 ASE enters buy side. If ASE fill is fast (3-5 seconds), may
get filled at good price before reversal. If slow, may enter into a
reversing market.

**Detection**: Check if ZN move is sustained. Two approaches:
1. **Delay**: Don't fire signal until ZN has held the new level for D seconds
   (e.g., D=3). Costs some of the lead time but filters fake-outs.
2. **Two-stage**: Fire signal immediately at reduced confidence, upgrade
   confidence after D seconds if ZN holds.

**Test**: Measure fake-out rate — what % of N-tick ZN moves reverse >50%
within 5/10/15 seconds? This determines whether delay is needed and how much.

### EC2: SR3 Leads (Reverse Lead-Lag)

**Scenario**: Around FOMC or data releases, SR3 (being the front-end rate
product) moves BEFORE treasuries.

**Impact**: Signal would fire late. ZN moves after SR3 already moved. By the
time signal says BUY, the move is already done.

**Detection**: Condition 2 (absorption check) catches this. If SR3 already
moved the expected amount, signal stays NEUTRAL.

**Additional safeguard**: During known data-release windows (use existing
PauseWindow infrastructure), suppress signals entirely. The lead-lag
relationship reverses or becomes simultaneous around data.

### EC3: Simultaneous Movement (No Lead-Lag)

**Scenario**: Both instruments move at the same time. No exploitable delay.

**Impact**: Signal might fire but there's no time to act.

**Detection**: The conditional probability table will show this — if the
"same direction within 5s" rate is very high (>80%) but almost all of those
responses happen in the first 1-2 seconds, there's no actionable window.

**Metric**: Track not just "did SR3 follow within T?" but also "was there a
delay of at least D seconds before SR3 followed?" Need delay ≥ ASE reaction
time (estimated 2-5 seconds).

### EC4: Ratio Shift (Gradual)

**Scenario**: The ratio drifts from 3.0 to 3.5 over several days.

**Impact**: Signal magnitude estimates become wrong. Expected SR3 move is
over/under-estimated.

**Detection**: Rolling ratio estimation (Method A/B) catches this
automatically if recalculated frequently.

**Test**: How much does the ratio vary day-to-day? Week-to-week? If variance
is small (<10% from mean), infrequent recalibration is fine. If large, need
intraday recalibration.

### EC5: ZN Move in Illiquid Period

**Scenario**: ZN moves 3 ticks at 6 AM ET with only 200 lots bid/offer.
SR3 is even thinner.

**Impact**: ZN move is noise from thin book, not a real signal. SR3 may not
respond because there's no one to trade with.

**Detection**: Volume confirmation (Condition 4) filters this. Also: check
ZN bid-ask spread — if wider than normal, discount the signal.

**Practical filter**: Only generate signals during liquid hours (e.g., 7 AM -
4 PM ET, or define per-product liquid windows).

### EC6: Large Move (Potential Regime Break)

**Scenario**: ZN moves 8+ ticks in 30 seconds (major data surprise, crisis).

**Impact**: This might be the START of a correlation break, not normal
co-movement. Following the signal could mean catching a falling knife.

**Detection**: Cap the signal at a maximum ZN move. E.g., if |ΔZ| > 6 ticks,
output NEUTRAL regardless — the move is too large to be normal co-movement.

**Refinement**: The conditional probability table will show the win rate for
large moves. If it drops significantly for N>5, the cap confirms itself from
data.

### EC7: Multiple Rapid Signals

**Scenario**: ZN moves 2 ticks, signal fires. 5 seconds later, ZN moves
another 2 ticks.

**Impact**: Is this one signal or two? If two, do they stack?

**Rule**: Signals do NOT stack. While a signal is active (within shelf_life),
new ZN moves only UPDATE the existing signal (new direction, new confidence,
reset shelf_life). A new signal replaces the old one.

### EC8: Signal Conflicts with Core Strategy

**Scenario**: Directional bias says BUY SR3, but the quad-leg arb has a
strong sell signal on the same contract.

**Rule**: The directional bias is an INPUT, not an override. It biases ASE
parameters (e.g., slightly more aggressive on buy, slightly less on sell)
but does not override the core pricing engine. Exact integration defined in
Section 8.

---

## 7. Test Cases for Validation

Before going live, each of these must produce satisfactory results.

### TC1: Ratio Stability

**What**: Compute ratio on rolling 1hr, 2hr, 4hr windows across multiple
days.

**Pass criteria**:
- Intraday ratio standard deviation < 15% of mean
- Day-to-day ratio change < 10%
- No periods where ratio inverts (SR3 moves opposite to ZN for >10 minutes)

**If fails**: Ratio is too unstable for a fixed-ratio model. Need either
very frequent recalibration or a different approach.

### TC2: Win Rate by Move Size

**What**: Build the conditional probability table (Section 4) from data.

**Pass criteria**:
- For N ≥ 3 ticks (ZN): P(same direction, 10s) > 60% AND P(opposite, 10s) < 20%
- For N ≥ 2 ticks (ZT): similar or better
- Clear monotonic improvement: larger N → higher win rate

**If fails**: The lead-lag relationship is not exploitable at these
thresholds. May need higher N (fewer signals) or the relationship simply
doesn't exist at useful timescales.

### TC3: Response Time Adequacy

**What**: Build the response time distribution.

**Pass criteria**:
- Median response time > 3 seconds (enough for ASE to react)
- P25 response time > 1 second (not all responses are instant)
- "No response within 60s" rate < 30% for N ≥ 3 signals

**If fails**: SR3 responds too fast (market is too efficient for this edge)
or too rarely (relationship is too loose to be useful).

### TC4: False Positive Characterisation

**What**: Examine all signals where SR3 went opposite direction.

**Look for**:
- Cluster in time? (specific hours/events produce false positives)
- Cluster by market condition? (low liquidity, high volatility)
- Associated with correlation breaks?

**Pass criteria**: False positives are explainable and filterable. After
applying filters, win rate improves by >5 percentage points.

### TC5: Edge Case Frequency

**What**: Count occurrence of each edge case (EC1-EC8) in historical data.

**Pass criteria**:
- EC1 (fake-out): < 15% of signals
- EC2 (reverse lead-lag): < 10% of liquid-hours signals
- EC6 (large moves): < 5% of signals
- No single edge case dominates the loss distribution

### TC6: ZN vs ZT Comparison

**What**: Build all of the above for both ZN and ZT in parallel.

**Decision criteria**:
- Which has higher win rate at comparable signal frequency?
- Which has longer response time (more time for ASE)?
- Which has more stable ratio?
- Which has fewer false positives?

Select the winner for Phase 1 deployment. The loser becomes Phase 2
secondary signal or is discarded.

### TC7: Time-of-Day Analysis

**What**: Slice all metrics by hour of day.

**Expect**:
- Signal quality varies by session (US morning vs afternoon vs Asia/Europe)
- Some hours may need to be excluded (low-liquidity periods)
- Lead-lag structure may differ by session

**Output**: Approved trading hours for the signal. Hours outside this window
→ signal suppressed.

---

## 8. Integration with ASE Infrastructure

### Signal → ASE Mapping

The signal does NOT create new orders. It modifies the behavior of existing
ASE strategies.

Three integration modes, in order of increasing aggressiveness:

#### Mode 1: Soft Bias (Conservative)

Signal biases the avoidance/bias parameters on existing ASEs:

- BUY signal → reduce avoidanceValue on buy side by X (tighter spread,
  more fill probability) OR increase bsValue slightly toward buy
- SELL signal → mirror for sell side
- NEUTRAL → no change to parameters

This is the lightest touch. The core pricing engine still controls everything.
The signal just nudges the parameters.

#### Mode 2: ASE Type Routing (Medium)

Signal activates/deactivates specific ASE types:

- BUY signal + high confidence → activate Buy-Only ASEs, deactivate Sell-Only
- SELL signal + high confidence → activate Sell-Only ASEs, deactivate Buy-Only
- NEUTRAL → standard bidirectional ASEs active

This is the approach described in the PPT. It requires pre-configured ASE
sets (Buy-Only, Sell-Only, Neutral) ready to swap.

#### Mode 3: Hit Trigger (Aggressive)

Signal directly triggers market-taking:

- BUY signal + very high confidence → HitMan fires immediately on SR3 buy side
- This is the "ZN moved 3, hit SR3 buy" scenario from the original idea

This is the most aggressive mode and should only be used when the conditional
probability table shows >75% same-direction rate at the given N.

### Priority Rules

1. Safety mechanisms (Spike, PauseWindow) ALWAYS override the signal
2. Core pricing engine sets the base price — signal does not change it
3. Signal adjusts execution aggressiveness around that base price
4. If signal confidence < 0.5 → Mode 1 only (soft bias)
5. If signal confidence ≥ 0.5 and < 0.75 → Mode 2 allowed
6. If signal confidence ≥ 0.75 → Mode 3 allowed

### Signal Lifecycle in ASE

    t=0:   ZN moves N ticks → signal generated
    t=0:   Absorption check → SR3 hasn't moved → signal valid
    t=0:   Correlation check → ρ > threshold → signal reliable
    t=0:   Signal dispatched to ASE routing layer
    t=1-3s: ASE adjusts (Mode 1/2/3 depending on confidence)
    t=3-15s: ASE operating under biased parameters
    t=shelf_life: Signal expires → revert to NEUTRAL → ASE returns to default

Total bias duration: ~3-30 seconds per signal. This is why macro breaks
don't matter.

---

## 9. Mathematical Summary

### Notation

    Z(t)    Treasury price (ZN or ZT) at time t
    S(t)    SR3 price at time t
    ΔZ(t,τ) = Z(t) - Z(t-τ)           Price change over window τ
    r       Empirical ratio: ΔZ / ΔS
    ρ(t)    Rolling Pearson correlation over window W
    τ       Signal lookback window (seconds)
    T_min   Minimum ZN tick count to trigger signal
    D       Delay before confirming signal (seconds)
    L       Signal shelf life (seconds)

### Signal Generation (Pseudocode)

    every tick:
        ΔZ = Z(now) - Z(now - τ)
        ΔS = S(now) - S(now - τ)

        if |ΔZ| < T_min:
            signal = NEUTRAL
            return

        expected_ΔS = ΔZ / r
        absorption = |ΔS| / |expected_ΔS|

        if absorption > 0.7:
            signal = NEUTRAL          # SR3 already moved, no edge left
            return

        if ρ(now) < ρ_min:
            signal = NEUTRAL          # correlation unreliable
            return

        direction = sign(ΔZ)
        confidence = CPT[|ΔZ|] × (ρ(now) / ρ_baseline) × (1 - absorption)

        signal = {
            direction:  BUY if direction > 0 else SELL,
            confidence: clamp(confidence, 0, 1),
            shelf_life: L,
            timestamp:  now
        }

### Ratio Estimation (Pseudocode)

    every M minutes:
        flips = find_co_flips(Z_ticks, S_ticks, window=W)
        ratios = [ΔZ_i / ΔS_i for each flip i]

        r = median(ratios)
        r_iqr = iqr(ratios)

        if r_iqr / r > 0.30:
            flag_ratio_unstable()

### Correlation Monitor (Pseudocode)

    every 1 minute:
        ΔZ_series = 1-min returns of Z over last W minutes
        ΔS_series = 1-min returns of S over last W minutes
        ρ = pearson(ΔZ_series, ΔS_series)

        if ρ < 0.75:
            regime = LOW → suppress all signals
        elif ρ < 0.90:
            regime = MEDIUM → scale confidence by ρ/0.90
        else:
            regime = HIGH → full confidence

---

## 10. Implementation Plan

### Step 1: Data Collection

Collect synchronized tick data for:
- ZN (front month)
- ZT (front month)
- SR3 (front quarterly, and/or the specific contract being traded)

Fields per tick: timestamp (ms), bid, ask, bid_qty, ask_qty, last_trade_price,
last_trade_qty, total_volume

Duration: minimum 1 week of liquid hours. Ideally 2-4 weeks covering
different volatility regimes.

Source: TT tick data export, or QH historical data API.

### Step 2: Build Conditional Probability Table

This is the core deliverable of the research phase. If this table shows
strong directional edge, proceed. If not, stop.

Specific output:
- CPT for ZN → SR3 (by N=1..6 ticks, T=5..60 seconds)
- CPT for ZT → SR3 (same dimensions)
- Standard errors for each cell
- Sample counts per cell (need ≥100 per cell for reliability)

### Step 3: Characterise Lead-Lag

Build the response time distribution:
- For each ZN/ZT N-tick signal, time until SR3 responds
- Median, P25, P75, no-response rate
- By time of day

This determines shelf_life and whether the edge is practically actionable.

### Step 4: Run Edge Case Analysis

For each edge case (EC1-EC8), measure frequency and impact:
- How often does each occur?
- What's the P&L impact when it occurs?
- Can it be filtered?

### Step 5: Backtest Signal

Simulate the signal on historical data:
- Apply signal generation logic with candidate parameters
- Assume ASE fill occurs D seconds after signal
- Classify each signal outcome: win / loss / no-fill
- Compute: win rate, average win, average loss, expected value per signal

Iterate on parameters (τ, T_min, ρ_min, L) to optimise expected value.

### Step 6: Forward Test on SIM

Run the signal in SIM alongside the live system:
- Signal generates bias, ASE runs in SIM with bias applied
- Compare SIM fill accuracy (biased) vs LIVE fill accuracy (unbiased)
- Minimum 1 week of parallel running

### Step 7: Controlled Live Deployment

- Start with Mode 1 only (soft bias, parameter nudging)
- Monitor fill accuracy improvement vs baseline
- After 1 week of positive results, graduate to Mode 2 (ASE routing)
- Mode 3 (hit trigger) only after 2+ weeks of proven Mode 2 results

---

## 11. Parameter Table (Starting Values)

All parameters are subject to calibration from data.

| Parameter | Symbol | Starting Value | Notes |
|-----------|--------|----------------|-------|
| Lookback window | τ | 10 seconds | Time window for detecting ZN move |
| Min ZN ticks | T_min (ZN) | 3 ticks | Minimum ZN move to trigger signal |
| Min ZT ticks | T_min (ZT) | 4 ticks | Minimum ZT move (higher ratio) |
| Absorption threshold | - | 0.7 | If SR3 moved >70% of expected, no edge |
| Correlation window | W | 120 minutes | Rolling window for ρ calculation |
| Correlation min (suppress) | ρ_min | 0.75 | Below this, suppress all signals |
| Correlation baseline | ρ_baseline | 0.95 | Used to scale confidence |
| Signal shelf life | L | 20 seconds | Signal expires after this |
| Ratio recalc interval | M | 30 minutes | How often to re-estimate r |
| Max ZN move (cap) | - | 6 ticks | Above this, NEUTRAL (regime break risk) |
| Liquid hours | - | 07:00-16:00 ET | Signal only during liquid session |
| Delay for confirmation | D | 0 seconds | Start at 0, increase if fake-outs high |

---

## 12. Decision Criteria: Phase 1 → Phase 2

Phase 1 is complete when:

1. Conditional probability table built for both ZN and ZT
2. One instrument selected as primary signal source
3. Win rate > 60% at T_min threshold for signals during liquid hours
4. Forward test on SIM shows fill accuracy improvement > 3% vs baseline
5. Edge cases characterized and filtered

Phase 2 expands to:
- Additional Treasury instruments (ZF, ZB, UB)
- Multiple SR3 contracts simultaneously
- Cross-product signals (does ZN move predict SR1 and ZQ too?)
- Integration with Timer Logic (bias the expansion value based on signal)
- Combination with cluster strategy (signal + relative value = compound edge)

---

## 13. Market Conditions: When to Use and When to Avoid

### Best Conditions (High-Confidence Signal)

**Ranged, liquid, no-event market during US hours**. This is the model's
sweet spot. Both ZN/ZT and SR3 are liquid, the ratio is stable, the lead-lag
is clean, and the only thing driving price is order flow and micro-level
supply/demand. The model is designed for exactly this: extracting short-lived
directional edge from co-movement in a stable regime.

Characteristics:
- ZN bid-ask spread is 1 tick (tight), standing quantity > 500 lots both sides
- SR3 bid-ask spread is 0.5 (minimum), standing quantity > 200 lots
- Rolling ρ > 0.90 (HIGH regime)
- No scheduled data releases in the next 30 minutes
- ATR of ZN in the last hour is within normal range (not spiking, not dead)
- Time: 8:00 AM – 3:00 PM ET (peak US liquidity)

**When ZN has occasional momentum bursts in an otherwise stable market**.
This is the ideal signal: ZN steps 3 ticks in 2 seconds (a paper buyer/seller
or a fast money flow), and SR3 hasn't yet responded. The burst is large
enough to be real, small enough to not be a regime break.

**When SR3 liquidity is thinner than ZN liquidity**. If ZN is the more
liquid market (which it typically is — ZN trades 1M+ lots/day vs SR3 at
~200-500K), information tends to arrive in ZN first because it's cheaper
to trade there. This natural liquidity asymmetry is what creates the
lead-lag in the first place. The wider the liquidity gap, the more reliable
the lead.

### Acceptable Conditions (Reduced Confidence, Mode 1 Only)

**European hours overlap (7-8 AM ET)**. ZN and SR3 are both active but
European flows (Bund, Gilt) can create noise in ZN that doesn't relate to
SOFR. The ratio may be slightly different. Use Mode 1 (soft bias) only,
not Mode 2/3.

**Mild directional market (ZN trending but slowly)**. If ZN is grinding up
0.5 tick per minute, the ratio still holds tick-by-tick. But the cumulative
drift means "buy bias" is on more than "sell bias," which may reduce
diversification of signal direction. Still usable, but be aware that the
signal will skew one direction.

**After a data release has settled (> 5 minutes post-release)**. The
initial burst around data is chaos (model is paused via PauseWindow). But
once the market stabilises at a new level and bid-ask spreads normalise,
the co-movement relationship re-establishes. Wait until ρ climbs back
above 0.75 before re-enabling signals.

### Avoid (Suppress Signals Entirely)

**During or immediately around scheduled data releases**. FOMC, NFP, CPI,
PPI, ISM, GDP — these events cause simultaneous or reverse-lead repricing.
SR3 may move BEFORE ZN (SOFR-specific events like FOMC), or both may move
simultaneously with no exploitable lag. The model's lead-lag assumption
breaks.

Why: The model assumes ZN leads SR3. At data releases, the market prices in
new information instantly across all products. There is no lead-lag to
exploit — only noise.

How: Use the existing PauseWindow infrastructure. Suppress signals from
T-2 minutes to T+5 minutes around any scheduled event.

**When rolling ρ drops below 0.75 (LOW regime)**. This is the correlation
circuit breaker. Something is causing the products to diverge — credit risk,
curve repricing, product-specific supply/demand, or a structural change.
The model cannot tell you WHY, only THAT the relationship is broken.

Why: If the ratio is wrong, every signal is wrong. The model's edge comes
entirely from the ratio being stable. When ρ drops, the ratio is suspect.

How: Automatic — the signal generation logic already suppresses when ρ < 0.75.

**During thin/illiquid markets (pre-open, late evening, holidays)**. ZN
may show a 3-tick move that's just a single lot hitting a wide bid-ask.
SR3 may be so thin that there's no one to trade with even if the signal
is right.

Why: The volume filter catches some of this, but the deeper problem is
that price moves in thin markets are noise, not information. The ZN move
doesn't mean anything about rates — it means someone hit a thin book.

How: Define liquid hours per product. Signal only during those hours.

**When ZN is driven by a factor that doesn't affect SR3**. Example:
Treasury auction supply shock (ZN cheapens on new supply, but SOFR is
unaffected). Or a convexity hedging event (mortgage servicers selling
ZN to hedge prepayment risk — purely a ZN supply/demand event).

Why: The model assumes a common factor drives both products. When the
ZN move comes from a ZN-only factor, SR3 will NOT follow, and the
signal produces a false positive.

How: This is the hardest case to filter automatically. Manual awareness
is needed: if you know an auction is happening, suppress. If convexity
hedging is active (typically during mortgage refi waves), be cautious.
Future enhancement: monitor specific ZN-only indicators and auto-suppress.

**When SR3 is moving first (reverse lead-lag)**. Around SOFR-fixing dates,
month-end, quarter-end, or when SR3 has its own supply/demand event, SR3
can lead ZN. The model's absorption check catches this (SR3 already moved
→ NEUTRAL), but if you know in advance that SR3 is likely to lead, it's
better to suppress signals entirely rather than rely on per-tick filtering.

**When both products are moving simultaneously with zero lag**. If the
lead-lag collapses to zero (both move at the same tick), there is no time
for the ASE to act. The signal fires but by the time it reaches the ASE,
the move is already done.

How: The response time distribution (TC3) will reveal this. If P25
response time < 1 second, the relationship is too fast to exploit.

---

## 14. Design Decision FAQ

### Why burst window of 3 seconds instead of longer?

The walkthrough exposed this: with τ=10 seconds and a 6-second lead-lag,
SR3 has already absorbed the move by the time the signal fires. The burst
window must be SHORTER than the lead-lag. At 3 seconds, ZN has moved
but SR3 hasn't started to respond yet (response starts at ~5-8 seconds).

The burst window is tunable and should be set to roughly:
    burst_window < median_response_time × 0.5

This ensures you're detecting the ZN event before SR3 reacts. If real data
shows a median response of 8 seconds, a 3-4 second burst is appropriate.
If response is faster (say 3 seconds), you'd need a 1-2 second burst.

### Why not use tick-level correlation?

The walkthrough caught this too. At 250ms tick resolution with a 6-second
lag, ZN(t) and SR3(t) are uncorrelated — because SR3(t) reflects ZN(t-24).
Computing concurrent correlation at tick level gives ρ ≈ 0.

Use 1-minute or 5-minute bar returns instead. The lag (6 seconds) becomes
a small fraction of the bar (10% of 1 minute, 2% of 5 minutes), so
concurrent correlation on bars captures the relationship correctly.

In real data: your PPT showed 98% correlation on 5-min candles. This is
the right timescale for correlation monitoring. The burst window operates
at tick level for detection; the correlation operates at bar level for
regime monitoring. These are intentionally different timescales.

### Why is the absorption check so important?

Without the absorption check, the model generates "buy SR3" signals after
SR3 has already moved up. You'd systematically enter late. The absorption
check asks: "has SR3 already captured most of the expected move?" If yes,
there is no remaining edge.

The threshold (70%) is deliberately generous. At 70% absorption, there's
only 30% of the expected move remaining — marginal edge. A stricter
threshold (e.g., 50%) would generate more signals but with thinner edge
per signal. Calibrate from real data by checking: at what absorption level
does the win rate cross 50%?

### Why 0.75 as the correlation threshold (not higher)?

0.75 is a conservative filter, not a quality target. At ρ=0.75, the
relationship still explains ~56% of variance (R²=0.56). The model doesn't
need perfect correlation — it needs the directional co-movement to be
reliable for the few seconds of the ASE fill window.

Think of it as: ρ=0.75 means "the products are still clearly moving
together." Below 0.75, the divergence is large enough that the ratio is
suspect and signals should be suppressed as a precaution.

In practice, if real data shows ρ between 0.85 and 0.98 during normal
periods, the 0.75 threshold only triggers during genuine regime breaks.
If ρ routinely dips below 0.85 during normal trading, the threshold
should be lowered — but this also means the model has less edge overall.

### Why cap at 6 ZN ticks (max_move)?

A move > 6 ticks in 3 seconds is not normal co-movement — it's a market
event. Events cause regime breaks, not smooth lead-lag. The model's CPT
may show high win rates for 5+ tick moves, but the win rate is unstable
(small sample, high variance, possible survivorship bias in backtesting).

The cap is a risk control: protect against catching a falling knife.
If ZN drops 8 ticks, the reason might be something that DOESN'T affect
SR3 (Treasury-specific) or something that will cause SR3 to overshoot
(panic selling). Either way, the model's ratio-based expectation is
unreliable.

Calibrate from data: check the CPT for moves > 6 ticks. If the win rate
stays high with low variance (100+ samples), the cap can be raised.

### Why shelf life of 20 seconds?

This comes from the response time distribution (P75). If 75% of SR3
responses happen within 15-20 seconds, then after 20 seconds the
expected move has either happened (no remaining edge) or isn't going
to happen (signal was wrong).

A stale signal is worse than no signal: it biases the ASE in a direction
that is no longer supported by evidence. The shelf life ensures signals
expire before they can do harm.

### Why three modes instead of just one?

The modes map to confidence levels because the cost of being wrong
differs:

- Mode 1 (soft bias): Nudges avoidance parameters. If wrong, the cost
  is slightly suboptimal spread positioning for a few seconds. Negligible.
- Mode 2 (ASE routing): Activates Buy-Only or Sell-Only ASEs. If wrong,
  you're only present on one side and miss fills on the other. Moderate
  opportunity cost.
- Mode 3 (hit trigger): Crosses the spread to enter. If wrong, you
  take an immediate payup loss. Direct cost.

Higher confidence justifies higher cost tolerance. Mode 3 should only
fire when the CPT shows > 75% directional probability — meaning the
payup cost is recovered by the edge more than 3 times out of 4.

### Why not trade the Treasury (ZN/ZT) directly?

Four reasons:

1. **DV01 mismatch**: ZN is $80/tick per lot, SR3 is $25/bp per lot.
   Hedging across these tenors introduces curve risk that you don't
   want for a 10-second hold.

2. **You're already running SR3 ASEs**: The signal improves execution
   of strategies you're already running. No new positions, no new risk.

3. **Execution edge is in SR3**: Your ASE infrastructure, rules, and
   parameter tuning are all built for SR3 markets. ZN execution would
   need its own infrastructure.

4. **The signal is low-frequency**: Maybe 10-30 signals per hour. Not
   enough for a standalone strategy, but perfect as an overlay on
   existing high-frequency ASE activity.

### Why not use the signal for Timer Logic expansion directly?

This is a Phase 2 enhancement. The signal could bias the expansion value:
when the signal says BUY with high confidence, increase expansion on buy
side (round more aggressively toward market). This amplifies the existing
Timer Logic mechanism rather than creating a new execution pathway.

The reason it's Phase 2: Timer Logic already has its own evidence
conditioning. Adding Treasury signals on top requires understanding the
interaction effects. If both Timer Logic evidence AND Treasury signal
say the same thing, they reinforce. If they disagree, you need a
priority rule. This interaction hasn't been tested yet.

### What if ZT gives a better signal than ZN?

This is why Phase 1 tests both in parallel. ZT (2-Year) is theoretically
closer to SOFR (both are short-end rates). ZN (10-Year) is more liquid
and may lead by more time (because it's a bigger, more actively traded
market).

The CPT will decide. If ZT shows:
- Higher same-direction rates (better signal quality)
- Longer response times (more time for ASE to act)
- More stable ratio (less recalibration needed)
- Fewer false positives

...then ZT wins. If ZN shows:
- Higher signal frequency (more ZN bursts to detect)
- Wider lead time (more comfortable action window)

...then ZN wins. It's possible both are useful at different times: ZT
for normal periods, ZN for volatile periods when ZT is too noisy.

### Is this just front-running the market?

No. Front-running implies using non-public information. This uses
publicly available, simultaneously visible price data. Both ZN and SR3
tick streams are available to every participant. The edge comes from:

1. Having infrastructure ready to act (ASE pre-configured)
2. Processing the signal faster than manual traders (code vs human)
3. Understanding when the signal is reliable (correlation regime)

This is a speed and preparedness advantage, not an information advantage.

---

## 15. Walkthrough Findings

Three bugs were caught by running synthetic data through the full pipeline
before touching real data. These findings are documented here because they
represent structural insights about the model, not just code fixes.

### Finding 1: Burst Window Must Be Shorter Than Lead-Lag

Original design: τ = 10 seconds (lookback for detecting ZN moves).
Problem: With 6-second lead-lag, SR3 absorbs the move within the
lookback window. Absorption check → 100% suppression → zero signals.

Fix: Use a 3-second burst window for move detection. The burst window
must be shorter than the lag, specifically:

    burst_window < median_response_time × 0.5

Root cause: The plan document described τ as a "lookback window" without
distinguishing between "move detection window" (should be short) and
"response evaluation window" (should be longer). These are different
timescales with different purposes.

### Finding 2: Tick-Level Correlation Is Zero for Lagged Relationships

Original design: Rolling ρ on tick-level (250ms) returns.
Problem: For a 6-second lag, ZN(t) and SR3(t) are measuring different
moments. Concurrent tick correlation ≈ 0 even when the relationship
is strong.

Fix: Compute correlation on 1-minute or 5-minute bar returns, where the
lag is small relative to the bar interval.

Root cause: Correlation is a measure of concurrent co-movement. For
lagged relationships, you need either: (a) cross-correlation at the
correct lag, or (b) coarser-grained returns where the lag washes out.
Approach (b) is simpler and sufficient for regime monitoring.

### Finding 3: Synthetic Data Underestimates Real Correlation

Synthetic data produced median ρ = 0.51. Real data (from PPT) shows
ρ = 0.98 on 5-min candles.

Why: Synthetic generator had 93% flat ticks and added independent noise.
Real markets have continuous price movement and more persistent
co-movement patterns.

Implication: The model parameters tuned on synthetic data will be
conservative. Real data will likely produce many more active signals
with higher confidence. The real calibration will be less about making
the model work and more about tightening the filters to manage signal
volume.

---

## 16. Known Limitations

### The model cannot tell you WHY the ratio changed

If the correlation drops, the model suppresses signals. It does not
diagnose whether the break is due to credit risk, curve repricing,
supply shock, or data error. Diagnosis requires fundamental context
that is outside the model's scope.

For the human operator: when the model goes silent (all NEUTRAL), check
the credit/macro dashboard. For the AI agent: flag "correlation break
at time T" and let the human decide whether to override.

### The CPT is backward-looking

The conditional probability table is built from historical data. If the
market microstructure changes (new participants, regulatory changes,
venue shifts), the CPT may become stale. Regular recalibration (weekly
or after any market structure event) is needed.

### The model has no view on magnitude

The signal says BUY or SELL, not "buy for 2 ticks of profit." The
magnitude of the expected SR3 move is estimated from the ratio, but
the actual P&L per signal depends on ASE fill quality, which is outside
the model's control.

### Small sample sizes for large moves

The CPT for 5+ tick moves may have < 100 samples (79 in the synthetic
walkthrough). This means the win rate estimate has high uncertainty.
Don't trust Mode 3 (hit trigger) for rarely-observed move sizes until
the sample is large enough (> 200 instances with standard error < 5%).

### The model assumes the market is one entity

In reality, different participants move ZN and SR3. A Treasury-only
event (auction, convexity hedge) moves ZN without affecting SR3. A
SOFR-specific event (Fed operations, repo stress) moves SR3 without
ZN. The model cannot distinguish these from normal co-movement.

The correlation filter catches the long-duration version of this
(sustained divergence → ρ drops). But a single isolated event within a
high-ρ regime can still produce a false positive.

### Latency matters more than accuracy

The model's edge decays rapidly — the response time distribution shows
most value in the first 5-15 seconds after a ZN move. If your .NET
application has 150-300ms latency processing the signal and routing it
to ASE, and the ASE has its own latency for adjusting quotes, the total
"signal to action" time might consume 1-3 seconds of the available
window. This is acceptable but means the implementation cannot add
unnecessary processing steps.

---

## 17. Operational Checklist

### Before enabling the signal each day

1. Check overnight credit/macro developments — any reason the ratio
   might have shifted? (TED spread move, repo rate unusual, curve
   steepener/flattener theme)
2. Verify ZN and SR3 are both in liquid state (bid-ask normal, depth
   normal, no pending data in next 5 minutes)
3. Confirm rolling ρ is in HIGH or MEDIUM regime from the prior
   session's close or this session's opening data
4. Set T_min threshold for the day (default unless unusual conditions)

### During the session

1. Monitor rolling ρ — if it drops to LOW, signals are auto-suppressed
   but also check WHY (manual awareness)
2. Track signal win rate in real-time — if it drops below 50% for 10+
   consecutive signals, pause and investigate
3. Watch for known signal-killer events: Treasury auctions (check
   calendar), FOMC communications (speeches, minutes), month/quarter-end
   flows
4. If the model is in Mode 2 or Mode 3, monitor total directional
   exposure — the signal creates a directional lean that compounds
   across contracts

### After the session

1. Record: number of signals, win rate, average response time, ρ
   range, which edge cases were hit
2. Compare today's CPT statistics to the historical CPT — any drift?
3. If win rate was below 50%, investigate: was there a specific event?
   A regime shift? A new pattern?
4. Update the CPT with today's data (append, don't replace — maintain
   the full history for trend analysis)

---

## Related

### Within Jarvis
- [[market-profiling/contract-segmentation]] — Contract groups the bias model operates across
- [[market-profiling/event-calendar-2026-2027]] — Events affecting bias signal timing
- [[fair-value/sofr-bootstrap-methodology]] — Complementary pricing methodology

### Knowledge Base
- [[knowledge-base/strategy/core-quad-leg-arbitrage]] — O-spread thesis this extends
- [[knowledge-base/strategy/execution-modifiers]] — B/S bias parameters this model modifies
- [[knowledge-base/ase-rules/ase-mechanics-and-parameters]] — ASE pipeline integration point
- [[knowledge-base/core/instruments-and-platform]] — SR3/ZN/ZT instrument specifications
- [[knowledge-base/ase-rules/custom-rules-production]] — HitMan/ASM rules the bias signal would trigger
