---
title: Valuation Engine Implementation Prompt
wp: WP-02
status: complete
created: 2026-03-29
last-updated: 2026-03-31
lines: 385
kb-depends:
  - knowledge-base/strategy/price-formulas-complete.md
jarvis-depends:
  - jarvis/fair-value/network-valuation-engine-plan.md
  - jarvis/fair-value/sofr-bootstrap-methodology.md
---

# Network Valuation Engine — Implementation Prompt

You are building a **Network Valuation Engine** for a STIR futures trader. This prompt contains everything you need: context, the finalized math model, assumed test data, test cases, edge cases, and deliverables. Execute top to bottom. Do not ask clarifying questions — all decisions have been made.

---

## Context (read, don't act on)

The trader trades US short-term interest rate futures: SR3 (3-month SOFR quarterly), SR1 (1-month SOFR monthly), ZQ (Fed Funds monthly). These instruments are connected by no-arbitrage equations: the price of a spread should equal the difference of its outright components, the price of a butterfly should equal the combination of its spreads, etc.

In reality, small deviations exist. The trader wants to identify which specific instruments are most mispriced relative to the network, so they can:
- Enter trades on mispriced contracts (buy undervalued, sell overvalued)
- Select better hedge legs (use instruments confirmed as fairly priced)
- Detect data feed errors (rogue contracts with extreme deviations)

The engine must process ~300 instruments in <1ms per full recalculation. It runs as a standalone process consuming live market data feeds. Latency target: <5ms end-to-end including data ingestion.

---

## The Math Model: Residual Attribution with Corroboration

### Inputs

For each instrument i, compute a **microprice** from live bid/ask data:

```
If (ask - bid) == 1 tick:
    microprice = (bid × askQty + ask × bidQty) / (bidQty + askQty)
If (ask - bid) == 2 ticks:
    microprice = (bid + ask) / 2
If (ask - bid) > 2 ticks:
    Mark instrument as ILLIQUID, exclude from all calculations
If bid >= ask (crossed market):
    Mark instrument as INVALID, exclude from all calculations
```

Tick size = 0.5 for all instruments in the test data.

### No-Arbitrage Equations

Each equation has the form: `Σ cⱼ × Pⱼ = 0` where cⱼ are integer coefficients and Pⱼ are observed microprices.

**Spread equation**: `O_A - O_B - P_{A-B} = 0`
- O_A, O_B are outright microprices
- P_{A-B} is the quoted spread microprice

**Butterfly equation**: `O_A - 2×O_B + O_C - P_{fly} = 0`
- P_{fly} is the quoted butterfly microprice

**Double butterfly equation**: `O_A - 3×O_B + 3×O_C - O_D - P_{dfly} = 0`
- P_{dfly} is the quoted double butterfly microprice

**Spread-from-spreads**: `P_{A-B} - P_{B-C} - P_{fly(A,B,C)} = 0`
- Connects two spreads to their parent butterfly

These are the fundamental equation types. The full equation set is generated from the instrument list — every listed spread/fly/dfly generates equations connecting it to its components.

### Blame Weights

Each instrument type has a **blame weight** (higher = less reliable = absorbs more blame when a residual is found):

| Type | Base Blame Weight | Rationale |
|------|------------------|-----------|
| Outright | 12 | Most volatile, least stable |
| Spread | 10 | Tighter range, actively traded |
| Butterfly (fly) | 5 | Very stable, moves rarely |
| Double butterfly (dfly) | 2 | Extremely stable |

**Dynamic modifiers** (multiplicative, applied per-instrument):
- **Spread width factor**: `1.0 + (spread_in_ticks - 1) × 0.3` — wider spread = less reliable microprice
- **Staleness factor**: `1.0 + staleness_seconds × 0.1` — stale data = less reliable (for test data, assume all instruments are fresh; implement the mechanism but set staleness to 0)

Effective blame weight = `base_weight × spread_width_factor × staleness_factor`

### Pass 0 — Rogue Detection

**Purpose**: Detect and quarantine equations with extreme residuals before scoring.

1. Compute residual for every equation: `r_e = Σ cⱼ × observed_microprice_j`
2. Compute robust statistics: `median_r = median(|all residuals|)`, `MAD = median(|r - median_r|)`, `σ_robust = 1.4826 × MAD`
3. Flag equation as ROGUE if: `|r_e| > 6 × σ_robust` OR `|r_e| > absolute_threshold`
   - `absolute_threshold` = 3.0 ticks (configurable)
4. Quarantined equations are excluded from Pass 1 and Pass 2
5. Instruments appearing ONLY in quarantined equations get flagged as "data suspect"
6. **Rogue instrument inference**: if ≥3 equations involving the same instrument are all quarantined, flag that instrument as the likely rogue source

### Pass 1 — Local Residual Attribution

For each surviving (non-quarantined) equation e:
- Participating instruments: `{i₁, ..., iₖ}` with coefficients `{c₁, ..., cₖ}` and effective blame weights `{w₁, ..., wₖ}`
- Total blame pool: `W = Σ wⱼ`
- Residual: `r_e = Σ cⱼ × microprice_j`

**Attribution for instrument j from equation e:**

```
δⱼ⁽ᵉ⁾ = (wⱼ / W) × (r_e / cⱼ)
```

**Sign convention:**
- Positive δ → instrument is overvalued (priced higher than the network implies it should be)
- Negative δ → instrument is undervalued (priced lower than the network implies)

**Why `r_e / cⱼ`:** The division by the coefficient converts equation-level residual into instrument-level mispricing. If an instrument has coefficient -2 (middle of a fly), it only needs to be off by half as much to explain the same residual. The sign flip is also correct: if the fly residual is positive, the middle leg (coefficient -2) being undervalued would explain it.

**Verification**: For each equation, the attributions must reconstruct the residual: `Σ cⱼ × δⱼ⁽ᵉ⁾ = r_e`. Include this as an assertion in the code.

### Pass 2 — Corroboration-Weighted Aggregation

Each instrument i collects all its attributed scores: `S_i = {δᵢ⁽¹⁾, δᵢ⁽²⁾, ..., δᵢ⁽ᵐ⁾}` from the m equations it participates in.

**Aggregation weight per equation:**
- Base weight = 1.0
- If equation residual `|r_e| < ε` (near-zero): multiply weight by `corroboration_factor`
- `ε = 0.1` ticks (configurable)
- `corroboration_factor = 2.5` (configurable)

**Final Score**: Weighted median of S_i using the aggregation weights above.

**Confidence**: 
```
agreement = (count of equations where sign of δ matches sign of final_score) / (total equations for this instrument)
corroboration_count = number of near-zero-residual equations for this instrument
confidence = min(1.0, agreement × (1 + 0.1 × corroboration_count))
```

**Minimum equation penalty**: Instruments in fewer than 2 equations get `confidence *= 0.5`

### Output

Per instrument, sorted by score ascending (most undervalued first):
```
{
  name: string,
  type: "outright" | "spread" | "fly" | "dfly",
  score: float,          // negative = undervalued, positive = overvalued
  confidence: float,     // 0.0 to 1.0
  equation_count: int,
  is_quarantined: bool,
  is_data_suspect: bool,
  contributing_equations: [{ equation_id, residual, attribution }]
}
```

---

## Test Data — Assumed Values

Use the following synthetic but realistic dataset. All prices in ticks (0.5 increments). Tick size = 0.5 for all instruments.

### Instruments (18 instruments)

**Outrights (6):**

| Name | Bid | Ask | BidQty | AskQty | Type |
|------|-----|-----|--------|--------|------|
| SR3_Sep25 | 95.750 | 95.755 | 500 | 300 | outright |
| SR3_Dec25 | 95.500 | 95.505 | 400 | 350 | outright |
| SR3_Mar26 | 95.250 | 95.255 | 350 | 400 | outright |
| SR3_Jun26 | 95.000 | 95.005 | 300 | 250 | outright |
| SR3_Sep26 | 94.750 | 94.755 | 200 | 180 | outright |
| SR3_Dec26 | 94.500 | 94.510 | 150 | 100 | outright |

Note: SR3_Dec26 has a 2-tick spread (0.010 = 2 × 0.005). All others have 1-tick spread.

**Spreads (5):**

| Name | Bid | Ask | BidQty | AskQty | Type | Components |
|------|-----|-----|--------|--------|------|------------|
| SP_Sep25_Dec25 | 0.245 | 0.250 | 600 | 500 | spread | SR3_Sep25 - SR3_Dec25 |
| SP_Dec25_Mar26 | 0.245 | 0.250 | 550 | 450 | spread | SR3_Dec25 - SR3_Mar26 |
| SP_Mar26_Jun26 | 0.250 | 0.255 | 500 | 400 | spread | SR3_Mar26 - SR3_Jun26 |
| SP_Jun26_Sep26 | 0.250 | 0.255 | 400 | 350 | spread | SR3_Jun26 - SR3_Sep26 |
| SP_Sep26_Dec26 | 0.250 | 0.255 | 300 | 250 | spread | SR3_Sep26 - SR3_Dec26 |

**Butterflies (4):**

| Name | Bid | Ask | BidQty | AskQty | Type | Components |
|------|-----|-----|--------|--------|------|------------|
| BF_Sep_Dec_Mar | 0.000 | 0.005 | 700 | 600 | fly | SR3_Sep25 - 2×SR3_Dec25 + SR3_Mar26 |
| BF_Dec_Mar_Jun | 0.000 | 0.005 | 650 | 550 | fly | SR3_Dec25 - 2×SR3_Mar26 + SR3_Jun26 |
| BF_Mar_Jun_Sep | -0.005 | 0.000 | 600 | 500 | fly | SR3_Mar26 - 2×SR3_Jun26 + SR3_Sep26 |
| BF_Jun_Sep_Dec | -0.005 | 0.000 | 500 | 400 | fly | SR3_Jun26 - 2×SR3_Sep26 + SR3_Dec26 |

**Double Butterflies (3):**

| Name | Bid | Ask | BidQty | AskQty | Type | Components |
|------|-----|-----|--------|--------|------|------------|
| DF_Sep_Dec_Mar_Jun | 0.000 | 0.005 | 800 | 700 | dfly | SR3_Sep25 - 3×SR3_Dec25 + 3×SR3_Mar26 - SR3_Jun26 |
| DF_Dec_Mar_Jun_Sep | 0.000 | 0.005 | 750 | 650 | dfly | SR3_Dec25 - 3×SR3_Mar26 + 3×SR3_Jun26 - SR3_Sep26 |
| DF_Mar_Jun_Sep_Dec | 0.000 | 0.005 | 700 | 600 | dfly | SR3_Mar26 - 3×SR3_Jun26 + 3×SR3_Sep26 - SR3_Dec26 |

### Equations (16 equations)

Generate all applicable equations from the instrument list:

**Type 1: Spread = Outright difference (5 equations)**
```
EQ01: SR3_Sep25 - SR3_Dec25 - SP_Sep25_Dec25 = 0
EQ02: SR3_Dec25 - SR3_Mar26 - SP_Dec25_Mar26 = 0
EQ03: SR3_Mar26 - SR3_Jun26 - SP_Mar26_Jun26 = 0
EQ04: SR3_Jun26 - SR3_Sep26 - SP_Jun26_Sep26 = 0
EQ05: SR3_Sep26 - SR3_Dec26 - SP_Sep26_Dec26 = 0
```

**Type 2: Butterfly = Outright combination (4 equations)**
```
EQ06: SR3_Sep25 - 2×SR3_Dec25 + SR3_Mar26 - BF_Sep_Dec_Mar = 0
EQ07: SR3_Dec25 - 2×SR3_Mar26 + SR3_Jun26 - BF_Dec_Mar_Jun = 0
EQ08: SR3_Mar26 - 2×SR3_Jun26 + SR3_Sep26 - BF_Mar_Jun_Sep = 0
EQ09: SR3_Jun26 - 2×SR3_Sep26 + SR3_Dec26 - BF_Jun_Sep_Dec = 0
```

**Type 3: Butterfly = Spread difference (4 equations)**
```
EQ10: SP_Sep25_Dec25 - SP_Dec25_Mar26 - BF_Sep_Dec_Mar = 0
EQ11: SP_Dec25_Mar26 - SP_Mar26_Jun26 - BF_Dec_Mar_Jun = 0
EQ12: SP_Mar26_Jun26 - SP_Jun26_Sep26 - BF_Mar_Jun_Sep = 0
EQ13: SP_Jun26_Sep26 - SP_Sep26_Dec26 - BF_Jun_Sep_Dec = 0
```

**Type 4: Double butterfly = Outright combination (3 equations)**
```
EQ14: SR3_Sep25 - 3×SR3_Dec25 + 3×SR3_Mar26 - SR3_Jun26 - DF_Sep_Dec_Mar_Jun = 0
EQ15: SR3_Dec25 - 3×SR3_Mar26 + 3×SR3_Jun26 - SR3_Sep26 - DF_Dec_Mar_Jun_Sep = 0
EQ16: SR3_Mar26 - 3×SR3_Jun26 + 3×SR3_Sep26 - SR3_Dec26 - DF_Mar_Jun_Sep_Dec = 0
```

---

## Test Cases to Implement and Verify

### Test 1: Baseline — All Fair (no mispricing)

Set all instrument prices to be perfectly consistent with the equations. All residuals should be 0 (or very near 0 due to microprice rounding). All scores should be ~0. All confidence values should be 1.0 (all equations corroborate).

**Purpose**: Verify the engine produces zero scores when there's nothing to find.

### Test 2: Single Outright Mispriced

Take the baseline and shift SR3_Dec25 bid/ask up by 1 tick (0.005 each). This should:
- Create non-zero residuals in all equations containing SR3_Dec25 (EQ01, EQ02, EQ06, EQ07, EQ09, EQ14, EQ15 — 7 equations)
- SR3_Dec25 should get the highest overvalued score
- Neighboring outrights (SR3_Sep25, SR3_Mar26) should get mild undervalued scores (they're connected but not the source)
- Spreads and flies should get small scores (less blame due to lower blame weights)
- Equations NOT containing SR3_Dec25 should remain near-zero, corroborating the instruments in those equations

**Purpose**: Verify that a single mispriced instrument gets correctly identified and the blame is concentrated on it.

### Test 3: Spread Mispriced (not outright)

Take the baseline and shift SP_Dec25_Mar26 bid/ask up by 1 tick. This should:
- Create non-zero residuals only in equations containing SP_Dec25_Mar26 (EQ02, EQ10, EQ11)
- SP_Dec25_Mar26 gets the highest overvalued score
- SR3_Dec25 and SR3_Mar26 get mild undervalued scores from EQ02, but are corroborated by their other equations → net scores should be small
- BF_Sep_Dec_Mar and BF_Dec_Mar_Jun get small scores from EQ10 and EQ11

**Purpose**: Verify that mispricing in a spread (not an outright) is correctly attributed to the spread, and outrights are protected by corroboration.

### Test 4: Conflict Resolution

Shift SR3_Mar26 up by 1 tick AND shift SP_Mar26_Jun26 down by 1 tick simultaneously. SR3_Mar26 appears overvalued from some equations, undervalued from others (because the spread shift creates a conflicting signal). The confidence for SR3_Mar26 should be LOW (conflicting signals). The engine should not produce a high-confidence score for a genuinely ambiguous situation.

**Purpose**: Verify that conflicting signals result in low confidence, not a false high-confidence score.

### Test 5: Rogue Detection

Shift SR3_Sep25 by 10 ticks (way beyond normal). Equations containing SR3_Sep25 should have extreme residuals that trigger the rogue detection threshold (>3 ticks absolute). These equations should be quarantined. SR3_Sep25 should be flagged as data suspect (multiple quarantined equations involving it). All other instruments should be scored normally using only the non-quarantined equations.

**Purpose**: Verify that extreme mispricings are quarantined, not allowed to pollute the scores of connected instruments.

### Test 6: Illiquid Instrument

Set SR3_Dec26 bid-ask spread to 3 ticks (>2 tick threshold). SR3_Dec26 should be marked ILLIQUID and excluded. All equations containing SR3_Dec26 (EQ05, EQ09, EQ16) should be excluded. Remaining instruments scored normally.

**Purpose**: Verify graceful handling of illiquid instruments.

### Test 7: Corroboration Effect (Scenario 2 from design)

Using the test data values above (which already embed small realistic mispricings): verify that instruments participating in more near-zero-residual equations get scores pulled closer to zero (the corroboration effect). Specifically compare scores of instruments with many equation connections (like SR3_Mar26, which appears in many equations) vs. instruments with few (like SR3_Dec26 which appears in fewer after illiquidity handling).

**Purpose**: Verify the corroboration weighting is working and not just averaging.

### Test 8: Performance Benchmark

Run the full calculation 10,000 times and report mean and p99 latency. Target: mean <0.5ms, p99 <1ms for the 18-instrument dataset. Extrapolate to 300 instruments (should be roughly linear in equation count).

**Purpose**: Confirm the model meets the <1ms latency requirement.

---

## Edge Cases to Handle

1. **All equations quarantined**: If rogue detection quarantines everything, output empty scores with a warning, not a crash.
2. **Instrument in zero equations after quarantine**: Score = 0, confidence = 0, flagged as "insufficient data".
3. **Division by zero in coefficient**: Should never happen (coefficients are nonzero by construction), but assert and handle gracefully.
4. **All instruments illiquid**: Return empty output with warning.
5. **Single equation for an instrument**: Score comes from one equation only — apply the 0.5× confidence penalty.
6. **Weighted median with all-zero weights**: If all equation weights are 0 (shouldn't happen), fall back to simple median.
7. **Negative blame weight after modifiers**: Clamp to minimum of 0.1.

---

## Deliverables (in order)

### Deliverable 1: Data Structures and Microprice Calculation
Define all data structures (Instrument, Equation, ValuationResult). Implement microprice calculation with the 1-tick/2-tick/illiquid logic. Load the test data. Print all microprices. Verify microprice for SR3_Dec26 uses midpoint formula (2-tick spread).

### Deliverable 2: Equation Definition and Residual Computation
Define all 16 equations with their coefficients. Compute and print all residuals from the test data microprices. This is the raw state of the network — some residuals will be near-zero, others will show small mispricings from the assumed test data.

### Deliverable 3: Pass 0 — Rogue Detection
Implement MAD-based rogue detection. Run on baseline residuals (no rogues expected). Then run Test 5 (10-tick shift) and verify the rogue is caught and quarantined.

### Deliverable 4: Pass 1 — Local Attribution
Implement the attribution formula `δⱼ = (wⱼ/W) × (r_e/cⱼ)`. Include the reconstruction assertion (`Σ cⱼ × δⱼ = r_e` for every equation). Run on the test data and print all attributions per equation.

### Deliverable 5: Pass 2 — Aggregation
Implement corroboration-weighted median and confidence calculation. Run the full 3-pass pipeline on the test data. Print the final ranked output.

### Deliverable 6: All Test Cases
Run Tests 1 through 7. For each test, print:
- The perturbation applied
- All equation residuals
- Any quarantined equations/instruments
- The final ranked output
- Whether the test PASSED or FAILED against the expected behavior described above

### Deliverable 7: Performance Benchmark
Run Test 8. Report timing.

### Deliverable 8: Final Clean Implementation
Refactor into a clean, well-commented module with:
- Clear separation: data loading → microprice → equations → pass0 → pass1 → pass2 → output
- All configurable parameters (blame weights, thresholds, corroboration_factor, ε) as constants at the top
- A `run_valuation(instruments, equations, config) → List[ValuationResult]` entry point
- Type hints throughout
- Docstrings on all public functions

---

## Implementation Language

**Primary: Python** (for rapid iteration, testing, and verification).

Use only standard library + numpy (for performance). No pandas, no external dependencies beyond numpy. The code must be self-contained in a single file.

After the Python implementation is verified, a C# port will be done in a separate session.

---

## Assumptions and Limitations

1. **Blame weights are initial estimates.** The 12:10:5:2 ratio is a starting point based on domain knowledge. These will be calibrated from historical data in a later phase. The model's ranking should be directionally correct even if the exact weights are wrong.

2. **Microprice is a simplification.** The VWAP microprice from top-of-book bid/ask/qty is a reasonable but imperfect estimate of fair value. More sophisticated microprice models (order flow, trade-weighted) will be evaluated in a later phase.

3. **Static blame weights per type.** In reality, some outrights are more liquid than others. The spread_width_factor and staleness_factor partially address this, but a fully per-instrument learned weight would be better. Deferred to calibration phase.

4. **No cross-product equations in test data.** The test data only has SR3 outrights/spreads/flies/dflies. In production, cross-product equations (SR1-ZQ, SR3-SR1) will be added. The model handles arbitrary equations — no code changes needed, just a larger equation set.

5. **Weighted median is O(n log n) per instrument.** For instruments in many equations (say 15), this is negligible. For 300 instruments × 15 equations average, total aggregation is ~4,500 median computations — well within budget.

6. **Corroboration factor (2.5) and ε (0.1 ticks) are tunable.** They significantly affect how much "protection" corroborated instruments get. If the model is too conservative (everything scores near zero), reduce corroboration_factor. If too aggressive (noisy scores), increase it.

7. **The model identifies relative mispricing, not absolute.** It cannot tell you if the entire curve is 5 ticks too high — it only sees deviations from internal consistency. This is by design: the trader's edge is in relative value, not in predicting the level.

---

## Do not:
- Ask clarifying questions. All decisions are made above.
- Use external APIs or web fetches. All data is provided.
- Create visualizations or diagrams. Focus on code and test results.
- Over-engineer. This is a reference implementation for verification, not production code.
- Skip any test case. All 8 tests must run and report results.

## Related

### Within Jarvis
- [[fair-value/network-valuation-engine-plan]] — Plan this prompt implements
- [[fair-value/sofr-bootstrap-methodology]] — Curve methodology feeding this engine

### Knowledge Base
- [[knowledge-base/strategy/price-formulas-complete]] — Microprice definitions ensuring consistency
