#!/usr/bin/env python3
"""
sofr_bootstrap_fair_value.py
============================
SOFR Curve Bootstrap & O-Spread Fair Value Calculator

Bootstraps SOFR and Fed Funds discount curves from futures + OIS market
data, then computes implied SR3 fair values via forward rate decomposition.

Core identity exploited:
    SR3_rate = compounded_daily_SOFR(IMM_start, IMM_end)

    This 3-month compounded rate can be recovered from the SOFR discount
    curve as a single forward rate.  When the curve is bootstrapped from
    SR1 (1-month SOFR) futures, the implied SR3 deviates from the market
    SR3 by exactly the mispricing the O-spread strategy captures.

O-spread price convention (ASE units):
    Leg_k = PriceMult × (SR1_k_price − SR3_price),  PriceMult = 100
    O     = Leg_near + Leg_far
          = 100 × (SR1_near + SR1_far − 2 × SR3)

    Fair value replaces SR3_market with SR3_implied from the curve.

Downstream consumers:
    WP-07  Dynamic Avoidance Model   — curve-derived fair value reference
    WP-13  Pricing Engine Prototype   — FairValueProvider interface

Usage:
    python sofr_bootstrap_fair_value.py

    In production, replace the MARKET_DATA dict with a live feed adapter.
"""

import QuantLib as ql
from dataclasses import dataclass, field
from typing import List, Tuple, Optional, Dict
import sys

# ═══════════════════════════════════════════════════════════════════════
# 1. CONFIGURATION
# ═══════════════════════════════════════════════════════════════════════

EVAL_DATE = ql.Date(28, 3, 2026)  # Most recent business day

# Calendars and day counts
SOFR_CALENDAR = ql.UnitedStates(ql.UnitedStates.SOFR)
FF_CALENDAR   = ql.UnitedStates(ql.UnitedStates.GovernmentBond)
RATE_DC       = ql.Actual360()      # SOFR / FF rate convention
CURVE_DC      = ql.Actual365Fixed() # Curve time-axis convention
PRICE_MULT    = 100                 # ASE price multiplier

# Bootstrap method: Discount trait + LogCubic interpolation
# Chosen for smoothness and positivity of discount factors.
# Alternative: PiecewiseLinearZero — simpler, piecewise-linear zero rates,
# but can produce kinks in forward rates at pillar boundaries.
BOOTSTRAP_CLASS = ql.PiecewiseLogCubicDiscount


# ═══════════════════════════════════════════════════════════════════════
# 2. MARKET DATA  (placeholder — replace with live feed)
# ═══════════════════════════════════════════════════════════════════════
# Rates in decimal (0.0430 = 4.30%).  Futures prices = 100 − rate.
# The data below is illustrative.  Values are internally consistent
# but do not represent any actual market snapshot.

MARKET_DATA = {
    # ── Overnight fixings ──
    "sofr_overnight": 0.0430,
    "ff_overnight":   0.0428,

    # ── SR1 futures (1-Month SOFR) ──
    # (month, year, price)
    "sr1_futures": [
        (4,  2026, 95.700),   # Apr26  4.300%
        (5,  2026, 95.725),   # May26  4.275%
        (6,  2026, 95.775),   # Jun26  4.225%
        (7,  2026, 95.850),   # Jul26  4.150%
        (8,  2026, 95.925),   # Aug26  4.075%
        (9,  2026, 96.000),   # Sep26  4.000%
        (10, 2026, 96.075),   # Oct26  3.925%
        (11, 2026, 96.125),   # Nov26  3.875%
        (12, 2026, 96.175),   # Dec26  3.825%
        (1,  2027, 96.225),   # Jan27  3.775%
        (2,  2027, 96.250),   # Feb27  3.750%
        (3,  2027, 96.275),   # Mar27  3.725%
    ],

    # ── SR3 futures (3-Month SOFR quarterly, MARKET prices) ──
    # These are NOT curve inputs — they're what we compare against.
    "sr3_futures": [
        (3,  2026, 95.715),   # H6  Mar26
        (6,  2026, 95.855),   # M6  Jun26
        (9,  2026, 96.035),   # U6  Sep26
        (12, 2026, 96.150),   # Z6  Dec26
    ],

    # ── ZQ futures (30-Day Fed Funds) ──
    "zq_futures": [
        (4,  2026, 95.720),
        (5,  2026, 95.745),
        (6,  2026, 95.800),
        (7,  2026, 95.875),
        (8,  2026, 95.950),
        (9,  2026, 96.025),
        (10, 2026, 96.100),
        (11, 2026, 96.150),
        (12, 2026, 96.200),
        (1,  2027, 96.250),
        (2,  2027, 96.275),
        (3,  2027, 96.300),
    ],

    # ── OIS swaps (extending curves beyond futures strip) ──
    "sofr_ois": [
        (ql.Period(2, ql.Years), 0.0395),
        (ql.Period(3, ql.Years), 0.0380),
        (ql.Period(5, ql.Years), 0.0370),
    ],
    "ff_ois": [
        (ql.Period(2, ql.Years), 0.0393),
        (ql.Period(3, ql.Years), 0.0378),
        (ql.Period(5, ql.Years), 0.0368),
    ],
}


# ═══════════════════════════════════════════════════════════════════════
# 3. EXPIRY GROUP DEFINITIONS
# ═══════════════════════════════════════════════════════════════════════

@dataclass
class ExpiryGroup:
    """One quarterly O-spread expiry group."""
    name: str
    # IMM codes for date resolution
    sr3_imm_code: str       # e.g. "H6" for Mar26
    sr3_next_imm_code: str  # e.g. "M6" for Jun26 (end of SR3 period)
    sr3_imm_ref_year: int   # year hint for IMM.date()
    sr3_next_ref_year: int
    # Which SR1 months are the near and far legs
    sr1_near_month: int
    sr1_near_year: int
    sr1_far_month: int
    sr1_far_year: int
    # Which SR3 market data index to use
    sr3_market_idx: int

    # ── Resolved dates (populated by resolve()) ──
    sr3_start: Optional[ql.Date] = field(default=None, repr=False)
    sr3_end:   Optional[ql.Date] = field(default=None, repr=False)

    def resolve(self):
        """Compute IMM reference period dates."""
        self.sr3_start = ql.IMM.date(
            self.sr3_imm_code, ql.Date(1, 1, self.sr3_imm_ref_year))
        self.sr3_end = ql.IMM.date(
            self.sr3_next_imm_code, ql.Date(1, 1, self.sr3_next_ref_year))


# The four active expiry groups per core-quad-leg-arbitrage.md §4.
EXPIRY_GROUPS = [
    ExpiryGroup("Mar26", "H6", "M6", 2026, 2026,
                sr1_near_month=4, sr1_near_year=2026,
                sr1_far_month=5,  sr1_far_year=2026,
                sr3_market_idx=0),
    ExpiryGroup("Jun26", "M6", "U6", 2026, 2026,
                sr1_near_month=7, sr1_near_year=2026,
                sr1_far_month=8,  sr1_far_year=2026,
                sr3_market_idx=1),
    ExpiryGroup("Sep26", "U6", "Z6", 2026, 2026,
                sr1_near_month=10, sr1_near_year=2026,
                sr1_far_month=11,  sr1_far_year=2026,
                sr3_market_idx=2),
    ExpiryGroup("Dec26", "Z6", "H7", 2026, 2027,
                sr1_near_month=1, sr1_near_year=2027,
                sr1_far_month=2,  sr1_far_year=2027,
                sr3_market_idx=3),
]


# ═══════════════════════════════════════════════════════════════════════
# 4. DATE UTILITIES
# ═══════════════════════════════════════════════════════════════════════

def first_bday(month: int, year: int, cal: ql.Calendar) -> ql.Date:
    """First good business day of the given calendar month."""
    return cal.adjust(ql.Date(1, month, year), ql.Following)


def last_bday(month: int, year: int, cal: ql.Calendar) -> ql.Date:
    """Last good business day of the given calendar month."""
    if month == 12:
        eom = ql.Date(31, 12, year)
    else:
        eom = ql.Date(1, month + 1, year) - 1
    return cal.adjust(eom, ql.Preceding)


def sr1_reference_period(month: int, year: int) -> Tuple[ql.Date, ql.Date]:
    """CME SR1 contract reference period = calendar month boundaries."""
    return first_bday(month, year, SOFR_CALENDAR), last_bday(month, year, SOFR_CALENDAR)


def zq_reference_period(month: int, year: int) -> Tuple[ql.Date, ql.Date]:
    """CME ZQ contract reference period = calendar month boundaries."""
    return first_bday(month, year, FF_CALENDAR), last_bday(month, year, FF_CALENDAR)


def decompose_imm_quarter(sr3_start: ql.Date, sr3_end: ql.Date
                          ) -> List[Tuple[str, ql.Date, ql.Date]]:
    """
    Split an SR3 IMM quarter into contiguous monthly sub-periods.

    Boundaries are placed at the first SOFR business day of each
    calendar month.  This guarantees contiguity: the end date of
    sub-period N is the start date of sub-period N+1.

    Returns list of (label, start, end).
    """
    periods = []
    current = sr3_start
    while current < sr3_end:
        # Next month boundary
        m = current.month() + 1
        y = current.year()
        if m > 12:
            m, y = 1, y + 1
        next_boundary = SOFR_CALENDAR.adjust(ql.Date(1, m, y), ql.Following)
        end = min(next_boundary, sr3_end)

        # Label: "Stub" for partial months, full month name otherwise
        if current == sr3_start and current.dayOfMonth() > 1:
            label = f"Stub {current.month()}/{current.year()}"
        elif end == sr3_end and end.dayOfMonth() < 25:
            label = f"Stub {end.month()}/{end.year()}"
        else:
            label = f"{current.month()}/{current.year()}"
        periods.append((label, current, end))
        current = end
    return periods


# ═══════════════════════════════════════════════════════════════════════
# 5. CURVE CONSTRUCTION
# ═══════════════════════════════════════════════════════════════════════

def build_sofr_curve(eval_date: ql.Date, mkt: dict) -> ql.YieldTermStructure:
    """
    Bootstrap a SOFR discount curve from:
      1. Overnight deposit   (very short end)
      2. SR1 futures         (1–12 month strip)
      3. OIS swaps           (2Y+ extension)

    SR3 futures are deliberately EXCLUDED so the curve is independent
    of the instrument we're pricing.  This avoids circularity: the
    curve tells us what SR3 *should* be, not what it *is*.

    Returns: PiecewiseLogCubicDiscount YieldTermStructure
    """
    sofr = ql.Sofr()
    helpers = []

    # ── Overnight deposit (T+0, 1 day) ──
    helpers.append(ql.DepositRateHelper(
        ql.QuoteHandle(ql.SimpleQuote(mkt["sofr_overnight"])),
        ql.Period(1, ql.Days),
        0,                   # settlement days (T+0 for SOFR)
        SOFR_CALENDAR,
        ql.Following,
        False,               # end-of-month
        RATE_DC))

    # ── SR1 futures (1-Month SOFR) ──
    for month, year, price in mkt["sr1_futures"]:
        start, end = sr1_reference_period(month, year)
        if end <= eval_date:
            continue  # skip expired contracts
        helpers.append(ql.OvernightIndexFutureRateHelper(
            ql.QuoteHandle(ql.SimpleQuote(price)),
            start, end, sofr))

    # ── OIS swaps (extending the curve) ──
    for tenor, rate in mkt["sofr_ois"]:
        helpers.append(ql.OISRateHelper(
            2,           # T+2 settlement
            tenor,
            ql.QuoteHandle(ql.SimpleQuote(rate)),
            sofr))

    curve = BOOTSTRAP_CLASS(eval_date, helpers, CURVE_DC)
    curve.enableExtrapolation()
    return curve


def build_ff_curve(eval_date: ql.Date, mkt: dict) -> ql.YieldTermStructure:
    """
    Bootstrap a Fed Funds discount curve from:
      1. Overnight deposit
      2. ZQ futures (30-Day Fed Funds)
      3. FF OIS swaps

    Mirrors the SOFR curve construction but using FedFunds index.
    """
    ff = ql.FedFunds()
    helpers = []

    helpers.append(ql.DepositRateHelper(
        ql.QuoteHandle(ql.SimpleQuote(mkt["ff_overnight"])),
        ql.Period(1, ql.Days),
        0,
        FF_CALENDAR,
        ql.Following,
        False,
        RATE_DC))

    for month, year, price in mkt["zq_futures"]:
        start, end = zq_reference_period(month, year)
        if end <= eval_date:
            continue
        helpers.append(ql.OvernightIndexFutureRateHelper(
            ql.QuoteHandle(ql.SimpleQuote(price)),
            start, end, ff))

    for tenor, rate in mkt["ff_ois"]:
        helpers.append(ql.OISRateHelper(
            2, tenor,
            ql.QuoteHandle(ql.SimpleQuote(rate)),
            ff))

    curve = BOOTSTRAP_CLASS(eval_date, helpers, CURVE_DC)
    curve.enableExtrapolation()
    return curve


# ═══════════════════════════════════════════════════════════════════════
# 6. FORWARD RATE EXTRACTION
# ═══════════════════════════════════════════════════════════════════════

def forward_rate(curve: ql.YieldTermStructure,
                 start: ql.Date, end: ql.Date) -> float:
    """
    Simple forward rate between two dates, Act/360.

    Computed from discount factors:
        r = (DF(start)/DF(end) − 1) / τ

    This is exact — no interpolation error beyond what's in the curve.
    """
    df_s = curve.discount(start)
    df_e = curve.discount(end)
    tau = RATE_DC.yearFraction(start, end)
    if tau <= 0:
        return 0.0
    return (df_s / df_e - 1.0) / tau


def implied_sr3_rate(curve: ql.YieldTermStructure,
                     sr3_start: ql.Date, sr3_end: ql.Date,
                     eval_date: ql.Date) -> float:
    """
    Implied 3-month compounded SOFR rate for the SR3 reference period.

    For contracts whose reference period has already started (sr3_start
    < eval_date), this computes the forward rate over the REMAINING
    period only.  A production implementation would incorporate realized
    SOFR fixings for the elapsed portion and blend them with the forward
    rate for the remainder.

    Simplification flag: if sr3_start < eval_date, the output covers
    only [eval_date, sr3_end] and the caller should note the partial
    coverage.
    """
    effective_start = max(sr3_start, eval_date)
    return forward_rate(curve, effective_start, sr3_end)


def implied_sr1_rate(curve: ql.YieldTermStructure,
                     month: int, year: int) -> float:
    """Implied rate for a calendar month (matching SR1 reference period)."""
    start, end = sr1_reference_period(month, year)
    return forward_rate(curve, start, end)


def implied_zq_rate(curve: ql.YieldTermStructure,
                    month: int, year: int) -> float:
    """Implied rate for a calendar month (matching ZQ reference period)."""
    start, end = zq_reference_period(month, year)
    return forward_rate(curve, start, end)


# ═══════════════════════════════════════════════════════════════════════
# 7. O-SPREAD FAIR VALUE
# ═══════════════════════════════════════════════════════════════════════

@dataclass
class GroupResult:
    """Full result set for one expiry group."""
    name: str
    partially_fixed: bool

    # SR3
    sr3_market_price: float
    sr3_implied_price: float
    sr3_market_rate: float
    sr3_implied_rate: float
    sr3_rich_cheap_bp: float   # market rate − implied rate, in bp

    # SR1 near
    sr1_near_market_price: float
    sr1_near_implied_rate: float

    # SR1 far
    sr1_far_market_price: float
    sr1_far_implied_rate: float

    # O spread
    o_market: float        # ASE units (PriceMult × price diff)
    o_fair: float          # curve-derived fair value in same units
    o_edge: float          # o_market − o_fair

    # SR1-ZQ basis (SOFR − FF) for each month, in bp
    basis_near_bp: float
    basis_far_bp: float

    # Sub-period decomposition
    sub_periods: List[Tuple[str, float]] = field(default_factory=list)


def compute_group(group: ExpiryGroup,
                  sofr_curve: ql.YieldTermStructure,
                  ff_curve: ql.YieldTermStructure,
                  mkt: dict,
                  eval_date: ql.Date) -> GroupResult:
    """Compute all fair value metrics for one expiry group."""

    group.resolve()
    partially_fixed = (group.sr3_start < eval_date)

    # ── SR3 implied ──
    sr3_impl = implied_sr3_rate(sofr_curve, group.sr3_start, group.sr3_end,
                                eval_date)
    sr3_impl_price = 100.0 - sr3_impl * 100.0

    sr3_mkt_price = mkt["sr3_futures"][group.sr3_market_idx][2]
    sr3_mkt_rate  = (100.0 - sr3_mkt_price) / 100.0

    # Rich/cheap: positive = market prices a higher rate than curve implies
    #             → SR3 is cheap (good to buy) / O spread is rich (good to sell)
    sr3_rc_bp = (sr3_mkt_rate - sr3_impl) * 10000.0

    # ── SR1 implied (should closely match market since SR1 is a curve input) ──
    sr1_near_impl = implied_sr1_rate(sofr_curve,
                                     group.sr1_near_month, group.sr1_near_year)
    sr1_far_impl  = implied_sr1_rate(sofr_curve,
                                     group.sr1_far_month, group.sr1_far_year)

    # Find SR1 market prices from futures strip
    sr1_near_mkt = _find_futures_price(mkt["sr1_futures"],
                                       group.sr1_near_month, group.sr1_near_year)
    sr1_far_mkt  = _find_futures_price(mkt["sr1_futures"],
                                       group.sr1_far_month, group.sr1_far_year)

    # ── O spread ──
    # O = PriceMult × (SR1_near + SR1_far − 2 × SR3)
    o_mkt  = PRICE_MULT * (sr1_near_mkt + sr1_far_mkt - 2.0 * sr3_mkt_price)
    o_fair = PRICE_MULT * (sr1_near_mkt + sr1_far_mkt - 2.0 * sr3_impl_price)
    # Note: o_fair uses market SR1 (not implied) because SR1 IS the curve
    # input.  The only degree of freedom is SR3_implied.

    # ── SR1-ZQ basis per month ──
    sofr_near = implied_sr1_rate(sofr_curve,
                                 group.sr1_near_month, group.sr1_near_year)
    sofr_far  = implied_sr1_rate(sofr_curve,
                                 group.sr1_far_month, group.sr1_far_year)
    ff_near   = implied_zq_rate(ff_curve,
                                group.sr1_near_month, group.sr1_near_year)
    ff_far    = implied_zq_rate(ff_curve,
                                group.sr1_far_month, group.sr1_far_year)

    basis_near = (sofr_near - ff_near) * 10000.0
    basis_far  = (sofr_far  - ff_far)  * 10000.0

    # ── Sub-period decomposition (diagnostic) ──
    effective_start = max(group.sr3_start, eval_date)
    sub_periods_raw = decompose_imm_quarter(effective_start, group.sr3_end)
    sub_periods = []
    for label, s, e in sub_periods_raw:
        r = forward_rate(sofr_curve, s, e)
        sub_periods.append((label, r))

    return GroupResult(
        name=group.name,
        partially_fixed=partially_fixed,
        sr3_market_price=sr3_mkt_price,
        sr3_implied_price=sr3_impl_price,
        sr3_market_rate=sr3_mkt_rate,
        sr3_implied_rate=sr3_impl,
        sr3_rich_cheap_bp=sr3_rc_bp,
        sr1_near_market_price=sr1_near_mkt,
        sr1_near_implied_rate=sr1_near_impl,
        sr1_far_market_price=sr1_far_mkt,
        sr1_far_implied_rate=sr1_far_impl,
        o_market=o_mkt,
        o_fair=o_fair,
        o_edge=o_mkt - o_fair,
        basis_near_bp=basis_near,
        basis_far_bp=basis_far,
        sub_periods=sub_periods,
    )


def _find_futures_price(futures_list, month, year) -> float:
    """Look up a futures price by month/year from the market data list."""
    for m, y, px in futures_list:
        if m == month and y == year:
            return px
    raise ValueError(f"No futures data for {month}/{year}")


# ═══════════════════════════════════════════════════════════════════════
# 8. OUTPUT FORMATTING
# ═══════════════════════════════════════════════════════════════════════

def print_curve_diagnostics(label: str, curve: ql.YieldTermStructure,
                            eval_date: ql.Date):
    """Print discount factors and zero rates at selected tenors."""
    print(f"\n{'─'*60}")
    print(f"  {label} Curve Diagnostics")
    print(f"{'─'*60}")
    print(f"  {'Tenor':<8} {'Date':<22} {'DF':>10} {'Zero Rate':>10}")
    print(f"  {'─'*8} {'─'*22} {'─'*10} {'─'*10}")
    for months in [1, 2, 3, 6, 9, 12, 18, 24]:
        d = SOFR_CALENDAR.advance(eval_date, ql.Period(months, ql.Months))
        df = curve.discount(d)
        zr = curve.zeroRate(d, RATE_DC, ql.Continuous).rate()
        print(f"  {months:>3}M     {str(d):<22} {df:>10.7f} {zr*100:>9.4f}%")


def print_group_result(r: GroupResult):
    """Print results for one expiry group."""
    flag = " [PARTIAL]" if r.partially_fixed else ""
    print(f"\n{'═'*60}")
    print(f"  {r.name} Expiry Group{flag}")
    print(f"{'═'*60}")

    print(f"\n  SR3 Contract:")
    print(f"    Market price:  {r.sr3_market_price:.4f}  "
          f"(rate: {r.sr3_market_rate*100:.4f}%)")
    print(f"    Implied price: {r.sr3_implied_price:.4f}  "
          f"(rate: {r.sr3_implied_rate*100:.4f}%)")
    print(f"    Rich/Cheap:    {r.sr3_rich_cheap_bp:+.2f} bp  "
          f"({'CHEAP' if r.sr3_rich_cheap_bp > 0 else 'RICH'})")

    print(f"\n  SR1 Near ({r.sr1_near_market_price:.3f})  "
          f"implied rate: {r.sr1_near_implied_rate*100:.4f}%")
    print(f"  SR1 Far  ({r.sr1_far_market_price:.3f})  "
          f"implied rate: {r.sr1_far_implied_rate*100:.4f}%")

    print(f"\n  O Spread (ASE units, tick=0.5):")
    print(f"    Market:     {r.o_market:>+7.2f}")
    print(f"    Fair value: {r.o_fair:>+7.2f}")
    print(f"    Edge:       {r.o_edge:>+7.2f}  "
          f"({r.o_edge / 0.5:+.1f} ticks)")

    print(f"\n  SR1-ZQ Basis (SOFR − FF):")
    print(f"    Near month: {r.basis_near_bp:>+.2f} bp")
    print(f"    Far month:  {r.basis_far_bp:>+.2f} bp")

    if r.sub_periods:
        print(f"\n  Sub-period Forward Rates:")
        for label, rate in r.sub_periods:
            print(f"    {label:<16} {rate*100:.4f}%")


def print_summary_table(results: List[GroupResult]):
    """Compact summary across all groups."""
    print(f"\n{'═'*72}")
    print(f"  SUMMARY — O Spread Fair Value Across Expiry Groups")
    print(f"{'═'*72}")
    print(f"  {'Group':<8} {'SR3 Mkt':>8} {'SR3 Impl':>9} {'R/C(bp)':>8} "
          f"{'O Mkt':>7} {'O Fair':>7} {'Edge':>7} {'Ticks':>6}")
    print(f"  {'─'*8} {'─'*8} {'─'*9} {'─'*8} "
          f"{'─'*7} {'─'*7} {'─'*7} {'─'*6}")
    for r in results:
        pfx = "*" if r.partially_fixed else " "
        print(f" {pfx}{r.name:<7} {r.sr3_market_price:>8.4f} "
              f"{r.sr3_implied_price:>9.4f} {r.sr3_rich_cheap_bp:>+8.2f} "
              f"{r.o_market:>+7.2f} {r.o_fair:>+7.2f} {r.o_edge:>+7.2f} "
              f"{r.o_edge/0.5:>+5.1f}")
    print(f"\n  * = partially fixed (SR3 reference period already started)")
    print(f"  Edge > 0 → O spread is EXPENSIVE vs curve "
          f"(attractive to SELL)")
    print(f"  Edge < 0 → O spread is CHEAP vs curve "
          f"(attractive to BUY)")


# ═══════════════════════════════════════════════════════════════════════
# 9. MAIN
# ═══════════════════════════════════════════════════════════════════════

def main():
    print("SOFR Curve Bootstrap & O-Spread Fair Value Calculator")
    print(f"Evaluation date: {EVAL_DATE}")
    print(f"Bootstrap: {BOOTSTRAP_CLASS.__name__}")

    ql.Settings.instance().evaluationDate = EVAL_DATE

    # ── Build curves ──
    print("\nBootstrapping SOFR curve from SR1 futures + OIS...")
    sofr_curve = build_sofr_curve(EVAL_DATE, MARKET_DATA)
    print("Bootstrapping Fed Funds curve from ZQ futures + OIS...")
    ff_curve = build_ff_curve(EVAL_DATE, MARKET_DATA)

    # ── Curve diagnostics ──
    print_curve_diagnostics("SOFR", sofr_curve, EVAL_DATE)
    print_curve_diagnostics("Fed Funds", ff_curve, EVAL_DATE)

    # ── Compute fair values per group ──
    results = []
    for group in EXPIRY_GROUPS:
        r = compute_group(group, sofr_curve, ff_curve, MARKET_DATA, EVAL_DATE)
        results.append(r)
        print_group_result(r)

    # ── Summary ──
    print_summary_table(results)

    # ── Basis term structure ──
    print(f"\n{'═'*60}")
    print(f"  SOFR − FF Basis Term Structure (curve-implied)")
    print(f"{'═'*60}")
    print(f"  {'Month':<10} {'SOFR':>8} {'FF':>8} {'Basis(bp)':>10}")
    print(f"  {'─'*10} {'─'*8} {'─'*8} {'─'*10}")
    for m, y, _ in MARKET_DATA["sr1_futures"]:
        start, end = sr1_reference_period(m, y)
        if end <= EVAL_DATE:
            continue
        sofr_r = forward_rate(sofr_curve, start, end)
        ff_r   = forward_rate(ff_curve, start, end)
        basis  = (sofr_r - ff_r) * 10000
        month_label = f"{m:02d}/{y}"
        print(f"  {month_label:<10} {sofr_r*100:>7.4f}% {ff_r*100:>7.4f}% "
              f"{basis:>+9.2f}")


if __name__ == "__main__":
    main()
