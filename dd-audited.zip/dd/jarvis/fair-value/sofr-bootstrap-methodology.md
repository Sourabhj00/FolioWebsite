---
title: SOFR Bootstrap Methodology — Curve-Derived Fair Value
wp: WP-02
status: complete
created: 2026-03-28
last-updated: 2026-03-31
lines: 255
kb-depends:
  - knowledge-base/strategy/core-quad-leg-arbitrage.md
  - knowledge-base/strategy/price-formulas-complete.md
  - knowledge-base/core/instruments-and-platform.md
  - knowledge-base/strategy/execution-modifiers.md
jarvis-depends:
  - jarvis/fair-value/network-valuation-engine-plan.md
  - jarvis/fair-value/valuation-engine-implementation-prompt.md
tags: [sofr, bootstrap, fair-value, curve, quantlib]
domain: fair-value
---

# SOFR Curve Bootstrap & O-Spread Fair Value — Methodology

This document formalizes the curve-derived fair value calculation for the SR3|SR1
O spread. It replaces the judgment component of the current O_target estimation
with an auditable, market-data-driven anchor.

Downstream consumers: WP-07 (Dynamic Avoidance Model), WP-13 (Pricing Engine
Prototype / FairValueProvider interface).

---

## Part 1: Existing Methodology — Honest Assessment

### What currently happens

The O_target (expressed as buyBiased / sellBiased values per expiry group) is set
by the trader through a combination of:

1. **Curve intuition**: the trader observes OIS swap rates, SR1 futures levels,
   and Fed expectations to form a view on where the O spread "should" trade.
2. **Historical range**: the trader knows the recent range of the O spread and
   positions within it.
3. **Discretionary adjustment**: the target is nudged based on flow conditions,
   time-of-day, and upcoming events (FOMC, data releases).

This process is effective — the strategy is profitable — but it has two weaknesses.
First, the fair value anchor is implicit; there is no way to audit whether the
chosen O_target was optimal after the fact. Second, the target cannot update
automatically when the curve moves; it requires manual intervention.

### What the bootstrap replaces

The curve-derived fair value replaces step (1) above: the subjective "where should
the O spread trade" judgment. It computes the theoretically correct O spread level
from the SOFR discount curve, given current SR1 futures and OIS swap rates.

### What it does NOT replace

The bootstrap output is a **fair value anchor**, not a complete trading signal.
The following layers remain on top of it and are not affected:

- **Avoidance parameters** (Av_ZQ, Av_FF): widen the buy/sell spread around
  fair value based on volatility conditions. These are execution modifiers.
- **B/S Bias** (BS_ZQ, BS_FF): directional tilts within the spread. These
  reflect flow or positioning views.
- **Rounding** (RD/RU): defensive passive execution. This is mechanical.
- **Trader discretion**: the trader can still override the curve fair value when
  they have information the curve doesn't capture (e.g., imminent policy shifts,
  known block flows).

The architecture is: `O_target = CurveFairValue + discretionary_offset`, where
the discretionary offset defaults to zero and the curve provides the baseline.

---

## Part 2: Mathematical Framework

### The core identity

SR3 prices a 3-month compounded SOFR rate over an IMM-to-IMM reference period.
This rate equals the compounded product of daily SOFR fixings over the quarter:

    R_3m = [ ∏(1 + SOFR_i × d_i / 360) − 1 ] × 360 / D

where d_i is the day count fraction for each fixing and D is the total Actual/360
day count of the reference period.

The same compounded rate can be decomposed into sub-period forward rates. For any
partition of the reference period into contiguous sub-periods [t_0, t_1], [t_1, t_2],
..., [t_{n-1}, t_n]:

    (1 + R_3m × D/360) = ∏_k (1 + r_k × d_k / 360)

where r_k is the compounded forward rate for sub-period k and d_k is its day count.

### Sub-period structure

For each SR3 quarterly contract, the IMM reference period spans parts of four
calendar months. Taking Mar26 as the example:

    SR3 Mar26: March 18 → June 17 (91 calendar days, ~65 business days)

    Stub 1:  March 18 – March 31   (~10 bus days, partial month)
    Month 1: April 1 – April 30     (~22 bus days, SR1 Apr)
    Month 2: May 1 – May 31         (~21 bus days, SR1 May)
    Stub 2:  June 1 – June 17       (~12 bus days, partial month)

SR1 Apr and SR1 May directly price two of the four sub-periods. The two stub
periods (partial March and partial June) are not directly observable from SR1
contracts and must be derived from the SOFR discount curve.

This is why a bootstrap is required: the O spread's fair value depends on the
stub rates, which are only available from a curve that interpolates between the
observable instrument maturities.

### Implied SR3 fair value

From the bootstrapped SOFR discount curve:

    SR3_implied_rate = [ DF(IMM_start) / DF(IMM_end) − 1 ] × 360 / D

    SR3_implied_price = 100 − SR3_implied_rate × 100

The mispricing is:

    mispricing = SR3_market_rate − SR3_implied_rate    (in basis points)

Positive mispricing means SR3 market rate is higher than the curve implies, i.e.,
the SR3 futures price is lower (cheaper) than fair value.

### O spread fair value

The O structure is −10 SR3 + 3 SR1_near + 3 SR1_far. In price space:

    O_value = −10 × SR3_price + 3 × SR1_near_price + 3 × SR1_far_price

The curve-derived fair value uses implied prices for all three instruments:

    O_fair = −10 × SR3_implied_price + 3 × SR1_near_implied_price + 3 × SR1_far_implied_price

The market O value uses actual market prices:

    O_market = −10 × SR3_market_price + 3 × SR1_near_market_price + 3 × SR1_far_market_price

The edge = O_market − O_fair. When the curve is bootstrapped from SR1 futures
(not SR3), the SR1 implied prices match market (by construction), so the edge
reduces to:

    edge = −10 × (SR3_market − SR3_implied)

This is the SR3 mispricing scaled by the SR3 lot ratio. The O spread fair value
is entirely determined by whether SR3 is rich or cheap relative to the curve
built from SR1 and OIS data.

### Converting to ASE tick space

The O_fair and O_market values above are in "lot × price" units. To convert to
the ASE tick space that the trader's buyBiased/sellBiased values use, divide by
the appropriate normalization factor from the ASE configuration:

    O_target_ticks = (O_fair × PriceMultiplier) / ASE_normalizer

The exact conversion depends on the ASE spread definition (ratio, multiplier,
tick size). The Python script outputs values in both rate-space (basis points)
and the lot-weighted price space, leaving the final ASE tick conversion to the
production code that already handles this.

### SR1-ZQ basis

The SOFR-FF basis for each month is the difference between the SOFR forward rate
and the Fed Funds forward rate over the same period:

    basis_month = r_SOFR_month − r_FF_month

This is computed by bootstrapping a second curve (Fed Funds) from ZQ futures and
comparing forward rates month by month. The basis is an input to Legs 3 & 4
pricing (the SR3|ZQ legs) and is currently captured by the monitoring instruments
(SR1-ZQ inter-product spreads). The curve-derived basis provides a cross-check
against the live microprice observations.

---

## Part 2b: QuantLib Class Mapping

### SOFR curve

**Index**: `ql.Sofr()` — overnight SOFR index. Calendar: UnitedStates::SOFR.
Day counter: Actual/360. Fixing days: 0.

**Bootstrap helpers** (in maturity order):

1. `ql.DepositRateHelper(rate, Period(1, Days), 0, calendar, Following, False, Actual360())`
   Anchors the very short end at the current overnight SOFR fixing.

2. `ql.OvernightIndexFutureRateHelper(QuoteHandle(price), startDate, endDate, sofr)`
   One per SR1 contract month. Start/end = first/last business day of the calendar
   month. Price in CME convention (100 − rate).
   Critical: these are the PRIMARY curve inputs. SR3 futures are deliberately
   excluded to avoid circularity.

3. `ql.OISRateHelper(2, Period(n, Years), QuoteHandle(rate), sofr)`
   For tenors beyond the SR1 futures strip (typically 2Y+). Settlement = T+2.

**Curve construction**:
`ql.PiecewiseLogCubicDiscount(evalDate, helpers, Actual365Fixed())`

This uses the Discount trait (bootstrap on discount factors) with LogCubic
interpolation (monotone cubic on log-discount factors). This combination
produces smooth forward rates and guaranteed positive discount factors.

Alternative: `PiecewiseLinearZero` — simpler, but produces discontinuous forwards
at pillar boundaries. Use for debugging or when smoothness is less important.

### Fed Funds curve

**Index**: `ql.FedFunds()` — overnight EFFR index. Calendar: FederalReserve.

**Bootstrap helpers**: Same structure as SOFR but with ZQ futures and FedFunds
index. Uses `UnitedStates(UnitedStates.FederalReserve)` calendar.

### Forward rate extraction

From the bootstrapped curve, the compounded forward rate for any period [d1, d2]:

```python
df1 = curve.discount(d1)
df2 = curve.discount(d2)
days = Actual360().dayCount(d1, d2)
rate = (df1 / df2 - 1.0) * 360.0 / days
```

This matches CME futures settlement methodology (daily compounding, Act/360).

### Design decisions and tradeoffs

**Why exclude SR3 from the bootstrap?** Including SR3 would make the curve
consistent with SR3 market prices by construction. The implied SR3 would equal
the market SR3, producing zero mispricing always. The whole point is to build
the curve from SR1 (the more granular instrument) and independently derive what
SR3 should be worth.

**Why LogCubic on discount factors?** Log-discount interpolation ensures positive
discount factors and produces reasonably smooth forward rates. Cubic (rather than
linear) reduces forward rate jumps at pillar dates. For the short end where SR1
futures provide monthly resolution, interpolation choice matters less — the data
is dense enough that all reasonable methods agree.

**What about convexity adjustments?** For short-dated SOFR futures (< 2 years),
the futures-vs-forward convexity bias is negligible (< 0.1 bp). The
`OvernightIndexFutureRateHelper` handles the compounding period correctly. For
deferred contracts further out the curve, a convexity adjustment may be needed;
this is not implemented in the initial version.

**What about realized fixings?** When the evaluation date falls within an SR3
reference period, some daily SOFR fixings are already published. The curve gives
a forward-looking estimate for these realized dates. For production accuracy, the
known fixings should be fed into the index via `sofr.addFixing(date, rate)` and
the curve should be re-bootstrapped. The script includes a hook for this but uses
curve-only estimates by default.

---

## Related

### Within Jarvis
- [[fair-value/network-valuation-engine-plan]] — Phase 1 plan for the engine this methodology feeds
- [[fair-value/valuation-engine-implementation-prompt]] — Implementation spec derived from this methodology
- [[strategy-research/directional-bias-model]] — Complementary lead-lag signal extending pricing methodology

### Knowledge Base
- [[knowledge-base/strategy/core-quad-leg-arbitrage]] — O-spread convergence thesis this derives fair value for
- [[knowledge-base/strategy/price-formulas-complete]] — Formula definitions this methodology extends
- [[knowledge-base/core/instruments-and-platform]] — Contract specs for curve construction inputs
- [[knowledge-base/strategy/execution-modifiers]] — Avoidance/bias parameter definitions referenced in integration design
