---
title: Network Valuation Engine — Phase 1 Plan
wp: WP-02
status: complete
created: 2026-03-29
last-updated: 2026-03-31
lines: 389
kb-depends:
  - knowledge-base/strategy/price-formulas-complete.md
  - knowledge-base/strategy/execution-modifiers.md
  - knowledge-base/ase-rules/custom-rules-production.md
jarvis-depends:
  - jarvis/fair-value/sofr-bootstrap-methodology.md
  - jarvis/fair-value/valuation-engine-implementation-prompt.md
  - jarvis/fill-analysis/README.md
---

# Network Valuation Engine — Phase 1 Plan

## 1. What We're Building

A standalone valuation engine that subscribes to live market data for all
listed instruments in the STIR complex (SR3, SR1, ZQ — outrights, spreads,
flies, dflies) and computes a relative mispricing score for every contract.
The output is a ranked list from most-undervalued to most-overvalued, with
confidence, updated on every market tick.

This is the generalization of the existing `diff = v1 - v2 + v3` system
(which values the SR1 calendar via 3 monitoring instruments) to the full
network of ~200-300 listed instruments connected by no-arbitrage equations.

### What it is NOT (yet)

- Not integrated into the .NET pricing pipeline (Phase 2)
- Not driving avoidance/bias parameters automatically (Phase 3)
- Not performing interchange decisions (Phase 4)
- Not doing portfolio optimization (Phase 5)

It runs as a separate process, consuming TT market data, publishing scores.
The existing system continues to run independently.

---

## 2. Architecture

```
┌──────────────────────────────────────────────────┐
│               TT .NET SDK (Client-Side)          │
│  PriceSubscription (InsideMarket) × ~300 instr   │
│  Coalesced at 35ms — ~8,400 events/sec max       │
│  Fields: DirectBid/Ask Price & Qty per instrument │
└──────────────────┬───────────────────────────────┘
                   │ FieldsUpdated events
                   ▼
┌──────────────────────────────────────────────────┐
│            Market Data Cache                      │
│  Per-instrument: bid, ask, bidQty, askQty,        │
│  microprice, spread width, staleness timestamp    │
│  Updated incrementally on each event              │
└──────────────────┬───────────────────────────────┘
                   │ On any instrument update
                   ▼
┌──────────────────────────────────────────────────┐
│          Valuation Engine (3-pass)                │
│                                                   │
│  Pass 0: Rogue Detection                          │
│    - Compute all equation residuals               │
│    - Flag |r| > 6σ OR |r| > absolute threshold   │
│    - Quarantine affected equations                 │
│                                                   │
│  Pass 1: Local Residual Attribution               │
│    - For each equation: δⱼ = (wⱼ/W) × (r/cⱼ)    │
│    - Blame weights: outright=12, spread=10,       │
│      fly=5, dfly=2 (initial, to be calibrated)    │
│                                                   │
│  Pass 2: Corroboration-Weighted Aggregation       │
│    - Per instrument: collect all attributions      │
│    - Weight near-zero-residual equations higher    │
│    - Output: score (continuous) + confidence (0-1) │
│                                                   │
│  Latency budget: <1ms for full recalculation      │
└──────────────────┬───────────────────────────────┘
                   │
                   ▼
┌──────────────────────────────────────────────────┐
│           Output: Ranked Instrument List          │
│  Per instrument:                                  │
│    - Score: negative=undervalued, positive=over    │
│    - Confidence: 0-1 (agreement across equations)  │
│    - Equation count: how many equations inform it  │
│    - Quarantine flag: true if data suspect         │
│  Published via shared memory / named pipe / file   │
│  Updated on every market tick                      │
└──────────────────────────────────────────────────┘
```

### TT SDK Integration Notes

- Subscription type: `PriceSubscriptionType.InsideMarket` (not MarketDepth)
- Use `DirectBidPrice`/`DirectAskPrice`/`DirectBidQuantity`/`DirectAskQuantity`
  (excluding implied quantities — consistent with HitMan Condition 8 philosophy)
- Max 15,000 subscriptions on standard plan; 300 instruments is trivial
- Client-side 35ms coalescing is acceptable — valuation is not latency-critical
  at the microsecond level; it's a signal that changes over seconds
- Server-side (uncoalesced) would be better but not required for Phase 1

---

## 3. Mathematical Model — Residual Attribution with Corroboration

### 3.1 Inputs

For each instrument i:
- `microprice_i` computed from live bid/ask/qty
  - If spread = 1 tick: VWAP = (Bid × AskQty + Ask × BidQty) / (BidQty + AskQty)
  - If spread = 2 ticks: midpoint = (Bid + Ask) / 2
  - If spread > 2 ticks: instrument marked illiquid, excluded from calculations

This is consistent with price-formulas-complete §2 microprice definition,
extended with the 2-tick midpoint fallback from the original prompt.

### 3.2 No-Arbitrage Equations

Each equation has the form: Σ cⱼ × Pⱼ = 0

Where cⱼ are integer coefficients and Pⱼ are microprices. Examples:

**Spread equations** (for each listed spread):
  O_A - O_B - P_{A-B} = 0
  where O_A, O_B are outright microprices, P_{A-B} is the quoted spread microprice

**Fly equations** (for each listed butterfly):
  O_A - 2×O_B + O_C - P_{A-2B+C} = 0

**Dfly equations** (for each listed double butterfly):
  O_A - 3×O_B + 3×O_C - O_D - P_{A-3B+3C-D} = 0

**Spread-from-spreads** (where a fly is built from two spreads):
  P_{A-B} - P_{B-C} - P_{fly(A,B,C)} = 0

**Cross-product equations** (SR1 vs ZQ, matching your diff identity):
  P_{SR1-ZQ near} - P_{SR1-ZQ far} + P_{ZQ near-far} - P_{SR1 near-far} = 0

The full equation set is defined by the exchange-listed instrument set.
Every listed spread/fly/dfly generates at least one equation connecting
it to its component outrights, plus potentially equations connecting
it to other listed structures.

### 3.3 Blame Weights

Each instrument type has an initial blame weight (higher = less reliable = more blame):

| Type       | Blame Weight | Rationale                                |
|------------|-------------|------------------------------------------|
| Outright   | 12          | Most liquid individually but most volatile |
| Spread     | 10          | Tighter range, actively traded            |
| Fly        | 5           | Very stable, less actively traded         |
| Dfly       | 2           | Extremely stable, rarely moves            |

These are starting values. Phase 2 will calibrate from historical data.

Additional weight modifiers (multiplicative, applied per-instrument):
- **Volume factor**: instruments with higher daily volume get lower blame
  (more reliable). Factor = max(0.5, 1.0 - log10(volume) / 10)
- **Spread width factor**: instruments with wider bid-ask spreads get
  higher blame (microprice is less reliable). Factor = 1.0 + (spread_ticks - 1) × 0.3
- **Staleness factor**: instruments that haven't updated recently get
  higher blame. Factor = 1.0 + staleness_seconds × 0.1

Effective blame weight = base_weight × volume_factor × spread_factor × staleness_factor

### 3.4 Pass 0 — Rogue Detection

Before scoring, detect and quarantine data anomalies.

**Step 1**: Compute residuals for all equations: r_e = Σ cⱼ × P_observed_j

**Step 2**: Compute robust statistics of residual distribution:
  - Median absolute deviation (MAD) — more robust than std dev
  - σ_robust = 1.4826 × MAD

**Step 3**: Flag equation e as rogue if:
  - |r_e| > 6 × σ_robust, OR
  - |r_e| > absolute_threshold (user-configurable, start at 3 ticks)

**Step 4**: Quarantine handling:
  - Quarantined equations are excluded from Pass 1 and Pass 2
  - Instruments appearing ONLY in quarantined equations are flagged
    as "data suspect" in the output
  - Instruments appearing in both clean and quarantined equations
    retain their clean-equation scores

**Step 5**: Rogue instrument inference:
  - If multiple equations involving the same instrument are quarantined,
    that instrument is the likely rogue (not the equations)
  - Log this for monitoring; useful for detecting data feed issues

### 3.5 Pass 1 — Local Residual Attribution

For each surviving equation e with residual r_e:
  - Participating instruments: {i₁, ..., iₖ}
  - Coefficients: {c₁, ..., cₖ}
  - Effective blame weights: {w₁, ..., wₖ}
  - Total blame pool: W = Σ wⱼ

Attribution for instrument j from equation e:

    δⱼ⁽ᵉ⁾ = (wⱼ / W) × (r_e / cⱼ)

Sign convention:
  - Positive δ → instrument is overvalued (priced higher than network implies)
  - Negative δ → instrument is undervalued (priced lower than network implies)

The division by cⱼ correctly handles:
  - Sign: if cⱼ is negative (instrument enters equation with minus sign),
    the attribution flips direction
  - Magnitude: if |cⱼ| > 1 (e.g., middle leg of a fly with coefficient -2),
    the instrument needs less mispricing to explain the same residual

### 3.6 Pass 2 — Corroboration-Weighted Aggregation

Each instrument i collects attributed scores from all equations it
participates in: S_i = {δᵢ⁽¹⁾, δᵢ⁽²⁾, ..., δᵢ⁽ᵐ⁾}

**Aggregation weight per equation**:
  - Base weight = 1.0
  - Corroboration boost: if |r_e| < ε (near-zero residual), multiply
    weight by corroboration_factor (start at 2.5)
  - ε = 0.1 ticks (configurable)

**Final Score**: Weighted median of S_i using equation aggregation weights.
  Weighted median is robust to outlier equations while respecting corroboration.

**Confidence**: Agreement ratio with corroboration adjustment.
  - agreement = (count of equations agreeing on sign) / (total equations)
  - corroboration_count = number of near-zero-residual equations for this instrument
  - confidence = agreement × (1 + 0.1 × corroboration_count)
  - Capped at 1.0

**Minimum equation threshold**: Instruments participating in fewer than
2 equations get confidence penalty (multiply by 0.5). Single-equation
instruments are inherently less reliable.

### 3.7 Output Structure

Per instrument:
```
{
  instrument_id: string,        // e.g., "SR3 Sep25"
  instrument_type: enum,        // Outright, Spread, Fly, Dfly
  score: float,                 // negative=undervalued, positive=overvalued
  confidence: float,            // 0.0 to 1.0
  equation_count: int,          // how many equations inform this score
  quarantined: bool,            // data suspect flag
  contributing_equations: [...] // for debugging/tracing
}
```

Sorted by score ascending (most undervalued first) → most overvalued last.

---

## 4. Implementation Plan

### Week 1: Model Core + ExampleValues Walkthrough

**Deliverables:**
1. Formal equation set definition (generated from instrument list)
2. Step-by-step worked example on ExampleValues.xlsx
3. Python reference implementation with tests
4. Performance benchmark (target <1ms for 300 instruments)

**Depends on:** ExampleValues.xlsx upload from trader

### Week 2: C# Implementation + TT SDK Scaffold

**Deliverables:**
1. C# standalone console application
2. TT SDK market data subscription scaffold (InsideMarket for N instruments)
3. Market data cache with microprice computation
4. Valuation engine integrated with live data feed
5. Console output: ranked list refreshed on each update

**Depends on:** Python reference impl validated by trader

### Week 3: Robustness + Calibration Infrastructure

**Deliverables:**
1. Rogue detection with MAD-based thresholds
2. Logging framework: all residuals, attributions, scores per tick
3. Historical data replay capability (for backtesting)
4. Weight sensitivity analysis tooling (vary weights, observe score stability)
5. Dashboard or output format for trader to monitor scores during live session

### Week 4: Validation + Handoff

**Deliverables:**
1. Run parallel to live trading (read-only) for 5 trading days
2. Compare model scores against trader's actual entry/exit decisions
3. Identify and document discrepancies between model and trader intuition
4. Calibrate blame weights and thresholds based on live observations
5. Decision document: proceed to Phase 2 integration or iterate Phase 1

---

## 5. Quant Model Library Integration Points

When the quant model library is shared, these are the specific slots
where alternative models could replace or enhance components:

| Component | Current Approach | Potential Replacement |
|-----------|-----------------|----------------------|
| Microprice | VWAP from bid/ask/qty | Bayesian microprice, order flow models |
| Blame weights | Fixed per type, multiplicative factors | Kalman filter for dynamic estimation |
| Aggregation | Weighted median | Factor model (PCA on residuals) |
| Rogue detection | MAD-based statistical threshold | Isolation forest, Mahalanobis distance |
| Confidence | Agreement ratio | Bayesian posterior from belief propagation |
| Weight calibration | Manual / offline BP | Online learning (EMA of attribution accuracy) |

The architecture is modular specifically to allow hot-swapping these
components. Each pass is a function with defined inputs/outputs.

---

## 6. Risk Register

**R1 — Circular reinforcement**: If instrument B appears in 5 equations
and all 5 also contain instrument X (which is mispriced), B gets false
corroboration. Mitigation: corroboration only counts from equations with
near-zero residuals. If X is mispriced, equations containing X will have
non-zero residuals and won't corroborate B.

**R2 — Weight sensitivity**: Scores are sensitive to blame weight ratios.
If outright:spread ratio is wrong, attributions are wrong. Mitigation:
Phase 1 Week 3 sensitivity analysis. Phase 2 historical calibration.

**R3 — Stale data masking real mispricing**: An instrument that hasn't
updated in 5 seconds might appear "fair" because its microprice hasn't
changed, but the instruments around it have moved. Mitigation: staleness
factor in blame weights. Also: if microprice is unchanged for >N seconds
while connected instruments have moved, flag as stale.

**R4 — Sparse network regions**: Some instruments (e.g., far-dated dflies)
participate in very few equations. Their scores have low statistical
power. Mitigation: minimum equation threshold + confidence penalty.

**R5 — Model vs. trader disagreement**: The model may systematically
disagree with trader intuition in certain market regimes. This is
actually valuable — it either exposes a model flaw or reveals an
unconscious trader bias. The Week 4 validation explicitly tests for this.

---

## 7. Success Criteria for Phase 1

1. Model computes scores for all ~300 instruments in <1ms on trader's hardware
2. Rogue detection correctly identifies synthetic data anomalies in test data
3. Worked example on ExampleValues.xlsx matches trader's intuitive assessment
4. During 5-day parallel run, model's top-5 undervalued/overvalued contracts
   overlap with trader's actual trade selections >60% of the time
5. No false positives in rogue detection during the parallel run
   (i.e., no quarantining of instruments the trader considers valid)
6. Score stability: for instruments in tight markets (1-tick spread),
   score should not flip sign more than 2x per minute under normal conditions

---

## 8. Connection to Existing System (Forward-Looking)

Phase 2 integration points (for reference, not built in Phase 1):

- **Timer Logic expansion**: valuation confidence could feed expansion value.
  High confidence that outright is undervalued → higher expansion on buy side.
  Slot: replaces/augments the static expansion in timer-logic §4.

- **Avoidance auto-tuning**: if model detects SR1-ZQ basis becoming
  volatile (high residuals in basis equations), Av_FF could auto-escalate
  without waiting for the 12:55-13:05 window.
  Slot: extends execution-modifiers §8 dynamic avoidance.

- **B/S Bias from scores**: if model says ZQ near-far calendar is
  undervalued, BS_ZQ could auto-adjust to buy bias.
  Slot: replaces manual BS_ZQ input in execution-modifiers §3.

- **HitMan parameter modulation**: if model says hedge leg outright is
  overvalued, HitMan VolRatioLegII could loosen (fire more easily,
  since overvalued instrument is more likely to come down to bid).
  Slot: extends custom-rules-production §Rule 1 Condition 1.

- **Leg prioritization**: model scores across all 4 legs could determine
  which leg the pricing pipeline prioritizes for quote placement.
  Currently all 4 legs quote simultaneously; Phase 3 could bias toward
  legs where the model sees better opportunity.

## Related

### Within Jarvis
- [[fair-value/sofr-bootstrap-methodology]] — Curve bootstrap that feeds this engine
- [[fair-value/valuation-engine-implementation-prompt]] — Implementation spec derived from this plan
- [[fill-analysis/_index|Fill Analysis]] — Accuracy baseline this engine aims to improve

### Knowledge Base
- [[knowledge-base/strategy/price-formulas-complete]] — Microprice and formula definitions used in the model
- [[knowledge-base/strategy/execution-modifiers]] — Parameters this engine's output informs
- [[knowledge-base/ase-rules/custom-rules-production]] — Production rules that would consume valuation signals
