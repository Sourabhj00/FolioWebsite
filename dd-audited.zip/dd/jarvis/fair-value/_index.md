---
title: Fair Value — Map of Content
wp: WP-02
status: complete
last-updated: 2026-03-31
lines: 33
---

# Fair Value — Map of Content

WP-02 output plus forward-looking valuation engine design. Covers SOFR curve
bootstrap methodology (replacing judgment-based O_target with curve-derived
fair value) and the Network Valuation Engine (5-phase plan, implementation
prompt, working Python engine). (~1,029 lines of markdown + ~1,677 lines of Python)

## Files

- [[sofr-bootstrap-methodology]] — Mathematical framework for curve-derived O-spread fair value: core identity, sub-period structure, implied SR3 pricing, ASE tick conversion, QuantLib class mapping, and design tradeoffs. (~255 lines)
- [[network-valuation-engine-plan]] — Phase 1 plan (Weeks 1–4, April 2026): 300-instrument live data subscription, 3-pass residual attribution with rogue detection, blame weights, TT SDK integration, risk register, success criteria. (~389 lines)
- [[valuation-engine-implementation-prompt]] — Self-contained implementation spec: 18-instrument synthetic test dataset (6 outrights, 5 spreads, 4 flies, 3 dflies), 16 no-arbitrage equations, 8 test cases, edge cases, 8 deliverables. (~385 lines)

## Non-Markdown Assets

- `network_valuation_engine.py` — Network Valuation Engine reference implementation: residual attribution with corroboration, dataclass and list-based (4× faster) implementations, rogue detection. (~1,029 lines)
- `sofr_bootstrap_fair_value.py` — SOFR/Fed Funds curve bootstrap: constructs SOFR and FF curves from futures + OIS data, computes implied SR3 fair values. (~648 lines)

## KB Dependencies

- [[knowledge-base/strategy/price-formulas-complete]] — Microprice definitions and formula structures this methodology extends
- [[knowledge-base/strategy/core-quad-leg-arbitrage]] — O-spread convergence thesis that fair value anchors
- [[knowledge-base/core/instruments-and-platform]] — Contract specs (tick sizes, DV01) for curve construction
- [[knowledge-base/strategy/execution-modifiers]] — Avoidance/bias parameter definitions referenced in fair value integration design

## Related Folders

- [[fill-analysis/_index|Fill Analysis]] — Accuracy baseline the valuation engine aims to improve
- [[timer-logic/_index|Timer Logic]] — Formula implementation that consumes pricing outputs
- [[market-profiling/_index|Market Profiling]] — Contract groups that interact with fair value calculations
- [[strategy-research/_index|Strategy Research]] — Directional bias model extending pricing methodology
- [[reference-libraries/quantlib/_index|Ref: QuantLib]] — QuantLib classes used in SOFR bootstrap implementation
