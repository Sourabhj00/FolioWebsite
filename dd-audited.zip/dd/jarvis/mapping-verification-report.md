---
title: Jarvis Vault Mapping — Verification Report
wp: n/a
status: complete
created: 2026-03-31
last-updated: 2026-03-31
lines: 99
kb-depends: []
jarvis-depends: []
---

# Jarvis Vault Mapping — Verification Report

**Date**: 2026-03-31
**Scope**: Full structural retrofit + quality audit of Jarvis vault navigation infrastructure

---

## Verification Summary

| Metric | Count |
|--------|-------|
| Folders with `_index.md` | 14 / 14 |
| Files with YAML frontmatter | 73 / 73 (100%) |
| Wikilinks (intra-Jarvis) | 136 |
| Wikilinks (cross-vault KB) | 64 |
| Total wikilinks | 200 |
| Broken links found | 0 |
| Navigation overhead (lines) | 1,383 |
| Navigation overhead (%) | 13.4% (under 15% target) |

---

## What Was Done

### Initial Scaffold (Phase 1–6)

15 `_index.md` MOC files created across all folders. 72 markdown files
given YAML frontmatter (`title`, `wp`, `status`, `created`,
`last-updated`, `lines`, `kb-depends`, `jarvis-depends`). Core analysis
files (22) given `## Related` sections with bidirectional wikilinks.
Reference library files (51) retained their internal cross-reference
patterns (MASTER_INDEX → topics → details).

### Quality Audit + Fixes

A deep audit verified every MOC description, frontmatter field, wikilink,
and line count. Issues found and fixed:

**Errors (7):**
- E1: All 73 `lines:` frontmatter values were wrong (stale counts from
  before frontmatter/Related sections were added). All recalculated.
- E2: Broken KB link `accuracy-measurement` (hyphens) vs actual file
  `accuracy_measurement` (underscores). Fixed by renaming KB file to
  match vault hyphen convention.
- E3: `analysis_summary.json` line count in MOC: 515 → 441.
- E4: `fill_detail.csv` column count in MOC: 14 → 16.
- E5: `expiry_summary.csv` MOC description omitted "Other" expiry group.
- E6: CLAUDE.md reference-libraries total: ~3,205/45 files → ~3,466/45.
- E7: Original verification report metrics were stale. Rewritten (this file).

**Inconsistencies (4):**
- I1: Frontmatter `kb-depends` and `## Related` KB links disagreed in 5
  files. Synchronized — both now list the same KB dependencies.
- I2: Ambiguous bare wikilinks (`[[README]]`, `[[MASTER_INDEX]]`,
  `[[SOURCE_MANIFEST]]`) qualified with folder paths to prevent Obsidian
  resolution ambiguity across duplicate filenames.
- I3: Two leaf-to-leaf links missing backlinks (directional-bias-model →
  contract-segmentation and → sofr-bootstrap-methodology). Backlinks added.
- I4: Nonsensical `jarvis-depends` (fill-analysis/README depending on its
  own _index.md) replaced with meaningful dependency.

**Questionable dependencies (flagged):**
- Q1: sofr-bootstrap → execution-modifiers: valid but description was
  misleading (described downstream consumer, not upstream dependency). Fixed.
- Q2–Q3: contract-segmentation → core-quad-leg-arbitrage and
  ase-mechanics-and-parameters: implicit dependencies with no body text
  references. Kept with TODO comment on ase-mechanics.

**Design (2):**
- D1: CSV row counts now distinguish data rows from header rows.
- D2: Two empty glob artifact directories removed.

---

## Content Distribution

| Category | Lines | % |
|----------|------:|---:|
| Core analysis content | 8,967 | 86.6% |
| Navigation overhead (frontmatter + MOCs + Related) | 1,383 | 13.4% |
| **Total vault** | **10,350** | **100%** |

---

## Known Limitations

1. **KB link paths verified against actual files.** All 64 cross-vault KB
   wikilinks resolve to existing files in knowledge-base/ after the
   `accuracy_measurement` → `accuracy-measurement` rename.

2. **Reference library `## Related` sections**: 51 reference-library files
   use "Deep Dive → details/..." cross-references rather than standardized
   `## Related` sections. Deliberate — these are external reference material
   with their own internal navigation (MASTER_INDEX → topics → details).

3. **One TODO comment**: `contract-segmentation.md` KB Dependencies section
   flags `ase-mechanics-and-parameters` as potentially inherited context
   rather than direct dependency.
