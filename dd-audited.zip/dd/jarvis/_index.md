---
title: Jarvis — Root Map of Content
wp: n/a
status: complete
last-updated: 2026-03-31
lines: 33
---

# Jarvis — Root Map of Content

Analysis and output layer for the STIR futures trading system. Contains
work-package deliverables, models, research, and reference libraries
produced from the 3-month execution plan. The sibling knowledge-base/
vault holds authoritative system design — Jarvis extends it with results.
(~9,391 lines of markdown across 72 files)

## Folders

- [[plan/_index|Plan]] (~955 lines) — 3-month execution plan and WP completion tracker. Start here for priorities and status.
- [[fill-analysis/_index|Fill Analysis]] (~121 lines md + data) — WP-01: production fill accuracy across 3,225 fills. Grand accuracy 56.32%.
- [[timer-logic/_index|Timer Logic]] (~1,438 lines md + code) — WP-04 formula audit + WP-05 .NET implementation. 151/152 tests passing.
- [[fair-value/_index|Fair Value]] (~1,029 lines md + code) — WP-02 SOFR bootstrap + Network Valuation Engine design.
- [[market-profiling/_index|Market Profiling]] (~764 lines) — WP-03 contract segmentation + WP-12 event calendar.
- [[strategy-research/_index|Strategy Research]] (~1,260 lines) — Treasury lead-lag directional bias model (planned, not implemented).
- [[reference-libraries/_index|Reference Libraries]] (~3,466 lines) — QuantLib ecosystem + portfolio/risk analytics. Load on-demand only.

## KB Corrections (Jarvis Authoritative)

Where Jarvis findings contradict KB documents, the Jarvis finding is
authoritative for the specific issue:

- **execution-modifiers.md §5**: MISSING −BS_FF term in Leg 3/4 base formulas. Found by [[timer-logic/verification-report|WP-04 audit]]. Use [[knowledge-base/strategy/price-formulas-complete]] as sole formula source.
- **accuracy-measurement.md §2**: BS_ZQ simplification identity fails when BS_ZQ ≠ 0. Found by [[timer-logic/verification-report|WP-04 audit]].

## Navigation Protocol

1. Always read a folder's `_index.md` before loading individual files.
2. Use line counts in parentheses to budget context window.
3. Follow wikilinks for dependencies rather than loading entire folders.
4. For KB context, load `knowledge-base/core/` first (~170 lines), then only the specific KB files listed in `kb-depends` frontmatter.
