---
tags: [strategy, timer-logic, expansion, rounding, evidence, fillable-price, signals]
domain: strategy
load-priority: on-demand
last-updated: "2026-03-29"
status: staging-pending-verification
---

# Timer Logic — Evidence-Conditioned Execution Pricing

Replaces hard defensive rounding with market-evidence-conditioned rounding to improve fill rate without blindly sacrificing edge. The name "Timer Logic" is a proper noun — it has no relation to TimedParameterService, PauseWindows, or time-based scheduling.

---

## 1. Problem Statement

The pricing pipeline (ref: [[price-formulas-complete]]) computes continuous raw leg prices from trader inputs, diff, avoidance, and bias. These raw prices must be discretised to valid tick levels (0.5 increments per [[instruments-and-platform]], §ASE) before submission to ASE.

Hard defensive rounding (RD for buys, RU for sells) systematically pushes every order to the worst valid tick, regardless of how close the raw price was to the next tick toward market. A raw buy price of 4.4 rounds to 4.0 — identical to a raw price of 4.01. The microprice signal's decimal precision is destroyed.

Timer Logic recovers that precision by conditioning the rounding decision on market evidence: when evidence supports a fill at the nearer tick, round toward market; otherwise, retain the defensive rounding.

---

## 2. Position in the Pricing Pipeline

Timer Logic applies at a specific point in the calculation chain:

```
Trader inputs (O_Buy, O_Sell)
    ↓
Diff computation (v1, v2, v3 → diff)         ← ref: price-formulas-complete §3
    ↓
Raw leg prices (Legs 1–4)                     ← ref: price-formulas-complete §4, §7
    ↓
Avoidance adjustment (Av_ZQ, Av_FF)           ← ref: execution-modifiers §2, §5
    ↓
B/S Bias adjustment (BS_ZQ, BS_FF)            ← ref: execution-modifiers §3, §6
    ↓
>>> TIMER LOGIC (expansion-conditioned rounding) <<<
    ↓
Discretised leg prices → submitted to ASE     ← ref: price-formulas-complete §6, §9
    ↓
ASE rules evaluate (HitMan, ASM, etc.)        ← ref: custom-rules-production
```

Timer Logic replaces the fixed RD/RU step. It receives the fully-adjusted raw price (post-avoidance, post-bias) and outputs a valid tick-level price. Everything upstream (diff, avoidance, bias) and downstream (ASE rules, Backoff, Payup) is unchanged.

---

## 3. Rounding Mechanism

### Tick Geometry

Valid order prices are discrete at 0.5 intervals. Any raw price falls within a tick interval [floor, ceiling] where floor and ceiling are consecutive valid ticks.

### Hard Rounding (Baseline)

- **Buys**: RD(x) = floor of tick interval. Always rounds away from market.
- **Sells**: RU(x) = ceiling of tick interval. Always rounds away from market.

### Timer Rounding

Introduce **expansion** ∈ [0, 0.5), a value encoding confidence that the nearer tick is fillable.

- **Buys**: If distance from raw price to ceiling tick ≤ expansion → round UP (toward market). Else → round DOWN (defensive).
- **Sells**: If distance from raw price to floor tick ≤ expansion → round DOWN (toward market). Else → round UP (defensive).

Formally:

```
TimerRD(x, expansion):
    floor = RD(x), ceil = RU(x)
    if ceil == floor: return floor          // exactly on tick
    if (ceil - x) ≤ expansion: return ceil  // close enough → round toward market
    else: return floor                      // defensive

TimerRU(x, expansion):
    floor = RD(x), ceil = RU(x)
    if ceil == floor: return ceil
    if (x - floor) ≤ expansion: return floor
    else: return ceil
```

### Cross-Validation

After Timer rounding, the existing cross-validation check applies: if any leg's Buy ≥ Sell, the contract is paused (ref: [[price-formulas-complete]] §11). This guards against expansion causing crossed markets.

The maximum safe expansion depends on the O spread width and avoidance parameters. As expansion approaches 0.25 with a 2-tick O spread (O_Sell − O_Buy = 2.0), crossed-market risk emerges.

---

## 4. Expansion as a Confidence Signal

The expansion value encodes the .NET layer's confidence that a fill at the nearer tick is achievable. This creates a continuous dial from conservative to aggressive:

| Expansion | Behavior | Use Case |
|-----------|----------|----------|
| 0.00 | Identical to hard rounding | No evidence, full defense |
| 0.05 | Round toward market only when raw is within 0.05 of tick | High confidence required |
| 0.15–0.20 | Moderate expansion, ~30–40% of recalculations affected | Normal operation |
| 0.30+ | Aggressive, most recalculations round toward market | Fast liquidation, high urgency |

The trader's input price itself can encode this intent:

- **Buy 4.95** → expansion ≈ 0.05: Only pursue 5.0 when near-certain. Conservative.
- **Buy 5.10** → expansion ≈ 0.40: Capture most 5.0 opportunities. Don't miss.
- **Buy 5.40** → expansion ≈ 0.90: Accept 5.5 fills, attempt 5.0 when possible.

---

## 5. Edge Cost Analysis

### Per-Leg Cost

Each expansion event costs 0.5 ticks per leg (the price moves one tick toward market). With four prices per recalculation (Leg 1 Buy, Leg 2 Buy, Leg 1 Sell, Leg 2 Sell), the possible total edge cost per recalculation is:

| Expansions Firing | Total Cost | Classification |
|---|---|---|
| 0 | 0.0 ticks | No effect — Timer = Hard |
| 1 | 0.5 ticks | Single — one price expanded |
| 2 | 1.0 ticks | Double — two prices expanded |
| 3 | 1.5 ticks | Heavy — three prices expanded (rare) |
| 4 | 2.0 ticks | Quad — all four prices expanded (very rare) |

### Compounding Across Legs

Legs 1 and 2 raw buy prices sum to a constant: `(O_Buy - 2×Av_ZQ)` (independent of diff). Whether both legs simultaneously fall in their expansion zones depends on whether this constant's fractional position within the tick grid allows it. At specific diff values, both buy legs can expand simultaneously, producing a 1.0-tick cost classified as "double" even though only the buy side is affected.

### Relationship to O Spread Edge

The O spread edge budget is `O_Sell − O_Buy`. With a typical 2.0-tick edge:

- Single expansion costs 25% of edge budget
- Double expansion costs 50% of edge budget
- Quad expansion eliminates all defensive padding

Timer Logic is net-positive only when the incremental fills from expansion generate more P&L than the edge sacrificed on fills that would have occurred under hard rounding regardless.

---

## 6. Evidence-Conditioned Expansion — Signal Framework

Static expansion (fixed value) captures the basic mechanism. Evidence-conditioned expansion makes the value dynamic based on market state, computed in .NET per contract on each pricing cycle.

### 6.1 Price Discovery Signals

These signals estimate the **fillable price** — the discrete tick level most likely to produce a fill.

**Microprice (existing)**: Book-weighted midpoint. Already computed per [[price-formulas-complete]] §2. Represents instantaneous fair value. Fast-moving, reacts to every book change. Provides the raw price that Timer Logic rounds.

**Volume VWAP (new — .NET computation)**: Accumulation of `(trade price × trade volume) / total volume` over a rolling window. Reflects where actual trades are occurring, not just where the book rests. Slower-moving than microprice. When Volume VWAP and microprice agree, confidence is high. When they diverge (microprice has moved but Volume VWAP hasn't followed), the move is unconfirmed.

**LTP at discrete tick prices (new — .NET computation)**: Last Traded Price at each valid tick level. Unlike the single LTP available in ASE rules (ref: [[custom-rules-production]] §HitMan, Condition 5), this tracks the most recent trade at *each* relevant tick — e.g., when was the last trade at 4.5, when was the last trade at 5.0. A recent LTP at the desired fill price is the strongest short-term signal. If no trade at the desired price for 50+ seconds, probability of near-term fill drops substantially.

**Microprice behavior at tick boundaries**: As microprice approaches a valid tick level (e.g., moving from 3.85 → 3.90 → 4.01), the ask flips and microprice jumps discontinuously. Volume VWAP then confirms whether the flip persists. This flip-and-confirm pattern is a key signal for identifying transitions between fillable tick levels.

### 6.2 Confidence Signals

These signals estimate confidence that the discovered price is **achievable**.

**Direct vs. Total Quantity**: `DirectBidQuantity` vs `BidQuantity` (which includes implied). Available in ASE rules (ref: [[custom-rules-production]], HitMan Condition 8 uses DirectAskQuantity for implied avoidance). Timer Logic extends this beyond the crossing price to a general confidence multiplier: high direct-to-total ratio across the book → genuine trading interest → higher confidence.

**Standing Bid/Ask Quantity**: Resting quantity at the desired fill tick. Thick standing bid on the quote leg → more protection for passive fills. Available in ASE (`BidQuantityAtPrice`). Enriched in .NET with time-since-last-change to distinguish active from stale levels.

**PIQ (Position In Queue)**: Estimated lots ahead of the trader's order at a given price level. Not directly available from TT SDK — inferred from total resting quantity at the price and the time the order was submitted. Lower PIQ → higher fill probability → supports expansion.

**Historical volume at each price**: Lots traded at each discrete tick level over a rolling window. Distinguishes between prices that trade actively (high volume, continuous fills) and prices that are passed through without trading (gap moves). High historical volume at the desired fill price → higher confidence.

**Momentum and direction**: Whether the relevant leg prices are moving toward or away from the desired fill price. Microprice trending toward the desired tick + Volume VWAP confirming → increase expansion. Moving away → decrease or zero out expansion.

### 6.3 Signal Availability

| Signal | Available in ASE Rules | Currently Used in Rules | Requires .NET Computation |
|--------|:---:|:---:|:---:|
| Microprice (book-weighted) | Via CalcPrice | Yes | Already computed |
| Volume VWAP (trade-weighted) | No | No | Yes — rolling trade tape |
| LTP at specific tick prices | Partial (single LTP only) | Yes (HitMan Cond 5) | Extended: per-price LTP history |
| Time since LTP at price | No | No | Yes — timestamped LTP log |
| DirectQty vs TotalQty | Yes | Yes (implied avoidance) | Enrichable in .NET |
| Standing Bid/Ask Qty | Yes | Yes (multiple rules) | Available as-is |
| PIQ (Position In Queue) | No | No | Yes — inferred from queue state |
| Historical volume per price | No | No | Yes — rolling trade tape |
| Microprice momentum | No | Indirectly (ASM session range) | Yes — rolling window |
| Volume VWAP momentum | No | No | Yes — rolling window |
| Cross-leg correlation | No (single-leg scope) | No | Yes — .NET observes both legs |
| Book replenishment rate | No | No | Yes — bid stability tracking |

### 6.4 Signal Hierarchy

For latency-constrained execution (within 56ms quote throttle, ref: [[instruments-and-platform]] §Key Operational Parameters):

1. **LTP at desired price** — fastest confirmation. Binary: recent trade at this price or not.
2. **Microprice position** — instantaneous book state. Already in pipeline.
3. **Standing quantity and DirectQty ratio** — book quality. Low computation cost.
4. **Volume VWAP** — trade-weighted confirmation. Requires rolling accumulation.
5. **Momentum/trend** — directional persistence. Requires rolling window comparison.
6. **PIQ** — queue position. Requires order state tracking.
7. **Historical volume** — longer-term price activity. Highest latency tolerance.

Signals 1–3 are suitable for per-tick evaluation. Signals 4–7 update on a coarser cadence (every N ticks or every M milliseconds) and are consumed as pre-computed state by the per-tick expansion calculation.

---

## 7. Execution States

For an ASE buy: L1 is the quoting leg (passive buy rests on L1 bid), L2 is the hedge leg (sell into L2 bid when L1 fills). "L1 Bid strong/weak" refers to the thickness of the resting bid on L1 where the buy order sits. "L2 Bid strong/weak" refers to the thickness of the L2 bid that the hedge sell targets.

### 7.1 Core States (Trader-Identified)

**State 1 — L1 Bid weak, L2 Bid weak**
Both legs thin. No urgency on either side. Passive wait. Neither HitMan (ref: [[custom-rules-production]] §Rule 1, Condition 6 — LiqCheck fails) nor ASM fires aggressively. Timer Logic: conservative expansion — microprice position is primary signal; Volume VWAP confirmation required before any expansion.

**State 2 — L1 Bid strong, L2 Bid weak**
Protected passive buy on L1, uncertain hedge conditions on L2. HitMan territory: Condition 1 (hedge offer thin relative to bid) can fire. If momentum is present (prices moving up, LTP confirming), HitMan cross is optimal. If market is dull (no momentum), better to remain passive and wait for transition to State 1 or State 4. Timer Logic: expansion conditioned on momentum — high momentum → high expansion (capture the move), no momentum → low expansion (passive ASM enter preferred).

**State 3 — L1 Bid strong, L2 Bid strong**
Both legs thick at favorable levels. If `(L1_Bid + 1_tick) combined with (L2_Bid)` achieves desired ASE spread price, this is a high-quality opportunity. Estimated to occur in ~2–3% of observations due to market efficiency.

Caution: If occurring much more frequently, likely indicates a pricing error (e.g., mis-entered O_Buy/O_Sell) or a transient dislocation that should be captured quickly. Anomaly detection recommended: if State 3 frequency exceeds ~5% over a rolling window, flag for review.

Timer Logic: maximum expansion — this is a fill-both-legs opportunity. Prioritise speed of execution.

**State 4 — L1 Bid weak, L2 Bid strong**
Thin L1 bid (uncertain passive fill) but thick L2 bid (favorable hedge). Better than State 1: if the passive buy fills on L1, the hedge sell on L2 has high fill certainty. Even if L2 bid weakens (L2 bid becomes ask), this transitions to State 1 — so State 4 is strictly better than State 1 as a starting position.

Timer Logic: moderate expansion. L2 strength justifies confidence in the hedge leg; the constraint is L1 fill probability. PIQ and standing quantity at L1 bid are the primary signals. Clip size increase can be considered here: the favorable L2 conditions justify larger position risk on L1.

### 7.2 Extended States (Analysis-Identified)

**State 5 — Sweep aftershock on L2**
An aggressive buyer has just swept through L2 bid (visible via LTP at L2 bid or above, sudden BidQty drop). L2 bid is temporarily depleted; new bid may be one tick lower or very thin. HIGH-URGENCY window: the L2 bid is about to reset/refill. If the sweep signals continued momentum, fill L1 quickly (even crossing). HitMan may catch this if the depleted bid causes Condition 1 to pass, but HitMan does not know the depletion *just happened* vs. has been sitting. Volume VWAP spike on L2 in .NET can detect the recency.

Timer Logic: spike expansion briefly, decay over 2–5 seconds if conditions don't persist.

**State 6 — Book imbalance cascade**
L1 bid growing while L2 bid thickening simultaneously. The spread is compressing toward the desired price. Neither leg individually triggers HitMan/ASM thresholds, but the cross-leg convergence is a strong composite signal. ASE rules cannot see this (single-leg scope). .NET can detect by comparing L1 bid momentum and L2 bid momentum.

Timer Logic: increase expansion as convergence accelerates. The cross-leg signal supplements per-leg signals.

**State 7 — Iceberg / refresh detection on L1**
L1 bid gets partially filled but replenishes to the same level within ticks. Suggests an algorithmic buyer is working at that price — the bid is more reliable than its instantaneous quantity indicates. .NET detects this by tracking bid replenishment rate at the quote price.

Timer Logic: increase confidence in passive fill at L1 bid → lower expansion needed (the fill will come to you). Can also justify clip size increase.

**State 8 — Stale book (no activity)**
Neither L1 nor L2 has traded for an extended period (30+ seconds). Quantities are resting but no fills occurring. Microprice and Volume VWAP are stable from inactivity, not from equilibrium. Fill probability at any price is low in the near term.

Timer Logic: reduce expansion to near-zero. Don't chase fills that aren't coming. Wait for activity to resume.

**State 9 — Implied liquidity alignment**
On L1, DirectBidQty ≈ BidQty (bid is almost entirely direct). On L2, DirectBidQty is also dominant. Both legs show genuine resting interest, not other spread engines. Extends the HitMan Condition 8 implied avoidance concept (ref: [[custom-rules-production]] §Rule 1, Condition 8) from a single-price check to a general book quality signal.

Timer Logic: increase confidence multiplier. Direct-dominated books are more predictable.

---

## 8. Architecture

### Computation Split

The architecture separates evidence computation (.NET) from execution mechanics (ASE):

```
.NET VERSION_V9                                ASE (co-located with CME)
  (ref: architecture-and-dataflow.md)
┌──────────────────────────────┐              ┌──────────────────────────┐
│ MarketDataSubscriber         │              │ HitMan: cross on signal  │
│   ↓                          │              │ ASM: join on signal      │
│ VwapCalculator (v1,v2,v3)    │              │ Prevent Quote Cross      │
│   ↓                          │              │ Quote Best Bid/Ask       │
│ FinalDifferenceCalculator    │              │ Quote Throttle (56ms)    │
│   ↓                          │              │ Backoff: hedge patience  │
│ PriceCalculator              │              │ WCT Payup: hedge chase   │
│   ↓                          │              │       ↑                  │
│ Timer Logic rounding         │              │ Receives discretised     │
│   ↓                          │   GTC limit  │ leg prices via           │
│ PriceSignalRouter            │ ──orders──→  │ TTOrderActionService     │
│   ↓                          │              │                          │
│ [NEW] Evidence signals:      │              │ ASE rules evaluate       │
│   • Rolling trade tape       │              │ CalcPrice from received  │
│   • Volume VWAP accumulator  │              │ prices — rules unchanged │
│   • LTP-per-price history    │              └──────────────────────────┘
│   • Momentum windows         │
│   • Cross-leg correlation    │              ┌──────────────────────────┐
│       ↓                      │              │ FillSubscription         │
│ Dynamic expansion value      │  ←── fills ──│   (spread fill events)   │
│   (fed back to Timer Logic)  │              │   ref: order-mgmt §9    │
│                              │              └──────────────────────────┘
│ [NEW] AccuracyMeasurement    │
│   (hooks into fill pipeline) │
│   ref: accuracy-measurement  │
└──────────────────────────────┘
```

.NET adjusts the prices sent to ASE. ASE parameters stay static. The ASE rules (ref: [[custom-rules-production]]) operate on the Timer-adjusted CalcPrice without modification. This avoids the complexity and risk of dynamically modifying ASE rule parameters.

### Data Requirements

| Data | Source | Storage | Window |
|------|--------|---------|--------|
| Trade tape (price, volume, timestamp) | TT SDK market data | Circular buffer per instrument | ≤60 seconds |
| LTP per discrete tick price | Derived from trade tape | Timestamp map per tick level | ≤15 minutes |
| Bid/Ask replenishment events | TT SDK book updates | Counter per price level | ≤60 seconds |
| Volume VWAP | Computed from trade tape | Single rolling value | ≤60 seconds |
| Microprice momentum | Computed from microprice history | Short rolling window | ≤10 seconds |

Primary operational window: instantaneous to 60 seconds. Extended window (up to 15 minutes) used only for LTP-at-price history and rare regime-detection cases.

### Latency Constraints

Quote throttle inside = 56ms (ref: [[instruments-and-platform]] §Key Operational Parameters). The full evidence computation must complete well within this. Design implications:

- Pre-aggregate rolling statistics incrementally (update on each tick, never recompute from scratch)
- Use fixed-size circular buffers — no heap allocation in the hot path
- Signal hierarchy (§6.4) determines per-tick vs. coarser-cadence computation
- Signals 1–3 (LTP, microprice, standing qty) evaluated per tick
- Signals 4–7 (Volume VWAP, momentum, PIQ, historical volume) updated on coarser cadence and consumed as pre-computed state

---

## 9. Interaction with Existing Systems

### 9.1 Avoidance and Bias (ref: [[execution-modifiers]])

Timer Logic applies after avoidance and bias adjustments. The raw price it receives already incorporates Av_ZQ, Av_FF, BS_ZQ, and BS_FF. Timer Logic does not fight avoidance — it only softens the final rounding step on the already-widened price.

Dynamic avoidance scheduling (12:55–13:05 window, ref: [[execution-modifiers]] §8) operates independently. During the Fed window, avoidance pushes prices deeper into the book AND Timer Logic should reduce expansion (high-volatility regime → less confidence in any fill price).

### 9.2 HitMan (ref: [[custom-rules-production]] §Rule 1)

HitMan evaluates CalcPrice — which is now the Timer-adjusted price. When Timer Logic expands a buy price upward by 0.5 ticks, HitMan's Condition 3 (quote at inside bid) may pass more frequently because the expanded price is closer to or at the inside. This is synergistic: Timer Logic improves queue position; HitMan fires when microstructure confirms.

HitMan's Condition 7 (spread price check) validates economics post-cross. Timer-expanded prices may cause the spread check to fail at slightly different diff values than hard-rounded prices. This is self-correcting: if the expansion pushed the price to a level where the spread doesn't work, the check prevents execution.

### 9.3 ASM (ref: [[custom-rules-production]] §Rule 2)

ASM's Condition 2 checks if the calculated price is one tick from the inside bid. Timer-expanded prices are already closer to inside → ASM may fire less frequently (the quote is already at inside, so there's no "join" to perform). This is correct behavior: Timer Logic already did what ASM would have done.

### 9.4 Backoff (ref: [[custom-rules-production]] §Rule 6)

Backoff operates at the pre-hedge stage — after the quote fill, before hedge submission. It evaluates L2 book conditions to decide whether to rest the hedge one tick back. Timer Logic does not directly interact with Backoff because Timer Logic affects the quote price (pre-quote), not the hedge price.

However, in State 3 (both legs strong, rare opportunity), there is an indirect conflict: the favorable spread economics require filling at specific L2 tick levels, but Backoff may pull the hedge back one tick if L2 book is thick (QtyThreshold exceeded). Resolution options:

1. .NET sends a price one tick more aggressive, anticipating Backoff pullback (net position unchanged)
2. Accept Backoff as the cost of its general benefit (most fills aren't State 3)
3. Phase 2: dynamically adjust Backoff parameters via .NET when State 3 is detected

Option 2 is recommended initially. Option 1 introduces coupling between .NET and ASE rule behavior that is fragile.

### 9.5 WCT Payup (ref: [[custom-rules-production]] §Rule 8)

WCT Payup operates post-hedge, independent of quote-side Timer Logic. No interaction.

### 9.6 Safety Mechanisms (ref: [[safety-mechanisms]])

- **Cross-validation guard** ([[price-formulas-complete]] §11): Catches Timer-caused crossed markets (Buy ≥ Sell). Essential safety net. No modification needed.
- **Wide Spread Guard** ([[safety-mechanisms]] §3): When leg spreads > 1 tick, contract pauses. Timer Logic is moot during pauses.
- **Spike Detection** ([[safety-mechanisms]] §1): System-wide pause. Timer Logic is moot.
- **Fill Threshold** ([[safety-mechanisms]] §5): If Timer Logic increases fill rate significantly, the 100-lot threshold may trigger more frequently. Monitor after deployment.

---

## 10. Risks and Open Items

### Confirmed Risks

**R1 — Edge erosion exceeding fill gain**: Timer Logic's net value depends on incremental fills (fills that would not have occurred under hard rounding) outweighing edge sacrificed on non-incremental fills (fills that would have occurred regardless). Requires SIM validation with fill attribution: track which fills were at Timer-expanded prices vs. hard-rounded prices.

**R2 — Double/quad expansion compounding**: When multiple prices expand simultaneously, edge cost compounds (1.0–2.0 ticks per recalculation). The probability depends on `O_Buy − 2×Av_ZQ` modulo the tick grid. At specific parameter combinations, double expansion frequency can exceed 20%. Monitor via the classification distribution.

**R3 — Crossed market from expansion**: When expansion approaches 0.25 with a 2.0-tick O spread, Buy ≥ Sell can occur. The cross-validation guard catches this, but the resulting pause is an operational disruption. Maximum safe expansion should be computed per parameter set and enforced as a hard ceiling.

**R4 — Volume VWAP lag**: Volume VWAP lags microprice during fast moves. The "flip-and-confirm" pattern (microprice jumps, Volume VWAP follows) means waiting for Volume VWAP confirmation misses the fastest opportunities. Mitigation: use LTP for speed, Volume VWAP for confirmation (§6.4 hierarchy).

**R5 — Latency budget**: Evidence computation in .NET must complete within the 56ms quote throttle cycle. Tick-level data across multiple instruments and rolling windows is non-trivial. Incremental computation and fixed-size circular buffers are mandatory.

### Open Items

**O1 — PIQ availability**: Position In Queue inference from TT SDK. Not confirmed whether the SDK exposes sufficient queue state data. Needs SDK documentation review.

**O2 — Dynamic clip sizing**: States 4 and 7 suggest increasing clip size when conditions are favorable. Currently, reload clip is static per contract (ref: [[glossary]], Reload; [[order-management]] §3). Dynamic clip sizing would be a new capability in the ReloadMgr (ref: [[architecture-and-dataflow]] §4.1).

**O3 — State 3 anomaly detection**: If State 3 frequency exceeds expected rate (~5%), flag as potential pricing error or transient dislocation. Whether this belongs in the evidence layer or as a separate safety mechanism is TBD.

**O4 — Optimal rolling window sizes**: Primary window (microprice momentum, Volume VWAP) and confirmation window (LTP history) sizes require empirical calibration with SIM data. Starting recommendation: 10-second primary, 60-second confirmation.

**O5 — Phase 2 — ASE parameter modulation**: .NET dynamically adjusting ASE rule parameters (e.g., loosening HitMan VolRatio when confidence is high) via the TT SDK. Deferred until Phase 1 (dynamic expansion) is validated.

---

## 11. Accuracy Measurement

Timer Logic's value must be measured empirically. The accuracy measurement system (ref: [[accuracy-measurement]]) provides this via a three-way decomposition computed at each fill event:

### Decomposition

At fill time, four O values are computed using current market data from VwapCalculator cache (ref: [[architecture-and-dataflow]] §3 Stage 3) and the fill event from FillSubscription (ref: [[order-management]] §9):

```
O_target              Trader's O_Buy or O_Sell
    ↓ [Rounding cost]    Timer Logic impact: rounded price vs raw price
O_rounded_now         Reverse from TimerRound(forward(O_target, current diff))
    ↓ [Staleness cost]   Diff moved since .NET last sent price
O_from_entry          Reverse from EntryPrice (what .NET sent to ASE)
    ↓ [Execution cost]   ASE rules: Backoff, Payup, HitMan
O_from_match          Reverse from MatchPrice (what actually filled)
```

- **Rounding cost** isolates Timer Logic's edge impact per fill
- **Staleness cost** measures how much diff moved between price computation and fill — captures quote throttle (56ms) and deduplication (ref: [[order-management]] §6) effects
- **Execution cost** measures ASE rule impact in O-space — equivalent to the existing TD metric (ref: [[order-management]] §9.2) but expressed in the O price domain
- **Total = sum of all three**, verified by sanity check

### Key Verification Criteria (Pre-Production)

1. **Forward-reverse identity**: Reversing from the raw forward price must return O_target (formula consistency check).
2. **Crossed-market frequency**: Zero Timer-Logic-caused crossed-market pauses across the full SIM period.
3. **Rounding cost distribution**: Mean rounding cost < 0.15 ticks per fill, max < 1.0.
4. **Staleness distribution**: Mean staleness < 0.1 ticks. If consistently > 0.3, quote throttle or deduplication is suppressing needed updates.
5. **Fill attribution**: Segment fills into "incremental" (would not have occurred under hard rounding) vs "existing" (would have occurred regardless). Net P&L from incrementals must exceed rounding cost on existings.
6. **Classification distribution**: Single expansion < 40%, double < 15%, heavy/quad < 5% across all contracts and diff ranges.
7. **Latency**: Evidence computation P99 latency < 10ms (well within 56ms throttle).
8. **PhaseStart exclusion**: 1-lot canary fills excluded from accuracy stats (ref: [[order-management]] §5).

---

## Related

- [[price-formulas-complete]] — Formulas Timer Logic modifies at the rounding step (§6, §9)
- [[execution-modifiers]] — Avoidance and bias applied before Timer Logic
- [[core-quad-leg-arbitrage]] — Strategy structure Timer Logic prices
- [[custom-rules-production]] — ASE rules operating on Timer-adjusted prices
- [[ase-mechanics-and-parameters]] — ASE engine pipeline Timer Logic feeds into
- [[instruments-and-platform]] — Tick size (0.5) and quote throttle (56ms) constraints
- [[glossary]] — Microprice, diff, avoidanceValue, Reload definitions
- [[safety-mechanisms]] — Cross-validation guard and other protections
- [[order-management]] — Reload system (§3), fill events (§9), deduplication (§6)
- [[architecture-and-dataflow]] — .NET pipeline where evidence computation and accuracy measurement run
- [[accuracy-measurement]] — Three-way accuracy decomposition: reverse formulas, capture logic, sanity checks

### Jarvis Downstream
- [[jarvis/timer-logic/verification-report]] — WP-04 pre-implementation audit: 20 test cases, 4 issues found
- [[jarvis/timer-logic/implementation/README]] — WP-05 C# implementation (151/152 tests passing)
