---
tags: [residuals, convergence, positions, pricing-identity]
domain: strategy
load-priority: on-demand
last-updated: "2026-03-26"
---

# Residuals and Convergence

Residual positions created by fills, the closed pricing identity, and how positions converge to the stable structure. Load when analyzing position management.

---

## 1. Core Decomposition Relationships

The O spread decomposes into the four ASE legs via two fundamental relationships:

### Relationship 1 — O Splits into Near and Far SR3|SR1 Legs

> SR3|SR1 Mar Apr26 + SR3|SR1 Mar May26 = SR3|SR1 Mar26 O

The `diff` (synthetic SR1 calendar) determines the split. When the SR1 calendar widens, Leg 1 takes more of the O value; when it narrows, Leg 2 takes more. This ensures that across all fills, the legs maintain proportional exposure to the O structure.

### Relationship 2 — SR3|SR1 Converts to SR3|ZQ via the Basis

> SR3|ZQ Mar Apr26 = SR3|SR1 Mar Apr26 − (SR1 Apr − ZQ Apr)
> SR3|ZQ Mar May26 = SR3|SR1 Mar May26 − (SR1 May − ZQ May)

The residual in this conversion is the SR1-ZQ inter-product basis for each month. Legs 3 and 4 are priced at the SR3|SR1 leg prices minus their respective SR1-ZQ microprices (v1 and v2).

---

## 2. Residual Contracts by Fill Event

Each ASE fill creates a residual position that must be managed (manually or by offsetting fills on other ASEs):

| Fill Event | Residual Created | Classification |
|------------|------------------|-----------------|
| Leg 1 fill (SR3\|SR1 near) | SR1 near-far calendar | Low volatility, range-bound |
| Leg 2 fill (SR3\|SR1 far) | SR1 near-far calendar (opposite direction) | Low volatility, range-bound |
| Leg 3 fill (SR3\|ZQ near) | SR1-ZQ near-month basis | Range-bound; triggers SR1FF Avoidance when volatile |
| Leg 4 fill (SR3\|ZQ far) | SR1-ZQ far-month basis | Range-bound; triggers SR1FF Avoidance when volatile |
| Leg 1 + Leg 2 fills (paired) | SR1 near-far calendar (net of both) | Low volatility |
| Leg 3 + Leg 4 fills (paired) | SR1-ZQ near basis + SR1-ZQ far basis + ZQ calendar | Subject to SR1FF Avoidance |

### Interpretation

- **Legs 1 and 2**: Generate offsetting calendar residuals. If Leg 1 and Leg 2 fill proportionally over time, their calendar residuals cancel each other.
- **Legs 3 and 4**: Generate offsetting SR1-ZQ basis residuals. Similarly, proportional fills result in cancellation.
- **Paired fills**: When all four legs fill proportionally, the net residual converges toward zero and the position approaches the stable O structure.

---

## 3. The Closed Pricing Identity

The three monitoring instruments form a closed identity with the SR1 calendar:

> (SR1 near − ZQ near) − (SR1 far − ZQ far) + (ZQ near − ZQ far) = SR1 near − SR1 far

This can be rearranged as:

> SR1 near − SR1 far = (SR1 near − ZQ near) − (SR1 far − ZQ far) + (ZQ near − ZQ far)

Or in terms of microprices:

> diff = v1 − v2 + v3

Where:
- v1 = Microprice(SR1 near − ZQ near)
- v2 = Microprice(SR1 far − ZQ far)
- v3 = Microprice(ZQ near − ZQ far)

### Derivation Insight

This identity means the system can derive any one of these four spreads from the other three. The system uses the three component spreads (v1, v2, v3) as inputs because they are individually more liquid and tighter-spread than the SR1 calendar (diff) itself.

The SR1 calendar is derived synthetically, providing a more reliable microprice than observing it directly in a potentially less liquid instrument.

---

## 4. Convergence Dynamics

If all four ASEs fill proportionally over time:

### Calendar Residual Convergence

- Leg 1 buy accumulates a **long SR1 near-far calendar** residual
- Leg 2 buy accumulates a **short SR1 near-far calendar** residual (opposite direction)
- **Net effect**: The calendar residuals offset each other

### Basis Residual Convergence

- Leg 3 and Leg 4 fills accumulate SR1-ZQ basis residuals (near and far months)
- If fills on both legs are proportional, the basis residuals from both months average toward zero
- The ZQ calendar component cancels naturally (embedded in the legs' prices)

### Convergence to Stable Structure

When fills are proportional and residuals cancel:

> Net Position ≈ Short 10 SR3 + Long 3 SR1 near + Long 3 SR1 far (the stable O structure)

The cumulative P&L from fills plus the locked-in cost from arbitrage offsets = net arbitrage edge captured across the spread legs.

---

## 5. Practical Position Management

In practice, fills are **not always proportional**. The trader periodically inspects net residual positions:

- **Accumulated long calendar**: May exit some quantity of the SR1 near-far calendar spread, locking in residual profit or incorporating a directional view.
- **Accumulated basis residual**: May exit paired ZQ legs or rebalance the SR1-ZQ hedge.
- **Unhedged SR3**: If Leg 1 and Leg 2 fills are uneven, SR3 exposure may accumulate. Manual offsetting via direct SR3 positions or opposite-side Leg fills.

### Manual Exit Incorporation of Directional Views

The trader does not mechanically close residuals at fair value. Instead:

- If the trader believes the SR1 calendar will widen further, they may hold or extend the long calendar position
- If the trader expects basis convergence or credit spread tightening, they may adjust the SR1-ZQ residual exposure
- Exit timing incorporates the trader's directional conviction, not just reversion to zero

This manual exit strategy allows the system to capture additional alpha beyond the core 1-2 tick arbitrage edge.

---

## 6. Residual Monitoring Instruments

The three monitoring instruments (Aliases 1, 2, and 3) directly reflect the residuals:

| Alias | Instrument | Residual It Represents |
|-------|-----------|------------------------|
| Alias 1 | SR1-ZQ near-month inter-product | SR1-ZQ near basis (generated by Leg 3 fills) |
| Alias 2 | SR1-ZQ far-month inter-product | SR1-ZQ far basis (generated by Leg 4 fills) |
| Alias 3 | ZQ near-far calendar | SR1 calendar (generated by Legs 1+2 or implicitly by Legs 3+4 fills) |

When any residual becomes volatile (high bid-ask spread, large microprice moves), the corresponding monitoring instrument's spread widens. This triggers:

- **Avoidance escalation**: ZQ Spread Avoidance (Av_ZQ) for Aliases 1+2, SR1FF Avoidance (Av_FF) for Alias 3
- **Quote widening**: Both buy and sell prices on affected legs move into depth
- **Dynamic adjustment**: During scheduled events (12:55–13:05), Av_FF escalates to 0.11

---

## 7. Identity Verification and Calculation Order

The closed identity ensures calculation consistency:

1. **Market data arrives**: Bid-ask updates for all three monitoring instruments
2. **Microprices computed**: v1, v2, v3 calculated from current bids and asks
3. **Diff derived**: diff = v1 − v2 + v3 (synthetically computes SR1 calendar)
4. **Legs priced**: All four leg prices computed from the diff and avoidance/bias parameters
5. **Validation**: If any Buy >= Sell on any leg, contract paused
6. **Deduplication**: If prices unchanged from last snapshot, no orders sent

Every price update implicitly respects the closed identity: the three component spreads always sum to the SR1 calendar representation embedded in the diff.

---

## 8. Summary: Residual Management Strategy

| Stage | Residuals | Action |
|-------|-----------|--------|
| **Entry** | Proportional fills accumulate offsetting residuals | System quotes all 4 legs with inter-leg compensation |
| **Accumulation** | Uneven fills → net calendar and basis exposure | Trader monitors and may add/reduce via manual trades |
| **Monitoring** | Aliases 1/2/3 signal residual volatility | System escalates avoidance; trader may adjust exposure |
| **Exit** | Trader exits accumulated residuals | Incorporates directional views on basis/calendar; not mechanical |
| **Convergence** | Proportional fills offset residuals → O structure achieved | Arbitrage edge captured; hedges dissolve; core position intact |

The system design acknowledges that residuals are inevitable byproducts of fills. Rather than managing them away completely, the system:

1. Uses them as pricing signals (the three monitoring instruments)
2. Offers them controlled entry (avoidance/bias parameters)
3. Allows the trader to express tactical views on their convergence (manual exit timing)
4. Ensures proportional fills naturally lead to stable structure convergence (relationship identities)

## Related

- [[core-quad-leg-arbitrage]] — Strategy that generates residual positions
- [[instruments-and-platform]] — Contract specs for residual valuation
- [[price-formulas-complete]] — Pricing identity that residuals close through
- [[methodology-and-framework]] — P&L on matched fills vs open residuals
- [[Plan-2026-03-28]] — Comprehensive work plan referencing this file

### Jarvis Downstream
- [[jarvis/timer-logic/verification-report]] — Residual behavior verified in WP-04 audit
