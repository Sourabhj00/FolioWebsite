---
tags: [ancillary, case-spreads, bond-rolls, euribor, sonia]
domain: strategy
load-priority: on-demand
last-updated: "2026-03-26"
---

# Ancillary Strategies

Non-core strategies deployed as ASE configurations. Load when working with ancillary spread strategies.

---

## 1. SR1-ZQ Inter-Product Spread ("Case")

**Status:** Implemented — 7 monthly configs deployed
**Core Mechanic:** Direct inter-product spread between SR1 and ZQ for a single expiry month.

**Formula:**
> 100 × SR1 − 100 × ZQ

**Coverage:**
- Monthly expiries (Mar–Sep)
- Each month traded as a standalone inter-product spread

**Purpose:** Building blocks that the core quad-leg arbitrage arbitrages across. Direct exposure to SR1-ZQ basis independent of the O structure.

**Market & Instrument:** CME: SR1 vs ZQ, monthly expiries

---

## 2. Bond Futures Roll Spreads ("Rol" / "Roll" / "Roll's")

**Status:** Implemented — 80+ ASE config files deployed
**Core Mechanic:** Calendar roll spreads on bond futures. Buy front month, sell back month in 1:−1 ratio.

**Contract Coverage:**

- **US Treasuries:** ZN (10Y Note), ZT (2Y Note), ZF (5Y Note), ZB (30Y Bond), UB (Ultra Bond), R/TN (2Y Note variations)
- **German:** FGBL (Bund), FGBM (Bobl), FGBS (Schatz), FGBX (Euro Schatz)
- **Italian:** FBTP (BTP), FBTS (Short-Term BTP)
- **French:** FOAT (OAT)
- **Canadian:** CGB (Avg Life Bond), CGF (Five-Year), CGZ (Two-Year)

**Exchanges:** CME, Eurex, Montreal Exchange

**Config Variants:**
- **"Rol"** — Standard roll configuration
- **"Roll"** — Alternative naming convention for rolls
- **"Roll's"** — Variant configuration (possibly with different rule parameters or execution pathway)

**Purpose:** Capture roll-over spread narrowing as futures contracts approach delivery/expiration. Exploit the carry and financing advantage of shorter-dated instruments.

---

## 3. SR3-CRA Butterfly Basis ("Int SR3 CRA" / "CRADF" / "BED")

**Status:** Implemented — ASE configs deployed
**Core Mechanic:** Trades the basis between SR3 butterflies and CRA (Credit Risk Adjusted) butterflies. Mixed PriceMultipliers (100 for SR3, 1 for CRA) reflect different rate conventions.

**Variants:**

- **"Int SR3 CRA"** — SR3 butterfly vs CRA butterfly spread-of-spreads. Example: "Int SR3 CRA Jun26 3mo" = SR3:BF M6-U6-Z6 vs CRA:BF M6-2U6+Z6
- **"CRADF"** — CRA Difference: inter-product spread between two CRA butterflies across different tenors
- **"BED"** — Basis trade: CRA vs SR3 outright for a single expiry. Example: "BED Dec24" = CRA Z4 vs SR3 Z4

**Purpose:** Captures credit spread dynamics within the SOFR complex. CRA instruments price credit risk premia; the basis against SR3 (unsecured rates) provides exposure to credit spread tightening/widening.

**Market & Instrument:** CME: SR3 and CRA butterflies

---

## 4. ZQ Fed Fund Spread Structures ("ZQ Str")

**Status:** Implemented — 50+ ASE config files deployed
**Core Mechanic:** Various structured spread trades on Fed Fund Futures. Configuration names encode the structure.

**Examples:**
- "ZQ Str JulAug AO 2_1" — July vs August calendar with specific ratio structure
- "ZQ Str Mar Fly" — March butterfly (month1 − 2×month2 + month3)
- "O_R" suffix — Outright vs Roll variant

**Structures Supported:**
- Calendar spreads (front month vs back month)
- Butterflies (3-month and longer combos)
- Multi-month ratio combinations

**Purpose:** Direct exposure to Fed Fund futures curve dynamics. Complements SR1/SOFR arbitrage by trading the FF curve independently. Useful for capturing FF-SOFR basis convergence or curve reshaping.

**Market & Instrument:** CME: ZQ across numerous monthly expiries

---

## 5. Euribor Spreads ("IER" / "ER Str" / "AAA")

**Status:** Implemented — ASE configs deployed
**Core Mechanic:** Capture spread dynamics in Euribor rate futures across tenors and structures.

**Variants:**

- **"IER"** — Euribor inter-product spreads across expiries. Example: "IER Jun-Sep" = Euribor spread from Jun to Sep
- **"ER Str"** — Euribor strips with ratio structures. Configurable multi-leg spreads on Euribor futures
- **"AAA"** — Butterfly spread-of-spreads. Example: "AAA" = SR3:BF U6-Z6-H7 vs SR3:BF H7-M7-U7 (cross-expiry butterfly)

**Purpose:** European interest rate arbitrage. Captures basis between Euribor and other rate complex components (e.g., EUR OIS). Similar philosophy to SR3-SR1-ZQ but for EUR rates.

**Market & Instrument:** Eurex: ER3 (Euribor) and associated butterfly instruments

---

## 6. SONIA and SARON Cross-Exchange Basis

**Status:** Implemented — ASE configs deployed
**Core Mechanic:** Inter-product and inter-exchange spreads on SONIA (Sterling) and related rate futures.

**Variants:**

- **"ISO"** — Inter-product Spread Outright for SONIA. Example: "ISO Dec26-Dec27" = SONIA Dec26-Dec27 calendar spread vs SO3 Dec26-Dec27 calendar spread (uses 100x PriceMultiplier)
- **"ISA3"** — Inter-product Spread SONIA vs SA3 (3-month SONIA). Example: "ISA3 Dec26" = SONIA Dec26 outright vs SA3 Dec26 outright

**Exchanges:** ICE (SONIA, SO3, SA3)

**Purpose:** Capture cross-tenor basis dynamics in the UK SONIA complex. Bridges 1-month and 3-month SONIA rate structures.

**Market & Instrument:** ICE: SONIA (I prefix), SO3, SA3

---

## 7. Euribor Butterfly and Inter-Product Spreads ("ER Str" / "AAA" detailed)

**Status:** Implemented — ASE configs deployed
**Core Mechanic:** Multi-leg structures capturing Euribor curve and basis dynamics.

**Variants:**
- **"ER Str"** — Euribor strips: calendars, butterflies, or custom ratio spreads on consecutive Euribor expiries
- **"AAA"** — Euribor butterfly spread-of-spreads: compares two 3-month butterflies across different tenors to capture curve slope changes

**Purpose:** Capture curve convexity and slope changes in the Euribor rate complex. Offers exposure to longer-dated European rate dynamics.

**Market & Instrument:** Eurex and CME: Euribor (ER3) and related butterfly instruments

---

## 8. Cross-Exchange SONIA-SR3 Basis ("Int SRI" / "Tee")

**Status:** Implemented — ASE configs deployed
**Core Mechanic:** Inter-product spreads between SR3 butterflies (US SOFR) and SONIA/SARON instruments (UK SONIA), bridging US-UK rate differentials.

**Variants:**
- **"Int SRI"** — SR3 vs SONIA/SARON inter-product spread
- **"Tee"** — Transatlantic equivalent configuration (possibly with specific tenor pairings)

**Purpose:** Capture transatlantic rate basis between US SOFR and UK SONIA. Reflects relative funding costs, regulatory treatment, and credit spread differences between USD and GBP overnight rate complexes.

**Market & Instrument:** CME (SR3) vs ICE (SONIA/SARON)

---

## 9. US Treasury Curve Trades ("aa" / "US")

**Status:** Implemented — ASE configs deployed (no rules attached, semi-automated)
**Core Mechanic:** Multi-leg bond futures curve trades.

**Examples:**
- **"aa 2-5-10"** — Treasury butterfly: ZT(3) : ZF(−5) : ZN(1) in ratio 3:−5:1
- **"US 2-10"** — 2-year vs 10-year spread
- **"2-3 vs ED Z2M3"** — Cross-asset trade: 2-3yr Treasury vs Eurodollar

**Tenors Covered:** ZT (2Y), ZF (5Y), ZN (10Y), ZB (30Y), UB (Ultra Bond)

**Purpose:** Capture curve reshaping and steepening/flattening trades. Synthetic exposure to long-term interest rate volatility and macro rate expectations.

**Market & Instrument:** CME: Treasury futures (ZT, ZF, ZN, ZB, UB, GE for Eurodollar cross-trades)

---

## 10. X_Y Secondary Strategy

**Status:** Partially Implemented — Infrastructure exists; initialization commented out in Program.cs
**Core Mechanic:** Simplified 2-leg strategy on SR3|SR1 X and Y ASE instruments. Uses independent parameters from X_Y_Parameter.csv layered on top of the main contract's buyBiased/sellBiased.

**Structure:**
> Leg1 Buy = xyBuyBiased + mainBuyBiased
> Leg2 Buy = −xySellBiased + mainBuyBiased

Anti-symmetric formula: when xyBuyBiased is positive (aggressive on Leg1), Leg2 becomes passive (negative sell-biased component). When xyBuyBiased is negative, Leg1 becomes passive.

**Purpose:** Secondary layer enabling two-level pricing: main contract level (tied to all four core legs) and X_Y level (independent tactical expression on just SR1 near-far structure).

**Configuration Files:**
- `ContractLegs_X_Y.csv` — Maps which contracts participate in X_Y strategy
- `X_Y_Parameter.csv` — Holds independent X_Y parameters (xyBuyBiased, xySellBiased)

**Market & Instrument:** CME SR3|SR1 ASE instruments with X/Y suffixes

**Current Status:** Infrastructure fully coded but strategy initialization is commented out. Can be activated by uncommenting in Program.cs if needed.

---

## Summary Table

| Strategy | Configs | Coverage | Core Purpose |
|----------|---------|----------|--------------|
| Case (SR1-ZQ) | 7 | 7 monthly expiries | Building blocks for O arbitrage |
| Rol/Roll/Roll's (Bonds) | 80+ | ZN, ZT, ZF, ZB, UB, FGBL, FGBM, FGBS, FGBX, FBTP, FBTS, FOAT, CGB, CGF, CGZ | Bond roll spread capture |
| Int SR3 CRA | Variable | SR3 vs CRA butterflies | Credit spread dynamics |
| ZQ Str | 50+ | ZQ multiple expiries | Fed Fund curve trading |
| IER / ER Str / AAA | Variable | Euribor across tenors | EUR rate arbitrage |
| ISO / ISA3 | Variable | SONIA complex | UK rate curve trading |
| Int SRI / Tee | Variable | SR3 vs SONIA | Transatlantic basis |
| aa / US | Variable | ZT, ZF, ZN, ZB, UB | US Treasury curve |
| X_Y | Partial | SR3\|SR1 near-far | Secondary tactical layer |

## Related

- [[instruments-and-platform]] — Contract specs for SR1-ZQ, bond, Euribor products
- [[core-quad-leg-arbitrage]] — Core strategy these supplement
- [[glossary]] — Naming conventions (Case, Rol, IER, etc.)
- [[Plan-2026-03-28]] — Comprehensive work plan referencing this file
