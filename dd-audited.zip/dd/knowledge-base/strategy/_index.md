# Strategy — Map of Content

Core and ancillary strategy logic. Covers the quad-leg arbitrage thesis,
pricing formulas, execution parameter modifiers, residual position
management, and non-core spread strategies.

## Files

- [[core-quad-leg-arbitrage]] — The SR3-SR1-ZQ quad-leg arb: thesis (O-spread convergence), stable structure (−10:+3:+3), decomposition into 4 ASEs, quoting/hedge leg assignments, and the pricing identity.
- [[price-formulas-complete]] — Every formula: microprice calc, diff derivation, per-leg buy/sell raw prices, rounding rules, avoidance/bias application, wide-spread fallback.
- [[execution-modifiers]] — Avoidance (symmetric spread-widening) and B/S Bias (directional skew): philosophy, per-leg formulas, parameter interactions, combined effect tables.
- [[residuals-and-convergence]] — Residual positions from each fill event, the closed pricing identity (Leg1+Leg2=O, Leg3/4 via basis), convergence mechanics, and position management.
- [[ancillary-strategies]] — Non-core strategies: SR1-ZQ "Case" spreads, bond roll spreads (Rol/Roll/Roll's), Euribor IER, SONIA. Config counts and formulas.
- [[timer-logic]] — Evidence-conditioned rounding: replaces hard RD/RU with market-evidence-based expansion. Signal framework (microprice, Volume VWAP, LTP history, PIQ), execution states, ASE rule interaction analysis, edge cost model. Status: staging pending SIM erification.

## Related Folders

- [[core/_index|Core]] — Glossary and instrument specs referenced by all strategies
- [[ase-rules/_index|ASE Rules]] — Rules that execute strategy logic within the ASE
- [[execution-analysis/_index|Execution Analysis]] — Measures how well strategies perform
- [[application/_index|Application]] — .NET app that implements strategy parameters
- [[planning/_index|Planning]] — Work plan referencing strategy logic across multiple goals

### Jarvis Analysis
- [[jarvis/timer-logic/_index|Jarvis: Timer Logic]] — WP-04/05: formula audit and C# implementation
- [[jarvis/fair-value/_index|Jarvis: Fair Value]] — WP-02: SOFR bootstrap and valuation engine
- [[jarvis/market-profiling/_index|Jarvis: Market Profiling]] — WP-03: contract segmentation using strategy parameters
- [[jarvis/strategy-research/_index|Jarvis: Strategy Research]] — Directional bias model extending strategy logic
