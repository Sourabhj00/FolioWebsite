---
tags: [strategy, quad-leg, arbitrage, o-spread, decomposition]
domain: strategy
load-priority: on-demand
last-updated: "2026-03-26"
---

# Core Quad-Leg Arbitrage Strategy

The core SR3-SR1-ZQ quad-leg arbitrage strategy — thesis, structure, decomposition, and operating mechanics. Load when discussing strategy logic or modifications.

---

## 1. Core Thesis

The SR3|SR1 "O" spread (a 3-leg structure combining one SR3 quarterly and two SR1 monthlies) has a calculable fair value. The live market price of this structure deviates from fair value due to transient market forces, but converges over time. The strategy captures this convergence by entering at favourable distortions and allowing mean-reversion to generate profit.

---

## 2. The Stable Structure

The target position is the SR3|SR1 O spread, defined as:

- **Short** 10 lots SR3 (quarterly SOFR)
- **Long** 3 lots SR1 near-month
- **Long** 3 lots SR1 far-month

For the March 26 expiry group: SR3 Mar / SR1 Apr / SR1 May at ratio −10 : +3 : +3. June, September, and December follow the same pattern shifted forward by one quarter.

This structure is considered "stable" — its price moves within a narrow, predictable range. The trader sets buy and sell prices based on fair value calculations and current portfolio exposure.

---

## 3. Decomposition into Four ASEs

Rather than executing the 3-leg O spread directly, the system decomposes it into four 2-leg ASE spreads that trade in more liquid markets. Each ASE is a synthetic spread executed on TT Autospreader, with one quoting leg (passively quoted in the market) and one hedge leg (filled on the opposite side when the quote fills).

Using March 26 as reference:

| Leg | ASE Name | Quoting Leg | Hedge Leg | Ratio (3:−5) |
|-----|----------|-------------|-----------|--------------|
| 1 | SR3\|SR1 Mar Apr26 | SR1 Apr (+3) | SR3 Mar (−5) | 3 : −5 |
| 2 | SR3\|SR1 Mar May26 | SR1 May (+3) | SR3 Mar (−5) | 3 : −5 |
| 3 | SR3\|ZQ Mar Apr26 | ZQ Apr (+3) | SR3 Mar (−5) | 3 : −5 |
| 4 | SR3\|ZQ Mar May26 | ZQ May (+3) | SR3 Mar (−5) | 3 : −5 |

Legs 1 and 2 are SR3-vs-SR1 spreads. Legs 3 and 4 are SR3-vs-ZQ spreads derived from Legs 1 and 2 by stripping out the SR1-ZQ inter-product basis.

**Production ASE configurations** use the 6:−10 ratio, which equals 2×(3:−5) and represents 2 fills per clip, maintaining mathematical equivalence to the stable structure.

---

## 4. Expiry Groups

The system runs four quarterly expiry groups simultaneously:

| Group | SR3 Contract | Near SR1 | Far SR1 | Near ZQ | Far ZQ |
|-------|-------------|----------|---------|---------|--------|
| Mar26 | SR3 Mar (H6) | SR1 Apr (J6) | SR1 May (K6) | ZQ Apr (J6) | ZQ May (K6) |
| Jun26 | SR3 Jun (M6) | SR1 Jul (N6) | SR1 Aug (Q6) | ZQ Jul (N6) | ZQ Aug (Q6) |
| Sep26 | SR3 Sep (U6) | SR1 Oct (V6) | SR1 Nov (X6) | ZQ Oct (V6) | ZQ Nov (X6) |
| Dec26 | SR3 Dec (Z6) | SR1 Jan27 (F7) | SR1 Feb27 (G7) | ZQ Jan27 (F7) | ZQ Feb27 (G7) |

Each group has the same 4-leg ASE structure and identical calculation logic.

---

## 5. Trader Inputs

For each expiry group, the trader enters:

- **Buy Price** — the price at which they want to buy the O structure
- **Sell Price** — the price at which they want to sell the O structure
- **Buy Quantity / Sell Quantity** — total target lots per side
- **Reload Clip** — number of lots per order submission (buy reload, sell reload)

---

## 6. Monitoring Instruments

The system continuously observes three live market instruments per expiry group. These are inter-product and calendar spreads quoted on TT, used as pricing inputs:

| Alias | Instrument | Example (Mar26) |
|-------|-----------|-----------------|
| Alias 1 | SR1-ZQ near-month inter-product | SR1 Apr − ZQ Apr |
| Alias 2 | SR1-ZQ far-month inter-product | SR1 May − ZQ May |
| Alias 3 | ZQ near-far calendar | ZQ Apr − May |

For each instrument, the system computes a **microprice** from the live bid-ask ladder:

> Microprice = (Bid × AskQty + Ask × BidQty) / (BidQty + AskQty)

If the bid-ask spread exceeds 0.5 ticks, the system falls back to the simple midpoint `(Bid + Ask) / 2`. **Guard**: if spread > 1 tick, the contract is paused to prevent execution when microprice is unreliable.

---

## 7. The Diff — Synthetic SR1 Calendar Observation

Instead of observing the SR1 near-far calendar spread directly, the system derives it from the three monitoring instruments:

> diff = Microprice(SR1-ZQ near) − Microprice(SR1-ZQ far) + Microprice(ZQ near-far calendar)

Algebraically, this simplifies to **SR1 near − SR1 far** (the SR1 calendar), but it is observed indirectly through three more liquid, tighter-spread instruments. This synthetic observation provides a more reliable microprice than the SR1 calendar spread itself.

The diff determines how the trader's O price is split between the near-month and far-month ASE legs. Every time any of the three monitoring instruments ticks, the diff updates and the entire price calculation re-runs.

---

## 8. Leg Prices: Anti-Symmetric Structure

Leg 1 and Leg 2 prices are anti-symmetric around diff: Leg 1 uses +diff, Leg 2 uses −diff. This creates a natural hedge.

**Base prices (before B/S Bias):**

- Leg 1 Buy = (O Buy + diff) / 2
- Leg 1 Sell = (O Sell + diff) / 2
- Leg 2 Buy = (O Buy − diff) / 2
- Leg 2 Sell = (O Sell − diff) / 2

**Cross-check**: Leg 1 + Leg 2 always equals the O input price (before avoidance adjustments). The diff determines the allocation — when the SR1 calendar widens, more value shifts to Leg 1 (near month) and less to Leg 2 (far month), and vice versa.

Avoidance and B/S Bias parameters are then applied (see **Execution Modifiers** document).

---

## 9. Leg 3 & 4: SR3|ZQ Derivation

The SR3|ZQ legs are derived from the SR3|SR1 legs by subtracting the corresponding SR1-ZQ inter-product basis:

- Leg 3 Buy = Leg 1 Buy Raw − Microprice(SR1-ZQ near) (then adjusted by SR1FF parameters)
- Leg 3 Sell = Leg 1 Sell Raw − Microprice(SR1-ZQ near) (then adjusted by SR1FF parameters)
- Leg 4 Buy = Leg 2 Buy Raw − Microprice(SR1-ZQ far) (then adjusted by SR1FF parameters)
- Leg 4 Sell = Leg 2 Sell Raw − Microprice(SR1-ZQ far) (then adjusted by SR1FF parameters)

**Identity**: SR3|ZQ = SR3|SR1 − (SR1 − ZQ). The residual when converting from a SR3|SR1 position to a SR3|ZQ position is the SR1-ZQ inter-product basis for that month.

---

## 10. X & Y ASEs (Secondary Structure)

In addition to the four core ASE legs, the system supports X and Y ASEs — 3-leg spreads that embed the ZQ calendar directly into the ASE structure:

**X (Mar26):** SR3 Mar (−10) / ZQ Apr-May calendar (−3) / SR1 Apr (+6)

**Y (Mar26):** SR3 Mar (−10) / ZQ Apr-May calendar (+3) / SR1 May (+6)

X captures the near-month (SR1 Apr) with a short ZQ calendar embedded. Y captures the far-month (SR1 May) with a long ZQ calendar embedded. Together, X + Y reconstitutes the O position at double scale.

X and Y prices are derived from the O price and a separate X_Y bias parameter:

> X Buy = RD(X_Y Buy Bias + O Buy)
> X Sell = RU(X_Y Sell Bias + O Sell)
> Y Buy = RD(−X_Y Sell Bias + O Buy)
> Y Sell = RU(−X_Y Buy Bias + O Sell)

The same defensive rounding applies: buy prices round down, sell prices round up. Currently outputs to console only — does not route orders to the exchange.

---

## 11. Core Edge and Convergence

**Core edge:** SR3 (3-month SOFR) can be decomposed into SR1 (1-month SOFR) components. SR1 should price consistently with ZQ (Fed Funds) after accounting for the SOFR-FF basis. Deviations from fair value create the arbitrage opportunity.

The three monitoring instruments form the pricing anchor: they are more liquid and tighter-spread than the SR1 calendar itself, providing a more reliable microprice signal.

**Mean reversion:** The O spread price deviates from fair value due to transient market forces. The strategy enters at favourable distortions and allows mean-reversion to converge the market back to fair value, locking in a 1-2 tick edge across the spread legs.

---

## 12. Current Status

- **System**: New_Regime v9
- **Asset Class**: STIR Futures — SOFR (SR3, SR1), Fed Funds (ZQ)
- **Exchange**: CME Globex
- **Execution**: TT Autospreader (ASE) via .NET SDK
- **Active Configurations**: 529+ ASE configs deployed
- **Status**: Live production (ProdLive environment)

## Related

- [[glossary]] — Master terminology
- [[instruments-and-platform]] — Contract specs for SR3/SR1/ZQ
- [[price-formulas-complete]] — Pricing formulas for each leg
- [[execution-modifiers]] — Avoidance and bias applied to strategy prices
- [[residuals-and-convergence]] — Position residuals from quad-leg fills
- [[custom-rules-production]] — Production rules executing this strategy
- [[order-management]] — Reload/clip system implementing fill logic
- [[Plan-2026-03-28]] — Comprehensive work plan referencing this file

### Jarvis Downstream
- [[jarvis/timer-logic/verification-report]] — Quad-leg structure verified across 20 test cases
- [[jarvis/fair-value/sofr-bootstrap-methodology]] — Derives fair value anchoring O-spread convergence thesis
- [[jarvis/market-profiling/contract-segmentation]] — Segments quad-leg aliases into execution groups
- [[jarvis/strategy-research/directional-bias-model]] — Extends O-spread thesis with Treasury lead-lag signal
