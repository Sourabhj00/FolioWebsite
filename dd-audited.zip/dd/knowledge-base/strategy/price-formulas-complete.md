---
tags: [pricing, formulas, microprice, diff, avoidance, bias]
domain: strategy
load-priority: on-demand
last-updated: "2026-03-26"
---

# Price Formulas — Complete Reference

All price calculation formulas for the core strategy. Load when debugging pricing, verifying calculations, or modifying the formula engine.

---

## 1. Notation Definitions

- **O_Buy, O_Sell** — Trader-entered O spread buy and sell prices
- **diff** — Composite microprice spread signal: `Microprice(SR1-ZQ near) − Microprice(SR1-ZQ far) + Microprice(ZQ near-far calendar)`
- **v1** — Microprice(SR1-ZQ near-month inter-product)
- **v2** — Microprice(SR1-ZQ far-month inter-product)
- **Av_ZQ** — ZQ Spread Avoidance parameter
- **BS_ZQ** — ZQ Spread B/S Bias parameter
- **Av_FF** — SR1FF Avoidance parameter
- **BS_FF** — SR1FF B/S Value parameter
- **RD(x)** — Round down to nearest valid tick
- **RU(x)** — Round up to nearest valid tick

---

## 2. Microprice Calculation

For each monitoring instrument, compute:

> Microprice = (Bid × AskQty + Ask × BidQty) / (BidQty + AskQty)

**Fallback (when bid-ask spread > 0.5 ticks):**

> Microprice = (Bid + Ask) / 2

**Guard**: If bid-ask spread exceeds 1 tick, all orders for the affected contract are paused. This prevents execution when the microprice is unreliable due to thin liquidity.

---

## 3. The Diff Formula

The synthetic SR1 calendar is derived from three monitoring instruments:

> diff = Microprice(SR1-ZQ near) − Microprice(SR1-ZQ far) + Microprice(ZQ near-far calendar)

Algebraically, this simplifies to SR1 near − SR1 far, but is observed indirectly through three more liquid instruments. Every market data tick on any of the three instruments triggers a diff recalculation.

---

## 4. Legs 1 & 2 — SR3|SR1 Base Prices

**Base prices (before B/S Bias adjustment):**

> Leg 1 Buy Raw = (O_Buy + diff) / 2 − Av_ZQ
> Leg 1 Sell Raw = (O_Sell + diff) / 2 + Av_ZQ
> Leg 2 Buy Raw = (O_Buy − diff) / 2 − Av_ZQ
> Leg 2 Sell Raw = (O_Sell − diff) / 2 + Av_ZQ

**Cross-check**: Before avoidance, Leg 1 + Leg 2 = O input price. The diff determines the allocation.

---

## 5. Legs 1 & 2 — B/S Bias Adjustment (ZQ Spread)

**If BS_ZQ > 0 (buy bias on SR1-ZQ calendar):**

> Leg 1 Buy Raw += BS_ZQ
> Leg 2 Sell Raw −= BS_ZQ

**If BS_ZQ < 0 (sell bias on SR1-ZQ calendar):**

> Leg 1 Sell Raw += BS_ZQ
> Leg 2 Buy Raw −= BS_ZQ

Positive bias makes Leg 1 Buy more aggressive and Leg 2 Sell less aggressive. Negative bias reverses this.

---

## 6. Legs 1 & 2 — Final Rounding

After all adjustments:

> Leg 1 Buy = RD(Leg 1 Buy Raw)
> Leg 1 Sell = RU(Leg 1 Sell Raw)
> Leg 2 Buy = RD(Leg 2 Buy Raw)
> Leg 2 Sell = RU(Leg 2 Sell Raw)

**Rounding rule**: Buy prices are rounded **down** to the nearest valid tick (passive on buy side). Sell prices are rounded **up** (passive on sell side). This is intentionally defensive — the system never aggresses at the order-price level.

---

## 7. Legs 3 & 4 — SR3|ZQ Base Prices

**Base prices (including BS_FF in base, before conditional B/S Value adjustment):**

> Leg 3 Buy Raw = Leg 1 Buy Raw − v1 − BS_FF − Av_FF
> Leg 3 Sell Raw = Leg 1 Sell Raw − v1 − BS_FF + Av_FF
> Leg 4 Buy Raw = Leg 2 Buy Raw − v2 − BS_FF − Av_FF
> Leg 4 Sell Raw = Leg 2 Sell Raw − v2 − BS_FF + Av_FF

Legs 3 and 4 are computed from Legs 1 and 2 raw (before their final rounding) minus the respective SR1-ZQ microprice (v1 for near month, v2 for far month), minus BS_FF, and adjusted by avoidance.

---

## 8. Legs 3 & 4 — B/S Value Adjustment (SR1FF)

The B/S Value parameter works on BOTH buy and sell sides simultaneously, unlike the ZQ B/S which is asymmetric between legs. BS_FF is subtracted in the base formula for all four prices. The conditional adjustment then adds it back on one side, leaving that side unaffected while the other side retains the `− BS_FF` shift.

**If BS_FF > 0 (sell bias on SR1-ZQ basis):**

Adds BS_FF back to buy prices on both legs (cancels the base subtraction, leaving buys unaffected; sells retain `− BS_FF` making them more aggressive):

> Leg 3 Buy Raw += BS_FF
> Leg 4 Buy Raw += BS_FF

**If BS_FF < 0 (buy bias on SR1-ZQ basis):**

Adds BS_FF back to sell prices on both legs (cancels the base subtraction, leaving sells unaffected; buys retain `− BS_FF` which is a positive shift since BS_FF is negative, making buys more aggressive):

> Leg 3 Sell Raw += BS_FF
> Leg 4 Sell Raw += BS_FF

---

## 9. Legs 3 & 4 — Final Rounding

After all adjustments:

> Leg 3 Buy = RD(Leg 3 Buy Raw)
> Leg 3 Sell = RU(Leg 3 Sell Raw)
> Leg 4 Buy = RD(Leg 4 Buy Raw)
> Leg 4 Sell = RU(Leg 4 Sell Raw)

Same defensive rounding as Legs 1 & 2: buys down, sells up.

**Timer Logic override**: When Timer Logic is active, the RD/RU step is
replaced by evidence-conditioned rounding (TimerRD/TimerRU). See
[[timer-logic]] for the expansion mechanism and signal framework.

---

## 10. X & Y ASE Formulas

X and Y prices are derived from the O price and X_Y bias parameters:

> X Buy = RD(X_Y Buy Bias + O_Buy)
> X Sell = RU(X_Y Sell Bias + O_Sell)
> Y Buy = RD(−X_Y Sell Bias + O_Buy)
> Y Sell = RU(−X_Y Buy Bias + O_Sell)

X and Y are anti-symmetric: when X_Y bias is zero, both X and Y price at the O level. When non-zero, the bias shifts X and Y in opposite directions.

---

## 11. Cross Validation

After all pricing and rounding:

**For each leg**: If `Leg Buy >= Leg Sell`, the entire contract group is **paused**. This prevents locked or crossed market conditions from generating invalid orders.

---

## 12. Deduplication

Newly calculated prices are compared against the last emitted prices (tracked per contract and per A/B set). If identical, **no orders are sent**. This eliminates unnecessary message traffic.

A force-recalculate flag overrides this check after:
- Parameter changes
- Reload events
- Contract state transitions

---

## 13. Summary Formula Table

| Leg | Buy Formula | Sell Formula |
|-----|-------------|--------------|
| 1 | RD((O_Buy + diff) / 2 − Av_ZQ [+ BS_ZQ if >0]) | RU((O_Sell + diff) / 2 + Av_ZQ [+ BS_ZQ if <0]) |
| 2 | RD((O_Buy − diff) / 2 − Av_ZQ [− BS_ZQ if <0]) | RU((O_Sell − diff) / 2 + Av_ZQ [− BS_ZQ if >0]) |
| 3 | RD(L1_Buy_Raw − v1 − BS_FF − Av_FF [+ BS_FF if >0]) | RU(L1_Sell_Raw − v1 − BS_FF + Av_FF [+ BS_FF if <0]) |
| 4 | RD(L2_Buy_Raw − v2 − BS_FF − Av_FF [+ BS_FF if >0]) | RU(L2_Sell_Raw − v2 − BS_FF + Av_FF [+ BS_FF if <0]) |
| X | RD(X_Y_Buy_Bias + O_Buy) | RU(X_Y_Sell_Bias + O_Sell) |
| Y | RD(−X_Y_Sell_Bias + O_Buy) | RU(−X_Y_Buy_Bias + O_Sell) |

---

## 14. Key Calculation Properties

1. **Legs 1+2 Identity**: Before avoidance, Leg 1 + Leg 2 always equals O price. Avoidance adjustments are symmetric, so this identity holds approximately after rounding.

2. **Leg 3+4 Derivation**: Derived from Legs 1+2 by subtracting SR1-ZQ microprice. Maintains the decomposition: SR3|ZQ = SR3|SR1 − (SR1 − ZQ).

3. **Passive Execution**: Rounding (buy down, sell up) ensures the system never initiates at a worse price than calculated. Orders rest passively in the book.

4. **Microprice Reliability**: If any monitoring instrument's spread exceeds 1 tick, all orders are paused. If spread > 0.5 ticks, fallback to midpoint to handle edge cases.

## Related

- [[glossary]] — Definitions of microprice, diff, avoidanceValue, bsValue
- [[core-quad-leg-arbitrage]] — Strategy structure these formulas price
- [[execution-modifiers]] — Avoidance and bias parameters applied in formulas
- [[methodology-and-framework]] — TD formula measures deviation from these prices
- [[custom-rules-production]] — Rules that evaluate CalcPrice from these formulas
- [[Plan-2026-03-28]] — Comprehensive work plan referencing this file

### Jarvis Downstream
- [[jarvis/timer-logic/verification-report]] — WP-04 audit confirmed this as sole authoritative formula source (overrides execution-modifiers §5)
- [[jarvis/timer-logic/implementation/README]] — WP-05 C# implementation of §4–9, §13
- [[jarvis/fair-value/sofr-bootstrap-methodology]] — Extends formulas into curve-derived O-spread fair value
- [[jarvis/fair-value/network-valuation-engine-plan]] — Network engine using formula structure
- [[jarvis/fair-value/valuation-engine-implementation-prompt]] — Implementation spec for formula-based engine
- [[jarvis/plan/wp-status]] — WP completion status referencing formula corrections
