---
tags: [avoidance, bias, execution, parameters, modifiers]
domain: strategy
load-priority: on-demand
last-updated: "2026-03-26"
---

# Execution Modifiers — Avoidance and B/S Bias

Avoidance and B/S Bias parameters — what they do, how they interact, and combined effects. Load when tuning execution parameters.

---

## 1. Philosophy

The execution modifiers address two distinct concerns:

- **Avoidance** handles **uncertainty** — when a residual instrument becomes volatile, the microprice is less reliable, so the system widens the quoted spread (moves both buy and sell into depth) to reduce the risk of adverse fills.
- **B/S Bias** handles **directional conviction** — when the trader has a view on which way a residual will move, the system selectively makes one side more aggressive to capture more fills aligned with that view.

---

## 2. ZQ Spread Avoidance (Legs 1 & 2)

Applies to the SR3|SR1 legs. The residual from these fills is the SR1 near-far calendar (equivalently, the ZQ near-far calendar, since SR1-ZQ bases are range-bound).

**Avoidance = 0.1**: Both buy and sell prices shift 0.1 ticks into depth (buy drops, sell rises). This symmetrically widens the quoted spread when the ZQ/SR1 calendar becomes volatile.

**Application:**

> Leg 1 Buy Raw = (O_Buy + diff) / 2 − Av_ZQ
> Leg 1 Sell Raw = (O_Sell + diff) / 2 + Av_ZQ
> Leg 2 Buy Raw = (O_Buy − diff) / 2 − Av_ZQ
> Leg 2 Sell Raw = (O_Sell − diff) / 2 + Av_ZQ

The subtraction/addition of `Av_ZQ` is symmetric on both sides: buys decrease by the avoidance amount, sells increase by the avoidance amount.

---

## 3. ZQ Spread B/S Bias (Legs 1 & 2)

Directional bias on the ZQ/SR1 calendar residual. The bias makes fills more aggressive on the ASE/side combinations whose fills produce a residual aligned with the trader's directional view.

**B/S = −0.1 (sell bias on the calendar):**

- Leg 1 Sell becomes 0.1 more aggressive (price drops toward market)
- Leg 2 Buy becomes 0.1 more aggressive (price rises toward market)
- These are the fills that, taken together, produce a **short SR1 near-far calendar residual** — aligned with the sell bias
- The opposite sides (Leg 1 Buy, Leg 2 Sell) are unaffected

**B/S = +0.1 (buy bias on the calendar):**

- Leg 1 Buy becomes 0.1 more aggressive
- Leg 2 Sell becomes 0.1 more aggressive
- These produce a **long calendar residual** — aligned with the buy bias

**Application (from Appendix A):**

> If BS_ZQ > 0: Leg 1 Buy Raw += BS_ZQ ; Leg 2 Sell Raw −= BS_ZQ
> If BS_ZQ < 0: Leg 1 Sell Raw += BS_ZQ ; Leg 2 Buy Raw −= BS_ZQ

---

## 4. Combined Effect of Avoidance and B/S Bias (Legs 1 & 2)

When both avoidance and B/S are active, they interact. Avoidance widens the spread; B/S bias creates asymmetry. The net effect depends on the sign of the bias.

### Worked Example: Avoidance = 0.1, B/S = −0.1 (sell bias)

Starting with raw base prices:
- Leg 1 Sell Raw (base) = (O_Sell + diff) / 2

**Step 1: Apply Avoidance (symmetric)**
- Leg 1 Sell Raw = (O_Sell + diff) / 2 + 0.1 (shifted up into depth)

**Step 2: Apply B/S Bias (sell bias = negative)**
- Leg 1 Sell Raw += (−0.1) = (O_Sell + diff) / 2 + 0.1 − 0.1
- Leg 1 Sell Raw = (O_Sell + diff) / 2 (back to base)

**Result on Leg 1 Sell**: The avoidance and bias **cancel**. The sell order stays at the original calculated level.

---

For Leg 1 Buy (non-biased side):

**Step 1: Apply Avoidance (symmetric)**
- Leg 1 Buy Raw = (O_Buy + diff) / 2 − 0.1 (shifted down into depth)

**Step 2: Apply B/S Bias (sell bias = negative)**
- No adjustment to Leg 1 Buy (BS_ZQ < 0 only affects Leg 1 Sell and Leg 2 Buy)

**Result on Leg 1 Buy**: Retreats **0.1 into depth**.

---

### Interpretation

On the sell-bias side, the sell order stays at the original calculated level (bias offsets the avoidance), while the buy order retreats. This reflects the trader's willingness to sell the calendar residual but caution about buying it.

This cancellation pattern applies to all combinations:
- **Avoidance + matching bias** → non-biased side retreats; biased side stays firm
- **Avoidance alone** → both sides retreat symmetrically
- **B/S bias alone** → biased side advances; non-biased side neutral

---

## 5. SR1FF Avoidance (Legs 3 & 4)

Applies to the SR3|ZQ legs. The residual from converting SR3|SR1 positions to SR3|ZQ positions is the SR1-ZQ inter-product basis. When these bases become volatile, avoidance widens both buy and sell prices into depth, symmetrically on both Leg 3 and Leg 4.

**Application:**

> Leg 3 Buy Raw = Leg 1 Buy Raw − v1 − Av_FF
> Leg 3 Sell Raw = Leg 1 Sell Raw − v1 + Av_FF
> Leg 4 Buy Raw = Leg 2 Buy Raw − v2 − Av_FF
> Leg 4 Sell Raw = Leg 2 Sell Raw − v2 + Av_FF

The subtraction/addition of `Av_FF` is symmetric: buys decrease, sells increase. This applies identically to both Leg 3 and Leg 4.

---

## 6. SR1FF B/S Value (Legs 3 & 4)

Directional bias on the SR1-ZQ inter-product residual. Unlike the ZQ Spread B/S (which creates asymmetry between Leg 1 and Leg 2), the SR1FF B/S shifts the same side on both Leg 3 and Leg 4 simultaneously.

**Positive bsValue (sell bias on SR1-ZQ):**

- Sell prices on both Leg 3 and Leg 4 become more aggressive (shift toward market)
- Buy prices are unaffected
- Both legs lean in the same direction (both more willing to sell the basis)

**Negative bsValue (buy bias on SR1-ZQ):**

- Buy prices on both Leg 3 and Leg 4 become more aggressive
- Sell prices are unaffected
- Both legs lean in the same direction (both more willing to buy the basis)

**Application (from Appendix A):**

> If BS_FF > 0: Leg 3 Buy Raw += BS_FF ; Leg 4 Buy Raw += BS_FF
> If BS_FF < 0: Leg 3 Sell Raw += BS_FF ; Leg 4 Sell Raw += BS_FF

---

## 7. Combined Effect of Avoidance and B/S Value (Legs 3 & 4)

The same cancellation logic applies as with Legs 1 & 2.

**Example: Avoidance = 0.1, B/S Value = +0.1 (sell bias)**

**Leg 3 Buy (non-biased side):**
- Avoidance pushes buy down by 0.1 (into depth)
- B/S Value does not affect buy
- Net: **0.1 into depth**

**Leg 3 Sell (biased side):**
- Avoidance pushes sell up by 0.1 (into depth)
- B/S Value pushes sell down by 0.1 (toward market)
- Net: **cancels, stays at base level**

**Leg 4** follows the same pattern as Leg 3 (both legs are identical in structure).

Result: On the sell-bias side, both Leg 3 and Leg 4 sell orders stay firm at the calculated level, while both buy orders retreat into depth. This reflects the trader's willingness to sell the SR1-ZQ basis but caution about buying it.

---

## 8. Dynamic Avoidance Scheduling

The `avoidanceValue` parameter can be dynamically adjusted based on time of day via the **TimedParameterService**.

**Default behavior:**

- `avoidanceValue` set to a configured level (e.g., 0.05)
- Applied symmetrically to Legs 3 & 4

**Dynamic adjustment (when "dynamic" flag enabled):**

- During the **12:55–13:05 window** (FOMC/Fed timing), `avoidanceValue` is automatically set to **0.11**
- This significantly widens the spread during known volatility events
- On exit from the window, reverts to the configured default

**Purpose**: Increases defensive quoting around scheduled economic announcements or policy events when market volatility is expected to spike.

---

## 9. Summary Table

| Parameter | Leg(s) | Effect | Adjustment |
|-----------|--------|--------|------------|
| Av_ZQ | 1, 2 | Symmetric spread widening on SR3\|SR1 legs | Buy −Av_ZQ, Sell +Av_ZQ |
| BS_ZQ | 1, 2 | Asymmetric aggression on calendar residual | Depends on sign; cancels with avoidance |
| Av_FF | 3, 4 | Symmetric spread widening on SR3\|ZQ legs | Buy −Av_FF, Sell +Av_FF |
| BS_FF | 3, 4 | Aggression on both legs (same side) for SR1-ZQ residual | Depends on sign; cancels with avoidance |

---

## 10. Key Insights

1. **Avoidance is defensive**: It widens spreads symmetrically, reducing adverse fill risk during volatility.

2. **B/S Bias is directional**: It makes one side more aggressive, expressing a tactical view on residual convergence.

3. **Cancellation pattern**: When avoidance and bias are active on the same leg/side, they interact: the biased side often stays firm (cancellation) while the non-biased side retreats.

4. **Asymmetry**: ZQ B/S Bias is asymmetric between legs (Leg 1 vs Leg 2 treated differently). SR1FF B/S Value is symmetric (both legs treated identically).

5. **Dynamic scheduling**: Avoidance can be automatically escalated during known risk windows, reducing manual tuning.

## Related

- [[glossary]] — Definitions of avoidanceValue, bsValue, buyBiased, sellBiased
- [[price-formulas-complete]] — Formulas that consume avoidance and bias
- [[core-quad-leg-arbitrage]] — Strategy these modifiers apply to
- [[custom-rules-production]] — Production rules sensitive to modified prices
- [[safety-mechanisms]] — Timed Parameter Service schedules avoidance changes
- [[methodology-and-framework]] — Fill patterns affected by modifier settings
- [[Plan-2026-03-28]] — Comprehensive work plan referencing this file

6. **Timer Logic sequencing**: Timer Logic applies after all avoidance and bias adjustments. It receives the fully-adjusted raw price and only modifies the final rounding step. It does not fight avoidance — avoidance widens first, Timer Logic then decides how to discretise the widened price. See [[timer-logic]] §2 for pipeline position.

### Jarvis Downstream
- [[jarvis/timer-logic/verification-report]] — CRITICAL: WP-04 found §5 MISSING −BS_FF term in Leg 3/4 base formulas
- [[jarvis/market-profiling/contract-segmentation]] — Per-group avoidance/bias parameter recommendations
- [[jarvis/strategy-research/directional-bias-model]] — Planned model to dynamically modify B/S bias
- [[jarvis/fair-value/network-valuation-engine-plan]] — Plans avoidance auto-tuning from valuation scores
- [[jarvis/fair-value/sofr-bootstrap-methodology]] — References avoidance/bias in integration design
