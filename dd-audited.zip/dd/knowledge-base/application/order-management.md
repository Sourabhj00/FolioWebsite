---
tags: [orders, reload, clips, sets, phase-start, state-flags]
domain: application
load-priority: on-demand
last-updated: "2026-03-26"
---

# Order Management & State Control

Order lifecycle, reload system, A/B set management, phase start protocol, and operational state flags. Load when working with order submission or state management.

---

## 1. Operational State Flags

These flags control order and contract state. They differ from strategy parameters (buyBiased, sellBiased) — they are application-level toggles.

### 1.1 isEnabled

**What it does**: Toggles whether orders are active or paused.

**When false**: Orders are **paused** at the exchange — they are held but not deleted. The exchange sees them as GTC (Good-Till-Cancel) orders still waiting.

**When true**: Orders are allowed to be active (quoting, not resting).

**Use case**: Trader temporarily stops quoting without clearing orders. Faster recovery than deletion/resubmission.

**Resets spike detector**: When trader clicks Enable after a spike pause, this also triggers the spike detector latch reset.

### 1.2 isDelete

**Important: Despite the name, this controls whether orders should exist at all.**

**When false**: All orders for the contract are **DELETED** from the exchange. No working orders.

**When true**: Orders are allowed to exist (normal running state).

**Use case**: Fully exit a contract and clean up all working orders immediately.

**Effect**: isDelete = true is the default/normal state. Setting to false triggers order deletion.

### 1.3 defencive (trader's spelling of "defensive")

**What it does**: UI flag for defensive mode. When active, modifies alert filtering and potentially execution behavior.

**When true**: Telegram/Teams alerts are filtered — only priority alerts are sent. Reduces noise during expected volatile periods.

**When false**: All alerts fire (full verbosity).

**Use case**: During high-activity windows (e.g., Fed event) or after a spike, trader activates defensive mode to focus on critical alerts.

### 1.4 dynamic

**What it does**: Enables the `TimedParameterService` to automatically adjust `avoidanceValue` during specific time windows.

**When true**: During the **12:55–13:05 window** (FOMC/Fed timing), `avoidanceValue` is automatically escalated to **0.11**, widening spreads on Legs 3/4 for additional protection around rate-sensitive events.

**When false**: Timed adjustments are suppressed. `avoidanceValue` remains at its manually set level regardless of time of day.

**Use case**: Trader enables this for sessions that span Fed event windows, disables it for sessions that are safely outside those windows.

---

## 2. Order Lifecycle

### 2.1 Order Types & Submission

**All orders are GTC (Good-Till-Cancel) limit orders** submitted via TT .NET SDK to ASE synthetic instruments.

- No market orders
- No immediate-or-cancel (IOC)
- Orders persist until: filled, modified, or explicitly deleted

### 2.2 Order State Transitions

#### New Submission

Condition: No order exists for a given contract/ASE/side.

Action:
1. Calculate price from diff + parameters
2. Submit GTC limit order at calculated price with reload clip qty (e.g., 3 lots)
3. Acquire submission lock (per contract/ASE/side)
4. Wait for exchange confirmation

#### Price Modification

Condition: Order exists AND newly calculated price differs from last emitted price.

Action:
1. Modify order in-place (amend the limit price)
2. No new order ID — same order key preserved
3. ASE handles the modification atomically

**Deduplication**: If calculated price identical to last emitted price, no modification sent (avoids unnecessary message traffic).

#### No Action (Deduplication)

Condition: Calculated price same as last submitted price.

Action: No order message sent. Preserves existing order as-is.

Force-recalculate flag (set after parameter changes or reload events) overrides deduplication.

#### Deletion

Condition: Contract deactivated (isDelete = false) OR quantity target drops to zero.

Action: Delete order from exchange immediately.

Exception: Orders with active hedge children are paused (not deleted) to avoid legging risk — the hedge must be aware of the deletion.

### 2.3 Submission Lock

Per-key lock (contract/ASE/side) prevents duplicate submissions during rapid price updates.

**Lock lifecycle**:
1. Acquired before order submission
2. Held during transmission to exchange
3. Released only on: exchange confirmation, explicit rejection, or submission failure

**Purpose**: Prevents race condition where multiple price ticks within milliseconds trigger parallel submission attempts for the same order key.

---

## 3. Reload Mechanism (Iceberg Order Management)

### 3.1 Configuration

Per contract, per side, trader specifies:

| Parameter | Meaning |
|---|---|
| totalBuyQty | Maximum quantity to buy across all clips |
| totalSellQty | Maximum quantity to sell across all clips |
| reloadBuyQty | Size of each buy clip (e.g., 3 lots) |
| reloadSellQty | Size of each sell clip (e.g., 3 lots) |

### 3.2 Clip Lifecycle

**Initial submission**: Order placed at `reloadBuyQty` size (e.g., 3 lots) at calculated price.

**On full fill**:
1. Old order key removed from OrderBookManager
2. Fresh price calculation triggered for next clip
3. Next clip submitted at then-current market price
4. Total accumulated quantity increments

**Continues until**: Total accumulated quantity reaches `totalBuyQty` target.

### 3.3 Average Fill Price Tracking

Because each clip reloads at the then-current price, the average fill price **tracks the market as it moves**:

- If market rallies during accumulation: later clips fill at higher prices
- If market declines: later clips fill at lower prices
- Average = Σ(MatchPrice × Qty) / Σ(Qty) reflects the true path of the market during accumulation

**Benefit**: Avoids the "execution pressure" of a single large order — clips spread the impact.

### 3.4 Zero Quantity Handling

If `reloadBuyQty` or `totalBuyQty` is set to zero:
- No buy orders submitted for that contract
- Sell-side continues normally (or vice versa)

---

## 4. A/B Set Management

### 4.1 Dual Execution Capacity

Each contract has two independent sets (A and B) of ASE leg mappings:

| Set | Legs | TT Autospreader Instance |
|---|---|---|
| A | SR3\|SR1 A, SR3\|ZQ A | autospreader_a (separate) |
| B | SR3\|SR1 B, SR3\|ZQ B | autospreader_b (separate) |

Both sets receive the same calculated prices independently.

### 4.2 Activation Flags

| Flag | Behavior |
|---|---|
| useA = true | Set A active — orders submitted to A's ASE instruments |
| useA = false | Set A inactive — orders deleted from A's instruments |
| useB = true | Set B active — orders submitted to B's ASE instruments |
| useB = false | Set B inactive — orders deleted from B's instruments |

### 4.3 Simultaneous Operation

Both useA and useB can be true simultaneously, effectively **doubling execution capacity**:
- Each set quotes independently
- Each set manages its own reload clips
- Each set accumulates its own fill statistics
- Aggregate contract-level statistics include fills from both sets

### 4.4 Deactivation Protocol

When a set is deactivated (e.g., useA = false):

1. **Orders with active hedge children**: PAUSED (not deleted)
   - Reason: ASE hedge orders depend on parent being live; deleting parent can leg the system
   - Paused orders are held but not filling; they await hedge confirmation

2. **Orders without working hedges**: DELETED immediately
   - Safe to delete — no dependent hedge positions

---

## 5. Phase Start — Canary Order Protocol

### 5.1 Purpose

Detects adverse selection: fills at a "good" price often indicate the market is moving against that level.

### 5.2 Sequence

#### Step 1: Probe (Canary Submission)

- Submit 1-lot limit order at calculated price
- One canary per leg per side (4 legs × buy/sell = 8 canaries per contract)
- Watch for 30 seconds

#### Step 2: Monitor & Evaluate

For each of the 8 canaries:

| Outcome | Action |
|---|---|
| Canary fills within 30 sec | → Adverse selection detected → Contract paused immediately |
| Canary survives 30 sec | → Price level is safe → Delete canary, increment success counter |

#### Step 3: Success Threshold

- 8 consecutive canary successes required (all 8: 4 legs × buy/sell)
- Each successful canary: success counter increments
- Counter resets to 0 if any canary fills

#### Step 4: Release

- After 8 consecutive successes: full-size orders released
- Releases at current market price (price may have drifted from original canary level)

### 5.3 Watchdog & Reset

**35-second timer**: Catches stuck phase-start sequences.

Scenario: System submitted canaries for Leg 1, 2, 3 but Leg 4 is stuck (network delay, exchange backlog).

Watchdog:
- Monitors elapsed time between first canary and 8th canary submission
- If 35 seconds elapse without reaching 8 or 0 successes: reset sequence
- Cancels stuck canaries and rebroadcasts the entire sequence

### 5.4 Configuration

| Parameter | Default |
|---|---|
| phaseStart enabled | Per-contract toggle in UI |
| Canary qty | 1 lot |
| Observation window | 30 seconds |
| Success threshold | 8 |
| Watchdog timer | 35 seconds |

### 5.5 Rationale

If a 1-lot order at a "good" price fills immediately, it suggests:
- Market is moving in the opposite direction (the price is being picked off)
- System's calculation was too aggressive
- Entering at full size would incur significant slippage

Eight consecutive canary survivals indicate the price level is genuinely safe for passive quoting.

---

## 6. PriceSnapshot Deduplication

### 6.1 Mechanism

Before submitting an order, the newly calculated price is compared to the **last emitted price** for that contract and A/B set.

```
If (NewPrice == LastEmittedPrice)
  → No order message sent
Else
  → Submit or modify order
```

### 6.2 Tracking

`LastEmittedPrice` tracked separately per:
- Contract (Mar26, Jun26, etc.)
- ASE (Leg 1, 2, 3, 4)
- Side (Buy, Sell)
- Set (A or B)

### 6.3 Force Recalculate

Deduplication is bypassed when:
- Parameter changes trigger a full recalculation
- Reload event occurs (old clip filled, next clip needed)
- Trader clicks "Refresh" or similar manual override

**Effect**: Ensures next price calculation unconditionally generates an order signal, even if price hasn't changed.

---

## 7. Parent-Child Order Tracking

ASE handles multi-leg execution automatically. OrderBookManager tracks parent-child relationships for safe deletion.

### 7.1 Parent Order

The quoting leg (passive side). Example: SR3\|SR1 buy order with quoting leg = SR1.

### 7.2 Child Order (Hedge)

The hedge leg (opposite side, automatically triggered). Example: SR3 sell order triggered when SR1 buy fills.

### 7.3 Deletion Safety

Before deleting a parent order:
1. Check if child order (hedge) is still working
2. If child is active: pause (don't delete) — avoid legging risk
3. If child completed or absent: safe to delete immediately

### 7.4 Reconstruction on Resume

After a pause/resume cycle:
- Parent orders are resurrected at new calculated prices
- Hedges are automatically relinked by ASE based on order key
- No manual reconstruction needed

---

## 8. Order Submission Flow Diagram

```
┌─────────────────────────────────────────────────────────────┐
│ Price Calculated: PriceCalculator outputs new prices        │
└────────────┬────────────────────────────────────────────────┘
             │
             ↓
┌─────────────────────────────────────────────────────────────┐
│ Check Deduplication:                                        │
│   If NewPrice == LastEmittedPrice → Skip order signal       │
│   Else → Proceed                                            │
└────────────┬────────────────────────────────────────────────┘
             │
             ↓
┌─────────────────────────────────────────────────────────────┐
│ Check isEnabled & isDelete:                                 │
│   If isEnabled == false → Pause (hold orders, don't submit) │
│   If isDelete == false → Delete (remove all orders)         │
│   Else → Proceed with submit/modify/delete logic            │
└────────────┬────────────────────────────────────────────────┘
             │
             ↓
┌─────────────────────────────────────────────────────────────┐
│ Acquire Submission Lock (per contract/ASE/side)             │
└────────────┬────────────────────────────────────────────────┘
             │
             ↓
┌─────────────────────────────────────────────────────────────┐
│ Determine Action:                                           │
│   If order exists:                                          │
│     → Modify (new price)                                   │
│   Else:                                                     │
│     → New submit (at reload clip qty)                      │
└────────────┬────────────────────────────────────────────────┘
             │
             ↓
┌─────────────────────────────────────────────────────────────┐
│ Send to TTOrderActionService (TT .NET SDK)                  │
│   → Submit, Modify, or Delete                              │
└────────────┬────────────────────────────────────────────────┘
             │
             ↓
┌─────────────────────────────────────────────────────────────┐
│ Wait for Exchange Confirmation                              │
└────────────┬────────────────────────────────────────────────┘
             │
             ↓
┌─────────────────────────────────────────────────────────────┐
│ Release Submission Lock                                      │
│ Update LastEmittedPrice in PriceSnapshot                    │
│ (On fill: trigger next reload or update stats)              │
└─────────────────────────────────────────────────────────────┘
```

---

## 9. Fill Reporting & Accuracy Tracking

### 9.1 Fill Event

When ASE reports a fill:
1. `FillSubscription` receives fill notification
2. Fill record created: timestamp, side, qty, entry price, match price, execution price
3. `OrderBookManager` receives fill event

### 9.2 Accuracy Scoring

For each fill:
```
TD = (MatchPrice − EntryPrice) / 0.5  [for buys]
TD = (EntryPrice − MatchPrice) / 0.5  [for sells]

Accuracy = (1 − TD) × 100%
```

Classifications:
- TD = 0 → Exact
- TD > 0 → Payup
- TD < 0 → Backoff

### 9.3 Per-Alias Statistics

`OrderBookManager` accumulates:
- Total filled quantity (buy and sell separately)
- Payup ticks / backoff ticks (signed sum)
- Overall accuracy % (weighted)
- Last-5-fill accuracy (rolling window)
- Last-5-minute accuracy (time-based rolling window)

### 9.4 Daily Export

At end of session:
- Statistics exported to daily JSON file (format: `YYYY-MM-DD_cleaned.json`)
- Schema: fill records with all fields (timestamp, alias, side, qty, prices, accuracy)
- Used for post-session analysis and historical trending

---

## 10. Multi-Leg Order Coordination

### 10.1 ASE Hedging

When a quoting leg fills (e.g., SR1 in SR3|SR1):
1. ASE automatically triggers hedge order on opposite leg (SR3 short)
2. Hedge order is submitted at current market best (potentially aggressive)
3. Both orders carry the same order key for tracking

### 10.2 Reload on Full Fill

When a clip fully fills:
1. `ReloadMgr` detects full fill
2. Old order key removed
3. Fresh price calculation for next clip
4. Next clip (e.g., 3 lots) submitted at then-current price
5. Cycle repeats until totalQty exhausted

---

*Order management architecture validated against New_Regime v9 production code: OrderSignalRouter.cs, ReloadManager.cs, PhaseManager.cs, OrderBookManager.cs, TTOrderActionService.cs.*

## Related

- [[architecture-and-dataflow]] — System architecture hosting order management
- [[safety-mechanisms]] — Safety checks in the order pipeline
- [[core-quad-leg-arbitrage]] — Strategy structure driving reload/clip logic
- [[ase-mechanics-and-parameters]] — ASE engine that triggers orders
- [[Plan-2026-03-28]] — Comprehensive work plan referencing this file
