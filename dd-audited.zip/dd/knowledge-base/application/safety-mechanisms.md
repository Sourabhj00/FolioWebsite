---
tags: [safety, spike-detection, traffic-controller, vwap, connectivity]
domain: application
load-priority: on-demand
last-updated: "2026-03-26"
---

# Safety Mechanisms & Protection Layers

All protection layers that guard against adverse execution, data issues, and rate limit violations. Load when reviewing or modifying safety parameters.

---

## Overview

Five independent protection layers operate in parallel. Each is triggered independently and can pause orders on affected contracts. Recovery mechanisms vary — some auto-resume, some require manual trader action.

---

## 1. Spike Detection (Circuit Breaker)

### Mechanism

Watches a configurable single instrument for sudden price moves. If the price range within a time window exceeds a tick threshold, all orders across all contracts are paused immediately.

### Configuration

| Parameter | Default | Meaning |
|---|---|---|
| WatchInstrument | ZN Mar26 | 10-Year Note contract (liquid proxy for rate shock) |
| TickThreshold | 5 | Ticks of movement to trigger |
| TimeWindow | 2 | Seconds within which threshold is measured |

### Behavior

- **Trigger**: Price moves >5 ticks within 2 seconds on ZN
- **Action**: PauseAll signal broadcast to all contracts
- **State**: Latched (remains triggered until explicitly reset by next `isEnabled` signal from trader)
- **Recovery**: Manual — trader must click "Enable" to resume (not automatic)

### Use Case

Protects against flash crashes, Fed announcement spikes, or technical errors in market data. Similar in spirit to TT's Max Order Move rule but implemented at system level across all contracts.

---

## 2. Scheduled Pause Windows (PauseWindow)

### Mechanism

Time-based automatic pause/resume tied to known market events or trader-scheduled maintenance windows.

### Configuration

Window schedules stored in `ScheduleStore`. Each entry specifies:
- Window start time (UTC)
- Window end time (UTC)
- Affected contract(s) (or "all")

### Behavior

- **On window entry**: All affected contracts automatically pause (orders held, not deleted)
- **On window exit**: All affected contracts automatically resume
- **Trader override**: Contracts manually paused by trader (via UI checkbox) remain paused across resume — system does not override trader intent
- **Recovery**: Automatic at window end time

### Use Cases

Common scenarios:
- **12:55–13:05 UTC**: Fed event window (FOMC announcements, PCE release)
- **21:00 UTC**: CME end-of-day volume cliff
- **Overnight maintenance**: Scheduled system restarts

---

## 3. Wide Spread Guard (Liquidity Check)

### Mechanism

If any monitoring instrument's bid-ask spread exceeds 1 tick, all orders for the affected contract are paused.

### Trigger Condition

For each monitoring instrument (SR1-ZQ near/far, ZQ calendar):
```
If (Ask − Bid) > 1 tick → Pause affected contract
```

### Fallback Mechanism

When spread is wide (0.5–1.0 tick range):
- Microprice calculation falls back from VWAP to simple midpoint: `(Bid + Ask) / 2`
- Orders remain active (no pause), but microprices become less precise

When spread exceeds 1.0 tick:
- Pause triggered immediately (more conservative than fallback)
- Rationale: spread >1 tick indicates thin liquidity, making VWAP and even midpoint unreliable

### Recovery

Automatic: Orders resume when any monitoring instrument's spread tightens back to ≤1 tick.

---

## 4. Invalid Data Guard (Data Validation)

### Mechanism

If any market data update returns invalid, empty, or sentinel values, all orders pause immediately.

### Trigger Conditions

| Data Issue | Action |
|---|---|
| VWAP goes invalid (decimal.MaxValue) | PauseAll |
| Tick size returns 0 or negative | PauseAll |
| Bid-ask ladder returns null/empty | PauseAll |
| Quantities return 0 or invalid | PauseAll |
| WebSocket connection drops | PauseAll |

### Rationale

Prevents execution on stale or corrupted prices. A single bad data point can cascade through the pricing pipeline, so immediate pause is safest.

### Recovery

Automatic: Orders resume when valid market data resumes.

---

## 5. Fill Threshold Circuit Breaker

### Mechanism

Cumulative fill counter tracks all system-tagged fills. When the running total reaches a configurable threshold, all orders pause and the counter resets.

### Configuration

| Parameter | Default |
|---|---|
| Threshold | 100 lots |
| Reset on trigger | Yes |

### Behavior

1. System counts all fills across all contracts (buy and sell)
2. When cumulative count reaches 100 lots: **PauseAll** triggered
3. Counter immediately resets to 0
4. Next fill cycle resumes from 0

### Use Case

Acts as a periodic "time-out" to allow trader inspection and manual verification of fill quality. After 100 lots, system pauses, trader can review fills (accuracy, P&L, any anomalies), then manually resume.

### Recovery

Manual: Trader clicks "Enable" to resume and reset counter.

---

## 6. Message Traffic Rate Limiter (Traffic Controller)

### Mechanism

Monitors order message volume per instrument-alias across multiple time windows. Prevents exchange throttling and API bans from excessive messaging.

### Configuration

| Window | Limit | Meaning |
|---|---|---|
| 1-second | 185 messages | Per-instrument-alias peak message rate |
| 1-minute | 1,960 messages | Sustained per-minute rate |
| 5-minute | 4,960 messages | Sustained per-five-minute rate |

### Bucketing

Per-instrument-alias, NOT per-contract. Example:
- SR3\|SR1 Dec Feb26 - A (one bucket)
- SR3\|SR1 Dec Feb26 - B (separate bucket if useB enabled)
- SR3\|ZQ Dec Feb26 - A (separate bucket)

### Behavior

1. Each order submission, modification, or deletion counts as one message
2. Bucketed per instrument-alias
3. If any limit breached: affected instrument paused for cooldown period
4. After cooldown: auto-resume
5. Prevents runaway repricing loops from exhausting exchange connection

### Recovery

Automatic: Pauses for configured cooldown (default: 30–60 seconds), then auto-resumes.

---

## 7. Alert System (Notification-Only)

### Mechanism

Real-time notifications via Telegram/Teams for execution anomalies and market events. **Alert-only — does NOT pause orders.**

### Alert Types

| Alert | Trigger |
|---|---|
| Payup fill | Any fill with TD > 0 (filled worse than limit) |
| Multi-contract payup | Payup fills on >2 different contracts within 30 seconds |
| Multi-ASE fills | Fills across >2 different ASE instruments within 30 seconds |
| VWAP spike | Monitoring instrument price moves >N ticks in M seconds |
| Volume anomaly | Unusual fill clustering or pattern detected |

### Defensive Mode

When `defencive` flag is active (UI toggle):
- Telegram alerts are filtered to priority alerts only
- Reduces noise during high-activity periods
- Prevents alert fatigue during expected volatile windows

### Recovery

N/A — alerts are passive notifications. Trader manually responds if action is needed.

---

## 8. Interaction & Recovery Summary

### Which Pauses Are Automatic vs. Manual?

| Mechanism | Recovery Mode |
|---|---|
| Spike Detection | Manual (trader clicks Enable) |
| Scheduled Pause Windows | Automatic (at window end) |
| Wide Spread Guard | Automatic (when spread tightens) |
| Invalid Data Guard | Automatic (when data resumes) |
| Fill Threshold | Manual (trader clicks Enable) |
| Traffic Rate Limiter | Automatic (after cooldown) |
| Alerts | N/A (notification only) |

### Pause Precedence

All pauses are "OR'd" — any triggered pause blocks order submission. Examples:

```
If (Spike triggered) OR (Invalid Data) OR (Fill Threshold reached)
  → PauseAll
```

Only when ALL pause conditions clear can orders resume.

### Preserve Across Pause

When a contract is resumed after a pause:
- Existing open orders are **preserved** (not deleted)
- Prices are recalculated for next submission
- Reload position continues from where it left off
- Exception: Scheduled pause respects trader-manual pauses (does not override)

---

## 9. Configuration Management

### Setting Safety Parameters

All safety parameters are stored in `SpikeParamStore` and `ScheduleStore` (in BACKEND_V9):

1. Trader updates parameters in UI
2. WebSocket message sends update to VERSION_V9
3. `LiveParameterStore` updates in-memory
4. Next market data tick applies new parameters
5. Spike detector or traffic controller uses updated values on next evaluation

### Dynamic Scheduling

`TimedParameterService` (referenced in codebase) enables timed parameter adjustments:
- Example: `avoidanceValue` automatically increases to 0.11 at 12:55–13:05 UTC (Fed event window)
- Separate from `ScheduledPause` — widening spreads rather than pausing
- Controlled by `dynamic` flag in UI

---

## 10. Watchdog Timers

### Phase Start Watchdog

- Monitors canary order sequences
- 35-second timer catches stuck phase-start sequences between 1–7 canaries
- If timer expires without reaching 8 successes: reset sequence and rebroadcast canary orders
- Prevents indefinite stalls when canary success rate drops below threshold

### Fill Threshold Watchdog

- Implicit: counter resets after each pause trigger
- Prevents infinite pause loops if fills continue at high rate

---

*Safety layer architecture validated against New_Regime v9 production codebase. Mechanisms activated in SpikePauseService.cs, PhaseManager.cs, MarketDataService.cs, TrafficCtrl.cs, ScheduledPause.cs, and OrderSignalRouter.cs.*

## Related

- [[architecture-and-dataflow]] — System architecture these mechanisms protect
- [[order-management]] — Order pipeline these mechanisms gate
- [[execution-modifiers]] — Timed Parameter Service manages avoidance scheduling
- [[glossary]] — Spike, VWAP, and other terms defined here
- [[Plan-2026-03-28]] — Comprehensive work plan referencing this file

### Jarvis Downstream
- [[jarvis/timer-logic/verification-report]] — Safety layers (PauseAll, fill threshold, kill switch) verified in WP-04 audit
