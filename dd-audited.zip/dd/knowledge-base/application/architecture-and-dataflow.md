---
tags: [application, architecture, dataflow, websocket, parameters]
domain: application
load-priority: on-demand
last-updated: "2026-03-26"
---

# Application Architecture & Dataflow

System architecture, component layout, service pipeline, and communication flow for the New_Regime v9 trading application. Load when modifying or extending the application.

---

## 1. Two-Component System Architecture

The trading system is split into two major components:

### 1.1 BACKEND_V9 (ASP.NET WebSocket Server + UI)

- Hosts the HTML/JavaScript user interface
- Runs WebSocket server for real-time bidirectional communication
- Maintains three core parameter stores:
  - `ContractParameterStore`: Live parameters for each contract (buyBiased, sellBiased, etc.)
  - `ScheduleStore`: Time-window pause/resume schedules
  - `SpikeParamStore`: Spike detector configuration (watch instrument, tick threshold, time window)
- Provides dashboard and control interface for trader

### 1.2 VERSION_V9 (.NET Trading Engine)

- Runs the live trading strategy
- Communicates with BACKEND_V9 via WebSocket
- Connects to TT platform via TT .NET SDK
- Executes all pricing calculations and order routing logic
- Maintains order book state and fill statistics

---

## 2. Communication Pipeline

```
BACKEND_V9                          VERSION_V9
┌──────────────────────────┐       ┌──────────────────────────┐
│ ContractParameterStore   │ ───→  │ ConfigWebSocketClient    │
│ ScheduleStore            │       │                          │
│ SpikeParamStore          │ ←──── │ LiveParameterStore       │
└──────────────────────────┘       │ (thread-safe in-memory)  │
         ↑                          │                          │
         │                          │ OnParametersUpdated ──→  │
      WebSocket                     │                          │
         │                          └──────────────────────────┘
         └─────────────────────────────────────────────────────
```

All configuration updates flow from BACKEND to VERSION_V9 via WebSocket. The engine holds a `LiveParameterStore` (thread-safe, in-memory) that gets updated when new parameters arrive.

---

## 3. Engine Processing Pipeline

When market data arrives or parameters update, the engine processes in this order:

### Stage 1: Parameter Update Reception

- `ConfigWebSocketClient` receives new parameters from BACKEND_V9
- Parameters written to `LiveParameterStore` (thread-safe)
- `OnParametersUpdated` event fires

### Stage 2: Market Data Collection

- `MarketDataSubscriber` subscribes to `PriceSubscription` on CME MultilegInstruments
- Instruments: three monitoring spreads per expiry group (SR1-ZQ near, SR1-ZQ far, ZQ calendar)
- Each tick updates market data cache with new bid-ask ladder

### Stage 3: Microprice Calculation

- `VwapCalculator` computes microprice for each monitoring instrument
- Formula: `Microprice = (Bid × AskQty + Ask × BidQty) / (BidQty + AskQty)`
- Fallback: if spread > 0.5 ticks, use midpoint `(Bid + Ask) / 2`
- Output: three VWAP values (v1, v2, v3)
- `OnVwapUpdated` event fires

### Stage 4: Synthetic Spread Calculation

- `FinalDifferenceCalculator` computes the diff signal:
  ```
  diff = v1 − v2 + v3
  where:
    v1 = VWAP(SR1-ZQ near-month inter-product)
    v2 = VWAP(SR1-ZQ far-month inter-product)
    v3 = VWAP(ZQ near-far calendar)
  ```
- This represents the synthetic SR1 calendar (near-far spread)
- `OnFinalDifferenceUpdated` event fires

### Stage 5: Price Calculation

- `PriceCalculator` is a 4-leg price engine that generates prices for all four legs per expiry group
- Inputs: diff, buyBiased/sellBiased, bsValue, avoidanceValue, bsZQSpread, avoidanceZQSpread
- Outputs: Leg 1 Buy/Sell, Leg 2 Buy/Sell, Leg 3 Buy/Sell, Leg 4 Buy/Sell prices
- All prices rounded defensively (buy down, sell up)
- `PriceSnapshot` deduplication: if calculated prices identical to last emitted, no order signal generated
- Force-recalculate flag overrides deduplication after parameter changes or reload events

### Stage 6: Order Routing

- `PriceSignalRouter` receives calculated prices
- Routes signals to `TTOrderActionService` (TT .NET SDK wrapper)
- Submits, modifies, or deletes orders on TT Autospreader synthetic instruments
- Submission lock per contract/ASE/side prevents duplicate submissions during rapid price updates

### Stage 7: Execution & Feedback

- TT Autospreader (ASE) handles multi-leg hedging automatically
- ASE fills routed back via `FillSubscription` and `OrderBookManager`
- Fill records logged: timestamp, side, qty, entry price, match price, execution price
- Parent-child order tracking for hedge awareness before cancellation

---

## 4. Supporting Services

### 4.1 State Management

- **PhaseManager**: Manages canary order sequences (Phase Start protocol)
  - Tracks 1-lot test orders per leg
  - Counts successful canaries toward 8-success threshold
  - Triggers full-size order release or contract pause
  - 35-second watchdog catches stuck sequences

- **ReloadMgr**: Iceberg order management
  - Tracks totalBuyQty/totalSellQty targets per contract side
  - Submits clips of reloadBuyQty/reloadSellQty size
  - On full fill, triggers new price calculation for next clip
  - Continues until totalQty exhausted

- **OrderBookManager**: Parent-child and fill tracking
  - Maintains live order state for each contract/ASE/side
  - Tracks hedge parent-child relationships for safe deletion
  - Accumulates fill statistics per alias: total qty, payup ticks, backoff ticks, accuracy
  - Computes last-5-fill and last-5-minute accuracy metrics
  - Persists daily statistics to JSON files

### 4.2 Protection & Control

- **SpikePauseService**: Spike detection
  - Monitors configurable single instrument (default: ZN 10Y Note)
  - Watches for price range > N ticks within M seconds (default: 5 ticks in 2 seconds)
  - On trigger: pauses ALL orders across ALL contracts
  - Latched: remains triggered until next isEnabled signal resets

- **ScheduledPause** (PauseWindow service): Time-based automatic pause/resume
  - Reads schedule from ScheduleStore
  - Automatically pauses orders on window entry
  - Automatically resumes on window exit
  - Preserves trader's manual pauses across resume — does not override trader intent

- **TrafficCtrl** (Message Traffic Rate Limiter): Per-instrument-alias rate limiting
  - Monitors messages in three windows: 1-sec (185 limit), 1-min (1960 limit), 5-min (4960 limit)
  - Buckets by instrument-alias, not per-contract
  - On limit breach: auto-pauses affected instrument for cooldown, then auto-resumes
  - Prevents exchange throttling and API bans

- **FillSubscription**: Real-time fill listener
  - Subscribes to TT's fill stream
  - Triggers accuracy scoring on each fill
  - Feeds accuracy metrics to OrderBookManager and UI

### 4.3 Alerts

- **MarketDataAlertManager**: Multi-channel notifications
  - Sends Telegram/Teams alerts for:
    - Each payup fill
    - Payup fills across >2 contracts within 30 seconds
    - Fills across >2 ASEs within 30 seconds
    - VWAP spike/move detection
    - Volume anomalies
  - "Defensive mode" (`defencive` flag): filters for priority alerts only
  - Notification-only — does NOT pause orders

---

## 5. Data Stores & Configuration

### 5.1 Static Configuration Files

- **ContractLegs.csv**: Mapping of contracts to 4-leg ASE definitions
  - Columns: Contract, Leg1_Name, Leg2_Name, Leg3_Name, Leg4_Name, SetA_Enabled, SetB_Enabled
  - Also maps O/X/Y leg suffixes for future expansion
  - Example: Mar26 → SR3|SR1 Mar Apr26, SR3|SR1 Mar May26, SR3|ZQ Mar Apr26, SR3|ZQ Mar May26

- **InstrumentSubscription.csv**: Market data subscription definitions
  - Lists all monitoring instruments (inter-product spreads and calendars) to subscribe to
  - Per-expiry: SR1-ZQ near, SR1-ZQ far, ZQ calendar
  - Used by MarketDataSubscriber to configure TT PriceSubscription

### 5.2 Runtime Data Stores (UI ↔ Engine)

- **ContractParameterStore**: Per-contract, per-side parameters
  - buyBiased, sellBiased (target O structure prices)
  - totalBuyQty, totalSellQty (reload targets)
  - reloadBuyQty, reloadSellQty (per-clip sizes)
  - bsValue, avoidanceValue (ZQ-leg bias and avoidance)
  - bsZQSpread, avoidanceZQSpread (SR1-leg parameters)
  - useA, useB (A/B set activation flags)
  - isEnabled, isDelete (order state flags)
  - phaseStart (canary protocol flag)

- **ScheduleStore**: PauseWindow time schedules
  - Lists time-of-day pause/resume windows
  - Example: 12:55–13:05 for Fed event protection

- **SpikeParamStore**: Spike detector config
  - WatchInstrument (e.g., "ZN Mar26")
  - TickThreshold (e.g., 5)
  - TimeWindow (e.g., 2 seconds)

---

## 6. Key Source Files

| File | Purpose |
|---|---|
| `PriceCalculation.cs` | 4-leg price engine: computes Leg 1–4 prices from diff and parameters |
| `FinalDifferenceCalculator.cs` | Computes diff = v1 − v2 + v3 |
| `VWAPCalculator.cs` | Computes VWAP (microprice) from bid-ask ladder |
| `PriceSignalRouter.cs` | Routes price signals to TTOrderActionService |
| `OrderSignalRouter.cs` | Determines submit/modify/delete actions per order |
| `ReloadManager.cs` | Manages iceberg order clips and reload logic |
| `PhaseManager.cs` | Canary order sequence and 8-success threshold |
| `MarketDataService.cs` | Subscribes to CME instruments and updates VWAP cache |
| `SpikePauseService.cs` | Spike detection and all-orders pause trigger |
| `Program.cs` | Application entry point, dependency injection, service initialization |
| `ContractLegs.csv` | Static leg mapping |
| `InstrumentSubscription.csv` | Market data subscription list |

---

## 7. System Data Flow Diagram

```
┌─────────────────────────────────────────────────────────────────┐
│                        BACKEND_V9 (UI)                          │
│  [ContractParameterStore] [ScheduleStore] [SpikeParamStore]    │
└──────────────────────┬──────────────────────────────────────────┘
                       │
                    WebSocket
                       │
                       ↓
┌─────────────────────────────────────────────────────────────────┐
│                    VERSION_V9 (Engine)                          │
│                                                                 │
│  ConfigWebSocketClient                                         │
│         ↓                                                       │
│  LiveParameterStore (in-memory, thread-safe)                   │
│         ↓ OnParametersUpdated                                   │
│                                                                 │
│  ┌─────────────────────────────────────────────────────────┐   │
│  │ MarketDataSubscriber ← CME MultilegInstruments          │   │
│  │   (PriceSubscription on monitoring spreads)             │   │
│  │   • SR1-ZQ near (v1)                                   │   │
│  │   • SR1-ZQ far  (v2)                                   │   │
│  │   • ZQ calendar (v3)                                   │   │
│  └──────────┬──────────────────────────────────────────────┘   │
│             ↓                                                   │
│  VwapCalculator (computes microprice per instrument)          │
│             ↓ OnVwapUpdated                                    │
│  FinalDifferenceCalculator (diff = v1 − v2 + v3)              │
│             ↓ OnFinalDifferenceUpdated                         │
│  PriceCalculator (4-leg engine)                                │
│    [Leg 1 Buy/Sell] [Leg 2 Buy/Sell]                          │
│    [Leg 3 Buy/Sell] [Leg 4 Buy/Sell]                          │
│             ↓                                                   │
│  PriceSnapshot Deduplication                                   │
│             ↓                                                   │
│  PriceSignalRouter → TTOrderActionService (TT .NET SDK)        │
│                      ↓                                         │
│                  TT Autospreader (529+ configs)                │
│                                                                 │
│  ┌─────────────────────────────────────────────────────────┐   │
│  │ Supporting Services:                                    │   │
│  │  • PhaseManager (canary protocol)                       │   │
│  │  • ReloadMgr (iceberg clips)                            │   │
│  │  • OrderBookManager (fill tracking, parent-child)       │   │
│  │  • SpikePauseService (circuit breaker)                  │   │
│  │  • ScheduledPause (time windows)                        │   │
│  │  • TrafficCtrl (rate limiter)                           │   │
│  │  • MarketDataAlertManager (Telegram/Teams)              │   │
│  └─────────────────────────────────────────────────────────┘   │
│                                                                 │
│  ← Fill data from TT Autospreader                              │
│    (FillSubscription → OrderBookManager → daily JSON export)   │
│                                                                 │
└─────────────────────────────────────────────────────────────────┘
```

---

## 8. Configuration & Execution Options

### A/B Set Architecture

Each contract can run two independent ASE instrument sets (A and B) simultaneously:

- Both sets receive the same calculated prices
- Each set points to separate TT Autospreader instances
- Controlled by `useA` and `useB` flags in UI
- Effective capacity: up to 8 ASE instruments per contract (4 legs × 2 sets)
- On deactivation: orders with active hedge children PAUSED (not deleted); orders without hedges DELETED

### Order Submission Lock

- Per-key lock (contract/ASE/side) prevents duplicate submissions
- Acquired before submission
- Released only on: exchange confirmation, rejection, or submission failure
- Prevents race conditions from rapid price updates

---

*Architecture validated against New_Regime v9 source analysis. All component interactions documented from live codebase (Program.cs, PriceCalculation.cs, MarketDataService.cs, OrderBookManager.cs, etc.).*

## Related

- [[order-management]] — Order lifecycle within this architecture
- [[safety-mechanisms]] — Safety layers in the service pipeline
- [[instruments-and-platform]] — Exchanges and products the app connects to
- [[execution-modifiers]] — Parameters stored in the three parameter stores
- [[Plan-2026-03-28]] — Comprehensive work plan referencing this file

### Jarvis Downstream
- [[jarvis/timer-logic/implementation/README]] — WP-05 C# code integrating into this .NET architecture
