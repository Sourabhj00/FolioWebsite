# Application — Map of Content

.NET trading application architecture and internals. Two-component system
(BACKEND_V9 ASP.NET + VERSION_V9 .NET engine) with WebSocket communication.

## Files

- [[architecture-and-dataflow]] — Two-component system, WebSocket communication, three parameter stores (Contract, Schedule, Spike), service pipeline, and data flow.
- [[order-management]] — Order lifecycle, reload system (totalQty/reloadQty/clip management), A/B set management, phase start protocol, operational state flags. **Largest file (450 lines) — load selectively.**
- [[safety-mechanisms]] — Five protection layers: Spike Detection (circuit breaker), Traffic Controller (rate limiter), Timed Parameter Service (scheduled avoidance), VWAP Staleness Guard, Exchange Connectivity Monitor.

## Related Folders

- [[core/_index|Core]] — Instrument specs the application operates on
- [[strategy/_index|Strategy]] — Strategy parameters the application implements
- [[ase-rules/_index|ASE Rules]] — Rules the application configures and runs
- [[planning/_index|Planning]] — Work plan referencing .NET application and order management goals

### Jarvis Analysis
- [[jarvis/timer-logic/implementation/_index|Jarvis: Timer Logic Implementation]] — WP-05: C# code integrating into this architecture
