---
title: Planning
last-updated: 2026-03-29
---

# Planning — Map of Content

Work planning documents. Contains structured plans with goals,
tasks, dependencies, and KB cross-references.

## Files

- [[Plan-2026-03-28]] — Comprehensive work plan (26 goals, ~138 tasks).
  Brain dump → structured plan covering ASE infrastructure, rules,
  testing, analysis, live trading, quant research, AI tooling, and
  new markets exploration. Open-ended timeline.

- [[plan-data-2026-03-28.json]] — Structured JSON export of the plan
  for building interactive visual planning boards. Same data as the
  markdown plan, machine-readable.

## Purpose

This folder serves two functions:
1. **Reference for Claude** — Any session in this project can load
   the current plan to understand priorities, dependencies, and
   connections between tasks and KB files.
2. **Reference for the user** — Living document of open work items,
   their status, and what's been deferred.

## Related Folders

- [[core/_index|Core]] — Always loaded, anchors all task context
- [[strategy/_index|Strategy]] — Referenced by Goals 1, 5, 6, 7, 8, 11, 12, 16, 17
- [[ase-rules/_index|ASE Rules]] — Referenced by Goals 1, 2, 11, 15, 19
- [[execution-analysis/_index|Execution Analysis]] — Referenced by Goals 3, 6, 7, 15, 17, 20
- [[application/_index|Application]] — Referenced by Goals 4, 6, 7, 18, 19
- [[sessions/_index|Sessions]] — Handoff files from planning sessions
