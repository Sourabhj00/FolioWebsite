# Top 20 Execution Cases — Timer Logic Decision Framework

## Assumed Baseline Parameters

| Parameter | Value | What It Means |
|-----------|-------|---------------|
| Buy target | 5.0 | Your target buy price for the O spread structure |
| Sell target | 7.0 | Your target sell price for the O spread structure |
| Edge budget | 2.0 ticks | The spread between buy and sell targets — your total profit margin per round trip |
| Spread widening (Legs 1&2) | 0.10 | Symmetric cushion that pushes buy orders lower and sell orders higher on Legs 1&2, reducing adverse fill risk |
| Directional bias | 0.00 | No directional skew (simplified for this analysis) |
| Tick size | 0.5 | Minimum price increment for ASE spread orders. Real prices can only exist at 0.5 intervals (e.g., 4.0, 4.5, 5.0) |
| Normal clip | 3 lots (6:-10 ratio) | Standard order size per reload |
| Calendar spread signal | 1.0 | The synthetic SR1 calendar value derived from three monitoring instruments, used to split the O price between Leg 1 and Leg 2 |
| Quote update speed limit | 56ms | Minimum time between order price updates when moving toward market. The system can update ~18 times per second. |

### What "Thick" and "Thin" Mean for Each Leg

The two outright legs inside each ASE have different typical liquidity levels:

**SR1 (the quoting leg — where your passive buy order rests):**
- Thick: ≥300 lots resting at a price level. Strong support.
- Moderate: 100–300 lots. Normal conditions.
- Thin: ≤50 lots. Fragile — the level can vanish quickly.

**SR3 (the hedge leg — where you sell when the quote fills):**
- Thick: ≥1000 lots. Very reliable fill on hedge.
- Moderate: 300–1000 lots. Normal conditions.
- Thin: ≤200 lots. Uncertain hedge — may need to chase the price.

### How the Net Value Calculation Works

For each case, the key question is: **does expanding (rounding toward market) make money or lose money?**

When Timer Logic rounds toward market, you place your order 0.5 ticks more aggressive. This means:
- You give up 0.5 ticks of edge on that leg
- But you might get a fill you wouldn't have gotten otherwise

There are two types of fills when Timer Logic is active:
- **Incremental fills**: Fills that ONLY happened because Timer Logic moved you closer to market. Without it, you'd have missed the fill entirely. These are pure value — you captured the full O spread minus the 0.5 tick cost.
- **Non-incremental fills**: Fills that would have happened anyway, even with the more conservative hard rounding. On these, you just gave away 0.5 ticks for nothing.

**Breakeven rule (for a 0.5 tick cost on one leg):**
If more than 25% of your Timer-Logic-affected fills are incremental, you're making money. The math: an incremental fill earns you 1.5 ticks (2.0 edge - 0.5 cost), while a non-incremental fill costs you 0.5 ticks. At 25% incremental, these balance out.

---

## State Space — What Defines a "Case"

Seven factors define the market state for Timer Logic decisions. Three are primary (they drive the decision), four are secondary (they adjust confidence).

### Primary Factors

| Factor | Levels | What It Controls |
|--------|--------|-----------------|
| Quote leg bid strength | Thick / Moderate / Thin | How safe is your passive buy order? |
| Hedge leg bid strength | Thick / Moderate / Thin | If your buy fills, can you reliably sell the hedge? |
| Price momentum | Toward / Flat / Away | Are prices moving toward your desired fill level or away from it? |

3 × 3 × 3 = 27 primary combinations.

### Secondary Factors

| Factor | Levels | What It Adds |
|--------|--------|-------------|
| Bid-ask gap on each leg | Both tight (1-tick) / One wide / Both wide | Wide gaps mean the price can jump 2 ticks when the level breaks |
| Trading activity | Active / Normal / Dead | Have actual trades occurred recently, or is the book just resting? |
| Raw price position in tick interval | Near a valid tick / Middle / Far from any tick | How close is the calculated price to a level where you can actually get filled? |
| Trade-weighted price + real order confirmation | Confirmed / Neutral / Diverging | Do actual recent trades and real (non-synthetic) orders support the book-weighted fair price? |

Full theoretical state space: ~8,700 combinations. After removing impossible combinations (e.g., "dead market + strong momentum") and collapsing correlated states (e.g., "wide gap" almost always comes with "thin book"): ~200 meaningful states.

The top 20 below cover ~85% of trading time and ~95% of fills.

---

## Summary Table

| # | Case | Quote Bid | Hedge Bid | Momentum | Freq | Timer Logic | Fill Prob (60s) | Fill Quality | Cost | % Incremental | Net Value | Clip Size |
|---|------|-----------|-----------|----------|------|-------------|----------------|-------------|------|---------------|-----------|-----------|
| 1 | Quiet Normal | Mod | Mod | Flat | 22% | 0.05 | 25% | Exact | 0–0.5 | 30% | +0.20 | Normal |
| 2 | Good Hedge Available | Mod | Thick | Flat | 12% | 0.15 | 40% | Favorable | 0.5 | 35% | +0.28 | Larger |
| 3 | Gentle Drift Toward | Mod | Mod | Toward | 10% | 0.20 | 45% | Exact | 0.5 | 50% | +0.50 | Normal |
| 4 | Weak Hedge | Mod | Thin | Flat | 8% | 0.00 | 20% | Unfavorable | 0 | — | 0.00 | Normal |
| 5 | Drifting Away | Mod | Mod | Away | 8% | 0.00 | 15% | Unfavorable | 0 | — | 0.00 | Normal |
| 6 | Aggressive Cross Setup | Thick | Thin (ask) | Toward | 6% | 0.25 | 70% | Slight payup | 0.5 | 60% | +0.65 | Normal |
| 7 | Join Inside Setup | Mod | Mod | Toward | 5% | 0.15 | 35% | Exact | 0.5 | 40% | +0.35 | Normal |
| 8 | Weak Quote, Strong Hedge | Thin | Thick | Flat | 4% | 0.15 | 20% | Favorable | 0.5 | 45% | +0.43 | Larger |
| 9 | Dead Market | Any | Any | Flat | 4% | 0.00 | 5% | Exact | 0 | — | 0.00 | Normal |
| 10 | Wide Gap on Quote Leg | Thin | Mod | Flat | 3% | 0.00 | 10% | Unfavorable | 0 | — | 0.00 | Smaller |
| 11 | Wide Gap on Hedge Leg | Mod | Thin | Flat | 3% | 0.00 | 15% | Bad payup | 0 | — | 0.00 | Smaller |
| 12 | Both Legs Strong (Rare) | Thick | Thick | Any | 2.5% | 0.40 | 85% | Favorable | 0.5–1.0 | 70% | +0.85 | Double |
| 13 | Fast Move Toward | Mod+ | Mod+ | Strong→ | 2.5% | 0.30 | 60% | Slight payup | 0.5 | 65% | +0.73 | Normal |
| 14 | Hedge Leg Just Got Swept | Any | Refilling | Toward | 2% | 0.35 | 55% | Moderate payup | 0.5 | 70% | +0.80 | Normal |
| 15 | Both Books Growing | Growing | Growing | Toward | 2% | 0.25 | 50% | Exact | 0.5 | 55% | +0.53 | Normal |
| 16 | Hidden Buyer on Quote | Refilling | Any | Flat | 1.5% | 0.05 | 55% | Exact | 0–0.5 | 20% | +0.10 | Larger |
| 17 | Fast Move Away | Any | Any | Strong← | 2% | 0.00 | 8% | Very bad | 0 | — | 0.00 | Pause |
| 18 | Mostly Synthetic Orders | Mixed | Mixed | Flat | 2% | 0.00 | 18% | Unfavorable | 0 | — | 0.00 | Smaller |
| 19 | Both Legs Wide Gap | Thin | Thin | Flat | 1.5% | 0.00 | 5% | Very bad | 0 | — | 0.00 | Pause |
| 20 | Fed/Event Window | Any | Any | Volatile | Sched | 0.00 | 10% | Very bad | 0 | — | 0.00 | Pause |

**Reading the table:**
- **Timer Logic**: The aggressiveness value (0 = fully defensive rounding, 0.49 = maximum aggression)
- **Fill Prob**: Estimated chance of getting a fill within 60 seconds
- **Fill Quality**: Whether the hedge typically fills at your target ("Exact"), better ("Favorable"), or worse ("Unfavorable"/"payup")
- **Cost**: Edge given up in O-spread ticks when Timer Logic fires
- **% Incremental**: Of the fills where Timer Logic changed the rounding, what fraction would NOT have happened under hard rounding
- **Net Value**: Expected profit per Timer-Logic-affected fill, in O-spread ticks. Positive = Timer Logic adds value in this case.
- **Clip Size**: Whether to increase ("Larger"), decrease ("Smaller"), or stop ("Pause") the standard order size

---

## Detailed Case Analysis

### Case 1: Quiet Normal (22% of time) — The Baseline

**What's happening:**
Normal market. Both legs have moderate liquidity, tight 1-tick bid-ask gaps, no directional pressure. Someone trades every 5–15 seconds on both legs. The book-weighted fair price (microprice) is oscillating slightly but not trending. The trade-weighted average price (Volume VWAP) is sitting in the middle of the tick interval.

**Specific book state:**
- Quote leg (SR1): 180 lots on the bid, 200 on the offer, 1-tick gap
- Hedge leg (SR3): 600 on the bid, 650 on the offer, 1-tick gap
- Last trade on both legs: 5–15 seconds ago
- Real orders (not synthetic): 75%+ of the book

**Timer Logic decision: 0.05 (very conservative)**
Only round toward market when the raw price is within 0.05 of the next valid tick — that's the closest 10% of the tick interval. Most price updates produce the same result as hard rounding. Timer Logic fires on roughly 10% of price recalculations in this state.

Why so conservative? There's no evidence that the market is coming to your price. No momentum, no urgency. Expanding aggressively would give away edge on fills you'd get anyway.

**What the ASE rules do in this state:**
- The aggressive crossing rule (HitMan) does NOT fire. Neither leg's offer is thin enough relative to its bid (the "offer weakness" ratio is too high). There's no signal to cross aggressively.
- The passive joining rule (ASM) MAY fire occasionally. When the calculated price happens to land 1 tick from the inside bid, and the hedge leg has enough liquidity (600 lots easily passes the 150-lot threshold for tight markets), ASM moves the quote to the inside. This happens about 15% of the time.
- The hedge patience rule (Backoff) fires about 30% of the time. When the quote fills, Backoff checks if the hedge leg has enough resting quantity to justify waiting one tick behind the best price. At 600 lots, it's borderline.

**Economics:**
- 25% chance of fill within 60 seconds from natural order flow
- When Timer Logic fires (10% of recalculations), about 30% of those fills are incremental
- Net value per Timer-affected fill: +0.20 ticks in O-spread terms
- This is marginal per fill, but Case 1 represents 22% of all trading time. Over hundreds of fills, it accumulates meaningfully.

**Clip size:** Normal (3 lots). No reason to adjust.

---

### Case 2: Good Hedge Available (12%) — Hedge Confidence

**What's happening:**
Your passive buy is in a normal state, but the hedge side has an unusually thick bid. If your buy fills, you can sell the hedge into a deep, reliable bid. Recent trades confirm activity at that hedge price level.

**Specific book state:**
- Quote leg (SR1): 200 bid, 180 offer, 1-tick gap
- Hedge leg (SR3): 1500 bid, 400 offer, 1-tick gap
- Recent trades on hedge leg confirm activity at the bid price
- Real orders: 80%+

**Timer Logic decision: 0.15 (moderate)**
The thick hedge bid gives you confidence that even if your buy is slightly more aggressive (thanks to Timer Logic rounding), the resulting hedge will fill reliably — and at a good price. You can afford to be more aggressive on the buy side because the hedge side protects you.

**What the ASE rules do:**
- HitMan: Hedge offer (400) relative to hedge bid (1500) = 27% ratio. The threshold is 10%. Too high — HitMan does not fire. The offer isn't thin enough to signal momentum.
- ASM: Fires when the quote price lands near the inside. With solid hedge liquidity, the gap-aware check passes easily.
- **Backoff works in your favor here.** When the buy fills and the hedge fires, Backoff checks the hedge leg: 1500 lots on the bid exceeds the 1000-lot threshold → Backoff activates. Your hedge order rests 1 tick behind the best price, trying for a better fill. With 1500 lots supporting that level, the backed-off order very likely fills — giving you a 0.5-tick improvement on the hedge. This is why "Fill Quality" shows "Favorable."

**Economics:**
- 40% fill probability. The thick hedge doesn't directly help your buy fill rate, but the system can afford slightly more aggression.
- When Timer Logic fires, 35% of fills are incremental
- The hedge patience rule typically saves 0.2 ticks on average
- Net: +0.28 per Timer-affected fill

**Clip size:** Larger (4-5 lots). The reliable hedge justifies more exposure. This would require the dynamic clip sizing feature discussed in the open items.

---

### Case 3: Gentle Drift Toward You (10%) — Momentum Confirmation

**What's happening:**
Prices are gently moving in your direction. The quote leg's microprice is trending UP (toward your buy order). The hedge leg is stable or trending DOWN (toward where you'd sell). Not fast enough to trigger the aggressive crossing rule, but clearly favorable. Recent trades at your desired price level confirm the move.

**Specific book state:**
- Quote leg (SR1): 250 bid, 150 offer, 1-tick gap
- Hedge leg (SR3): 700 bid, 500 offer, 1-tick gap
- Last trade at your desired buy price: within the last 10 seconds
- Trade-weighted price: confirming the move (trades are happening at levels that support the new prices)

**Timer Logic decision: 0.20 (moderately aggressive)**
The key evidence: someone traded at your desired fill price within the last 10 seconds. That's the strongest short-term signal — the price IS fillable, because someone just filled there. The trade-weighted price confirms the microprice move isn't just book shuffling.

Timer Logic fires on about 40% of recalculations at this aggressiveness level.

**What the ASE rules do:**
- HitMan: Offer ratios (500/700 = 71% on hedge, 150/250 = 60% on quote) are way above the 10% threshold. No crossing.
- ASM: Fires more frequently. Momentum + quote price near inside → the joining rule activates. Session range is narrow (gentle drift, not a breakout) → passes the "not too wide" check.
- Backoff: Hedge bid at 700 is below the 1000-lot threshold, but the ratio test may trigger. ~40% probability.

**Economics:**
- 45% fill probability. Momentum is bringing the market to you.
- 50% of Timer-Logic fills are incremental. This is the key — momentum carries fills to the expanded price that wouldn't reach the hard-rounded price.
- Net: +0.50 per Timer-affected fill. **This is a core value case for Timer Logic.**

**Clip size:** Normal. The momentum does the work; you don't need larger clips.

---

### Case 4: Weak Hedge (8%) — Danger Zone

**What's happening:**
Your buy side is fine, but the hedge side has a thin bid and a thick offer. If your buy fills, selling the hedge is uncertain — you might have to chase the price.

**Specific book state:**
- Quote leg (SR1): 200 bid, 180 offer, 1-tick gap
- Hedge leg (SR3): 150 bid, 800 offer, 1-tick gap
- The thick offer on the hedge side suggests selling pressure
- No momentum

**Timer Logic decision: 0.00 (fully defensive)**
Timer Logic is OFF. The thin hedge bid means any fill on the buy side creates a problem — you're exposed to a weak hedge. If you expand aggressively and get a buy fill, and then the hedge fails or requires chasing (paying up), you compound the loss: you paid more on the buy AND more on the hedge.

**What the ASE rules do:**
- HitMan: Hedge offer 800 vs bid 150 → the offer is THICK, not thin. The "offer weakness" signal is completely absent. HitMan is blocked — correctly so.
- ASM: The trend/session check may block it. With an imbalanced book (thick offer = selling pressure), ASM's "don't quote at extremes" filter activates.
- Backoff: If somehow filled, Backoff checks the hedge bid: 150 lots is below the absolute threshold (1000). The ratio test: 800 offer ≥ 0.3 × (bid behind) → probably passes. So Backoff fires — your hedge rests one tick behind. But with only 150 on the bid, that backed-off order may NOT fill. Now you're stuck (legged) waiting.

**Economics:**
- 20% fill probability
- Expected fill quality: unfavorable (hedge chasing likely costs +0.5 ticks)
- Net: 0.00. Correct decision to not expand. Avoid making a bad setup worse.

**Clip size:** Normal. Consider reducing if the hedge deteriorates further.

---

### Case 5: Drifting Away (8%) — Adverse Momentum

**What's happening:**
Prices are moving away from you. The quote leg's microprice is trending DOWN (away from your buy). Nobody has traded at your desired price for 30+ seconds. The trade-weighted price confirms the adverse move.

**Timer Logic decision: 0.00 (fully defensive)**
The market has moved past your price. Expanding would place orders at levels the market has already left behind. Any fills would be against momentum — the classic adverse selection setup.

The key signal: **no trade at your desired price for 30+ seconds.** This single observation overrides all other evidence.

**What the ASE rules do:**
- HitMan: The quote leg's offer is thick relative to its bid (300 vs 180). This is the opposite of the "thin offer = momentum" signal. Completely blocked.
- ASM: The session range and trend filters block it. When the bid is at or near the session's low point, ASM refuses to join (designed to prevent chasing into trends).

**Economics:**
- 15% fill probability (only on mean-reversion)
- Expected fill quality: unfavorable (+0.3 ticks payup on average)
- Net: 0.00. Do not expand into adverse momentum.

**Clip size:** Normal. Wait for the reversal.

---

### Case 6: Aggressive Cross Setup (6%) — HitMan Territory

**What's happening:**
The microstructure is screaming "cross now." The quote leg has a thick bid supporting your order and a tiny offer about to be swept. The hedge leg also shows a thin offer with confirmed recent trades at the crossing level. Momentum is toward you.

**Specific book state:**
- Quote leg (SR1): 350 bid, 30 offer, 1-tick gap
- Hedge leg (SR3): 500 bid, 40 offer, 1-tick gap
- Last trade on hedge at the offer price: confirmed (recent)
- Real orders: 90%+ (the thin offers are genuine, not synthetic)

**Timer Logic decision: 0.25 (aggressive)**
The aggressive crossing rule (HitMan) needs the quote to be resting AT the inside bid to fire. Without Timer Logic, hard rounding might place the quote 1 tick from the inside. Timer Logic's 0.25 aggressiveness ensures the quote reaches the inside bid, enabling HitMan to cross.

**This is the synergy case: Timer Logic enables HitMan.**

**What the ASE rules do:**
HitMan checks 8 conditions — in this state, all pass:
1. Hedge leg offer thin relative to bid: 40 / 500 = 8% ≤ 10% threshold ✓
2. Quote leg offer thin relative to bid: 30 / 350 = 8.6% ≤ 10% ✓
3. Quote is at the inside bid (Timer Logic ensured this) ✓
4. Offer at crossing price is small: 30 < 100 lot cap ✓
5. Last trade on hedge confirms activity at the crossing level ✓
6. Hedge bid has enough liquidity to absorb: 500 ≥ 400 lot minimum ✓
7. Spread economics check after crossing: passes (assumed) ✓
8. The offer at crossing price is real orders, not synthetic ✓

→ HitMan fires. Your quote crosses 1 tick through the market. Fill is near-immediate.

After the cross fills, Backoff checks the hedge: 500 bid, 40 offer. Offer is thin → Backoff does NOT trigger (below thresholds). Hedge goes at calculated price.

**Economics:**
- 70% fill probability. HitMan cross + reliable hedge into 500-lot bid.
- Fill quality: slight payup (+0.2 ticks) because crossing costs 1 tick on the quote, but hedge is usually exact.
- **60% of these fills are incremental.** Many ONLY happen because Timer Logic placed the quote at the inside where HitMan could trigger.
- Net: +0.65 per Timer-affected fill. **Highest per-fill value among common cases.**

**Clip size:** Normal. Don't oversize aggressive fills.

---

### Case 7: Join Inside Setup (5%) — ASM Territory

**What's happening:**
Market is gently favorable but not enough for the aggressive crossing rule. Your calculated price lands 1 tick away from the best bid. Timer Logic can bring it to the inside, where the passive joining rule (ASM) then moves it the final step.

**Specific book state:**
- Quote leg (SR1): 200 bid, 120 offer, 1-tick gap
- Hedge leg (SR3): 600 bid, 300 offer, 1-tick gap
- Session price range: narrow (< 4 ticks total so far today)
- Slight favorable momentum

**Timer Logic decision: 0.15 (moderate)**
Goal: bridge the gap between the hard-rounded price (2 ticks from inside) and the joinable position (1 tick from inside). Once Timer Logic gets the price to 1 tick away, ASM can join the inside.

**What the ASE rules do:**
- HitMan: Hedge offer/bid ratio 300/600 = 50%. Way too high → blocked.
- ASM: Checks if the quote is exactly 1 tick from the inside bid → Timer Logic made this true. Hedge liquidity check: 600 ≥ 150 lot threshold for tight markets ✓. Session range < 4 ticks ✓. Not at session extreme ✓. → **ASM fires.** Quote joins the inside bid.
- Backoff: ~40% probability on SR3 at 600 lots.

**Economics:**
- 35% fill probability. At the inside bid, fills come from natural flow.
- Fill quality: exact (passive fill, no crossing cost)
- 40% incremental
- Net: +0.35. Moderate positive. Consistent accumulation over the 5% of time this state occurs.

**Clip size:** Normal.

---

### Case 8: Weak Quote, Strong Hedge (4%) — The Loaded Spring

**What's happening:**
Your buy order sits on a thin bid (uncertain fill), but the hedge side has a massive bid (excellent conditions if you do get filled). This is better than Case 1 (quiet normal): if your thin buy fills, the hedge is nearly guaranteed.

**Specific book state:**
- Quote leg (SR1): 40 bid, 100 offer, 1-tick gap
- Hedge leg (SR3): 2000 bid, 300 offer, 1-tick gap

**Timer Logic decision: 0.15 (moderate)**
The 2000-lot hedge bid provides confidence, but the 40-lot quote bid limits what Timer Logic can achieve. Expanding improves the quote fill probability marginally, and that marginal improvement is valuable because the hedge payoff is excellent.

**State transition value:** This is a "loaded spring" — waiting for the quote side to improve. If the quote bid thickens, this upgrades to Case 12 (both legs strong — the highest value state). If the hedge bid weakens, it degrades to Case 1 (still fine).

**What the ASE rules do:**
- HitMan: Hedge offer/bid = 300/2000 = 15%. Just above the 10% threshold → barely fails. A small book change could trigger it.
- **Backoff works strongly in your favor.** Hedge bid 2000 > 1000 threshold → Backoff fires. Hedge rests 1 tick behind the best price. With 2000 lots supporting that level, the backed-off order fills with near certainty at a 0.5-tick improvement. This makes fill quality "Favorable."

**Economics:**
- 20% fill probability (constrained by thin quote side)
- Fill quality: favorable (-0.5 ticks, thanks to Backoff on the thick hedge)
- 45% incremental
- Net: +0.43. The excellent hedge subsidizes the marginal quote.

**Clip size:** Larger (4-5 lots). The thick hedge justifies more exposure.

---

### Case 9: Dead Market (4%) — No Evidence

**What's happening:**
Both legs have resting orders but nobody is trading. No fills on either leg for 30+ seconds. The microprice is static — not because prices are stable, but because nothing is happening. The trade-weighted price has no new data.

**Timer Logic decision: 0.00 (fully defensive)**
Zero evidence supports any fill price. The book looks "normal" by quantity, but the absence of trading means there's no confirmation that these prices are real. Expanding would commit to prices with no recent validation.

**The overriding signal:** Time since last trade at your desired price > 30 seconds → Timer Logic off, regardless of all other factors.

**Economics:**
- 5% fill probability. Random arrival only.
- Net: 0.00. Correct to not expand. Wait for activity to resume.

**Clip size:** Normal. No reason to reduce unless dead state persists > 2 minutes.

---

### Case 10: Wide Gap on Quote Leg (3%) — Fragile Quote Side

**What's happening:**
The quote leg's bid-ask gap has widened to 2 ticks (normally 1 tick). This means the bid is fragile — if it breaks, the price jumps 2 ticks instead of 1. The hedge leg is normal.

**Specific book state:**
- Quote leg (SR1): 30 bid, 25 offer, **2-tick gap**
- Hedge leg (SR3): 500 bid, 400 offer, 1-tick gap

**Timer Logic decision: 0.00 (fully defensive)**
When the quote leg gaps, the microprice becomes unreliable (the system already falls back to a simple midpoint instead of the book-weighted calculation). The passive joining rule (ASM) switches to its gap-aware mode, requiring 10× more liquidity (1500 lots instead of 150) before it will act. Timer Logic should not override these defensive measures.

If the gap is wide enough, the wide-spread safety guard pauses the contract entirely.

**Economics:**
- 10% fill probability. The gap means the bid could vanish at any moment.
- Fill quality: unfavorable (+0.3 ticks payup when the gap collapses during hedge)
- Net: 0.00. Don't expand into unreliable prices.

**Clip size:** Smaller or minimum. Gapped quote is high risk.

---

### Case 11: Wide Gap on Hedge Leg (3%) — Hedge Trap

**What's happening:**
Your buy side is healthy, but the hedge leg has a 2-tick gap. If your buy fills, the hedge has to sell into a gapped market where prices can jump unpredictably.

**Specific book state:**
- Quote leg (SR1): 200 bid, 150 offer, 1-tick gap
- Hedge leg (SR3): 100 bid, 80 offer, **2-tick gap**

**Timer Logic decision: 0.00 (fully defensive)**
Even though the buy side looks fine, the gapped hedge is a trap. If you get a buy fill, the hedge patience rule (Backoff) pulls back 1 tick — but the next level might be empty too. The hedge chasing rule (Payup) could then chase through the gap, consuming multiple ticks of edge.

**Economics:**
- 15% fill probability (quote side OK, but should avoid)
- Fill quality: bad (+1.0 ticks payup — hedge into gap is expensive)
- Net: Negative expected value when you account for hedge cost.

**Clip size:** Smaller. Gapped hedge is expensive.

---

### Case 12: Both Legs Strong (2.5%) — The Rare Opportunity

**What's happening:**
Both legs have thick bids, thin offers, and tight gaps. If you cross 1 tick on the quote and hit the hedge bid, the resulting spread price matches your target. This is the ideal setup — both legs are ready for immediate execution.

**Specific book state:**
- Quote leg (SR1): 400 bid, 35 offer, 1-tick gap
- Hedge leg (SR3): 1800 bid, 200 offer, 1-tick gap
- Trade-weighted price and microprice both confirm current levels
- Real orders: 85%+

**Timer Logic decision: 0.40 (near-maximum)**
Speed matters more than per-tick optimization. The 0.5-tick rounding cost is trivial against the 2.0-tick edge budget when fill certainty is ~85%. Get to the inside bid so the aggressive crossing rule can fire.

**IMPORTANT WARNING:** If this state occurs more than ~5% of the time, something is likely wrong. Markets are efficient — both legs being simultaneously perfect is genuinely rare. If it's happening frequently, check that your buy/sell targets aren't misentered (e.g., you typed 6.5 instead of 5.5).

**What the ASE rules do:**
- HitMan: All 8 conditions met (same analysis as Case 6 but even stronger). Fires → crosses quote.
- Backoff: Hedge bid 1800 > 1000 threshold → fires. Hedge rests 1 tick behind. With 1800 lots, the backed-off fill is virtually guaranteed at a 0.5-tick improvement.
- **Net of both rules:** HitMan costs 0.5 on the quote, Backoff saves 0.5 on the hedge → approximately break-even on execution, but BOTH LEGS FILL. Full O spread captured.

**Economics:**
- 85% fill probability. Both legs fill with high certainty.
- Fill quality: favorable (-0.3 ticks net — Backoff slightly exceeds crossing cost)
- 70% incremental. Most of these fills ONLY happen because Timer Logic placed the quote at the inside for HitMan to cross.
- Net: +0.85. **Highest net value of all cases.** Rare but exceptional.

**Clip size:** Double (6 lots). Maximize exposure to this opportunity.

---

### Case 13: Fast Move Toward You (2.5%) — Catch the Wave

**What's happening:**
Strong favorable momentum. The quote leg microprice has moved 1+ ticks in your direction over the last 5 seconds. Someone traded at your desired price within the last 3 seconds. The trade-weighted price is lagging but directionally aligned.

**Timer Logic decision: 0.30 (aggressive)**
The recent trade at your price is the strongest signal — someone filled there 3 seconds ago, so the price IS fillable right now. The trade-weighted price is still catching up (it always lags in fast moves), but directional alignment is sufficient.

This is a time-sensitive window. If momentum slows, Timer Logic should decay back toward 0.10 over 5-10 seconds.

**Economics:**
- 60% fill probability. Momentum carries fills.
- Fill quality: slight payup (+0.3 ticks — hedge in fast market)
- 65% incremental. Aggressive Timer Logic captures fills that hard rounding would miss entirely.
- Net: +0.73. High value, but time-sensitive — the window lasts seconds.

**Clip size:** Normal. Don't oversize into fast markets — the payup risk is real.

---

### Case 14: Hedge Leg Just Got Swept (2%) — Aftershock Window

**What's happening:**
Someone just aggressively bought through the hedge leg's bid (visible as a sudden drop of 500+ lots in under 1 second, plus a trade at the old bid level). The bid is temporarily depleted and will soon refill as market makers replenish.

**Timer Logic decision: 0.35 (high urgency)**
The 2-5 second window after a sweep is a high-probability fill zone. The sweep confirms directional conviction. If you can get your buy filled quickly, the refilling hedge bid will likely absorb your sell.

Your .NET system needs to detect this specifically: track sudden bid quantity drops on the hedge leg (delta > 500 lots in < 1 second) and flag the state.

**Economics:**
- 55% fill probability. Window is short but high conviction.
- Fill quality: moderate payup (+0.5 ticks — hedge into thin post-sweep book)
- 70% incremental. Timer Logic captures the narrow window.
- Net: +0.80 per fill. Very high value. Decays rapidly (2-5 seconds).

**Clip size:** Normal. Speed over size.

---

### Case 15: Both Books Growing (2%) — Convergence

**What's happening:**
Over the last 10 seconds, the quote leg bid has grown from 150 → 250 → 350 and the hedge leg bid has grown from 500 → 800 → 1100. Neither leg individually hits the thresholds for the aggressive crossing or joining rules, but the coordinated growth is a strong composite signal.

**Timer Logic decision: 0.25 (aggressive)**
This is a cross-leg signal that the ASE rules cannot see (they only look at one leg at a time). Your .NET system sees both legs and detects the convergence. When both legs strengthen simultaneously, the spread is compressing toward your desired fill level.

**Economics:**
- 50% fill probability. Converging books create fills.
- Fill quality: exact (coordinated books → clean execution)
- 55% incremental. The cross-leg signal adds genuine information.
- Net: +0.53. Solid value from information the ASE rules can't access.

**Clip size:** Normal.

---

### Case 16: Hidden Buyer on Quote Leg (1.5%) — Iceberg Detection

**What's happening:**
The quote leg bid shows only 80 lots, but it keeps replenishing to 80 within ticks after partial fills. Detected by tracking 3+ replenishments in 30 seconds. This means an algorithmic buyer is working at that level — the bid is much more reliable than the 80 lots suggest.

**Timer Logic decision: 0.05 (conservative)**
The iceberg means your passive fill probability is HIGHER than the book suggests — so you don't need to expand aggressively. The fill will come to you. The iceberg is doing the work of bringing the market to your price.

**The real opportunity is clip size, not Timer Logic.** The hidden buyer signals sustained interest at this level. More lots can be filled without moving the market.

**Economics:**
- 55% fill probability (much higher than the apparent 80-lot bid suggests)
- Fill quality: exact (passive fills, iceberg absorbs impact)
- Only 20% incremental (most fills would happen anyway)
- Net: +0.10 per Timer-affected fill (low). But larger clips at good quality capture more total P&L.

**Clip size:** Larger (4-5 lots). The iceberg justifies more exposure.

---

### Case 17: Fast Move Away (2%) — Adverse Selection Danger

**What's happening:**
Strong adverse momentum. The quote leg bid is collapsing, offer is thick and growing. The microprice has dropped 1.5+ ticks in 5 seconds. Nobody has traded at your desired price for 30+ seconds. The trade-weighted price confirms the selling.

**Timer Logic decision: 0.00 (fully defensive)**
Any fill in this state is almost certainly adverse selection — the market is running away from your price and you're being picked off. Even the hard-rounded price may be too aggressive.

This may not trigger the system-wide circuit breaker (which watches a different instrument and needs a 5-tick move in 2 seconds), so Timer Logic's zero-expansion acts as an additional layer of defense.

**Economics:**
- 8% fill probability (declining rapidly)
- Fill quality: very bad (+1.5 ticks payup if filled — severe hedge chasing)
- Net: Negative. If filled, high probability of adverse outcome.

**Clip size:** Pause trading temporarily. Resume when momentum reverses.

---

### Case 18: Mostly Synthetic/Implied Orders (2%) — Phantom Liquidity

**What's happening:**
Both legs show moderate total quantities, but when you look at the breakdown: more than 40% of the resting orders are synthetic (implied from other spread engines), not real direct orders. The apparent book is half phantom liquidity that will vanish the moment the underlying spread moves.

**Specific book state:**
- Quote leg (SR1): 250 total bid, but only 100 are real direct orders (60% implied)
- Hedge leg (SR3): 600 total bid, but only 250 are real (42% implied)

**Timer Logic decision: 0.00 (fully defensive)**
Implied orders are unreliable. They exist because another spread engine calculated that price level is profitable for their spread — but the moment that other spread's inputs change, their implied orders vanish. HitMan already checks for implied orders at the crossing price (its 8th condition), but Timer Logic adds a broader check: if the overall book is substantially implied, don't expand at all.

**Rule of thumb:** If real orders / total orders < 65% on either leg → Timer Logic off.

**Economics:**
- 18% fill probability (lower than the book suggests — implied is phantom)
- Fill quality: unfavorable (+0.3 ticks — hedge into implied book → vanishes during execution)
- Net: 0.00. Avoid.

**Clip size:** Smaller. Monitor until real orders recover.

---

### Case 19: Both Legs Wide Gap (1.5%) — Do Not Trade

**What's happening:**
Both legs have 2-tick bid-ask gaps with thin liquidity on both sides. The microprice is unreliable on both legs (using simple midpoint instead of book-weighted calculation). The system may be close to auto-pausing via the wide-spread safety guard.

**Timer Logic decision: 0.00 (fully defensive)**
Both legs unreliable. Any fill would be into gaps that can jump 2 ticks on either side. Execution quality would be terrible on both the quote and hedge.

**Economics:**
- 5% fill probability
- Fill quality: very bad (+1.0 ticks payup — gap execution compounds on both legs)
- Net: Negative expected value.

**Clip size:** Pause entirely. Resume when either leg tightens. If the monitoring instruments' spread exceeds 1 tick, the system auto-pauses anyway.

---

### Case 20: Fed/Event Window (Scheduled) — Known Volatility

**What's happening:**
The clock shows 12:55–13:05 UTC. An FOMC announcement or similar event is imminent. The spread widening parameter auto-escalates to 0.11 (pushing all orders deeper into the book). Any microstructure signal is unreliable because the entire market is about to reprice.

**Timer Logic decision: 0.00 (fully defensive)**
The spread widening system already pushes prices into depth for protection. Timer Logic should NOT counteract this by expanding aggressively — that would undo the defensive positioning. These are the minutes where a 50-tick move on bonds can happen in 2 seconds.

**Economics:**
- 10% fill probability (most orders pulled into depth by the widened spreads)
- Fill quality: very bad (+2.0 ticks if filled — event fills are heavily adverse)
- Net: Strongly negative if expanded. Correct to zero out.

**Clip size:** Pause or minimum. The system handles this automatically via scheduled pause windows.

---

## Where Timer Logic's Value Comes From

### By Case Tier

| Tier | Which Cases | % of Trading Time | Timer Logic Value | % of Total Value |
|------|------------|-------------------|-----------|-----------------|
| **High Value** | 6 (Cross Setup), 12 (Both Strong), 13 (Fast Toward), 14 (Sweep) | 13% | 0.25–0.40 | ~45% |
| **Moderate Value** | 2 (Good Hedge), 3 (Gentle Toward), 7 (Join), 8 (Weak/Strong), 15 (Cascade) | 33% | 0.15–0.25 | ~35% |
| **Marginal Value** | 1 (Quiet), 16 (Iceberg) | 23.5% | 0.05 | ~15% |
| **Zero (Correctly Off)** | 4, 5, 9, 10, 11, 17, 18, 19, 20 | 30.5% | 0.00 | 0% |

### Three Sources of Value

1. **Momentum capture (Cases 3, 6, 13, 14)**: ~28% of time, ~45% of value.
   Timer Logic captures time-sensitive opportunities by rounding toward market when momentum confirms the fill price.

2. **Structural strength (Cases 2, 8, 12)**: ~18.5% of time, ~35% of value.
   Timer Logic exploits favorable hedge conditions — when the hedge side is thick and reliable, the buy side can afford to be more aggressive.

3. **Passive improvement (Cases 1, 7, 16)**: ~28.5% of time, ~20% of value.
   Small per-fill benefit, but high frequency. Accumulates over many fills throughout the day.

### The Other Side: Knowing When NOT to Expand

The 30.5% of time at zero Timer Logic (Cases 4, 5, 9–11, 17–20) is equally important. These are the states where expanding would produce **negative-expected-value fills** that erase the gains above. The key "off" signals:

- No trade at desired price for 30+ seconds → dead market or adverse momentum
- Hedge bid thin or gapped → unreliable hedge makes any aggression dangerous
- Real order ratio below 65% → phantom book that vanishes during execution
- Strong adverse momentum → being picked off
- Event windows → market about to reprice entirely

### Expected System-Level Impact

Across all cases (weighted by frequency during active trading hours):

| Metric | Estimate |
|--------|----------|
| Timer Logic active (value > 0) | ~65% of trading time |
| Timer Logic actually changes the rounding | ~25% of price recalculations |
| Average edge cost when rounding changes | 0.35 ticks per O spread |
| Average % of changed-rounding fills that are incremental | ~45% |
| Average net value per Timer-Logic-affected fill | +0.42 ticks per O spread |
| Estimated fills attributable to Timer Logic | ~15–25% of all fills |
| Estimated P&L uplift vs hard rounding | +8–15% |