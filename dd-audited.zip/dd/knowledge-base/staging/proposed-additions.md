---
title: Proposed Additions — 2026-03-29
last-updated: 2026-03-29
---

# Proposed Additions

Items extracted from brain dump session 2026-03-29. Each item needs
user review before merging into the KB.

---

### Seasonality Trade Mechanics — SR3|SR1 3Leg at Rolls
**Target**: strategy/ancillary-strategies.md → New section "Seasonality Trades"
**Type**: New
**Proposed text**:
> ## Seasonality Trades
>
> Seasonality trades are more time-sensitive and less price-sensitive.
> They must be identified in advance and acted on at the right time.
>
> ### SR3|SR1 3Leg Front Contract at Rolls
>
> At SR3 quarterly expiry (roll date), roll traders enter the market
> and push the SR3|SR1 front contract spread upward.
>
> **Example — Mar 2026 cycle:**
> - SR3 Dec expiry: 13 Mar
> - SR3|SR1 Mar spread: Live price = 3, Fair value = 3.7
> - Expected price on 13 Mar (roll date): 4.2+
> - Edge: Time the entry before roll traders arrive
>
> **Key properties:**
> - Time-driven, not price-driven — the catalyst is the roll date
> - Predictable direction (up) due to roll mechanics
> - Should be tracked on a calendar with pre-set alerts
>
> A running list of seasonality trades should be maintained and
> reviewed weekly.

**Rationale**: Ancillary strategies is the natural home for
non-core spread strategies. This adds a time-based dimension
that doesn't exist in the current strategy documentation.

---

### Meeting Neutral Structure — Fed Sheet Formula Methodology
**Target**: strategy/ → New file "structures-and-fed-sheet.md"
**Type**: New
**Proposed text**:
> ## Meeting Neutral Structures
>
> A "Structure" is a spread construction that is neutral to a
> specific FOMC meeting. The price of the structure represents
> non-meeting rate expectations.
>
> ### Formula Construction
>
> For a meeting on day D of month M:
> - Days before meeting in month M: D₁
> - Days after meeting in month M (= days in M+1 before next
>   relevant date): D₂
> - Meeting Neutral = (M − M+1) × D₁ − (M+1 − M+2) × D₂
>
> When this expression equals zero, the structure is unaffected
> by the FOMC decision.
>
> **Example — June 17 meeting:**
> Meeting Neutral = (Jun−Jul) × 16 − (Jul−Aug) × 14 = 0
>
> ### Emergency (Intermeeting) Hike/Cut Pricing
>
> If an emergency event occurs (e.g., extreme CPI), an intermeeting
> hike/cut may be priced in. The Meeting Neutral structure will
> move away from zero.
>
> To deduce how much hike/cut is priced in:
> 1. Observe the current price of the Meeting Neutral structure
> 2. Assume the hike/cut occurs on the event day (e.g., CPI day)
> 3. Back out the implied rate change from the structure price
>
> ### "Structures" Definition
>
> In general usage, "Structures" refers to:
> - Meeting Neutral spreads
> - SR3|SR1 3-leg spreads
> - Any very stable strategy where worst cases are known
>
> These are the safest instruments for expressing views on
> rate expectations.

**Rationale**: This is core pricing methodology for the Fed Sheet
Excel tool. Currently undocumented. Could be a new file in
strategy/ since it's a distinct analytical framework, or could
merge into ancillary-strategies if preferred.

---

### PIQ Range Market Patterns
**Target**: execution-analysis/methodology-and-framework.md → New section "PIQ Patterns"
**Type**: New
**Proposed text**:
> ## PIQ Patterns
>
> ### Range Market PIQ Usage
>
> In range-bound markets, PIQ (Position in Queue) becomes a
> primary fill mechanism. Conditions favouring PIQ-based fills:
> - Price is ranged (not trending)
> - High bid-ask quantity (deep book)
> - High number of lots traded (active market)
> - Less flipping of prices (stable book)
> - Actual trades occur before flipping (real volume, not phantom)
> - More volatile correlated watch product available (directional
>   signal from related instrument)
>
> ### PIQ-Based Execution Pattern
>
> When range conditions are met:
> 1. Place orders using MinVol scalper algo
> 2. Monitor conditions — remove orders if conditions deteriorate
> 3. If conditions hold, improve PIQ over time and get filled
>
> ### PIQ as Market Condition Tracker
>
> PIQ behaviour across orders can be used to infer market state:
> - Stable PIQ across instruments → range/calm market
> - PIQ degrading across instruments → momentum building
> - PIQ improving on one side → directional pressure on other side

**Rationale**: Extends the existing execution analysis framework
with PIQ-specific patterns. The methodology file already covers
TD and fill accuracy — PIQ patterns are a natural extension.

---

### Market Profiling Framework
**Target**: strategy/ → New file "market-profiling.md"
**Type**: New
**Proposed text**:
> ## Market Profiling
>
> Objective: Profile traded contracts into groups (not individual
> contracts) to determine which ASE rules, rule parameters, and
> .NET parameters to use per group.
>
> ### Contract Grouping Example (SR3 Complex)
>
> SR3 has outrights, spreads, flies, etc. These should be seen
> as 3–4 groups:
> - **Front spreads (Group 1)**: More directional, data-dependent.
>   Different parameters than mid spreads.
> - **Mid spreads (Group 2)**: Usually in smaller range. WCT makes
>   sense here. Can leave mid spreads unhedged.
> - **Front ZQ outrights**: Usually stable but can burst in one
>   direction (e.g., intermeeting cut). Never enter from the side
>   where risk of burst is too large.
> - **3M spreads vs 3M flies**: May be similar. 3M flies may
>   resemble 3M D-flies. Numbers needed to verify — don't trust
>   feel alone.
>
> **Key insight**: Even for a particular market state (e.g.,
> volatile market), rule parameters differ for 3M spreads vs
> 12M spreads, even though both are spreads.
>
> ### Profiling Parameters
>
> All parameters should be converted to relative scale (e.g., 1–10)
> rather than absolute numbers:
> - Average volume traded per day
> - Bid-offer volume (depth)
> - Volatility
> - Reaction to current market events
> - Flipping frequency (does the contract flip often?)
> - Matching algo relevance (does PIQ matter, or use big lots
>   for pro-rata advantage?)
>
> ### Phased Approach
>
> **Phase 1 (within 2 weeks)**: Profile currently traded contracts.
> Basic parameters. Decide ASE and .NET parameters per group.
> Find flaws in current parameter logic (backend and frontend).
> Introduce quant models where needed.
>
> **Phase 2 (after 2 months)**: Profile full US market complex.
> Profile other fixed income markets.
>
> **Phase 3 (ongoing)**: Use profiles for market expansion.
> Find new markets that resemble profitable existing markets
> (e.g., find markets similar to SR1-FF based on bid-offer,
> volatility, etc.).
>
> ### Markets to Avoid
>
> - **Flipping markets**: Unreliable VWAP. People pull lots,
>   don't want to take fills.
> - **Dull markets**: Low participation, orders pulled.
> - **Volatile with thin books**: Bigger clips vs resting
>   liquidity causes adverse selection.
>
> ### Profile-Based Lot Allocation
>
> For different profiles, lots are allocated to strategies based
> on the assumptions under which those strategies were designed.
> E.g., for high volatility + low volume: Technical analysis
> strategies get more lot allocation.

**Rationale**: Market profiling is a distinct analytical framework
that bridges strategy design and parameter selection. It doesn't
fit in any existing file and warrants its own document in strategy/.

---

### Fill Analysis — Accuracy Improvement Methodology
**Target**: execution-analysis/methodology-and-framework.md → New section "Accuracy Improvement Framework"
**Type**: New
**Proposed text**:
> ## Accuracy Improvement Framework
>
> **Primary objective**: Increase accuracy first. Once accuracy
> is achieved, increase fills by increasing lot count.
>
> ### Segregation Study
>
> Study overall fills. Segregate into batches:
> - Accuracy < 60%: Identify causes. Convert causes to parameters.
>   Find parameter values where max accuracy is achieved.
> - Accuracy > 70%: Identify what's working. Protect these conditions.
>
> ### Payup/Backoff Pattern Analysis
>
> **Payups**: Take fills with payup, record market conditions
> at that time. Simulate the situation using various parameters
> to find better outcomes. Key question: If WCT Payup had been
> used, would accuracy improve? Check time gap and ticks moved
> before giving price.
>
> **Backoffs**: Identify patterns that caused backoffs. Compare
> with fills that succeeded in similar conditions.
>
> **Right vs Wrong fills**: Compare side-by-side to isolate
> the differentiating parameters.
>
> ### Parameters for Accuracy Study
>
> Record and analyze these at time of fill (before, during, after):
> - Bid-Offer spread
> - WCT Payup (would it have helped?)
> - Volume traded to that point vs previous days at same time
> - Direction of market vs direction of entry
> - Momentum
> - ATR (Average True Range)
> - Premium hitting (caveat: can't simulate matching algo —
>   even when hitting, fills not guaranteed)
> - VWAP difference across contracts: which contract eventually
>   converges? Which side is "right"?
>
> ### VWAP Convergence Analysis
>
> - Find which side VWAP converges to: outright side or spread
>   side? More liquid side? Side where buyer/seller was present?
> - Does it depend on market participants (e.g., ICE in outrights)
>   rather than having a single answer?
> - Find why VWAP differences exist.
> - Record number of lots and time taken to converge.

**Rationale**: The methodology file already has the 8-step analysis
framework and TD formula. This adds the accuracy improvement
workflow and specific parameters to study, making it actionable.

---

### VWAP Flip Bias — Verification Framework
**Target**: execution-analysis/methodology-and-framework.md → New section "VWAP Flip Bias Study" (or strategy/execution-modifiers.md)
**Type**: New (deferred 3 months, but document the framework now)
**Proposed text**:
> ## VWAP Flip Bias — Verification Study (Deferred)
>
> **Bias**: Price will flip in the direction of VWAP.
>
> ### Verification Challenges
>
> **Matching algo problem**: Can't simulate the matching algo,
> so can't directly test fill probability when price flips.
>
> ### Proposed Verification Approaches
>
> 1. **Complete flip assumption**: If complete price traded,
>    assume filled. Limited utility — price rarely completely
>    flips in normal trading and fills still occur without it.
> 2. **Lot threshold**: Decide a lot count beyond which assume
>    filled. Problem: each price level is different, and the
>    whole market acts as a single entity.
> 3. **VWAP threshold**: Find the VWAP level beyond which 90%
>    certainty of price flip. Highly dependent on market profile.
> 4. **Volume fraction**: E.g., 3% of daily traded volume.
>    Problem: each price is different.
>
> **Additional factor**: Time for which paper (arbitrage
> opportunity) exists — longer existence = higher fill probability.
>
> **Note**: May be more useful if majority of flips are complete
> flips, but this is unlikely and highly dependent on market
> profile. If hedge leg is completely flipped, high chance that
> first leg would have given a scalp opportunity.

**Rationale**: Documents the bias and verification framework
even though execution is deferred. When the study begins in
3 months, the thinking is already captured.

---

### Technical Analysis Integration Notes
**Target**: strategy/ → New file "technical-analysis-integration.md" (or resources/ as raw notes)
**Type**: New
**Proposed text**:
> ## Technical Analysis Integration
>
> ### Objectives
>
> 1. **ASE complement**: TA provides directional bias for entry
>    side and which side to avoid. Not standalone signals.
> 2. **Market profiling input**: TA patterns inform market state.
> 3. **Curve smoothing**: If a working TA strategy is found,
>    ASEs can churn around it to smooth the equity curve.
>
> ### Backtesting Methodology for ASE Complement
>
> Standard TA backtesting doesn't apply when TA is used as ASE
> complement. Example: 1-hour buy signal where market goes up
> for 55 minutes then crashes in last 5. Standard backtest =
> negative. But as ASE complement, 55 minutes of correct-side
> entry bias with immediate hedging = positive.
>
> **Key metric**: How long is the directional bias correct?
> Not: Is the signal profitable end-to-end?
>
> **Caveat**: Bias could flip every minute without giving
> right-side fills. Must test for fill realism.
>
> ### Optimization Approach
>
> Use ML/program to optimize parameters on historical periods
> where a specific market condition was known to exist (e.g.,
> run momentum strategy on known momentum period). Optimize for:
> - Zero returns (breakeven boundary)
> - Maximum profit
> - Maximum loss
>
> Examining these boundary parameters reveals best and worst
> cases for the parameter set.
>
> ### External Input — MM Team Notes
>
> **Gurpreet sir (Market Making)**:
> - Good TA products: SONIA, treasuries
> - FI is mean-reverting by nature
> - Watch: bonds, currencies, equities, levels
> - VAP (Volume At Price): Store prev day high-volume prices
>   as support. If price moves fast from it → churn.
>   If price stays → breakout likely.
> - Price velocity: Volume traded vs price moved → breakout
>   detection.
> - Short-term TA that works: 200 MA on 5min (US Ultra 10
>   worked Sep 24), Parabolic SAR, Stochastic, Levels,
>   Ichimoku Cloud, GANN, RSI, Pivots.
>
> **Ravi sir (Market Making)**:
> - Bollinger Bands + Pivots
> - 3 time frames approach (YT: 22 rules for Bollinger Bands)
> - Slope of bands matters
> - Use S/R bands, not exact prices

**Rationale**: TA integration is a planned future workstream.
These notes capture the framework and external inputs so they're
available when the work begins. Could live in strategy/ as a
proper file or in resources/ as raw notes — user to decide.

---

### Trader Psychology — Trading Biases Reference
**Target**: strategy/ → New file "trader-psychology.md" (or resources/)
**Type**: New
**Proposed text**:
> ## Trader Psychology — Bias Awareness
>
> ### Identified Biases
>
> **Anchoring Bias**: Seeing a price 3 days ago and using it as
> today's anchor. Historical data is the true anchor — trust
> data over memory.
>
> **Ostrich Bias**: Knowing a factor is missing but choosing to
> ignore it. Sometimes intentional to solve a narrower problem
> first. Rule: Always document your assumptions (what you're
> ignoring) alongside the specific case you're solving.
>
> **Outcome Bias**: Judging strategy quality by results alone.
> A strategy run during a profitable month looks good regardless
> of its actual edge. Must evaluate against methodology, not P&L.
>
> **False Dilemma**: Thinking there are only 2 options. Always
> check if there are more options before committing to a binary
> choice.
>
> ### Application
>
> Generate a periodic self-assessment questionnaire (inspired by
> "Trading in the Zone") to surface:
> - Current active biases
> - Weaknesses in decision-making
> - Strengths to leverage
> - Specific improvement actions
>
> Use questionnaire results to adjust trading behaviour and
> strategy parameters.

**Rationale**: Trading psychology directly impacts strategy
execution and parameter decisions. Documenting biases creates
accountability and a review mechanism.

---

### .NET Immediate Additions
**Target**: application/order-management.md → Section on safety/limits
**Type**: New
**Proposed text**:
> ### Unhedged Leg Limits
>
> **Max unhedged legs allowed**: Set a maximum for each direction.
> E.g., if 200 sell outrights are unhedged, do not initiate
> any ASE from the "sell outright" side until hedge is achieved.
>
> ### Consecutive Payup Control
>
> **Pause on consecutive payups**: If multiple consecutive payups
> occur, pause the ASE to prevent compounding adverse fills.

**Rationale**: These are immediate safety additions to the .NET
application. The order management file documents the order
lifecycle where these limits naturally belong.
