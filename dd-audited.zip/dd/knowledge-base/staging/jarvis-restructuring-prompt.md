# Jarvis Restructuring Prompt

**Purpose**: One-time prompt to retrofit the Jarvis knowledge base with KB-style
navigation infrastructure (MOC files, wikilinks, frontmatter, progressive disclosure).

**Usage**: Paste this prompt into a new Claude session with the Jarvis folder mounted.
Provide the Jarvis CLAUDE.md as the initial upload or ensure it's in the root.

---

## Master Prompt

```xml
<role>
You are a knowledge-base architect specializing in LLM-optimized vault
structures. You understand context window economics — every line loaded
is budget spent — and you design navigation systems that let an LLM find
the right context fast without loading everything.
</role>

<task>
Retrofit the Jarvis knowledge base with a navigation and cross-referencing
infrastructure modeled on the knowledge-base/ vault's architecture. Add
_index.md MOC files, YAML frontmatter, wikilink cross-references, and
line-count annotations to every folder and markdown file in the Jarvis
directory tree. Do not alter existing content — only add structural
scaffolding around it.
</task>

<context>
Jarvis is the analysis and output layer for a STIR futures trading system.
It contains work-package (WP) deliverables, models, research, and reference
libraries. A sibling vault called knowledge-base/ holds the authoritative
system design (strategy, ASE rules, instrument specs, application architecture).

Jarvis files already exist and contain real analysis. What's missing is the
connective tissue: there are no _index.md files in subfolders, no YAML
frontmatter, no wikilinks between related files, and no line-count budgets
to help Claude load selectively.

The knowledge-base/ vault already has this infrastructure and serves as the
reference architecture. Jarvis needs the same patterns so that Claude can:
1. Enter any Jarvis folder, read the _index.md, and know what's there
   without loading every file.
2. Follow wikilinks from any file to its dependencies — both within
   Jarvis and across to knowledge-base/ files.
3. Budget context window usage using line-count annotations.

Motivation: Without this structure, Claude either loads too much (wasting
context) or too little (missing critical dependencies). Both degrade
answer quality. This restructuring is a one-time investment that pays off
in every future session.
</context>

<instructions>
Follow these phases in order. Complete each phase fully before moving to
the next. Report what you did at each phase boundary.

## Phase 1 — Scan and Inventory

1. List every folder and file in the Jarvis directory tree.
2. For each markdown file, read it and record:
   - File path
   - Line count
   - A one-sentence summary of its content (what it covers, not what
     it is — "Per-alias fill accuracy across 3,225 production fills"
     not "A summary file")
   - Which other Jarvis files it references or logically depends on
   - Which knowledge-base/ files it depends on (use the KB dependency
     hints in the existing Jarvis CLAUDE.md as a starting point, but
     verify by reading the actual file content)
   - Its WP association (WP-01, WP-04, etc.) if identifiable
3. For non-markdown files (CSV, JSON, XLSX, Python scripts, C# code),
   record: path, approximate size, file type, and a one-line description
   of its role.
4. Present the full inventory as a table before proceeding. Wait for
   user confirmation to continue.

## Phase 2 — Create _index.md MOC Files

For each folder that contains 2+ files, create an `_index.md` following
this exact pattern:

```markdown
# [Folder Name] — Map of Content

[2-3 sentence description of what this folder contains and when to load it.
Include the total approximate line count for the folder.]

## Files

- [[filename-without-extension]] — [One-sentence description that tells
  you what's IN the file, not what the file IS. Be specific enough that
  Claude can decide whether to load it without reading it.]
- [[another-file]] — [Description]

## Non-Markdown Assets

- `filename.csv` — [Role description, row/column count if applicable]
- `script.py` — [What it does, key inputs/outputs]

## KB Dependencies

These knowledge-base/ files provide design context for this folder's
analysis outputs:

- [[knowledge-base/path/to/file]] — [Why this KB file matters here]

## Related Folders

- [[other-jarvis-folder/_index|Display Name]] — [Relationship]
- [[knowledge-base/relevant-folder/_index|KB: Display Name]] — [Relationship]
```

Rules for MOC files:
- File descriptions must be specific enough to enable selective loading.
  Bad: "Analysis results." Good: "Per-expiry accuracy breakdown with
  degradation rankings and statistical significance tests."
- Include line counts in parentheses after each markdown file description:
  `[[file]] — Description. (~120 lines)`
- List non-markdown assets separately — they can't be wikilinked but
  Claude needs to know they exist.
- KB Dependencies section bridges the two vaults. Use full relative
  paths from the Jarvis root: `[[knowledge-base/strategy/timer-logic]]`.

## Phase 3 — Add YAML Frontmatter to Each Markdown File

Add frontmatter to the top of every existing markdown file that lacks it.
Use this schema:

```yaml
---
title: [Human-readable title]
wp: [WP-XX or "n/a" if not WP-associated]
status: [complete | in-progress | planned | reference]
created: [YYYY-MM-DD if known, otherwise "unknown"]
last-updated: [today's date]
lines: [line count excluding frontmatter]
kb-depends:
  - knowledge-base/path/to/file.md
  - knowledge-base/path/to/another.md
jarvis-depends:
  - jarvis/path/to/related-file.md
---
```

Rules for frontmatter:
- `kb-depends` lists every knowledge-base/ file this file references or
  whose concepts it builds on. Be precise — link to specific files, not
  folders.
- `jarvis-depends` lists sibling files within Jarvis that this file
  connects to (e.g., a verification report depends on the implementation
  it verified).
- `status` reflects the file's current state:
  - `complete` — finished deliverable
  - `in-progress` — active work, may be partial
  - `planned` — placeholder or scope document, not yet executed
  - `reference` — external reference material (e.g., library docs)
- Do NOT modify any existing content below the frontmatter insertion point.

## Phase 4 — Add Wikilink Cross-References

For each markdown file, add a `## Related` section at the bottom (before
any existing footnotes or appendices) containing wikilinks to:

1. **Intra-Jarvis links**: Other Jarvis files that share data, build on
   this file's outputs, or provide prerequisite context.
2. **Cross-vault KB links**: knowledge-base/ files that define the
   concepts, formulas, or system components this file analyzes or extends.

Format:
```markdown
## Related

### Within Jarvis
- [[jarvis-file]] — [One phrase explaining the relationship]

### Knowledge Base
- [[knowledge-base/folder/file]] — [One phrase explaining the relationship]
```

Rules:
- Every link must be bidirectional: if A links to B, B must link back to A.
  After adding all links, do a consistency pass to verify this.
- Only link files with genuine dependencies. Do not link everything to
  everything. A file about SOFR bootstrapping does not need a link to
  ASE rule documentation unless it actually references ASE behavior.
- If you cannot determine a KB dependency with confidence, add a
  comment: `<!-- TODO: verify KB dependency -->` and flag it in your
  report.

## Phase 5 — Update Jarvis CLAUDE.md

Update the root Jarvis CLAUDE.md to reflect the new infrastructure:

1. Add line-count annotations to the Folder Index (matching KB style):
   `### fill-analysis/ (~XXX lines) — Load for execution quality discussion`
2. Update the Loading Protocol table if any new files or relationships
   were discovered during the scan.
3. Add a "Navigation Protocol" section that mirrors the KB's approach:
   - Always read `_index.md` before loading individual files in a folder
   - Use line counts to budget context window
   - Follow wikilinks for dependencies rather than loading entire folders
4. Ensure every folder in the directory tree has an entry in the Folder
   Index — no orphan folders.

## Phase 6 — Verification Pass

After all modifications:

1. Run a consistency check: every wikilink target must exist as an actual
   file. List any broken links.
2. Verify bidirectionality: for every `## Related` link A→B, confirm
   B→A exists. List any one-directional links.
3. Verify every folder with 2+ files has an `_index.md`.
4. Verify every markdown file has YAML frontmatter.
5. Count total lines added (structural overhead). Report it as a
   percentage of total vault size — this is the "navigation tax" and
   should be under 15%.
6. Present a summary table:
   | Metric | Count |
   |--------|-------|
   | Folders processed | |
   | _index.md files created | |
   | Files given frontmatter | |
   | Wikilinks added (intra-Jarvis) | |
   | Wikilinks added (cross-vault) | |
   | Broken links found | |
   | One-directional links found | |
   | Navigation overhead (lines / %) | |
</instructions>

<output_format>
At each phase boundary, report what was done in a brief summary table
before proceeding. The final output after Phase 6 is the verification
summary table above.

All file modifications should be made directly — this is not a proposal,
it is an execution task. However, present the Phase 1 inventory and wait
for user confirmation before making any file changes.
</output_format>

<constraints>
**Do:**
- Read every file before adding metadata about it. Never infer content
  from filenames alone.
- Preserve all existing file content exactly. Your additions go at the
  top (frontmatter), at the bottom (## Related), or as new files
  (_index.md). Nothing in between gets touched.
- Use consistent wikilink syntax: `[[filename]]` for same-folder,
  `[[folder/filename]]` for cross-folder, `[[knowledge-base/folder/filename]]`
  for cross-vault.
- Match the knowledge-base/ vault's voice in MOC files: concise,
  specific, no filler.

**Do not:**
- Do not create files that don't exist yet. If the Jarvis CLAUDE.md
  references a planned folder that has no files, skip it and note it
  in your report.
- Do not rewrite, rephrase, or reorganize existing file content. You
  are adding scaffolding, not editing substance.
- Do not guess KB dependencies. If a file doesn't clearly reference or
  build on a specific KB concept, don't force a link. Flag uncertainty
  with a TODO comment.
- Do not add wikilinks inside existing prose. Links go only in the
  `## Related` section and in `_index.md` files.

If you are unsure whether a file depends on a specific KB document,
say so explicitly with a TODO rather than creating a speculative link.
</constraints>

<examples>
<example type="ideal">
A well-structured _index.md for Jarvis fill-analysis/:

```markdown
# Fill Analysis — Map of Content

WP-01 output: production fill accuracy analysis across 3,225 fills
(Mar 1–13, 2026). Contains per-alias breakdowns, expiry group summaries,
degradation rankings, and P&L calculations. (~280 lines total)

## Files

- [[analysis-summary]] — Grand accuracy metrics (56.32% combined),
  buy/sell split, and methodology overview. (~90 lines)
- [[expiry-group-breakdown]] — Accuracy by expiry group (front-month
  through deferred) with statistical significance. (~85 lines)
- [[degradation-rankings]] — Aliases ranked by accuracy degradation
  from baseline, with root-cause annotations. (~105 lines)

## Non-Markdown Assets

- `alias_summary.csv` — Per-alias accuracy data (42 rows × 12 cols).
  Primary data source for all analysis files.
- `fill_pipeline.py` — ETL script: raw TT fills → cleaned CSV →
  accuracy calculations. Inputs: raw fill export. Outputs: alias_summary.csv.

## KB Dependencies

- [[knowledge-base/execution-analysis/methodology-and-framework]] —
  Defines the tick-deviation formula and fill quality metrics used here
- [[knowledge-base/core/instruments-and-platform]] — Contract specs
  (tick sizes, DV01) needed to interpret accuracy in dollar terms
- [[knowledge-base/strategy/core-quad-leg-arbitrage]] — Quad-leg
  structure that defines which aliases exist and how legs interact

## Related Folders

- [[market-profiling/_index|Market Profiling]] — Contract segmentation
  groups used to aggregate accuracy results
- [[timer-logic/_index|Timer Logic]] — Formula corrections that may
  explain accuracy patterns in certain expiries
- [[knowledge-base/execution-analysis/_index|KB: Execution Analysis]] —
  Authoritative methodology that this analysis implements
```
</example>

<example type="ideal">
YAML frontmatter for an existing analysis file:

```yaml
---
title: Fill Accuracy — Expiry Group Breakdown
wp: WP-01
status: complete
created: 2026-03-14
last-updated: 2026-03-30
lines: 85
kb-depends:
  - knowledge-base/execution-analysis/methodology-and-framework.md
  - knowledge-base/core/instruments-and-platform.md
jarvis-depends:
  - jarvis/fill-analysis/analysis-summary.md
  - jarvis/market-profiling/contract-segmentation.md
---
```
</example>

<example type="mistake">
Bad _index.md file description (too vague to enable selective loading):

```markdown
- [[analysis-summary]] — Summary of the analysis results.
```

This tells Claude nothing. It would have to load the file to know what's
in it, defeating the purpose of the MOC. Compare with the ideal example
above.
</example>

<example type="edge_case">
Folder with only non-markdown files (e.g., a Python implementation folder
with only .py and .cs files):

Still create an _index.md, but use "Non-Markdown Assets" as the primary
section. The MOC's job is unchanged — tell Claude what's here so it can
decide whether to load anything:

```markdown
# Timer Logic Implementation — Map of Content

WP-05 C# implementation of Timer Logic formulas. No markdown documentation
in this folder — see [[timer-logic/verification-report]] for the audit
that validated this code.

## Non-Markdown Assets

- `TimerLogic.cs` — Core C# class implementing evidence-conditioned
  rounding. 151/152 tests passing. (~340 lines)
- `TimerLogicTests.cs` — NUnit test suite covering all 20 verification
  cases from WP-04. (~520 lines)
- `test_results.json` — Latest test run output with pass/fail per case.

## KB Dependencies

- [[knowledge-base/strategy/timer-logic]] — Authoritative Timer Logic
  specification that this code implements
- [[knowledge-base/strategy/price-formulas-complete]] — Formula
  definitions referenced in the implementation

## Related Folders

- [[timer-logic/_index|Timer Logic (parent)]] — Verification report
  and audit findings
- [[knowledge-base/application/_index|KB: Application]] — .NET
  architecture this code integrates into
```
</example>
</examples>
```
