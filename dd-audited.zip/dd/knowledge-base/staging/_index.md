# Staging — Map of Content

Review queue for unmerged knowledge. Files here are not authoritative.
Claude writes proposed additions here; user approves before anything
moves to core or domain folders.

## Files

- [[proposed-additions]] — 9 proposed additions from 2026-03-29 brain dump:
  seasonality mechanics, Meeting Neutral formulas, PIQ range patterns,
  market profiling framework, fill analysis accuracy methodology,
  VWAP flip bias, TA integration notes, trader psychology, .NET additions

## Related Folders

- [[core/_index|Core]] — Target for approved fundamental additions
- [[strategy/_index|Strategy]] — Target for seasonality, market profiling, TA, psychology additions
- [[execution-analysis/_index|Execution Analysis]] — Target for PIQ, fill analysis, VWAP additions
- [[application/_index|Application]] — Target for .NET safety additions
- [[planning/_index|Planning]] — Plan that generated these proposals
