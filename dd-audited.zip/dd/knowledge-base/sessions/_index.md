# Sessions — Map of Content

Handoff files from prior Claude sessions. Read the most recent file at
session start when continuing prior work.

## Files

*No sessions yet.*

## Related Folders

- [[staging/_index|Staging]] — Pending changes from sessions
- [[planning/_index|Planning]] — Work plans with goals and task tracking
