---
tags: [terminology, definitions, reference]
domain: core
load-priority: core
last-updated: "2026-03-26"
---

# Glossary

Master glossary of custom terminology used across all knowledge base files. When definitions here conflict with textbook/internet definitions, these definitions take precedence.

## Terms

| Term | Definition | Conventional Equivalent (if any) |
|------|-----------|----------------------------------|
| **Contract** | A quarterly expiry label (e.g., "Mar26", "Jun26", "Sep26", "Dec26") representing a specific SR3 quarterly futures expiry around which the entire 4-leg arbitrage structure is built. NOT a single futures contract — it is the trader's name for a complete arbitrage cluster. | Expiry month bucket / Strategy group |
| **Leg 1** | The SR3\|SR1 inter-product spread for the first nearby SR1 month within a Contract's quarter. E.g., for "Mar26": SR3\|SR1 Mar Apr26. Traded as a TT Autospreader (ASE) synthetic instrument. | First inter-product spread leg |
| **Leg 2** | The SR3\|SR1 inter-product spread for the second nearby SR1 month within a Contract's quarter. E.g., for "Mar26": SR3\|SR1 Mar May26. | Second inter-product spread leg |
| **Leg 3** | The SR3\|ZQ inter-product spread for the first nearby ZQ month within a Contract's quarter. E.g., for "Mar26": SR3\|ZQ Mar Apr26. This leg is derived from Leg 1 minus VWAP(v1) and adjusted by bsValue/avoidanceValue. | First ZQ-derived spread leg |
| **Leg 4** | The SR3\|ZQ inter-product spread for the second nearby ZQ month within a Contract's quarter. E.g., for "Mar26": SR3\|ZQ Mar May26. Derived from Leg 2 minus VWAP(v2) and adjusted by bsValue/avoidanceValue. | Second ZQ-derived spread leg |
| **Set A / Set B** | Duplicate ASE instrument sets for the same Contract. Allows running two parallel autospreaders on the same strategy — enabling capacity scaling or independent parameter tuning. Controlled by `useA`/`useB` flags in the UI. | Parallel execution slots |
| **diff** | The "Final Difference" value: `diff = (v1 - v2) + v3`, where v1 = VWAP of Alias1 (SR1-ZQ inter-product spread), v2 = VWAP of Alias2 (SR1-ZQ inter-product spread for next month), v3 = VWAP of Alias3 (ZQ calendar spread). This is the core pricing signal that drives all 4 legs. | Composite VWAP-based spread differential |
| **buyBiased / sellBiased** | The trader's bid/ask level around which all leg prices are centered. These are NOT conventional bias offsets — they are the trader's target buy/sell prices for the overall structure. Leg prices are computed as `(buyBiased +/- diff) / 2`. | Strategy-level target price |
| **bsValue** | "Buy-Sell Value" — a directional skew parameter that widens the buy or sell side of Leg 3/4 prices. When positive, it adds to Leg3/4 buy prices; when negative, it adds to Leg3/4 sell prices. Effectively a directional bias control for ZQ legs. | Directional skew parameter |
| **avoidanceValue** | A symmetric spread-widening parameter applied to Leg 3/4 that pushes buy prices lower and sell prices higher — deliberately widening the spread to avoid adverse fills during volatile periods. Dynamically set to 0.11 during the 12:55-13:05 window (likely around Fed events). | Volatility avoidance spread cushion |
| **bsZQSpread** | An asymmetric adjustment applied to Leg 1/2 prices. When positive: adds to Leg1 buy and subtracts from Leg2 sell. When negative: adds to Leg1 sell and subtracts from Leg2 buy. Used to express a directional view on the SR1-ZQ basis relationship. | Inter-product basis skew |
| **avoidanceZQSpread** | A symmetric avoidance parameter specifically for Leg 1/2. Subtracts from buy prices and adds to sell prices, widening the spread symmetrically. Separate from `avoidanceValue` which only hits Legs 3/4. | SR1-leg volatility cushion |
| **dynamic** | A flag that enables the TimedParameterService to auto-adjust avoidanceValue during specific time windows (12:55-13:05). When off, timed adjustments are suppressed. | Auto-avoidance scheduling toggle |
| **Reload** | The order quantity management system. `totalBuyQty`/`totalSellQty` is the maximum quantity the trader wants to trade overall for a contract side. `reloadBuyQty`/`reloadSellQty` is the per-clip size. As fills occur, the system automatically reloads the next clip until totalQty is exhausted. | Iceberg / drip-feed order management |
| **VWAP (as used here)** | NOT a traditional volume-weighted average price. In this system, VWAP is computed as a micro-level bid-ask weighted midpoint: `price = (bid * askQty + ask * bidQty) / (bidQty + askQty)`. If spread > 0.5, falls back to simple midpoint `(bid + ask) / 2`. This is computed on each market data tick for each inter-product spread alias. | Quantity-weighted microprice |
| **ASE** | Autospreader Engine — TT's execution engine for synthetic spread instruments. The trader's system sends calculated prices to ASE-managed instruments which handle the multi-leg execution, hedging, and payup/backoff logic autonomously. | TT Autospreader |
| **Spike** | A configurable market protection: watches a single instrument (e.g., "ZN Mar26") and if price moves more than N ticks within M seconds, ALL orders across ALL contracts are paused. Latched: once triggered, remains triggered until the next isEnabled signal resets it. | Circuit breaker / spike detector |
| **Traffic Controller** | Rate limiter on TT API message volume. Monitors messages per instrument-leg in 1-sec (185 limit), 1-min (1960 limit), 5-min (4960 limit) windows. Triggers automatic pause with auto-resume after cooldown. Prevents exchange throttling/bans. | API rate limiter |
| **Case** | Config file prefix for SR1 vs ZQ single-month inter-product spread autospreaders. Formula uses `100 * Leg1 - 100 * Leg2` with PriceMultiplier=100 (converting rate format). E.g., "Case Apr" = SR1 Apr vs ZQ Apr spread. | SR1-ZQ monthly inter-product spread |
| **Rol / Roll** | Config file prefix for bond futures calendar roll spreads. "Rol ZN" = ZN front month vs next month. "Roll FGBL" = Eurex Bund roll. These are simple 2-leg calendar spreads (1:-1 ratio). | Futures roll / calendar spread |
| **Roll's** | Config file prefix with apostrophe-s — appears to be an alternate version of Roll configs, possibly with different rule parameters or for a different execution pathway. | Alternative roll config variant |
| **IER** | Inter-product Euribor Spread. "IER Jun-Sep" = Euribor spread across expiries. | Euribor inter-product spread |
| **Int SR3 CRA** | Inter-product spread between SR3 butterfly and CRA (Credit Risk Adjusted) butterfly. "Int SR3 CRA Jun26 3mo" = SR3:BF M6-U6-Z6 vs CRA+M6-2U6+Z6. Uses mixed PriceMultipliers (100 and 1). | SR3-CRA butterfly basis |
| **ZQ Str** | ZQ Strategy — various structured Fed Fund Futures spread configurations. Includes flies, calendars, and conditional trades. | ZQ spread structures |
| **X_Y** | A secondary/experimental strategy layer. Separate from the main 4-leg system. Uses ContractLegs_X_Y.csv mapping and X_Y_Parameter.csv for independent SR1 spread calculations. Currently commented out in Program.cs. | Experimental secondary strategy |
| **O / X / Y** | Leg suffixes in ContractLegs.csv beyond the standard 4 legs. O = Outright, X and Y = additional spread legs. E.g., "SR3\|SR1 Mar26 O", "SR3\|SR1 Mar26 X", "SR3\|SR1 Mar26 Y". Infrastructure for expansion to 10 legs exists but is commented out. | Extended leg designators |
| **PauseWindow** | A time-based automatic pause/resume window. Used to automatically stop trading during known market events (PPI releases, Chicago PMI, market close). | Scheduled trading halt |
| **HitMan** | An ASE custom rule that controls aggressive order execution. Monitors volume ratios and liquidity to decide when to "hit" the market. Has L1/L2 variants for each leg. Key variables: VolRatioLegI/II, LiqCheckLegI/II, StopVolLegI/II. | Aggressive execution / market-taking rule |
| **ASM (GJN ASM)** | Autospreader Market rule — a custom rule controlling passive quoting behavior. Monitors volume ratios and liquidity gaps to adjust quote placement. Has L1/L2 variants. Key variables: VolRatioLegI/II, LiqChkVolLegI/II, LiqAtGapLegI/II, MultLI/MultLII. | Passive quoting / market-making rule |
| **Backoff / Backoff_No_Cross** | An ASE rule that pulls quotes away from the market when adverse conditions are detected (thin book, high fill probability). Backoff_No_Cross variant prevents the price from crossing the opposite side. Variables: QtyRatio, MinAvailableLiq, BackoffVol. | Quote retreat rule |
| **GJN_Payup** | An ASE rule that allows paying through (crossing the spread) when conditions warrant aggressive execution. Variables: QtyRatio, StopVol, NumberOfPayups, AntiStopVol. | Spread-crossing aggression rule |
| **WCT Liquidity Payup** | A more sophisticated payup rule that factors in available liquidity at various price levels (Working Conditional Ticks). | Liquidity-aware payup rule |
| **Quote Throttle (GJN)** | Rate-limits quote modifications. InsideThrottle = minimum ms between requotes when price is inside the market; OutsideThrottle = when outside. | Quote modification rate limiter |
| **Prevent Quote Cross** | Rule preventing the trader's own bid from crossing their own offer. Variables: Qty (threshold), Implied (consideration of implied order depth). | Self-cross prevention |
| **Accuracy** | Fill quality metric: 100% = filled at entry price exactly. >100% = "Backoff" (filled better than entry). <100% = "Payup" (filled worse). Formula: `accuracy = 100 +/- (|tickDifference| / 5 * 100)`. Tracked per ASE instrument in real-time. | Fill quality score |
| **Payup / Backoff / Zero (fill types)** | Fill classification: Zero = filled at limit price. Payup = filled at a worse price (adverse). Backoff = filled at a better price (favorable). For buys: positive tick diff = Backoff, negative = Payup. For sells: reversed. | Fill slippage classification |
| **phaseStart** | A safety mechanism: when enabled, the system first submits a 1-lot "canary" order per leg and waits 30 seconds. If the canary is NOT filled (meaning the price level is safe), all 8 canaries (4 legs x buy/sell) must succeed before full-size orders are submitted. If any canary gets filled, the contract is paused — indicating the price level was too aggressive. | Canary / test-order market safety probe |
| **Timer Logic** | Evidence-conditioned rounding system that replaces hard defensive rounding (RD/RU) with expansion-based rounding. Expansion value encodes confidence that a fill at the nearer tick is achievable. Applied post-avoidance/bias, pre-ASE submission. NOT related to TimedParameterService or PauseWindows. | Adaptive rounding / smart discretisation |
| **Expansion (Timer Logic)** | A value ∈ [0, 0.5) controlling when Timer Logic rounds toward market vs. defensively. Higher expansion = more aggressive rounding = more fills at higher edge cost. Can be static (fixed value) or dynamic (evidence-conditioned per pricing cycle). | Rounding threshold |
| **Fillable Price** | The discrete tick level most likely to produce a fill given current market evidence. Derived from microprice, Volume VWAP, LTP history, and book state. Timer Logic's expansion value encodes confidence in the fillable price. | Executable price level |
| **Volume VWAP** | Trade-weighted average price: Σ(trade_price × volume) / Σ(volume) over a rolling window. Distinct from microprice (book-weighted). Confirms whether actual trades back the current book state. | Traditional VWAP |
| **PIQ** | Position In Queue — estimated lots ahead of the trader's order at a given price level. Inferred from total resting quantity and order submission time. Lower PIQ = higher fill probability. | Queue position |
| **Implied O** | The O spread price reverse-calculated from an actual
fill price and market data at fill time. Deviation from trader's target O
measures total system accuracy. | Reverse-engineered fair value |
| **dotnet_deviation** | Implied O at fill start minus target O. Captures
.NET pricing accuracy including Timer Logic rounding and diff timing. |
.NET pricing error |
| **ase_deviation** | Implied O at fill complete minus implied O at fill
start. Captures ASE rule impact: Backoff savings, Payup costs, hedge-window
market movement. | ASE execution error |

## Related

- [[instruments-and-platform]] — Contract specs for products defined here
- [[core-quad-leg-arbitrage]] — Strategy that uses these terms
- [[price-formulas-complete]] — Formulas using microprice, diff, avoidance, bias
- [[ase-mechanics-and-parameters]] — ASE engine concepts referenced in glossary
- [[Plan-2026-03-28]] — Comprehensive work plan referencing this file
- [[timer-logic]] — Timer Logic, expansion, fillable price terms defined here