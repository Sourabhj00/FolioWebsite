---
tags: [instruments, contracts, sr3, sr1, zq, exchanges, platform]
domain: core
load-priority: core
last-updated: "2026-03-26"
---

# Instruments and Platform

Instruments traded, exchanges used, contract specifications, and platform context. Load as baseline for any session.

## CME Contract Specifications

| Product | Contract Type | Notional Value | DV01 ($/bp/lot) |
|---------|---------------|-----------------|-----------------|
| SR3 | 3-Month SOFR Quarterly | $1,000,000 | $25.00 |
| SR1 | 1-Month SOFR Monthly | $4,166,667 | $41.67 |
| ZQ | 30-day Fed Funds Monthly | $4,167,000 | $41.67 |

## Exchanges & Venues

- **CME Globex**: SR3, SR1, ZQ, ZN, ZT, ZF, ZB, UB, and US Treasury bond futures
- **ICE**: SONIA (SONIA 3M index), SO3, SA3
- **Eurex**: Euribor (ER3), German bonds (FGBL/FGBM/FGBS/FGBX), Italian bonds (FBTP/FBTS), French bonds (FOAT)
- **Montreal Exchange**: Canadian bonds (CGB/CGF/CGZ)

## TT Autospreader Engine (ASE)

**Definition**: TT Autospreader Engine is a server-side execution engine that creates synthetic spread markets from outright exchange-traded leg instruments. ASE is **co-located with the CME matching engine** for low-latency quoting and hedging operations.

**Core Parameters**:
- Spread tick size: `0.5` for core ASE instruments
- Price multiplier: `PriceMultiplier = 100` for converting between rate format and spread quote format
- Execution pathway: TT .NET SDK submits GTC limit orders to ASE-managed synthetic instruments
- Auto-hedging: ASE decomposes parent spread orders into outright leg orders and manages their lifecycle autonomously

**Configuration Scale**: 529+ ASE configuration files spanning US, European, UK, and Canadian rate futures

## Product Codes & Aliases

### SOFR Complex (CME)
- `SR3`: 3-Month SOFR quarterly contracts (Mar, Jun, Sep, Dec expiries)
- `SR1`: 1-Month SOFR monthly contracts (all calendar months)
- `ZQ`: 30-day Federal Funds monthly contracts

### US Treasuries (CME)
- `ZN`: 10-Year Note
- `ZT`: 2-Year Note
- `ZF`: 5-Year Note
- `ZB`: Long Bond (20Y+)
- `UB`: Ultra Bond (20Y+, price-weighted)
- `R` / `TN`: Regional/TNote variants

### European & UK Rates
- `ER3`: Euribor 3-Month (Eurex)
- `FGBL`: German 10-Year Bund (Eurex)
- `FGBM`: German 5-Year Bobl (Eurex)
- `FGBS`: German 2-Year Schatz (Eurex)
- `FGBX`: German Bund (long-dated, Eurex)
- `FBTP`: Italian BTP 10-Year (Eurex)
- `FBTS`: Italian BTP short-dated (Eurex)
- `FOAT`: French OAT 10-Year (Eurex)

### Canadian Rates (Montreal Exchange)
- `CGB`: Canadian Government Bond 10-Year
- `CGF`: Canadian Government Bond 5-Year
- `CGZ`: Canadian Government Bond 2-Year

### SONIA (ICE)
- `I` / `SO3` / `SA3`: SONIA outright and spread instruments

## ASE Configuration File Prefixes

Configuration file naming encodes the spread structure and asset class:

### SOFR-Specific
- `Case`: SR1 vs ZQ single-month inter-product spreads (e.g., "Case Mar", "Case Apr")
- `ZQ Str`: ZQ structured spreads (butterflies, calendars, multi-month combinations)
- `Int SR3 CRA`: SR3 butterfly vs CRA (Credit Risk Adjusted) butterfly basis trades

### Bond Calendars
- `Rol` / `Roll` / `Roll's`: Bond futures calendar roll spreads (front month vs next month, 1:-1 ratio)
  - Example: "Rol ZN" (ZN front vs back), "Roll FGBL" (Eurex Bund roll)
  - Roll's variant: alternate version with different rule parameters

### SONIA-Based
- `ISO`: SONIA calendar vs SO3 calendar inter-product spreads
- `ISA3`: SONIA outright vs SA3 (3M SONIA) inter-product spreads

### Euribor-Based
- `IER`: Euribor inter-product spreads across different expiries

### Curve & Multi-Leg
- `aa`: Treasury curve trades (butterflies and multi-leg structures; e.g., "aa 2-5-10" = ZT:ZF:ZN in 3:-5:1 ratio)
- `US`: US Treasury curve spreads (e.g., "US 2-10" = 2yr vs 10yr)
- `ER Str` / `AAA`: Euribor butterfly structures and cross-expiry spreads

### Cross-Asset
- `Int SRI` / `Tee`: SONIA-SR3 cross-exchange basis (ICE SONIA vs CME SR3 butterflies)

## Related

- [[glossary]] — Master terminology for all instruments and platform concepts
- [[Plan-2026-03-28]] — Comprehensive work plan referencing this file

## Order & Execution Architecture

**Order Type**: GoodTillCancel (GTC) limit orders via TT .NET SDK

**Target Instruments**: All orders target TT Synthetic instruments on `MarketId.ASE`

**Execution Logic**:
- Parent spread order submitted to ASE
- ASE decomposes into outright leg orders (typically 3-5 ratio for SOFR strategies)
- Hedge fills trigger automatically; fills tracked via parent-child order relationships
- Payup/Backoff classification applied per ASE custom rule set

**Reload Management**: Iceberg-style drip-feed via `totalBuyQty`/`totalSellQty` (target size per side) and `reloadBuyQty`/`reloadSellQty` (clip size). System auto-reloads next clip as fills occur until total quantity exhausted.

## Rate Format Conversion

Core price calculation uses `PriceMultiplier = 100` to convert between rate-quoted instruments and spread quotes:
- Example: `Case Apr = 100 * SR1_Apr - 100 * ZQ_Apr` (inter-product spread in basis points)
- SONIA spreads and Euribor spreads also use 100x multiplier for consistency
- CRA spreads use mixed multipliers (100 for SR3, 1 for CRA) in some configurations

## Key Operational Parameters

- **Spread Tick Size**: 0.5 (standard for all core ASE instruments)
- **Quote Throttle Inside**: 56 ms (minimum time between requotes when price inside market)
- **Quote Throttle Outside**: 2 ms (minimum time between requotes when price outside market)
- **Traffic Rate Limits**:
  - 1-second window: 185 messages per instrument-leg
  - 1-minute window: 1960 messages per instrument-leg
  - 5-minute window: 4960 messages per instrument-leg
- **Spike Detection**: Monitors ZN (10-Year Note); default threshold 5 ticks in 2 seconds triggers full pause
- **Dynamic Avoidance Window**: 12:55–13:05 (around Fed/FOMC events); `avoidanceValue` set to 0.11 during this window

## Related

- [[glossary]] — Terminology for instruments described here
- [[core-quad-leg-arbitrage]] — Strategy built on SR3/SR1/ZQ
- [[methodology-and-framework]] — DPP derivation uses DV01 values from here
- [[ancillary-strategies]] — Non-core strategies on same instruments
- [[architecture-and-dataflow]] — Application that connects to these exchanges

### Jarvis Downstream
- [[jarvis/fill-analysis/README]] — WP-01 pipeline using tick sizes for accuracy calculation
- [[jarvis/fair-value/sofr-bootstrap-methodology]] — Contract specs for SOFR curve construction
- [[jarvis/market-profiling/contract-segmentation]] — Defines instruments being segmented into groups
- [[jarvis/market-profiling/event-calendar-2026-2027]] — Contract expiry dates and roll mechanics
- [[jarvis/strategy-research/directional-bias-model]] — SR3/ZN/ZT instrument specifications for lead-lag model
