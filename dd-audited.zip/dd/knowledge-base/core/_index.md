# Core — Map of Content

Baseline definitions and instrument specifications. Load for every session.
These files define the shared vocabulary and product specs that all other
folders depend on. If any file elsewhere contradicts core/, flag it and
follow core/.

## Files

- [[glossary]] — Master terminology: Contract, Legs 1–4, diff, buyBiased/sellBiased, bsValue, avoidanceValue, VWAP (microprice), ASE, Spike, Reload, and all naming conventions. Definitions here override textbook meanings.
- [[instruments-and-platform]] — SR3/SR1/ZQ contract specs (notional, DV01), exchange venues, ASE co-location, configuration scale (529+ ASEs), and SDK integration pathway.

## Related Folders

- [[strategy/_index|Strategy]] — Strategies built on these instruments
- [[ase-rules/_index|ASE Rules]] — Rules that operate within the ASE engine
- [[application/_index|Application]] — .NET app that implements these specs
- [[planning/_index|Planning]] — Work plan referencing core terms and instrument specs

### Jarvis Analysis
- [[jarvis/fill-analysis/_index|Jarvis: Fill Analysis]] — WP-01: production accuracy using contract specs
- [[jarvis/fair-value/_index|Jarvis: Fair Value]] — WP-02: curve construction from instrument specs
- [[jarvis/market-profiling/_index|Jarvis: Market Profiling]] — WP-03/12: segmentation and event calendar for these instruments
- [[jarvis/strategy-research/_index|Jarvis: Strategy Research]] — SR3/ZN/ZT lead-lag model
