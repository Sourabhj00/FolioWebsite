# CLAUDE.md — Navigation Manifest

This is the root navigation file for the STIR Futures Trading Knowledge Base.
Read this first. Then selectively load folders based on the task.

---

## Context Window Discipline

- **Always load `core/` first.** It contains the glossary and instrument specs
  that anchor all other context. ~170 lines total.
- **Prefer `_index.md`** in each folder before loading individual files.
  The MOC tells you what's in the folder so you can load only the files
  you actually need.

---

## Folder Index

### core/ (~170 lines) — Always Load
Baseline definitions and instrument specs. Required context for every task.
Contains: glossary (master terminology that overrides textbook meanings),
instrument contract specs (SR3/SR1/ZQ), platform capabilities.

### strategy/ (~930 lines) — Load for strategy tasks
Core quad-leg arbitrage thesis, pricing formulas, execution modifiers
(avoidance/bias), residual position management, and ancillary (non-core)
spread strategies.

**Load when**: strategy design, pricing questions, parameter tuning,
understanding the quad-leg structure, working with avoidance or bias values.

### ase-rules/ (~1,453 lines) — Load for rule work
ASE engine mechanics, the full 56-rule custom library, the 8 production
rules with exact conditions, all 20 TT default rules, and known bugs/
anomalies across rule generations.

**Load when**: selecting or comparing rules, tuning production rules,
debugging unexpected rule behavior, planning rule modifications.

**Note**: This is the largest folder. Load `ase-mechanics-and-parameters.md`
first as the foundation, then only the specific rule file you need.

### execution-analysis/ (~278 lines) — Load for analysis tasks
Tick Deviation formulas, fill quality metrics, P&L calculation framework,
and structural patterns observed across sessions.

**Load when**: running post-session analysis, building analysis tooling,
diagnosing fill quality issues, calculating P&L.

### application/ (~1,052 lines) — Load for code work
.NET application architecture (two-component system), order management
(reload/clip system), and five safety mechanism layers.

**Load when**: modifying or extending the .NET application, understanding
the parameter pipeline, working with order state management.

**Note**: `order-management.md` is 450 lines — the largest single file.
Load selectively if context is tight.

### staging/ — Load when reviewing pending additions
Unmerged knowledge extractions awaiting approval. Not authoritative.
Check here before proposing additions to avoid duplicating pending work.

### sessions/ — Load when continuing prior work
Handoff files from previous sessions. Read the most recent handoff at
session start if picking up where a prior session left off.

### planning/ — Load when reviewing or updating the work plan
Structured work plans with goals, tasks, dependencies, and KB
cross-references. Contains both human-readable markdown and
machine-readable JSON for visual planning tools.

**Load when**: checking current priorities, understanding task
dependencies, starting a new work session and need to know what's
in flight, building or updating visual planning boards.

### resources/ — Load only when analyzing source material
Raw source documents. Not authoritative. Load only when a task
specifically requires examining original source material.

---

## Loading Examples

| Task | Load |
|------|------|
| "Explain the quad-leg arb structure" | core/ + strategy/core-quad-leg-arbitrage.md |
| "Why is Sep26 accuracy so bad?" | core/ + execution-analysis/ + strategy/execution-modifiers.md |
| "Tune the HitMan production rules" | core/ + ase-rules/ase-mechanics-and-parameters.md + ase-rules/custom-rules-production.md |
| "Add implied avoidance to Gen 4 rules" | core/ + ase-rules/custom-rules-production.md + ase-rules/rule-anomalies-and-evolution.md |
| "Modify the reload system in the app" | core/ + application/order-management.md + strategy/core-quad-leg-arbitrage.md |
| "Review pending staging items" | core/ + staging/ |
| "Analyze today's fill data" | core/ + execution-analysis/methodology-and-framework.md |
| "Analyze this website/doc and add to KB" | core/ + relevant domain `_index.md` files → source material → write to staging/ |
| "What should I work on next?" | core/ + planning/Plan-2026-03-28.md |
| "Help me with Hitman rule tuning" | core/ + planning/ (check dependencies) + ase-rules/custom-rules-production.md |
| "How does Timer Logic work?" | core/ + strategy/timer-logic.md + strategy/price-formulas-complete.md |
| "Tune Timer Logic expansion" | core/ + strategy/timer-logic.md + strategy/execution-modifiers.md + ase-rules/custom-rules-production.md |
| "Measure fill accuracy" | core/ + execution-analysis/accuracy-measurement.md + strategy/price-formulas-complete.md |

---

## Knowledge Ingestion Protocol

When the user provides source material (websites, documents, attachments,
personal notes) for analysis and integration into the vault:

### Step 1: Establish context
Load `core/` (always). Then read `_index.md` of the 1–2 domain folders
most likely to overlap with the source material. This tells you what the
vault already knows before you analyze anything new.

### Step 2: Analyze the source
Read/fetch the provided material. Compare it against the existing
knowledge base. Identify what is:
- **Genuinely new** — not covered anywhere in the vault
- **Reinforcing** — confirms or adds detail to existing content
- **Contradicting** — conflicts with something already documented

### Step 3: Propose placement
For each extracted item, determine the target. **Prefer merging
into existing files** — create new files or folders when the content has no home in the current structure.

- **Existing file addition (default)** — specify the file, the section,
  and the exact proposed text. Add to the most relevant existing section,
  or propose a new section heading within the file if needed. Only
  propose what adds value beyond what's already there.
- **New file** — if the content represents a distinct topic that
  doesn't fit any existing file. Propose a name, target folder, and
  rationale. Follow the vault's naming convention (lowercase, hyphenated).
  Include the full YAML frontmatter and a `## Related` wikilink section.
- **New folder** — if the content represents an entirely new domain
  that doesn't belong in any existing folder. Must include an
  `_index.md` MOC file and an entry in CLAUDE.md's Folder Index.

### Step 4: Write to staging
Write all proposals to `staging/` using this format
per item:

```
### [Short description]
**Target**: [folder/filename.md] → [section name] (or "New file")
**Type**: New | Reinforcing | Contradicting
**Proposed text**:
> [exact text to add]
**Rationale**: [why this belongs here, what it adds]
```

If contradictions are found, surface both versions and do not resolve
without user approval.

### Step 5: Wait for approval
Do not apply any changes until the user has reviewed the staging file.

### Step 6: Apply and update navigation (on approval)
On approval, apply all approved changes and then perform these
maintenance steps — do not skip any:
1. **Update target files**: Apply the proposed text to the target file
   and section. Update `last-updated` in the file's YAML frontmatter.
2. **Update wikilinks**: Add any new `[[wikilinks]]` to the target
   file's `## Related` section for files it now references or is
   referenced by.
3. **Update MOC files**: If a new file was created, add it to the
   parent folder's `_index.md` with a one-line description and a
   `[[wikilink]]`. If a new folder was created, create its `_index.md`
   and add the folder to CLAUDE.md's Folder Index.
4. **Clean staging**: Remove the applied items from
   `staging/`. Leave unapproved or deferred items.

---

## Critical Rules

- **Never write to core/ or any domain folder directly.** Proposed changes
  go to `staging/`.
- **Never fabricate trading knowledge.** If not in the vault, say so.
- **Never silently resolve contradictions.** Surface both versions, ask to resolve.
- **Handoff protocol**: At end of substantial sessions, write to
  `sessions/YYYY-MM-DD-[topic-slug].md`.
