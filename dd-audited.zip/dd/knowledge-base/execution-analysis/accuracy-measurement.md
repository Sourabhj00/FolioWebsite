---
tags: [accuracy, measurement, reverse-formula, implied-o, fill-quality, analysis]
domain: execution-analysis
load-priority: on-demand
last-updated: "2026-03-29"
status: staging-pending-verification
---

# Accuracy Measurement — Reverse-Implied O System

Measures how far each fill's effective O price deviates from the trader's
target, decomposed into .NET pricing accuracy and ASE execution impact.
Load when building or analysing the accuracy measurement pipeline.

---

## 1. Concept

The forward pipeline transforms trader inputs into discretised leg prices:

```
O_target → diff split → avoidance/bias → Timer Logic → ASE rules → fill
```

The accuracy system runs this **in reverse**: given a fill price and the
market data at the moment of fill, reconstruct the implied O price. The
deviation between implied O and target O is the accuracy metric.

Two snapshots per ASE fill event yield two decomposed measurements:

| Snapshot | Captures | Deviation Meaning |
|----------|----------|-------------------|
| **Fill Start** (quote leg fills) | Market state + CalcPrice as executed | .NET pricing accuracy: "what O was the system effectively targeting when it got filled?" |
| **Fill Complete** (hedge leg fills) | Market state + realized spread price | Total system accuracy: "what O did the complete spread actually achieve?" |

**ASE execution impact** = Fill Complete implied O − Fill Start implied O.
This isolates the effect of Backoff, Payup, and market movement during
the hedge window.

---

## 2. Reverse Formulas — Legs 1 & 2

Given fill price P, actual diff at snapshot time, and parameters in effect.
These are the algebraic inverse of [[price-formulas-complete]] §4–6 and §13.

### Leg 1 (SR3|SR1 near-month)

```
O_Buy  = 2 × (P + Av_ZQ − max(BS_ZQ, 0)) − diff
O_Sell = 2 × (P − Av_ZQ − min(BS_ZQ, 0)) − diff
```

### Leg 2 (SR3|SR1 far-month)

```
O_Buy  = 2 × (P + Av_ZQ + min(BS_ZQ, 0)) + diff
O_Sell = 2 × (P − Av_ZQ + max(BS_ZQ, 0)) + diff
```

### Cross-Check Identity

From Legs 1+2, before rounding: L1_Raw + L2_Raw = O − 2×Av_ZQ (the
diff and BS_ZQ terms cancel within each side). The reverse formulas from
Leg 1 and Leg 2 should produce the same O_implied when applied to the
same snapshot. If they diverge, it indicates rounding residual or a data
capture timing mismatch between legs.

---

## 3. Reverse Formulas — Legs 3 & 4

Legs 3/4 chain through Legs 1/2 (ref: [[price-formulas-complete]] §7–9).
First reverse to intermediate L1/L2 raw, then apply §2 formulas.

### Leg 3 (SR3|ZQ near-month) → via Leg 1

```
Buy:  L1_Raw = P + v1 + Av_FF + min(BS_FF, 0)
Sell: L1_Raw = P + v1 − Av_FF + max(BS_FF, 0)
```

Then apply Leg 1 reverse formulas from §2 using L1_Raw as P.

### Leg 4 (SR3|ZQ far-month) → via Leg 2

```
Buy:  L2_Raw = P + v2 + Av_FF + min(BS_FF, 0)
Sell: L2_Raw = P + v2 − Av_FF + max(BS_FF, 0)
```

Then apply Leg 2 reverse formulas from §2 using L2_Raw as P.

### Full Leg 3 Buy Expanded

```
O_Buy = 2 × (P + v1 + Av_FF + min(BS_FF, 0) + Av_ZQ − max(BS_ZQ, 0)) − diff
```

### Full Leg 4 Buy Expanded

```
O_Buy = 2 × (P + v2 + Av_FF + min(BS_FF, 0) + Av_ZQ + min(BS_ZQ, 0)) + diff
```

---

## 4. Data Capture Specification

### 4.1 Snapshot Contents

Capture at both fill-start and fill-complete:

```
FillSnapshot {
    // Identity
    Timestamp           : DateTime (UTC, tick precision)
    ContractId          : string   (e.g., "Mar26")
    LegNumber           : int      (1, 2, 3, or 4)
    SetId               : string   ("A" or "B")
    Side                : enum     (Buy, Sell)
    Event               : enum     (QuoteFill, HedgeFill)

    // Fill data
    FillPrice           : decimal  (ASE spread price at which this event occurred)
    FillQty             : int

    // Market data — monitoring instruments
    v1                  : decimal  (microprice of SR1-ZQ near)
    v2                  : decimal  (microprice of SR1-ZQ far)
    v3                  : decimal  (microprice of ZQ near-far calendar)
    diff                : decimal  (v1 − v2 + v3, computed from above)

    // Market data — leg book state (BBO + quantities)
    L1_Bid              : decimal
    L1_Ask              : decimal
    L1_BidQty           : int
    L1_AskQty           : int
    L2_Bid              : decimal
    L2_Ask              : decimal
    L2_BidQty           : int
    L2_AskQty           : int

    // Parameters in effect at snapshot time
    O_Buy_Target        : decimal
    O_Sell_Target       : decimal
    Av_ZQ               : decimal
    BS_ZQ               : decimal
    Av_FF               : decimal
    BS_FF               : decimal
    Expansion           : decimal  (Timer Logic expansion value)
}
```

### 4.2 Capture Timing

**Fill Start** (Event = QuoteFill): The moment TT SDK reports a quote
leg fill. At this instant, the hedge order has not yet been submitted.
Market data reflects pre-hedge conditions.

**Fill Complete** (Event = HedgeFill): The moment TT SDK reports a hedge
leg fill. Market data reflects post-hedge conditions. The spread is now
fully realised.

### 4.3 What Cannot Be Captured (Acknowledged)

The market state *just before* the quote fill initiated (i.e., the tick
that caused the quote to fill) is not capturable with current architecture.
The first observable moment is the fill confirmation itself. This means
any market movement between the last .NET price calculation and the fill
event is not isolated — it folds into the .NET deviation metric.

---

## 5. Accuracy Computation — Pseudocode

```
function ComputeAccuracy(startSnap: FillSnapshot, completeSnap: FillSnapshot)
    → AccuracyRecord:

    // --- Step 1: Implied O at fill start ---

    impliedO_start = ReverseToO(
        leg       = startSnap.LegNumber,
        side      = startSnap.Side,
        price     = startSnap.FillPrice,
        diff      = startSnap.diff,
        av_zq     = startSnap.Av_ZQ,
        bs_zq     = startSnap.BS_ZQ,
        av_ff     = startSnap.Av_FF,
        bs_ff     = startSnap.BS_FF,
        v1        = startSnap.v1,
        v2        = startSnap.v2
    )

    // --- Step 2: Implied O at fill complete ---

    impliedO_complete = ReverseToO(
        leg       = completeSnap.LegNumber,
        side      = completeSnap.Side,
        price     = completeSnap.FillPrice,
        diff      = completeSnap.diff,
        av_zq     = completeSnap.Av_ZQ,
        bs_zq     = completeSnap.BS_ZQ,
        av_ff     = completeSnap.Av_FF,
        bs_ff     = completeSnap.BS_FF,
        v1        = completeSnap.v1,
        v2        = completeSnap.v2
    )

    // --- Step 3: Target O ---

    if startSnap.Side == Buy:
        targetO = startSnap.O_Buy_Target
    else:
        targetO = startSnap.O_Sell_Target

    // --- Step 4: Deviations ---

    dotnet_deviation = impliedO_start − targetO
    total_deviation  = impliedO_complete − targetO
    ase_deviation    = impliedO_complete − impliedO_start

    // --- Step 5: Theoretical raw price (what .NET should have sent) ---

    theoretical_raw = ForwardRaw(
        leg    = startSnap.LegNumber,
        side   = startSnap.Side,
        O      = targetO,
        diff   = startSnap.diff,
        av_zq  = startSnap.Av_ZQ,
        bs_zq  = startSnap.BS_ZQ,
        av_ff  = startSnap.Av_FF,
        bs_ff  = startSnap.BS_FF,
        v1     = startSnap.v1,
        v2     = startSnap.v2
    )

    rounding_impact = startSnap.FillPrice − theoretical_raw

    // --- Step 6: Classification ---

    if startSnap.Side == Buy:
        // For buys: positive deviation = bought at higher O = worse
        fillQuality = if total_deviation ≤ 0 then "Favorable"
                      elif total_deviation ≤ 0.5 then "Acceptable"
                      elif total_deviation ≤ 1.0 then "Costly"
                      else "Adverse"
    else:
        // For sells: negative deviation = sold at lower O = worse
        fillQuality = if total_deviation ≥ 0 then "Favorable"
                      elif total_deviation ≥ −0.5 then "Acceptable"
                      elif total_deviation ≥ −1.0 then "Costly"
                      else "Adverse"

    return AccuracyRecord {
        startSnap, completeSnap,
        impliedO_start, impliedO_complete, targetO,
        dotnet_deviation, ase_deviation, total_deviation,
        theoretical_raw, rounding_impact,
        fillQuality
    }


function ReverseToO(leg, side, price, diff, av_zq, bs_zq,
                     av_ff, bs_ff, v1, v2) → decimal:

    P = price

    // --- Legs 3 & 4: first reverse to intermediate L1/L2 raw ---

    if leg == 3:
        if side == Buy:
            P = P + v1 + av_ff + min(bs_ff, 0)
        else:
            P = P + v1 - av_ff + max(bs_ff, 0)
        leg = 1  // now reverse as Leg 1

    if leg == 4:
        if side == Buy:
            P = P + v2 + av_ff + min(bs_ff, 0)
        else:
            P = P + v2 - av_ff + max(bs_ff, 0)
        leg = 2  // now reverse as Leg 2

    // --- Legs 1 & 2: reverse to O ---

    if leg == 1:
        if side == Buy:
            return 2 * (P + av_zq - max(bs_zq, 0)) - diff
        else:
            return 2 * (P - av_zq - min(bs_zq, 0)) - diff

    if leg == 2:
        if side == Buy:
            return 2 * (P + av_zq + min(bs_zq, 0)) + diff
        else:
            return 2 * (P - av_zq + max(bs_zq, 0)) + diff


function ForwardRaw(leg, side, O, diff, av_zq, bs_zq,
                     av_ff, bs_ff, v1, v2) → decimal:

    // Compute raw price before rounding (ref: price-formulas-complete §13)

    if leg == 1 and side == Buy:
        raw = (O + diff) / 2 - av_zq + max(bs_zq, 0)
    elif leg == 1 and side == Sell:
        raw = (O + diff) / 2 + av_zq + min(bs_zq, 0)
    elif leg == 2 and side == Buy:
        raw = (O - diff) / 2 - av_zq - min(bs_zq, 0)
    elif leg == 2 and side == Sell:
        raw = (O - diff) / 2 + av_zq - max(bs_zq, 0)

    // Legs 3/4 chain from 1/2
    if leg == 3:
        l1_raw = ForwardRaw(1, side, O, diff, av_zq, bs_zq, 0, 0, 0, 0)
        if side == Buy:
            raw = l1_raw - v1 - av_ff - bs_ff + max(bs_ff, 0)
        else:
            raw = l1_raw - v1 + av_ff - bs_ff + min(bs_ff, 0)

    if leg == 4:
        l2_raw = ForwardRaw(2, side, O, diff, av_zq, bs_zq, 0, 0, 0, 0)
        if side == Buy:
            raw = l2_raw - v2 - av_ff - bs_ff + max(bs_ff, 0)
        else:
            raw = l2_raw - v2 + av_ff - bs_ff + min(bs_ff, 0)

    return raw
```

---

## 6. Edge Cases

### E1: Diff changed between .NET calc and fill

The diff used in .NET's price calculation (diff_calc) may differ from
diff at fill time (diff_snapshot). This is market timing, not a system
error. The reverse formula uses diff_snapshot — so the implied O reflects
what the market was actually pricing at fill time, not what .NET was
targeting. The deviation captures both the system's rounding and any
market movement since the last price calculation.

**Impact**: Expected source of ~0.1–0.3 tick deviation in normal markets.
During volatile periods (e.g., around the 12:55–13:05 avoidance window),
this can exceed 1.0 tick. Filter by time-of-day when analysing.

### E2: Parameters changed between snapshots

If the trader adjusts Av_ZQ, BS_ZQ, or O_Buy/O_Sell between fill start
and fill complete, the two snapshots use different parameters. The ASE
deviation metric becomes unreliable because the system was targeting a
different O at each snapshot.

**Mitigation**: Record parameters at each snapshot independently. Flag
records where parameters differ between start and complete.

### E3: HitMan cross at fill start

HitMan adds 1 tick to the CalcPrice on the quote leg (ref:
[[custom-rules-production]] §Rule 1). The fill price is therefore
CalcPrice + 1 tick (for buys). The implied O will show ~0.5 tick worse
than target. This is expected: HitMan intentionally sacrifices price for
fill certainty.

**Attribution**: The dotnet_deviation includes both rounding AND HitMan
crossing. To isolate HitMan's contribution, compare the fill price to
the CalcPrice that .NET sent. HitMan impact = FillPrice − CalcPrice.

### E4: Backoff at fill complete

Backoff subtracts 1 tick from the hedge price (ref:
[[custom-rules-production]] §Rule 6). If the hedge fills at the backed-off
price, implied O at complete shows ~0.5 tick *better* than at start.
If the hedge later pays up via WCT Payup, the implied O degrades.

**Attribution**: ase_deviation directly captures this. Negative ase_deviation
(for buys) = Backoff saved edge. Positive = Payup consumed edge.

### E5: WCT Payup chain

WCT Payup can fire up to 5 times (+ 1 WCT tick), adding up to 6 ticks
to the hedge price (ref: [[custom-rules-production]] §Rule 8). At fill
complete, implied O may show 1.5–3.0 ticks worse than at fill start.

**Impact**: These are the worst-case fills. The accuracy system should
flag fills where |ase_deviation| > 1.0 tick for individual review.

### E6: Multiple clips / reload

Each reload clip fills independently. Each clip gets its own start/complete
snapshot pair and its own AccuracyRecord. The reload clip number should be
tracked to detect degradation across clips (later clips fill in worse
conditions as the position accumulates).

### E7: Partial fills

If a quote leg partially fills (e.g., 3 of 6 lots), the snapshot captures
the partial fill price. The hedge is triggered for the partial quantity.
Treat each partial as a separate AccuracyRecord with its own fill quantity.

### E8: Leg 3/4 reverse uses v1/v2 at snapshot time

The v1 and v2 values (SR1-ZQ microprices) at fill time may differ from
those used in the .NET calculation that produced the Leg 3/4 price. This
is analogous to E1 but for the basis conversion layer. The deviation
captures both the .NET pricing gap and the basis movement.

### E9: Both Legs 1 and 2 filling near-simultaneously

If Leg 1 and Leg 2 both receive quote fills within the same market data
tick, both snapshots share the same diff. The implied O from both should
agree closely (the cross-check identity from §2 applies). If they diverge
by more than the rounding residual (max 0.5 ticks per leg = 1.0 tick
combined), flag as data quality issue.

---

## 7. Deviation Interpretation

### Sign Convention

| Side | Deviation | Meaning |
|------|-----------|---------|
| Buy  | Positive  | Bought at higher implied O than target → worse (overpaid) |
| Buy  | Negative  | Bought at lower implied O than target → better (got a bargain) |
| Sell | Positive  | Sold at higher implied O than target → better (got more) |
| Sell | Negative  | Sold at lower implied O than target → worse (undersold) |

### Decomposition

```
total_deviation = dotnet_deviation + ase_deviation

Where:
  dotnet_deviation  = implied_O_start − target_O
  ase_deviation     = implied_O_complete − implied_O_start
  total_deviation   = implied_O_complete − target_O
```

**dotnet_deviation** captures: Timer Logic rounding, diff timing mismatch,
parameter-to-market alignment.

**ase_deviation** captures: HitMan crossing (at start, folded into dotnet),
Backoff savings, Payup costs, market movement during hedge window.

Note: HitMan crossing occurs at the quote stage and is captured in the
fill-start price. It appears in dotnet_deviation, not ase_deviation.
Backoff and Payup occur at the hedge stage and appear in ase_deviation.

### Quality Thresholds (Starting Values — Iterate)

| Metric | Favorable | Acceptable | Costly | Adverse |
|--------|-----------|------------|--------|---------|
| total_deviation (buys) | ≤ 0 | 0 to +0.5 | +0.5 to +1.0 | > +1.0 |
| total_deviation (sells) | ≥ 0 | 0 to −0.5 | −0.5 to −1.0 | < −1.0 |
| ase_deviation (either) | < 0.25 | 0.25 to 0.5 | 0.5 to 1.0 | > 1.0 |

These are initial calibration values. Adjust based on observed
distributions after first production deployment.

---

## 8. Aggregation

Over a sample of N fills per contract:

```
mean_total_dev      = mean(total_deviation)        // systematic bias
std_total_dev       = stddev(total_deviation)       // consistency
mean_dotnet_dev     = mean(dotnet_deviation)        // .NET bias
mean_ase_dev        = mean(ase_deviation)           // ASE bias
pct_favorable       = count(Favorable) / N          // target: > 50%
pct_adverse         = count(Adverse) / N            // target: < 10%
worst_deviation     = max(|total_deviation|)         // worst case
```

### Attribution Ratios

```
dotnet_contribution = mean(|dotnet_deviation|) / mean(|total_deviation|)
ase_contribution    = mean(|ase_deviation|) / mean(|total_deviation|)
```

If dotnet_contribution > 0.6: the pricing layer is the primary source of
deviation → focus on Timer Logic calibration and diff timing.

If ase_contribution > 0.6: ASE rules are the primary source → focus on
Backoff/Payup tuning or HitMan threshold adjustment.

### Segmentation

Segment the analysis by:
- Contract (Mar26, Jun26, Sep26, Dec26)
- Leg (1, 2, 3, 4)
- Side (Buy, Sell)
- Time of day (pre-Fed, Fed window, post-Fed)
- Market regime (tight spread vs. wide spread on monitoring instruments)
- Timer Logic state (expanded vs. not expanded)

---

## 9. Relationship to Existing Accuracy Metric

The existing per-ASE accuracy metric (ref: [[glossary]], Accuracy) measures
fill quality relative to CalcPrice:

```
existing_accuracy = 100 ± (|tickDifference| / 5 × 100)
```

This captures **ASE execution quality only** — how well the ASE filled
relative to the price it received.

The reverse-implied O metric captures **total system quality** — how well
the entire pipeline (trader input → .NET → Timer Logic → ASE → fill)
achieved the trader's intent.

They are complementary:
- Existing metric diagnoses ASE rule performance
- New metric diagnoses end-to-end strategy performance
- The gap between them is the .NET pricing layer's contribution

---

## 10. Implementation Notes

### Storage

Each AccuracyRecord is lightweight (~200 bytes). At 100 fills per
threshold cycle (ref: [[safety-mechanisms]] §5), storage is negligible.
Write to CSV or in-memory buffer for real-time display; persist to
database for post-session analysis.

### Computation Cost

ReverseToO is ~5 arithmetic operations. ForwardRaw is ~5 operations.
Total per fill event: ~20 operations. Negligible relative to the 56ms
quote throttle cycle. No latency concern.

### First Iteration Scope

Ship with:
- Snapshot capture at QuoteFill and HedgeFill events
- Reverse formulas for Legs 1 & 2 only (defer Legs 3 & 4 to iteration 2)
- Basic deviation computation and classification
- CSV output for post-session analysis
- Console display of running mean_total_dev per contract

Defer to iteration 2:
- Legs 3 & 4 reverse (adds v1/v2 + BS_FF/Av_FF complexity)
- Real-time segmented aggregation
- Attribution ratios
- Integration with existing Accuracy metric
- Alerting on adverse fills

## Related

- [[price-formulas-complete]] — Forward formulas reversed in §2–3
- [[execution-modifiers]] — Avoidance and bias parameters used in reverse
- [[core-quad-leg-arbitrage]] — Strategy structure and leg definitions
- [[custom-rules-production]] — ASE rules causing ase_deviation (E3–E5)
- [[glossary]] — Existing Accuracy metric this complements
- [[safety-mechanisms]] — Fill threshold that gates measurement cycles
- [[timer-logic]] — Timer Logic whose impact this system measures
- [[methodology-and-framework]] — Existing TD/DPP analysis framework

### Jarvis Downstream
- [[jarvis/timer-logic/verification-report]] — HIGH: WP-04 found BS_ZQ simplification identity fails when BS_ZQ ≠ 0 (§2)
