---
tags: [execution, analysis, tick-deviation, pnl, fill-quality, dpp]
domain: execution-analysis
load-priority: on-demand
last-updated: "2026-03-26"
---

# Execution Analysis Methodology & Framework

Methodology, formulas, and step-by-step framework for replicating fill execution analysis and P&L reporting. Load when running post-session analysis.

---

## 1. Accuracy Methodology

### 1.1 Tick Deviation (TD) Formula

**Tick Deviation** measures how far each fill deviated from the trader's intended entry price, expressed in ticks (tick size = 0.5):

**Buy fills:**
```
TD = (MatchPrice − EntryPrice) / 0.5
```

**Sell fills:**
```
TD = (EntryPrice − MatchPrice) / 0.5
```

**Sign convention:**
- **Positive TD** = payup (filled worse than intended)
- **Negative TD** = backoff (filled better than intended)
- **Zero** = exact match at limit price

### 1.2 Weighted Fill Execution Accuracy

The accuracy percentage incorporates the quantity weight of each fill:

```
Accuracy % = (1 − Σ(TD_i × Qty_i) / Σ(Qty_i)) × 100
```

This formula ensures that larger fills have greater impact on the overall accuracy score. Validated against anchor examples: 10×1-lot all-exact fills = 100%; fills with TDs={0⁸,1,2} = 70%.

### 1.3 Interpretation Scale

| Accuracy Range | Meaning |
|---|---|
| 100% | Every lot filled at the intended price (zero slippage) |
| >100% | Net backoff — fills better than intended on average |
| 50–99% | Moderate payup — average TD between 0.02 and 1.0 ticks |
| <50% | Heavy payup — average TD exceeds 1.0 tick on average |

### 1.4 Fill Classification

Each fill is classified into one of three categories:

- **Zero**: Filled exactly at the limit price (TD = 0)
- **Payup**: Filled at a worse price than limit (positive TD for buys, negative for sells)
- **Backoff**: Filled at a better price than limit (negative TD for buys, positive for sells)

---

## 2. Dollar-Per-Point (DPP) Derivation

### 2.1 CME Contract Specifications

| Product | Contract | Notional | DV01 ($/bp/lot) |
|---|---|---|---|
| SR3 (3M SOFR) | Quarterly | $1,000,000 | $25.00 |
| SR1 (1M SOFR) | Monthly | $4,166,667 | $41.67 |
| ZQ (30-day Fed Funds) | Monthly | $4,167,000 | $41.67 |

### 2.2 Core ASE Ratio Dollar Sensitivity

The core ASE ratio is **3 quoting : −5 hedge** for all four legs:

| ASE Type | Quoting Leg | Hedge Leg | Quoting $/bp | Hedge $/bp |
|---|---|---|---|---|
| SR3\|SR1 (Legs 1 & 2) | 3 × SR1 @ $41.67 | 5 × SR3 @ $25.00 | **$125.01** | **$125.00** |
| SR3\|ZQ (Legs 3 & 4) | 3 × ZQ @ $41.67 | 5 × SR3 @ $25.00 | **$125.01** | **$125.00** |

### 2.3 DPP Calculation

**Dollar-Per-Point = $125.00 per spread price unit per 3:5 fill** (upper bound estimate).

This represents the quoting-leg-driven sensitivity. When the hedge leg drives the spread movement, effective DPP is lower (~$75). The true range is **$75–$125 depending on which leg drives the fill**:

- **Upper bound ($125)**: Quoting leg fills first; hedge fills at market
- **Midpoint ($100)**: Mixed execution
- **Lower bound ($75)**: Hedge leg fills first; quoting leg forced to aggressive price

For ASE fills with **6:−10 ratio** (double the standard size), DPP counts as **2 × $125 = $250 units**.

### 2.4 Matched P&L Calculation

Dollar P&L is calculated only for **matched fills** — pairs of buy and sell on the same alias:

```
Spread P&L = (Avg Sell Price − Avg Buy Price) × Matched Qty × DPP
```

- Only fills with both buy and sell activity contribute to P&L
- Matched quantity = min(total buy qty, total sell qty) for the alias
- Open positions (buy-only or sell-only on an alias) are excluded from dollar calculation
- X/Y ASE fills with unknown DPP are reported in spread price units, not dollars

---

## 3. Analysis Framework — Steps to Replicate

### Step 1: Load Fill Data

Load daily JSON fill files in format: `YYYY-MM-DD_cleaned.json`

Expected fields per fill record:
- `Timestamp`, `Alias`, `Side` (Buy/Sell), `Qty`, `EntryPrice`, `MatchPrice`

### Step 2: Compute Tick Deviation

For each fill record, calculate:

```
TD = (MatchPrice − EntryPrice) / 0.5  [for buys]
TD = (EntryPrice − MatchPrice) / 0.5  [for sells]
```

Classify: if TD = 0 → "Exact"; if TD > 0 → "Payup"; if TD < 0 → "Backoff"

### Step 3: Aggregate Daily Metrics

- Count total fill records, total lots, exact/payup/backoff lot counts
- Compute grand weighted accuracy using formula from 1.2
- Split by side (buy/sell) with separate accuracy for each

### Step 4: Compute Per-Alias Summary

For each alias, compute:

| Metric | Calculation |
|---|---|
| Buy qty | Sum of all buy lot counts |
| Avg buy price | Σ(MatchPrice_buy × Qty_buy) / Σ(Qty_buy) |
| Buy accuracy | (1 − Σ(TD_buy × Qty_buy) / Σ(Qty_buy)) × 100 |
| Sell qty | Sum of all sell lot counts |
| Avg sell price | Σ(MatchPrice_sell × Qty_sell) / Σ(Qty_sell) |
| Sell accuracy | (1 − Σ(TD_sell × Qty_sell) / Σ(Qty_sell)) × 100 |

### Step 5: Matched P&L Calculation

For each alias with both buy and sell fills:

1. Matched quantity = min(buy qty, sell qty)
2. Spread = Avg sell price − Avg buy price
3. Dollar P&L = Spread × Matched qty × $125 (or use $75–$100 for conservative range)
4. Rank by P&L: top 3 gainers and worst 3 losers

### Step 6: Expiry Group Summary

Aggregate aliases into expiry groups (Mar26, Jun26, Sep26, Dec26):

| Metric | Calculation |
|---|---|
| Total lots | Sum of all buy + sell lots in group |
| Buy lots | Sum of buy lots across aliases in group |
| Buy accuracy | Weighted average accuracy of all buy-side fills |
| Sell lots | Sum of sell lots across aliases in group |
| Sell accuracy | Weighted average accuracy of all sell-side fills |
| Combined accuracy | (1 − Σ(all TD × all Qty) / Σ(all Qty)) × 100 |

### Step 7: ASE Type Summary

Aggregate by ASE class (SR3\|SR1 vs SR3\|ZQ) and side:

- SR3\|SR1 Buy: total lots and accuracy
- SR3\|SR1 Sell: total lots and accuracy
- SR3\|ZQ Buy: total lots and accuracy
- SR3\|ZQ Sell: total lots and accuracy

### Step 8: Day-Over-Day Comparison

For aliases active on multiple days:

- Compare accuracy improvement/degradation
- Track volume scaling and its impact
- Flag structural changes in fill patterns

---

## 4. Structural Patterns to Watch For

### Pattern 1: Dec26 Expiry Group — Historically Cleanest

Dec26 consistently delivers the highest accuracy:
- Combined accuracy range: 67–70% across volume increases
- SR3\|ZQ Dec Jan26 Sell is particularly reliable (~70% accuracy even at 126+ lots)
- Tight spread behavior suggests low basis volatility

**Action**: Use Dec26 as the quality baseline. Flag other expiries if they drop below 60% accuracy.

### Pattern 2: Sep26 Expiry Group — Consistently Worst

Sep26 is the persistent problem child:
- Combined accuracy: ~51–52%
- SR3\|ZQ Sep Oct26 Sell is the critical weakness (~4–30% accuracy across sessions)
- SR1-ZQ October basis structurally wider or more volatile than other months

**Action**: Apply tighter avoidance parameters or smaller reload clips on Sep26. Consider reducing position size until the basis stabilizes.

### Pattern 3: Buy-Side Degradation at Volume Scale

Buy-side accuracy is highly sensitive to volume:
- Light days: buy accuracy 75%+
- High-volume days: buy accuracy drops to 45% or below
- Suggests the quoting leg becomes less competitive as order book fills

**Action**: Monitor buy/sell ratio. If buys exceed 500+ lots, expect significant payup. Consider defensive pricing (wider spreads) or reduced buy targets.

### Pattern 4: SR3|ZQ Sell-Side Structural Payup

SR3\|ZQ sell fills consistently underperform buy fills:
- Sell-side accuracy ~55%, buy-side ~61%
- Root cause: ZQ quoting leg thinner than SR3 hedge; slippage absorbed into SR3
- Effect compounds on high-volume days

**Action**: Accept this as a structural cost. Consider tightening buy prices instead of sell prices to widen the effective spread. Monitor ZQ bid-ask spreads for days when they exceed 0.5 ticks.

### Pattern 5: SR3|FF X/Y Fills — Extreme Payup Flag

X and Y ASE fills (especially on Jun26/Sep26) show extreme accuracy metrics:
- Jun26 X: −300% accuracy (filled 4 ticks worse than entry)
- Sep26 Y: −120% accuracy
- May indicate aggressive market-taking or stale entry prices

**Action**: If X/Y fills continue to show >200% payup, review EntryPrice calculation or mark these ASEs as "aggressive only when market-directional."

### Pattern 6: Losses Concentrate When Buying Into Falling Spreads

Largest losses occur when:
- System builds large buy positions
- Spread moves lower during accumulation
- System continues buying at higher levels than where sells occur

**Example**: Jun Jul26 (−$7,268 loss): bought 75 at 6.0818, sold 69 at 5.2391 — a 0.84 spread unit inversion.

**Action**: Implement spread-momentum check. If rolling 3-minute spread is down >1 tick, reduce buy aggressiveness.

### Pattern 7: Low Accuracy on Both Sides Widens Effective Spread Loss

When an alias has poor accuracy on both buy and sell:
- Buy accuracy 10%, sell accuracy 18% → compounded loss
- Sep Nov26 suffered this on Mar 17–19
- Effect: system pays up to get bought fills AND pays up to get sold fills

**Action**: If an alias shows <30% accuracy on both sides simultaneously, pause it. Suggests market is moving away from quoted prices.

### Pattern 8: Sell-Dominated Aliases That Sell Below Buy Price

Reverse spreads indicate structurally unfavorable conditions:
- When avg sell price < avg buy price on matched fills
- Suggests system was consistently buying into strength and selling into weakness

**Action**: Track the direction of large volume legs. If selling significantly below buying, consider reducing buy targets or pausing the alias.

---

## 5. Appendix — Quick Reference Formulas

```
TD_buy = (MatchPrice − EntryPrice) / 0.5
TD_sell = (EntryPrice − MatchPrice) / 0.5

Avg Fill Price = Σ(MatchPrice_i × Qty_i) / Σ(Qty_i)
Avg Entry Price = Σ(EntryPrice_i × Qty_i) / Σ(Qty_i)

Weighted Accuracy = (1 − Σ(TD_i × Qty_i) / Σ(Qty_i)) × 100%

Tick size = 0.5 (all ASE spread instruments)

Matched P&L = (Avg Sell − Avg Buy) × Matched Qty × DPP
```

---

*Framework validated against 2,836 fill records (Mar 5–19, 2026) across 48+ aliases. All calculations anchor to raw JSON fill data — no manual estimation or interpolation.*

## Related

- [[instruments-and-platform]] — DV01 and contract specs used in DPP derivation
- [[core-quad-leg-arbitrage]] — Strategy structure producing analyzed fills
- [[price-formulas-complete]] — Entry prices that TD is measured against
- [[execution-modifiers]] — Parameters affecting fill quality patterns
- [[custom-rules-production]] — Rules determining fill behavior
- [[Plan-2026-03-28]] — Comprehensive work plan referencing this file

### Jarvis Downstream
- [[jarvis/fill-analysis/README]] — WP-01 pipeline implementing this 8-step methodology
- [[jarvis/market-profiling/contract-segmentation]] — Uses accuracy metrics for group boundary validation
