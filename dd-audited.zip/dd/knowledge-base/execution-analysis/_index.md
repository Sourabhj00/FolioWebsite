# Execution Analysis — Map of Content

Post-session analysis methodology. Contains the formulas, metrics, and
step-by-step framework for replicating fill execution analysis and P&L
reporting.

## Files

- [[methodology-and-framework]] — Tick Deviation (TD) formula, weighted fill accuracy, DPP derivation, matched P&L calculation, 8-step analysis framework, and 8 structural patterns to watch for (Dec26 cleanest, Sep26 worst, buy-side volume sensitivity, SR3|ZQ sell-side payup, X/Y extreme payup, loss concentration in falling spreads).
- [[accuracy-measurement]] — Reverse-implied O accuracy system: captures
  fill-start and fill-complete snapshots, reverse-calculates implied O from
  actual market data, decomposes deviation into .NET and ASE components.
  Complements existing per-ASE Accuracy metric with end-to-end O-level
  measurement.

## Related Folders

- [[core/_index|Core]] — Instrument specs (DV01, tick sizes) used in calculations
- [[strategy/_index|Strategy]] — Strategy structure that produces the fills being analyzed
- [[ase-rules/_index|ASE Rules]] — Rule behavior that determines fill quality
- [[planning/_index|Planning]] — Work plan referencing fill analysis and accuracy goals

### Jarvis Analysis
- [[jarvis/fill-analysis/_index|Jarvis: Fill Analysis]] — WP-01: pipeline implementing the 8-step methodology
- [[jarvis/timer-logic/_index|Jarvis: Timer Logic]] — WP-04: audit of accuracy measurement formulas
