---
tags: [rules, production, live, conditions, parameters]
domain: ase-rules
load-priority: on-demand
last-updated: "2026-03-26"
---

# Custom Production Rules — Detailed Analysis

**Scope**: The 8 production ASE rules in detail — conditions, parameters, live values, test cases, and the complete interaction map. Load when tuning execution or diagnosing fill quality.

---

## ASE Configuration Snapshot

The **SR3|SR1 Mar Apr26 - A** spread shows:

| Parameter | Leg 1 (SR1 Apr26) | Leg 2 (SR3 Mar26) |
|-----------|-------------------|-------------------|
| Ratio | 6.0 | −10.0 |
| Multiplier | 100.0 | −100.0 |
| Pay Up Ticks | 0 | 0 |
| Active Quoting | ✓ | ✓ |
| Convert Quote to Hedge | Always | Always |
| Min Lean Qty | 0 | 0 |

**Both legs have Active Quoting enabled.** This is a double-quoting setup where either leg can initiate fills. Combined with "Convert Quote to Hedge = Always", when one leg fills, the working quote on the other leg converts to a hedge order rather than sending a separate hedge.

**Formula**: `100 * Leg1.MergedPrice - 100 * Leg2.MergedPrice` — Price Differential with both legs weighted at 100.

**Primary fill driver**: SR1 side (less liquid leg quoted more often; bigger payups attract fills there).

---

## Production Rule Stack

| Priority | Rule Name | Leg 1 | Leg 2 | Stage |
|----------|-----------|-------|-------|-------|
| 1 | HitMan +1-1 L1 v3 | ✓ | ✗ | Pre-Quote |
| 2 | GJN +1-1 ASM L1 v3 M | ✓ | ✗ | Pre-Quote |
| 3 | GJN Prevent Quote Cross | ✓ | ✓ | Pre-Quote |
| 4 | (GJN) Quote Best Bid/Ask | ✓ | ✓ | Pre-Quote |
| 5 | (GJN) Quote Throttle | ✓ | ✓ | Pre-Quote |
| 6 | GJN Backoff | ✓ | ✓ | Pre-Hedge |
| 7 | (FF) Liquidity [OR] Ratio Based Payup | ✗ | ✗ | Post-Hedge |
| 8 | GJN_WCT_Payup | ✓ | ✓ | Post-Hedge |

**Note**: HitMan and ASM are on Leg 1 only. Rule 7 (FF Payup) is disabled in production (both checkboxes unchecked). GJN_WCT_Payup is the active post-hedge rule.

---

## Rule Versions and Naming

Rules use consistent naming:
- **+1-1** = designed for ASE spreads with multipliers (Leg 1 positive, Leg 2 negative). Includes worst-case spread price check.
- **L1 / L2** = rule acts on that leg while watching conditions on the other leg.
- **v3** = version iteration. Production baseline.
- **M suffix** = intended to indicate ThisLeg-based (portable) variants, but inconsistently applied.

All actively-used rules shared here are 99% confirmed correct.

---

## Pre-Quote Rules

### Rule 1: HitMan +1-1 L1 v3

**Overview**: Aggressive quote-crossing rule that moves the quoting leg one tick through the market when conditions signal strong momentum on the hedge leg.

**Action**: Set quote price to `Leg1.CalculatedQuoteOrderPrice {+} 1 tick` (for buys, add 1 tick; for sells, subtract 1 tick).

**Conditions (8-condition AND gate)**:

| # | Condition | Parameter | Default | Meaning |
|---|-----------|-----------|---------|---------|
| 1 | Hedge leg offer weakness | `VolRatioLegII` | 0.1 | Offer at hedge bid+1 ≤ 10% of hedge bid. Signal: momentum to cross hedge side. |
| 2 | Quote leg offer thinness | `VolRatioLegI` | 0.1 | Offer at quote+1 ≤ 10% of quote bid. Before crossing, confirm no wall at crossing price. |
| 3 | Quote at inside bid | N/A | N/A | Quote price must equal current bid. Only cross from the inside, never from depth. |
| 4 | Offer size below cap | `StopVolLegI` | 100 | Offer qty at crossing price < 100 lots. Don't cross into large sitting offers. |
| 5 | Hedge LTP confirmation | N/A | N/A | Last trade on hedge leg must be at or above bid+1. Confirms trading at the crossing level. |
| 6 | Hedge liquidity floor | `LiqCheckLegII` | 400 | Hedge bid quantity ≥ 400 lots. Enough liquidity to absorb the cross. |
| 7 | Spread price check | `MultLI`, `MultLII`, `DesiredSpreadPrice` | 100, 100, spread target | `(QuotePrice + 1 tick) × MultLI − (HedgeBid + 1 tick) × MultLII ≤ DesiredSpreadPrice`. Validates spread economics post-cross. |
| 8 | Implied avoidance | N/A | N/A | Ask at crossing price must be entirely direct (exchange-native), not implied. |

**Spread price check detail**: The multipliers must be set by the user (ASE rule cannot automatically read the ASE's own multiplier parameter). For SR3|SR1 with multipliers 100:−100, this validates that crossing one tick on SR1 produces a spread price at or better than target.

**Self-disabling in gaps**: When bid-ask spreads 2+ ticks, the "bid+1" level becomes empty, Condition 1 passes trivially, but Condition 3 (quote at inside bid) and Condition 7 (spread check) fail more often → rule doesn't fire. GJN ASM handles gaps explicitly.

**Test case**:
> Buy side. SR1 (quote): Bid = 95.815, Ask = 95.820 (1 tick). 200 bid, 8 offered. SR3 (hedge): Bid = 95.800, Ask = 95.8025 (1 tick). 500 bid, 40 offered. LTP = 95.8025.
>
> Condition 1: Offer at 95.8025 = 40 ≤ 500 × 0.1 = 50? **Yes**
> Condition 2: Offer at 95.820 = 8 ≤ 200 × 0.1 = 20? **Yes**
> Condition 3: CalculatedQuote = 95.815 == Bid (95.815)? **Yes**
> Condition 4: Offer at 95.820 = 8 < 100? **Yes**
> Condition 5: LTP (95.8025) >= Bid+1 (95.8025)? **Yes**
> Condition 6: Bid (500) >= 400? **Yes**
> Condition 7: Spread check (assuming pass)
> Condition 8: No implied at 95.820? Assume **Yes**
>
> **Result**: All met. Quote moves from 95.815 to 95.820 (crosses ask). Fills immediately.

---

### Rule 2: GJN +1-1 ASM L1 v3 M

**Overview**: Passive-aggressive joining rule that moves the quote TO the inside market (not through it) when gap-aware conditions signal favorable leaning opportunity.

**Action**: Move quote to `Leg1.CalculatedQuoteOrderPrice {+} MinimumPriceIncrement` — for buys, up to the bid; for sells, down to the ask.

**Why only 1 tick moves with HitMan**: Rule priority. HitMan (priority 1) evaluates first. If HitMan's conditions are met, it crosses — ASM doesn't fire. If HitMan fails, ASM evaluates and may join. **Never 2 ticks of movement** because placement order matters.

**Conditions (5-condition AND gate)**:

| # | Condition | Parameter | Default | Meaning |
|---|-----------|-----------|---------|---------|
| 1 | Hedge leg volume ratio | `VolRatioLegII` | 0.12 | Offer at hedge bid+1 ≤ 12% of bid. Slightly looser than HitMan (0.1). |
| 2 | Quote positioning | N/A | N/A | `Leg1.CalculatedQuoteOrderPrice {+} tick == BidPrice`. Quote is 1 tick from inside → this move brings it TO inside. |
| 3 | Spread price check | `MultLI`, `MultLII`, `DesiredSpreadPrice` | 100, 100, target | Same worst-case validation as HitMan. |
| 4 | Gap-aware liquidity | `LiqChkVolLegII`, `LiqAtGapLegII` | 150 (1-tick), 1500 (2-tick) | **If bid-ask = 1 tick**: bid ≥ 150. **If bid-ask = 2 ticks**: bid ≥ 1500. Core innovation: gapped markets require 10× more conviction. |
| 5 | Trend/session filter | 3-branch OR gate | N/A | (a) Session range narrow (High − Low < 4 ticks) → always allow. (b) Selling side: bid not at session low (or bid == LTP). (c) Buying side: ask not at session high (or ask == LTP). Prevents hitting against day's trend. |

**Gap-aware liquidity rationale**: In a normal 1-tick spread, 150 lots on bid is sufficient. In a 2-tick gap, the bid is fragile (price could jump 2 ticks when it gives). Requiring 1500 ticks (10×) reflects the increased risk of the bid disappearing.

**Test case**:
> Gap market. SR3 (hedge): Bid = 95.800, Ask = 95.805 (2-tick gap). 2000 bid, 30 offered. Session High = 95.810, Low = 95.795. LTP = 95.8025. Side = Buy.
> SR1 (quote): Calculated = 95.8175, Bid = 95.8225.
>
> Condition 1: Offer at 95.805 = 30 ≤ 2000 × 0.12 = 240? **Yes**
> Condition 2: 95.8175 + 0.005 = 95.8225 == Bid (95.8225)? **Yes**
> Condition 3: Spread check (assume pass)
> Condition 4: Gap = 2 ticks. Bid (2000) >= LiqAtGap (1500)? **Yes**
> Condition 5: Side = Buy. Ask (95.805) != High (95.810), AND Ask (95.805) == LTP (95.8025)? No, but first part true, so... session range check: High − Low = 15 ticks > 4? Yes, narrow range? No. Trend check: second part (ask == LTP) not true. **Likely fails trend check.**
>
> **Result**: Most conditions met, but trend/session check likely blocks in this scenario.

---

### Rule 3: GJN Prevent Quote Cross

**Overview**: Safety net rule. If calculated price would cross the market (not via HitMan), adjust to one tick away.

**Conditions**: Visible in screenshot (priority 3, both legs enabled) but no JSON export provided. Functionally equivalent to TT's (TT) Prevent Quote Cross.

**Role in stack**: Sits between HitMan (which intentionally crosses) and remaining rules. Catches any crossing not covered by HitMan and prevents unintended aggressive fills.

---

### Rule 4: (GJN) Quote Best Bid/Ask

**Overview**: Quote depth limiter. Cancels the quote if it would rest more than `ticks` ticks away from the inside.

**Action**: Set quantity to 0 if `CalculatedQuoteOrderPrice < BidPrice − (tick × ticks)`.

**Parameter**: `ticks = 1` (from screenshot).

**Effect**: Quote only rests at the inside bid or one tick behind. At 2+ ticks deep, the quote is pulled.

**Interaction with HitMan/ASM**: Priority 4 (below both). HitMan/ASM fire first and can move price. Quote Best Bid/Ask evaluates the final price. If HitMan moved quote to inside, it passes. If calculated price is deep and no HitMan fired, this rule pulls it.

**Prevents**: Vulnerable depth orders during outages that don't get managed.

---

### Rule 5: (GJN) Quote Throttle

**Overview**: Rate-limits quote order modifications by time.

**Parameters**:
- `InsideThrottle = 56ms` (both legs)
- `OutsideThrottle = 2ms` (both legs)

**Effect**:
- **InsideThrottle = 56ms**: Suppress moves toward inside market if quote was already changed within 56ms. Allows ~18 updates per second. Tight enough to prevent excessive messaging in fast books, loose enough to not miss real opportunities.
- **OutsideThrottle = 2ms**: Almost no throttle on retreating from market. When market moves against you, quote pulls back instantly. Asymmetry is correct: no urgency in advancing (next tick will try again), but must be fast to retreat (adverse fill risk).

**Known limitation**: Does not work well with Quote-if-Best rule. When orders are removed and placed (vs replaced), the throttle does not apply, resulting in unlimited messaging. Flagged for improvement.

---

## Pre-Hedge Rules

### Rule 6: GJN Backoff

**Overview**: When hedge order is about to be submitted, checks if liquidity at hedge price is sufficient to justify backing off one tick (resting passively vs. crossing).

**Action**: Set hedge price to `CalculatedHedgeOrderPrice {-} 1 tick` (for buys, move down; for sells, move up).

**Conditions (OR gate — either path triggers)**:

**Path A — Ratio-based (relative liquidity)**:
- Offer qty at calculated hedge price ≥ `QtyRatio` × Bid qty one tick behind
- AND Offer qty > `MinAvailableLiq`

**Path B — Absolute threshold**:
- Offer qty at calculated hedge price ≥ `QtyThreshold`

**Parameters** (from screenshot):

| Variable | Leg 1 (SR1) | Leg 2 (SR3) |
|----------|-------------|-------------|
| QtyRatio | 0.3 | 0.3 |
| MinAvailableLiq | 80 | 80 |
| QtyThreshold | 300 | 1000 |

**Note**: Different QtyThreshold per leg. SR1 (300) is thinner; SR3 (1000) is more liquid.

**Interpretation**:
- Path A: Offer not getting swept (ratio test) AND meaningful support behind it → back off
- Path B: Massive offer (300-1000 lots depending on leg) → back off regardless of ratio

**Difference from TT's rule**: TT rule is simpler (absolute only). This rule adds ratio dimension, which adapts to liquidity regime. In active markets, absolute alone might always trigger → constant backoff. Ratio test says "even if 2000 offered, if only 500 bid behind, the level is one-sided."

**Test case**:
> Hedge buy on SR3 at 95.800. Book: Bid at 95.7975 = 150, Ask at 95.800 = 55.
>
> Path A: 55 >= 0.3 × 150 = 45? **Yes**. 55 > 80? **No**. Path A **fails**.
> Path B: 55 >= 1000? **No**. Path B **fails**.
>
> → No backoff. Hedge goes at 95.800 (crosses).
>
> If Ask at 95.800 = 120:
> Path A: 120 >= 45? **Yes**. 120 > 80? **Yes**. → **Backoff**: hedge at 95.7975.

---

## Post-Hedge Rules

### Rule 7 (disabled): (FF) Liquidity [OR] Ratio Based Payup Tick

**Status**: Disabled in production (both legs unchecked).

**Action**: Pay up one tick.

**Known issue**: QtyRatio formula bug (confirmed). Condition reads:
```
AskQuantity < (AskQuantity - MinimumPriceIncrement) × QtyRatio
```

This compares AskQuantity to itself minus a price increment (dimensionally invalid). Should be:
```
AskQuantity < BidQuantityAtPrice(AskPrice − tick) × QtyRatio
```

**Replaced by**: GJN_WCT_Payup (Rule 8).

---

### Rule 8: GJN_WCT_Payup

**Overview**: Active post-hedge payup with Worst Case Tick (WCT) dead zone. Chases hedge fills when market moves or offer thins, but adds patience buffer.

**Action**: Pay up one tick: `CurrentHedgeOrderWorkingPrice + 1 tick`.

**Conditions (AND gate)**:

**Main cap**:
```
CurrentWorking + 1 tick ≤ InitialPrice + (NumberOfPayups + WCTTicks) × tick
```

**WCT dead zone** (prevents early payup):
```
AskPrice - 1 tick ≥ InitialPrice + (WCTTicks × tick)
```

**Market trigger** (OR gate):

**Branch A — Market moved away**:
```
AskPrice > CurrentWorking + 1 tick
```

**Branch B — Offer thinning**:
```
(AskPrice ≠ CurrentWorking) AND
(AskQty < BidQtyAtPrice(AskPrice - tick) × QtyRatio OR AskQty < StopVol) AND
(AskQty < AntiStopVol)
```

**Parameters** (from screenshot):

| Variable | Leg 1 | Leg 2 |
|----------|-------|-------|
| QtyRatio | 0.09 | 0.09 |
| StopVol | 20 | 20 |
| NumberOfPayups | 5 | 5 |
| WCTTicks | 1 | 1 |
| AntiStopVol | 4000 | 4000 |

**WCT dead zone behavior**:
- Total payup budget: `NumberOfPayups (5) + WCTTicks (1) = 6 ticks`
- Won't fire until ask has moved at least `WCTTicks` beyond initial hedge price
- Example: Initial at 95.800. Ask at 95.8025 → WCT check fails (ask−1 = 95.800 NOT ≥ 95.8025). No payup.
- Ask moves to 95.8050 → ask−1 = 95.8025 ≥ 95.8025. **Now eligible for payup**.

**Rationale**: "Don't start paying up the instant the market moves 1 tick. Wait until it's moved WCT further. If it comes back within that window, you save payup ticks."

**Parameter interaction**:
- **QtyRatio = 0.09**: Very aggressive. Ask must be < 9% of bid behind. Only pay up when offer truly drying up.
- **StopVol = 20**: Absolute cap. If offer < 20 lots, pay up regardless of ratio (thin offer, about to be swept).
- **AntiStopVol = 4000**: Never pay up into walls. A 4000-lot offer is structural; wait it out.

**Test case**:
> Hedge buy placed at 95.800 (initial). WCTTicks = 1.
>
> T=0: Ask = 95.8025 (1 tick from initial). WCT check: 95.8025 − 1 tick = 95.800 ≥ 95.800 + 0.0025? **No** (equal but must be strictly ≥). **WCT blocks**.
>
> T=1: Ask = 95.805. WCT check: 95.805 − 0.0025 = 95.8025 ≥ 95.8025? **Yes**. Evaluate Branch A or B.
> Branch A: 95.805 > 95.800 + 0.0025 = 95.8025? **Yes**. → **Pay up**: reprice to 95.8025.
>
> Maximum payup: 95.800 + (5 + 1) × 0.0025 = 95.815. Total budget = 6 ticks (1 WCT + 5 payups).

---

## Rule Interaction Map

```
MARKET TICKS → Pre-Quote Stage
│
├─ Priority 1: HitMan +1-1 L1 v3 (Leg 1 only)
│  └─ If 8 conditions met: CROSS 1 tick
│
├─ Priority 2: GJN +1-1 ASM L1 v3 M (Leg 1 only)
│  └─ If 5 conditions + gap-aware: JOIN inside (1 tick only, since HitMan didn't fire)
│
├─ Priority 3: GJN Prevent Quote Cross (both legs)
│  └─ Safety net: if quote would cross (not via HitMan), adjust to 1 tick from inside
│
├─ Priority 4: (GJN) Quote Best Bid/Ask (both legs)
│  └─ If quote > 1 tick deep: CANCEL
│
└─ Priority 5: (GJN) Quote Throttle (both legs)
   └─ Rate limit: 56ms inside, 2ms outside

   ↓
   QUOTE FILLS
   ↓

Pre-Hedge Stage
│
└─ GJN Backoff
   └─ If offer thick (ratio OR absolute): BACK OFF 1 tick
   └─ If offer thin: CROSS (calculated price)

   ↓
   HEDGE WORKING
   ↓

Post-Hedge Stage
│
└─ GJN_WCT_Payup (only rule; Rule 7 disabled)
   └─ Wait WCTTicks (1) before engaging
   └─ Pay up if: market ran away OR offer thinning
   └─ Cap: NumberOfPayups (5) + WCTTicks (1) = 6 ticks total
```

---

## The Backoff → Payup Pipeline

These two rules form a coordinated pair:

1. **Backoff fires (pre-hedge)**: Hedge rests 1 tick behind market. Initial price is `CalculatedPrice - 1 tick`.
2. **WCT_Payup counting**: From backed-off initial, wait WCTTicks (1) before engaging payup logic.
3. **Net effect**: Hedge effectively waits for market to move 2 ticks against it (1 backoff + 1 WCT) before paying up. Then pays 1 tick at a time, up to 5 times.

**Best case**: Market comes back to backed-off price → hedge fills at −1 tick (better than calculated).
**Worst case**: Full payup chain → hedge at `CalculatedPrice - 1 + 6 = CalculatedPrice + 5`.

---

## HitMan and Backoff — Opposite Philosophies

The rules embody contrasting execution approaches on the same spread:

- **HitMan** (pre-quote, priority 1): "Conditions are perfect — cross the quoting leg NOW and get filled"
- **Backoff** (pre-hedge, priority 6): "We got the quote fill — be patient on the hedge and try for a better price"

This makes sense: HitMan fires when microstructure signals strong conviction. Once you have a fill, urgency shifts — back off gives you a shot at an even better spread realization than your target price.

---

## ASM's Role in the Stack

ASM (priority 2) sits between HitMan (priority 1) and safety-net rules (3–5). It handles cases HitMan can't:

- **HitMan self-disables in gaps** when bid-ask spreads 2+ ticks (Condition 3 and 7 fail)
- **ASM explicitly handles gaps** with separate liquidity thresholds (150 tight vs. 1500 gap)
- **ASM joins the inside** (less aggressive) rather than crossing, avoiding wasted messaging
- **Gap-awareness + trend filter** ensure it only fires when conditions warrant it

Combined with Quote Throttle (56ms inside suppression), ASM makes every move count: gap-awareness and trend filtering ensure only high-conviction moves break through to the market.

---

## Summary

Production rules balance three execution axes:

1. **Quoting aggression** (HitMan + ASM): Cross or join based on microstructure + gap-aware conditions
2. **Message traffic** (Throttle + Prevent Cross + Best Bid/Ask): Rate limit, safety nets, depth guards
3. **Legging management** (Backoff + WCT_Payup): Back off when possible, pay up only when necessary with WCT patience buffer

The result: targeted quote crosses (HitMan) on high-conviction signals, gap-aware joining (ASM) when microstructure allows, patient hedging with backoff, and disciplined payup only when the market has truly moved away or supply is drying up.

**Timer Logic interaction**: Production rules operate on CalcPrice, which is now Timer-adjusted when Timer Logic is active. HitMan's Condition 3 (quote at inside bid) fires more frequently with expanded prices. ASM may fire less frequently (expanded price already at inside). Backoff operates independently (pre-hedge stage). See [[timer-logic]] §9 for full interaction analysis.

## Related

- [[ase-mechanics-and-parameters]] — Engine pipeline these rules operate in
- [[custom-rules-library]] — Full library these 8 were selected from
- [[rule-anomalies-and-evolution]] — Known bugs affecting some production rules
- [[execution-modifiers]] — Avoidance/bias parameters that affect rule inputs
- [[methodology-and-framework]] — Fill quality metrics measuring rule effectiveness
- [[core-quad-leg-arbitrage]] — Strategy these rules execute
- [[Plan-2026-03-28]] — Comprehensive work plan referencing this file

### Jarvis Downstream
- [[jarvis/timer-logic/verification-report]] — WP-04 verified rule interaction with Timer Logic rounding
- [[jarvis/market-profiling/contract-segmentation]] — Group-specific parameter recommendations for these rules
- [[jarvis/fair-value/network-valuation-engine-plan]] — Plans integration with valuation engine output
- [[jarvis/strategy-research/directional-bias-model]] — HitMan/ASM rules the bias signal would trigger
