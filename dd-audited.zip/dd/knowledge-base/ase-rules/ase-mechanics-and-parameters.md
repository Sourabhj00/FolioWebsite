---
tags: [ase, mechanics, engine, parameters, pipeline]
domain: ase-rules
load-priority: on-demand
last-updated: "2026-03-26"
---

# ASE Mechanics and Parameters

**Scope**: How TT Autospreader (ASE) works mechanically, all configurable parameters, and the three rule stages. Load before any rule discussion or ASE configuration work.

---

## What Is an Autospreader (ASE)?

An ASE is a TT server-side engine that creates a **synthetic spread market** from two or more outright (exchange-traded) leg instruments. It shows you an implied bid/ask book for the spread, and when you trade that implied book, the ASE decomposes your spread order into outright leg orders and manages them through their lifecycle.

The ASE server is **co-located** with the CME matching engine. This latency proximity means the quoting/hedging loop runs at exchange proximity speeds, not at your desktop latency.

---

## The Default Engine Flow

Before any rules are applied, the ASE operates on a simple, conventional spreading logic:

**Step 1 — Spread calculation**: Using the formula you configured (Price Differential for spreads like SR3|SR1), the ASE looks at the live outright markets and computes an implied bid and implied ask for the synthetic spread.

**Step 2 — Quote submission**: When you submit a buy (or sell) at a price on the synthetic spread, the ASE figures out at what price it needs to rest a passive limit order on the **quoting leg** such that, if that quote fills and the hedge leg is executed at the current market, the net spread price achieves your target. It submits this quote order.

**Step 3 — Dynamic re-quoting**: As the hedge leg's market moves, the ASE recalculates the required quote price and **automatically reprices** your resting quote order. This is the core mechanic: every tick in the hedge leg potentially triggers a cancel/replace on the quote leg.

**Step 4 — Quote fill → hedge trigger**: The moment the quote leg gets a fill, the ASE immediately submits a **hedge order** on the other leg(s) to complete the spread. By default, this hedge is a limit order priced to cross the market at the price needed to achieve the spread price.

**Step 5 — Spread complete or legged**: If the hedge fills immediately, the spread unit is complete. If the hedge doesn't fill (market moved away), you are **legged** — exposed on one side only.

---

## What the Default Engine Does NOT Do

Without rules, the ASE has no concept of:

- Throttling how often it reprices the quote
- Pulling quotes when hedge-side liquidity is thin
- Backing off the hedge price to try for a better fill
- Paying up on the hedge if it's sitting unfilled
- Preventing the quote from crossing the market
- Limiting how far the quote can jump in one reprice
- Managing quantity increments for round-lot contracts
- Slop tolerance (accepting fills within a price range without requoting)

All of these behaviours require rules. The default engine is aggressive on requoting and passive on hedge management.

---

## Spread-Level Parameters

| Parameter | Purpose | Your Context |
|-----------|---------|--------------|
| **Name** | Display name of the synthetic spread | e.g., "SR3\|SR1 Mar Apr26" |
| **Spread Formula** | How the spread price is calculated from leg prices. Options: Price Differential, Ratio, Net Change, Custom, TT Splicer | **Price Differential** (standard) |
| **Calculated Tick Size** | Minimum tick of the synthetic spread, derived from leg tick sizes and multipliers | Depends on multiplier configuration |
| **Override Tick Size** | Manually set a different tick size | For display/trading precision |
| **Reload** | Splits a large spread order into smaller disclosed clips | Core to sequential clip feeding |
| **Sniper** | Hits all legs simultaneously when spread price is available (no quoting) | Not used in passive strategies |

---

## Leg-Level Parameters

| Parameter | Purpose | Your Context |
|-----------|---------|--------------|
| **Contract** | The outright instrument for this leg | SR3, SR1, or ZQ contract month |
| **Ratio** | Quantity relationship between legs. Negative = short. Does NOT affect spread price. | Your ratios: 3:−5, 6:−10 |
| **Multiplier** | Weights the leg price in the spread formula. Directly affects the implied spread price. | Critical for correct implied price; can be whole, decimal, or fractional (1/3 optimises ticking) |
| **Active Quoting** | Whether this leg rests passive orders in the market | At least one leg must have this enabled |
| **Enable Hedging** | Whether this leg sends a hedge order after a quote fill | Auto-enabled when Active Quoting is on |
| **Pay Up Ticks** | Number of ticks the hedge order will cross through the market beyond the calculated price | Default 0 = hedge at the exact price needed. Higher = more aggressive, less legging, worse fill quality |
| **Min Lean Qty** | Minimum quantity required in the hedge leg's book for the ASE to place a quote | Default: `ThisLeg.DisclosedRemainingQuantity`. Setting to 1 = lean on inside market only |
| **Queue Holder** | Number of additional price levels to trail behind the quoting order for queue position preservation | Places duplicate orders at consecutive levels |
| **Lean on Indicative** | Use indicative/auction prices for leaning during pre-open | Not relevant during regular trading hours |
| **Convert Quote to Hedge** | When multiple legs quote, reuses the working quote on the hedge leg instead of sending a new order | Three modes: "Attempt" (lowest latency, overfill risk), "Always" (waits for ack, no overfill), "Always Preserve Queue" (adds latency) |
| **Delta** | Display-only: shows the spread effect of a 1-tick move in this leg | Helps verify multiplier setup |

---

## Reload Sub-Parameters

| Parameter | Purpose |
|-----------|---------|
| **Disclosed Qty** | How many lots each clip shows to the market. Must be > 0 and ≤ order quantity |
| **Max Exposure (clips)** | How many clips can be legged simultaneously before the ASE stops quoting |
| **Offset** | Number of spread ticks to offset each reload from the original price |
| **Delay (ms)** | Milliseconds to wait before submitting the next clip after a fill |

---

## The Three Rule Stages — ASE Lifecycle

Rules intercept the ASE at three points. Understanding when each fires is essential for designing execution logic.

### Stage 1: Pre-Quote (Quoting Order Rules)

**When it fires**: Every time the ASE recalculates a quote order price or quantity — which is every time any hedge leg ticks. Fires extremely frequently.

**What it can do**:
- Override price: Replace the ASE's calculated quote price
- Override quantity: Reduce the quote quantity
- Suppress the quote: Prevent the order from being sent/modified

**Key insight**: Pre-quote rules fire very frequently — on every market tick. Rules here must be lightweight and well-considered, or they create excessive message traffic or suppress too many fills.

### Stage 2: Pre-Hedge (Pre-Hedge Order Rules)

**When it fires**: Once, immediately after a quote fill, before the hedge order is submitted.

**What it can do**:
- Override price: Change where the hedge enters the market
- Override quantity: Change how many lots are hedged
- Change order type: Switch from limit to market, FOK, IOC, etc.
- Forfeit: Cancel the hedge entirely (accept being legged)

**Why it matters for fill quality**: This is the **primary fill quality control point**. The default hedge price is calculated to achieve the exact spread price (TD=0). Pre-hedge rules that back off the price reduce payup but increase legging risk. Rules that pay up improve fill certainty but worsen fill quality.

### Stage 3: Post-Hedge (Post-Hedge Order Rules)

**When it fires**: Continuously, while a hedge order is working (resting) in the market. Re-evaluated on market data updates.

**What it can do**:
- Override price: Reprice the working hedge (e.g., pay up after some time)
- Override quantity: Change the resting hedge quantity

**Why it matters for fill quality**: Post-hedge rules manage **legged positions**. When the initial hedge doesn't fill, you're exposed. Post-hedge rules decide when to capitulate (pay up to get out of the leg) vs. when to wait (let the market come back). Every payup tick here directly increases TD and worsens fill quality.

---

## Key Concepts

### Lean / Lean Price

"Leaning on the book" means the ASE calculates its quote based on the quantity it observes at a given price level. The `MinLeanQuantity` parameter controls how deep the ASE walks the book before quoting. When the observed quantity drops below this threshold, the ASE doesn't quote — it waits for liquidity to return.

### Legging vs Payup

**Legging**: You fill one leg (quote) but the other leg (hedge) doesn't fill. You are now exposed to one-sided market risk. Legging duration and quantity directly determine whether you escape unscathed or suffer adverse fills.

**Payup**: The trade-off decision to improve the hedge price (cross deeper into the market) to increase the probability of filling it before the market moves further away. Every payup tick reduces fill quality (increases TD) but reduces legging risk.

### Rule Priority

Rules on the same stage evaluate in priority order (top = highest). A higher-priority rule's action can prevent a lower-priority rule from firing. Example: if HitMan (priority 1) crosses the quote, ASM (priority 2) doesn't evaluate because the price has already been moved.

### Auto-Reversal Brackets {}

Notation used in rules to handle buy/sell symmetry. Example: `{+}` means "add for buys, subtract for sells." This allows one rule definition to work correctly on both sides of a trade without explicit buy/sell branches.

---

## Summary

The ASE is a low-latency synthetic spread engine that manages the quoting-hedging lifecycle. Default behavior is aggressive on requoting and passive on hedging. Rules provide fine-grained control at three critical decision points: pre-quote (fill timing), pre-hedge (fill quality), and post-hedge (legging management). Understanding the parameters and stages is essential for tuning execution behavior.

## Related

- [[glossary]] — ASE terminology
- [[custom-rules-library]] — Full rule inventory that extends the engine
- [[custom-rules-production]] — Live production rules
- [[tt-default-rules]] — TT-provided default rules
- [[rule-anomalies-and-evolution]] — Known issues with the engine and rules
- [[architecture-and-dataflow]] — Application that hosts the ASE
- [[Plan-2026-03-28]] — Comprehensive work plan referencing this file

### Jarvis Downstream
- [[jarvis/market-profiling/contract-segmentation]] — ASE pipeline behavior underlying group accuracy patterns
- [[jarvis/strategy-research/directional-bias-model]] — ASE pipeline integration point for bias signals
