---
tags: [rules, custom, hitman, asm, noquote, ghost, library]
domain: ase-rules
load-priority: on-demand
last-updated: "2026-03-26"
---

# Custom Rules Library — Complete Inventory

**Scope**: Complete inventory of all 56 custom ASE rules — families, spread configurations, evolution per family, and production identification. Load when selecting or modifying rules for different spread structures.

---

## Library Overview

The 56 rules span the full lifecycle of the trading system's development. They include production rules, earlier iterations, experimental variants, spread-structure-specific adaptations, and utility rules. Many are variations of the same core idea tuned for different spread configurations or evolved through successive versions.

### Spread Structures Covered

The rules target four distinct spread leg configurations:

- **+1−1** (standard calendar spread): Leg1 long, Leg2 short. Most common — SR3|SR1, SR3|ZQ
- **−1+1+1** (O spread decomposition, Y-type): Leg1 short, Leg2 long, Leg3 long
- **−1−1+1** (O spread decomposition, X-type): Leg1 short, Leg2 short, Leg3 long
- **+1+1** (additive spread): Both legs long. Less common — only two ASM rules

### Rule Families Summary

| Family | Purpose | Stage | Count |
|--------|---------|-------|-------|
| HitMan | Aggressive crossing — moves THROUGH the inside | Pre-Quote | 18 |
| ASM | Passive-aggressive joining — moves TO the inside | Pre-Quote | 18 |
| Quote Control | Blocks or constrains quoting under specific conditions | Pre-Quote | 9 |
| Backoff | Pulls hedge price back from the inside when liquidity favors patience | Pre-Hedge | 2 |
| Payup | Chases hedge fills by improving price tick-by-tick | Post-Hedge | 3 |
| **Total** | | | **56** |

---

## HitMan Rules (18 rules)

HitMan rules cross aggressively through the inside when conditions signal the other side is about to move. All are Pre-Quote rules that advance the quote price by one tick past the current bid.

### Core Logic (All HitMan Rules)

Every HitMan rule checks some combination of:
- Volume ratio on quoting leg: Ask quantity at next tick small relative to bid (thin offer about to be swept)
- Volume ratio on hedge leg: Same thinning signal on other side of spread
- Absolute offer size cap (StopVol): Ask at crossing level must be below a hard ceiling
- Liquidity floor on hedge leg (LiqCheck): Enough resting bid liquidity to absorb the cross
- Spread price validation: Resulting spread price still meets desired price post-cross
- LTP confirmation: Last traded price at or beyond the crossing level
- Implied avoidance: Ask at crossing level is direct (not implied)

All use auto-reversal brackets `{+}` / `{<=}` / `{>=}` for buy/sell symmetry.

### 2-Leg HitMan Evolution

**Generation 1** (Rules 50, 51): No spread formula, no multipliers. Named "GJN HitMAN-Leg1" and "GJN HitMAN-Leg2". Checks volume ratios, StopVol, LTP on hedge leg, hedge liquidity — but never validates spread price against target. Fire purely on microstructure.

**Generation 2** (Rules 48, 49): Adds spread formula with multipliers. Named "GJN HitMAN-Leg1/Leg2 +1-1". Adds MultLI/MultLII parameters and spread price validation. Uses AskPrice directly and BidQuantityAtPrice approach for hedge-side depth checks.

**Generation 3** (Rules 2, 3, 4): LTP variants with HitImplied toggle. Named with "LTP11" and "LTP01" suffixes. Use explicit Leg1/Leg2 references (not ThisLeg). Add HitImplieds parameter. LTP11 = both legs must have traded at crossing level; LTP01 = hedge leg only.

**Generation 4** (Rules 39, 40): ThisLeg-based with LTP variants. Named "GJN HitMAN-L1 +1-1 LTP01/LTP11". Use ThisLeg references (portable). Rule 39 has 7 conditions (no HitImplied, no implied filter). Rule 40 adds Leg1 LTP confirmation (8 conditions). Neither includes implied avoidance from Generation 3.

**Multiplier support without LTP** (Rules 27, 28): Named "HitMan +1-1 L1/L2 v3". Have multipliers and spread validation, add implied avoidance check. Use hedge leg LTP only (not quoting leg). Structurally closest to production baseline.

**Production baseline** (Rules 25, 26): Named "HitMan L1/L2 v3". No multipliers (raw price differencing). Implied avoidance included. LTP on hedge leg only. Current production standard for 2-leg HitMan.

### 3-Leg HitMan Variants

**v5 — Most sophisticated** (Rules 17, 34): Rule 17 covers −1+1+1 (Y-type), Rule 34 covers −1−1+1 (X-type). 15 user parameters including per-leg volume ratios, LTP multipliers, direct quantity floors. HitImplieds toggle (0 = block all implied, 1 = disable filter). Leg3 is the quoting leg (long leg). Spread pricing uses ASM-style volume-adjusted prices for other legs.

**X and Y variants** (Rules 19, 21): Simpler 3-leg HitMan. Rule 19 for −1−1+1 (X-type), Rule 21 for −1+1+1 (Y-type). Fewer parameters (7 each). Hard-code implied check as `< 1` (no toggle). Use fixed 200-multiplier formulas. No DirectQty parameters.

**L1 HitMan v2** (Rule 22): Earlier 3-leg version. Only triggers on Leg1 thinning (no OR with Leg2). Uses ThisLeg reference. 9 parameters including VolRatioLegIII (checks volume on quoting leg itself). Notable cross-leg tick size error (uses Leg3 tick for Leg1 price increment).

### 3-Leg HitMan Anomaly

**Rule 22 cross-leg tick**: Spread pricing formula uses Leg3's MinimumPriceIncrement when calculating Leg1 price. Harmless for same-product spreads (all ticks identical). Incorrect for cross-product spreads.

---

## ASM Rules (18 rules)

ASM (Autospreader Market) rules join the inside market — they move the quote TO the best bid, not through it. Passive-aggressive strategy: get closer to front of queue when conditions favorable.

### Core ASM Logic

Every ASM rule checks:
- Quoting leg position: Calculated quote price (after advancing one tick) must be at or inside current bid (joining, not crossing)
- Trigger leg volume signal: At least one other leg shows thinning (same as HitMan)
- Spread price validation: Resulting spread still meets desired price post-join
- Liquidity or gap conditions: Trigger leg must have enough depth (LiqChk tight spreads) or extra depth (LiqAtGap wide spreads)

Key distinction from HitMan: Position check uses `== BidPrice` or `<= BidPrice`, NOT combined with offer-thinness cap. ASM doesn't need offer to be thin enough to sweep — just needs favorable conditions to improve queue position.

### 2-Leg ASM Evolution

**Earliest** (Rules 43, 24): Use BidQuantityAtPrice approach for gap spreads and DirectBidQuantityAtPrice for tight spreads. Named "GJN ASM L1 +1-1" and "GJN -1+1+1 L1 ASM".

**v3 without multipliers** (Rules 29, 30): Named "GJN ASM L1/L2 v3". Add range filter (High − Low < 4 ticks). Prevent ASM in trending or wide-range markets. No multiplier parameters.

**v3 with multipliers** (Rules 15, 16 and 31, 32): Two near-identical pairs. Both include MultLI/MultLII + range filter. Rules 15/16 have "M" suffix; Rules 31/32 don't. Structurally very similar.

**+1+1 additive variants** (Rules 41, 42): Named "GJN ASM L1/L2 +1+1". For additive spreads (both legs long). Spread formula adds rather than subtracts. Trigger uses BidQuantityAtPrice(AskPrice − tick) instead of AskQuantityAtPrice(BidPrice + tick).

**ASM+LTP hybrids** (Rules 44, 45): Named "GJN ASM+LTP Leg1/Leg2 +1-1". Combine ASM join logic with LastTradedPrice confirmation on trigger leg. More conservative — won't join unless market recently traded at supporting level.

### 3-Leg ASM Variants

**Original X/Y/O types** (Rules 5, 6, 7): Previously analyzed in depth. GJN_ASM_X (Rule 5) for −1+1+1 with Leg2 negative. GJN_ASM_Y (Rule 6) for −1+1+1 with Leg2 positive (volume detection flipped). GJN_ASM_O (Rule 7) for −1+1+1 with single-leg trigger. All use hardcoded 200 multipliers and Leg3 as quoting leg.

**Evolved X/Y with `<=` check** (Rules 18, 20): Named "GJN -1-1+1 ASM X" and "GJN -1+1+1 ASM Y". Identical structure to Rules 5/6 except position check uses `<=` instead of `==` (allows firing even when calculated price is below bid). Lower Leg2 LiqChk (200 vs 30).

**M-suffixed variants** (Rules 13, 14): Rule 13 ("GJN -1+1+1 ASM Y M") and Rule 14 ("GJN -1-1+1 ASM X M"). Use Leg3 in conditions despite M suffix. Rule 14 uses DirectAskQuantityAtPrice and DirectBidQuantity (explicitly filtering implied liquidity).

**v2 and v3 with ThisLeg** (Rules 12, 23, 8): Rule 24 ("L1 ASM") earliest. Rule 23 ("L1 ASM v2") adds `<=` check, switches to AskQuantityAtPrice approach, DirectBidQuantity >= 1 filter. Rule 12 ("L1 ASM v2 M") same as v2 but `==` (stricter). Rule 8 ("L1 ASM v3") same as v2 M.

**v3 with volume-adjusted pricing** (Rules 37, 38): Named "GJN -1-1+1 ASM v3" and "GJN -1+1+1 ASM v3". Use Floor/Min volume-adjusted pricing formula in spread check (same as HitMan v5). ASM's spread validation accounts for potential price movement on other legs based on volume.

### ASM Anomalies

**Rules 29, 32** (cross-leg tick): Tight-spread branch checks `Leg1.AskPrice - Leg1.BidPrice == Leg2.MinimumPriceIncrement`. For same-product spreads this evaluates correctly. For cross-product, applies wrong tick. Rule 15 has same issue.

**Rules 15/16 vs 31/32** (near-duplicates): Four rules in two pairs. Both "+1-1 ASM L1/L2 v3" with multipliers and range filters. "M" suffix on 15/16 doesn't correspond to consistent ThisLeg vs. Leg difference. May represent two saves with minor tweaks or one clean version + backup.

**Rule 41** (cross-leg tick in range): Range check uses `Leg1.High - Leg1.Low < 4 * Leg2.MinimumPriceIncrement`. Harmless for same-product, incorrect for cross-product.

---

## Quote Control Rules (9 rules)

These Pre-Quote rules gate whether the ASE quotes at all, or constrain the quote price. Safety mechanisms, directional filters, market condition guards.

### No-Quote Gates

**Rule 1 — "No Quote unless Hit"** vs **Rule 33 — "No Quote"** vs **Rule 56 — "Ghost ASE"**:

| Rule | Condition | Effect |
|------|-----------|--------|
| Rule 1 — GJN No Quote unless Hit | CalcPrice `<` AskPrice | Blocks passive quoting; only HitMan can cross |
| Rule 33 — GJN No Quote | CalcPrice `<=` AskPrice | Blocks ALL quoting including at ask; stricter |
| Rule 56 — (FF) Ghost ASE | CalcPrice `<` AskPrice | Identical to Rule 1 |

**Rules 1 and 56 are duplicates** with different names. "Ghost ASE" is older (FF) naming. One should be retired.

**Rule 33 is materially different**: `<=` means even when calculated price equals ask (passive at inside offer), the rule blocks it. Creates fully silent ASE that can only act through HitMan crossing. Useful when you want ASE structure but only want to aggress on favorable microstructure.

### Directional Filters

**Rule 52** ("(FF) Sell Only Quoting"): Sets qty=0 when Side==1 (buy). Only sell-side quotes go through.

**Rule 53** ("(FF) Buy Only Quoting"): Sets qty=0 when Side==2 (sell). Only buy-side quotes go through.

Simple directional toggles. Enable one to restrict ASE to single direction. Useful during trending markets or when taking only one spread side.

### NoQuote L1/L2 — Aggressive Market Quality Gate

**Rules 54, 55**: OR-based filters that shut off quoting when ANY condition fails:
- Either leg has wide spread (not 1-tick tight)
- Leg bid/ask ratio below threshold (Leg1: ratio < 8×, Leg2: ratio < 13×)
- Leg liquidity below 300 lots
- Implied quantity detected on relevant leg (DirectAskQuantity ≠ AskQuantity)

**Extreme ratio thresholds**: Require bid to be 8× or 13× ask. Quoting only activates in heavily one-sided markets. Very conservative — would only allow quoting in strongly one-sided books.

Rule 54 monitors Leg2 implieds and shuts off L2 quoting. Rule 55 monitors Leg1 implieds and shuts off L1 quoting.

### Price Modification Rules

**Rule 36 — Prevent Quote Cross**:

When calculated quote would cross the ask, pulls it back to ask − 1 tick. But only when the ask is thick:
- AskQuantity > 4000, OR
- Implied quantity at ask ≥ 500

Conditional safety rail: prevents crossing into heavy offers or implied-heavy levels, but allows crossing through normal-sized offers. Parameters tunable.

**Rule 46 — Quote Best Bid/Ask**:

Sets qty=0 if calculated price drops too far below bid: `CalcPrice < BidPrice − ticks × MinPriceIncrement`.

Outage/stale price protection. If ASE's calculated price diverges from market by more than `ticks` levels, stops quoting entirely. Default `ticks=1`.

---

## Backoff Rules (2 rules)

Both are Pre-Hedge rules that pull the hedge price back by one tick when the other side of book is too thick to cross profitably.

**Rule 47 — GJN Backoff** (Production):

Previously analyzed in depth. Uses `CalculatedHedgeOrderPrice`. Conditions:
- Ratio trigger: Ask qty ≥ QtyRatio × Bid qty one tick behind, AND ask qty > MinAvailableLiq
- OR: Ask qty ≥ QtyThreshold (absolute)

**Rule 9 — GJN_Backoff_No_Cross** (No-Cross variant):

Uses `AskPrice` instead of `CalculatedHedgeOrderPrice` for condition checks and sets hedge to `AskPrice − 1 tick`. The difference: production backoff prices off where TT would place the hedge; No-Cross prices off current market ask. These diverge when calculated hedge differs from current ask (e.g., payup ticks or other modifications).

Variable names also differ: production uses `QtyThreshold`, No-Cross uses `BackoffVol`.

---

## Payup Rules (3 rules)

All Post-Hedge rules that chase hedge fills by improving working price tick-by-tick.

**Rule 10 — GJN_Payup** (Without WCT):

Pays up when either:
- Ask has moved away (market running), OR
- Ask at different level from working price AND (ask thin relative to bid-behind depth OR ask below StopVol) AND ask not above AntiStopVol ceiling

Payup continues up to NumberOfPayups ticks.

**Rule 11 — GJN_WCT_Payup** (With Worst Case Tick) — Production active:

Same logic as Rule 10, plus Worst Case Tick dead zone. Payup cap extends to `NumberOfPayups + WCTTicks`, but rule won't fire unless ask has moved at least `WCTTicks` beyond initial hedge price. Creates buffer zone where rule sits idle — only starts chasing once market moved enough.

**Rule 35 — (FF) Payup** (Confirmed bug, disabled):

Has confirmed QtyRatio formula bug: condition checks `AskQuantity < (AskQuantity − MinimumPriceIncrement) × QtyRatio`. Subtracts price increment from quantity (dimensional error). Should compare AskQuantity to `BidQuantityAtPrice(AskPrice − tick) × QtyRatio` as GJN versions do. Disabled in production. GJN_WCT_Payup should be used.

---

## Naming Conventions

The library uses consistent patterns:

- **(FF)** prefix: Older rules, likely from previous regime or colleague. Tend to have simpler logic or known issues.
- **GJN** prefix: Current production set.
- **L1/L2**: Which leg rule applies to or triggers from.
- **+1-1 / -1+1+1 / -1-1+1 / +1+1**: Leg sign configuration the rule is designed for.
- **v2/v3/v5**: Version iterations. Higher generally more evolved.
- **M suffix**: Intended to mark ThisLeg-based (portable) variants. Inconsistently applied — some M-suffixed still use Leg3 references.
- **LTP01/LTP11**: Last-traded-price confirmation. 01 = hedge leg only, 11 = both legs.
- **X/Y/O**: Three decomposition structures for 3-leg O spread configurations.

### The "M" Suffix Inconsistency

M suffix intended to mark ThisLeg-based rules (portable across spreads). In practice:
- Rules 12, 15, 16 correctly use ThisLeg — M is accurate
- Rules 13, 14 still use Leg3 — M is misleading
- Rules 29, 30 don't have M but also don't use ThisLeg — consistent

Not a functional bug, just naming inconsistency. Rules work correctly; M suffix not reliable for portability.

---

## Evolution Timeline (Inferred)

Based on feature accumulation and naming:

1. **(FF) rules** — Oldest. Simple logic, no multipliers, some bugs.
2. **GJN HitMAN-Leg1/Leg2** (Rules 50/51) — First GJN HitMan. No spread price check.
3. **GJN HitMAN-Leg1/Leg2 +1-1** (Rules 48/49) — Adds multipliers and spread validation.
4. **HitMan L1/L2 v3** (Rules 25/26) — Production 2-leg baseline. Adds implied avoidance.
5. **HitMan +1-1 L1/L2 v3** (Rules 27/28) — Re-adds multipliers for cross-product.
6. **GJN HitMAN-L1 LTP01/LTP11** (Rules 39/40) — ThisLeg portability, LTP variants.
7. **GJN_HitMan LTP11/LTP01** (Rules 2/3/4) — Leg-explicit, adds HitImplied toggle.
8. **HitMan v5** (Rules 17/34) — 3-leg, most sophisticated.

Similar progression for ASM (24 → 23 → 12/8 → 5/6/7 → 18/20 → 37/38) and 2-leg ASM line (29/30 → 15/16/31/32 → 41/42 → 43 → 44/45).

---

## Production vs Non-Production

Confirmed production rules for **SR3|SR1 Mar Apr26**:

| Production Rule | Library Rule # |
|-----------------|---------------|
| HitMan +1-1 L1 v3 | 27 |
| GJN +1-1 ASM L1 v3 M | 16 |
| GJN Prevent Quote Cross | 36 |
| (GJN) Quote Best Bid/Ask | 46 |
| GJN Backoff | 47 |
| GJN_WCT_Payup | 11 |
| (FF) Payup (disabled) | 35 |

The remaining 49 rules are old versions, experimental variants, spread-structure-specific adaptations (3-leg, +1+1), or backup copies.

## Related

- [[ase-mechanics-and-parameters]] — Engine these rules plug into
- [[custom-rules-production]] — The 8 rules selected from this library for production
- [[rule-anomalies-and-evolution]] — Bugs and naming issues across the library
- [[tt-default-rules]] — Vendor rules that complement custom rules
- [[price-formulas-complete]] — CalcPrice that rule conditions evaluate
- [[Plan-2026-03-28]] — Comprehensive work plan referencing this file

---

## Known Issues Summary

**Confirmed bug**: Rule 35 (FF) Payup QtyRatio self-referential formula (disabled).

**Cross-leg tick size errors** (harmless for same-product, incorrect for cross-product): Rules 22, 29, 32, 15, 41.

**Duplicate rules**: 1 & 56 identical; 15/16 & 31/32 near-identical.

**Missing features by generation**: Gen 4 (Rules 39/40) lacks implied avoidance that was present in Gen 3 and production v3.

**Rules 54/55 extreme ratio thresholds**: 8× and 13× bid/ask ratios. Would only quote in heavily one-sided markets.

**Quote Throttle limitation**: Doesn't work with Quote-if-Best on remove/place (vs replace) — results in unlimited messaging.
