---
tags: [rules, bugs, anomalies, evolution, naming, generations]
domain: ase-rules
load-priority: on-demand
last-updated: "2026-03-26"
---

# Rule Anomalies and Evolution

**Scope**: Known bugs, cross-leg tick errors, naming inconsistencies, evolution timeline, and missing features by generation. Load when debugging rule behavior or planning rule modifications.

---

## Naming Conventions and Evolution

### Naming Convention Overview

The rule library uses consistent naming patterns to indicate rule category, generation, leg applicability, and feature set:

- **(FF)** prefix: Older rules from a previous regime or colleague. These tend to have simpler logic, fewer features, or known issues. "FF" origin uncertain but likely related to Fed Funds.
- **GJN** prefix: Current production rules from Gaurav Jain. Standard naming for actively maintained variants.
- **L1/L2**: Specifies which leg the rule is applied to or watches as the primary trigger.
- **+1-1 / -1+1+1 / -1-1+1 / +1+1**: Leg sign configuration the rule is designed for. Indicates whether the rule includes worst-case spread price validation.
- **v2/v3/v5**: Version iterations. Higher numbers generally indicate more evolved or feature-rich versions.
- **M suffix**: Intended to mark ThisLeg-based (portable) rule variants. Rules using `ThisLeg` references instead of explicit `Leg1`/`Leg2` references can work across different spreads without modification. Inconsistently applied — not reliable.
- **LTP01/LTP11**: Last-traded-price confirmation variants. 01 = hedge leg only must have LTP confirmation; 11 = both legs must have LTP confirmation.
- **X/Y/O**: Three decomposition structures for 3-leg O spread configurations. X-type = −1−1+1, Y-type = −1+1+1, O-type = original decomposition.

### Feature Progression by Generation

| Feature | Gen 1 (50/51) | Gen 2 (48/49) | Gen 3 (2/3/4) | Gen 4 (39/40) | v3 Prod (25/26) |
|---------|:---:|:---:|:---:|:---:|:---:|
| Spread price check | ✗ | ✓ | ✓ | ✓ | ✓ |
| Multiplier parameters | ✗ | ✓ | ✓ | ✓ | ✗ |
| Implied avoidance filter | ✗ | ✗ | ✓ | ✗ | ✓ |
| HitImplied toggle | ✗ | ✗ | ✓ | ✗ | ✗ |
| LTP variants | hedge only | hedge only | 01/11 | 01/11 | hedge only |
| ThisLeg portable | ✗ | ✗ | ✗ | ✓ | ✗ |

**Notable**: Generation 4 (ThisLeg-based) lost the implied avoidance check present in both Gen 3 and production v3. If Gen 4 rules are ever used in production, implied avoidance would need to be added back.

### Inferred Evolution Timeline

Based on feature accumulation, naming, and rule numbering:

1. **(FF) legacy rules** — Oldest. Simple logic, no multipliers, minimal safety checks. Examples: Rule 35 (bugged payup), Rules 52/53 (directional filters).

2. **GJN HitMAN-Leg1/Leg2 (Gen 1)** — Rules 50, 51. First GJN variant. Volume ratios, StopVol, LTP, hedge liquidity checks. No spread price validation — purely microstructure-driven crossing.

3. **GJN HitMAN-Leg1/Leg2 +1-1 (Gen 2)** — Rules 48, 49. Adds multipliers and spread price validation. Uses AskPrice directly and BidQuantityAtPrice for depth checks. Still missing implied avoidance.

4. **HitMan L1/L2 v3 (Production)** — Rules 25, 26. Production 2-leg baseline. Adds implied avoidance filter. Drops multipliers (not needed for same-product spreads where prices are directly comparable).

5. **HitMan +1-1 L1/L2 v3** — Rules 27, 28. Re-introduces multipliers for cross-product spreads while keeping implied avoidance. Combines production safety with cross-product pricing flexibility.

6. **GJN HitMAN-L1 LTP01/LTP11 (Gen 4)** — Rules 39, 40. Introduces `ThisLeg` portability. Adds LTP confirmation variants. Loses implied avoidance (oversight or intentional?).

7. **GJN_HitMan LTP11/LTP01 (Gen 3)** — Rules 2, 3, 4. Explicit leg references with LTP variants and HitImplied toggle for controlling implied tolerance on a per-rule basis.

8. **HitMan v5** — Rules 17, 34. 3-leg most sophisticated. Volume-adjusted spread pricing formula. Per-leg parameters. HitImplieds toggle. Accounts for price movement probability on other legs.

Similar progression exists for ASM and other rule families.

---

## Confirmed Bugs

### Rule 35: (FF) Payup — QtyRatio Formula Bug

**Status**: Confirmed bug. Disabled in production.

**The bug**:

The condition checks:
```
AskQuantity < (AskQuantity - MinimumPriceIncrement) × QtyRatio
```

This subtracts a price value (MinimumPriceIncrement, e.g., 0.0025) from a quantity value (AskQuantity, e.g., 100 lots), then multiplies by a ratio. This is dimensionally invalid — you cannot subtract a price from a quantity.

**What was intended**:

```
AskQuantity < BidQuantityAtPrice(AskPrice - 1 tick) × QtyRatio
```

This compares the ask quantity to the bid quantity one tick behind the ask, adjusted by the ratio. Correct interpretation: "pay up if the offer is weak relative to the support one level back."

**Impact**: The condition almost always evaluates to true (any quantity is less than itself minus a tiny value, times a ratio). The rule fires indiscriminately, causing uncontrolled payup.

**Corrected in**: Rule 11 (GJN_WCT_Payup) which uses the correct formula.

**Current status**: Rule 35 is disabled in production. GJN_WCT_Payup is the active post-hedge rule.

---

## Cross-Leg Tick Size Errors

Multiple rules apply one leg's `MinimumPriceIncrement` (tick size) where another leg's tick should be used. This creates incorrect behavior on cross-product spreads where legs have different tick sizes.

### Rules with Cross-Leg Tick Errors

| Rule | Location | Uses | Should Use | Impact |
|------|----------|------|------------|--------|
| 22 | Spread pricing formula | `ThisLeg.MinimumPriceIncrement` (Leg3 tick for Leg1 price) | Leg1's tick | Incorrect for cross-product spreads |
| 29 | Tight-spread check on Leg1 | `Leg2.MinimumPriceIncrement` | Leg1's tick | Compares Leg1 spread width against Leg2's tick |
| 32 | Tight-spread check on Leg1 | `Leg2.MinimumPriceIncrement` | Leg1's tick | Same as Rule 29 |
| 15 | Tight-spread check on Leg1 | `Leg2.MinimumPriceIncrement` | Leg1's tick | Same as Rules 29, 32 |
| 41 | Range filter | `Leg2.MinimumPriceIncrement` for Leg1 range | Leg1's tick | Calculates session range using wrong tick |

**Example impact** (cross-product):

If Leg1 is SR3 (0.25bp tick = 0.0025) and Leg2 is ZQ (0.5bp tick = 0.005):

- **Rule 29 tight-spread check**: Tests `Leg1.AskPrice - Leg1.BidPrice == 0.005` when it should test `== 0.0025`
- **For same-product spreads** (SR3 vs SR1, both SOFR): No difference since all ticks are 0.0025. Tests work correctly by accident.
- **For cross-product spreads** (SR3 vs ZQ): Condition produces incorrect evaluation. A 1-tick spread on Leg1 (0.0025) is treated as 2-tick or 0.5-tick depending on which leg's tick is used.

**Current status**: All harmless for production's same-product configurations (SR3|SR1, SR3|ZQ spreads use same-product leg pairings within each ASE). Would require fixing before deploying on cross-product single-ASE spreads.

---

## Duplicate and Near-Duplicate Rules

### Rules 1 and 56: Identical Logic, Different Names

**Rule 1**: "GJN No Quote unless Hit" — Sets qty=0 when `CalcPrice < AskPrice`

**Rule 56**: "(FF) Ghost ASE" — Sets qty=0 when `CalcPrice < AskPrice`

Both are functionally identical. Rule 56 is the older (FF) naming convention. One should be retired to reduce library clutter.

**Reason for two versions**: Likely name change during refactoring. "Ghost ASE" was the original (FF) naming; it was renamed to "No Quote unless Hit" for clarity.

### Rules 15/16 vs 31/32: Near-Duplicate ASM Variants

**Rules 15, 16**: "+1-1 ASM L1/L2 v3 M" — With "M" suffix

**Rules 31, 32**: "+1-1 ASM L1/L2 v3" — Without "M" suffix

Both pairs are "+1-1 ASM v3" with multipliers and range filters. Structurally almost identical:
- Both have `MultLI` and `MultLII` parameters
- Both have range filter (High − Low < 4 ticks)
- Both have similar liquidity checks

**Functional difference**: Inconsistent. The "M" suffix on 15/16 doesn't correspond to consistent `ThisLeg` vs. explicit leg reference differences.

**Current status**: Both pairs appear to be maintained. One pair may be a deprecated backup or represent parameter tuning variants.

---

## Naming Inconsistencies

### The "M" Suffix — Intended vs. Actual

The M suffix was intended to mark rules that use `ThisLeg` references instead of explicit `Leg1`, `Leg2`, `Leg3` references. `ThisLeg` makes rules portable across spreads without manual renaming.

**Correct M-suffixed rules**:
- **Rule 12**: "L1 ASM v2 M" — Uses `ThisLeg` ✓
- **Rule 15**: "+1-1 ASM L1 v3 M" — Uses `ThisLeg` ✓
- **Rule 16**: "+1-1 ASM L2 v3 M" — Uses `ThisLeg` ✓

**Incorrect M-suffixed rules**:
- **Rule 13**: "GJN -1+1+1 ASM Y M" — Still uses `Leg3` ✗
- **Rule 14**: "GJN -1-1+1 ASM X M" — Still uses `Leg3` ✗

**Rules without M that should arguably have it**:
- **Rule 29, 30**: "GJN ASM L1/L2 v3" — Don't use `ThisLeg` (don't have M, consistent)

**Functional impact**: Minimal. Rules work correctly regardless of M suffix presence. It's a documentation/naming inconsistency, not a functional bug. The M suffix is not a reliable indicator of portability — check the actual rule definition.

---

## Missing Features by Rule Generation

### Gen 4 HitMan (Rules 39/40) — Loss of Implied Avoidance

**What's missing**: Rules 39 and 40 lack the implied avoidance filter that was present in Generation 3 (Rules 2/3/4) and production v3 (Rules 25/26).

**The filter** (present in Gen 3 and v3 production):
```
DirectAskQuantity < (AskQuantity - DirectAskQuantity) + 1
```

This checks that the ask quantity is almost entirely direct (exchange-native), not implied. An implied ask at the crossing price signals another spread engine is on the other side — not ideal fill counterparty.

**Why it matters**: Crossing into implied quantity creates adverse selection (the implied was there because a better price exists elsewhere). Gen 4 rules omit this check entirely.

**Current status**: Only Gen 3 (Rules 2/3/4) and production v3 (Rules 25/26) have it. If Gen 4 rules are ever deployed to production, this filter should be added back.

---

## Rules with Extreme Parameters

### Rules 54/55: Extreme Bid/Ask Ratio Thresholds

**Rule 54**: "GJN NoQuote L1" — Monitors Leg2, shuts off L2 quoting if Leg2 bid/ask ratio < 13×

**Rule 55**: "GJN NoQuote L2" — Monitors Leg1, shuts off L1 quoting if Leg1 bid/ask ratio < 8×

**What the thresholds mean**:

- **8× ratio** (Rule 55): Bid must be 8 times the ask for quoting to be allowed
- **13× ratio** (Rule 54): Bid must be 13 times the ask for quoting to be allowed

Typical volume ratio thresholds in the library are 0.1–0.2 (meaning ask should be 10–20% of bid, or roughly 5–10× smaller). These 8× and 13× thresholds are far more extreme — requiring the bid to be 8–13× the ask.

**Practical effect**: Quoting would only activate in extremely skewed order books where one side is massively outweighing the other. In most normal market conditions, one side wouldn't be 8–13× larger than the other.

**Status**: These rules may be experimental (testing with extreme parameters) or intentionally designed for a very conservative quoting strategy where you only quote when the market is extremely one-sided in your favour.

---

## Known Limitation: Quote Throttle and Quote-if-Best

### The Issue

**Rule**: (GJN) Quote Throttle with parameters `InsideThrottle = 56ms`, `OutsideThrottle = 2ms`

**Problem**: The Quote Throttle does not work correctly with the Quote-if-Best rule when orders are removed and placed (rather than replaced).

**Mechanism difference**:
- **Replacement**: Quote order is amended in place (cancel/replace message). Throttle applies.
- **Remove/Place**: Quote order is cancelled and a new order is submitted separately (cancel followed by new). Throttle does not apply between operations.

**Result**: When using Quote-if-Best, the throttle effectively doesn't work — unlimited messaging can occur during cancel/new sequences.

**Impact**: Increases exchange message traffic unnecessarily during fast-moving markets.

**Status**: Known issue. Flagged for improvement. Previous tuning attempts focused on reducing messaging without affecting fills, but the fundamental issue requires rule redesign or a different implementation approach.

**Mitigation**: When Quote-if-Best is enabled alongside Quote Throttle, be aware that the throttle may not provide the expected message rate limiting. Monitor actual messaging volume against expected throttle limits.

---

## TT Documentation Known Issue

### Side Parameter Labeling Error

In TT's documentation for certain rules, the "Side" parameter labels may be inverted or inconsistent. The label "Side=Sell" may mean the opposite of what the label suggests, or use adjacent terminology that contradicts actual behavior.

**Current understanding**: The rules are written correctly in terms of their actual behavior within TT. But when reading the condition logic on paper against the TT documentation label, the label may appear to mean the opposite.

**Status**: Needs confirmation and clarification when detailed rule tuning is needed. For now, focus on actual rule behavior within the ASE rather than relying on the TT documentation label.

---

## Summary of Maintenance Priorities

### High Priority (Fix or Deprecate)

1. **Rules 1 and 56** — Duplicate "No Quote unless Hit" / "Ghost ASE". Deprecate one.
2. **Rules 54/55** — Review extreme ratio thresholds (8×/13×). Determine if intentional or experimental, document accordingly.
3. **Quote Throttle with Quote-if-Best** — Redesign or document the interaction limitation clearly.

### Medium Priority (Document and Consider for Future)

1. **Cross-leg tick errors** (Rules 22, 29, 32, 15, 41) — Harmless now but block cross-product spreads. Fix before cross-product deployment.
2. **Gen 4 HitMan implied avoidance** (Rules 39/40) — Add implied filter back if these rules are used in production.
3. **M suffix inconsistency** (Rules 13/14) — Clarify naming or fix rule definitions for consistency.

### Low Priority (Informational)

1. **Near-duplicate ASM pairs** (15/16 vs 31/32) — Determine if one is deprecated.
2. **Rules 50/51** (Gen 1 HitMan without spread check) — Likely obsolete but kept for reference.

---

## Testing Recommendations for Modified Rules

When modifying rules or deploying evolved versions, test for:

1. **Implied avoidance**: Confirm rule doesn't cross into implied quantity at the target price
2. **Cross-leg tick handling**: For cross-product spreads, verify tick size applied to each leg is correct
3. **Spread price validation**: After any price modification, confirm resulting spread price meets or beats target
4. **Parameter sensitivity**: Test with edge-case parameter values (0, max, extreme values) to ensure graceful degradation
5. **Message traffic**: Monitor actual pre-quote update frequency when throttling rules are active
6. **Fill distribution**: Track whether fill side distribution (L1 vs L2) matches expected strategy

---

## Questions for Future Clarification

1. Are Rules 15/16 and 31/32 both actively maintained, or is one a backup? If backup, should one be archived?
2. Rules 54/55 with 8×/13× ratio thresholds — are these intentional ultra-conservative parameters or experimental?
3. Gen 4 HitMan (39/40) without implied avoidance — is this omission intentional, or should implied filter be added back?
4. Which spread structure uses the +1+1 ASM rules (41/42)? These are the only rules designed for both-legs-long configuration.
5. Clarification on TT documentation Side parameter labeling — confirm actual behavior for rules using this parameter.

## Related

- [[custom-rules-library]] — Rules where anomalies were found
- [[custom-rules-production]] — Production rules affected by known bugs
- [[ase-mechanics-and-parameters]] — Engine behavior underlying anomalies
- [[instruments-and-platform]] — Cross-product tick size differences causing bugs
- [[Plan-2026-03-28]] — Comprehensive work plan referencing this file
