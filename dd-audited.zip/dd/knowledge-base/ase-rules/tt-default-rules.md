---
tags: [rules, tt-default, liquidity, throttle, slop, payup]
domain: ase-rules
load-priority: on-demand
last-updated: "2026-03-26"
---

# TT Default Rules — Complete Analysis

**Scope**: All 20 TT-provided default ASE rules with analysis, parameters, and test cases. Load when evaluating which default rules to enable or when comparing against custom rules.

---

## Rule Classification

| # | Rule Name | Stage | Purpose |
|---|-----------|-------|---------|
| 1 | (TT) All or None | Pre-Quote | Liquidity guard |
| 2 | (TT) Basic Slop | Pre-Quote | Message traffic reduction |
| 3 | (TT) Cancel/New Quote | Pre-Quote | Exchange compatibility |
| 4 | (TT) Inside Smart Quote | Pre-Quote | Message traffic reduction |
| 5 | (TT) Inside Smart Quote with LIMIT | Pre-Quote | Message traffic reduction |
| 6 | (TT) Quote Throttle | Pre-Quote | Message traffic reduction |
| 7 | (TT) Quote Best Bid/Ask | Pre-Quote | Price discipline |
| 8 | (TT) Max Order Move | Pre-Quote | Safety / anti-spike |
| 9 | (TT) Prevent Quote Cross | Pre-Quote | Price discipline |
| 10 | (TT) Prevent Overfill with Reload | Pre-Quote | Reload safety |
| 11 | (TT) Minimum Increment Quote | Pre-Quote | Exchange compliance |
| 12 | (TT) Hedge Price Limit | Pre-Hedge | Safety cap |
| 13 | (TT) Hedge Round | Pre-Hedge | Partial hedge management |
| 14 | (TT) Send Hedge as Market Order | Pre-Hedge | Aggressive hedging |
| 15 | (TT) Prevent Hedge Cross | Pre-Hedge | Price discipline |
| 16 | (TT) Minimum Increment Hedge | Pre-Hedge | Exchange compliance |
| 17 | (TT) Liquidity Based Backoff Tick | Pre-Hedge | Fill quality optimisation |
| 18 | (TT) Liquidity Based Payup Tick | Post-Hedge | Legging management |
| 19 | (TT) Ticks Away Based Go To Market | Post-Hedge | Legging management |
| 20 | (TT) Time Based Go To Market | Post-Hedge | Legging management |

---

## Pre-Quote Rules (Stage 1)

### Rule 1: All or None

**What it does**: Checks the hedge leg's market quantity. If the available quantity is less than what would be needed to hedge your quote, the ASE pulls the quote entirely. When sufficient hedge quantity returns, the quote is resubmitted.

**Parameters**: None (uses the spread's ratio and order quantity to determine required hedge quantity).

**Test case**: Buy SR1 at 3 lots (ratio 3:−5). SR3 bid shows 3 lots. Without rule, quote fills but hedge can only partially fill. With rule, quote is pulled until 5+ lots available on SR3.

**Use case**: Protects against guaranteed legging in thin markets. Essential when the hedge leg is illiquid.

**Trade-off**: Reduces fill count but eliminates worst legging scenarios.

---

### Rule 2: Basic Slop

**What it does**: Creates a price tolerance band around your entry price. While the calculated spread price stays within this band, the ASE does not reprice the quoting leg, even if the hedge leg has moved.

**Parameters**:
- `InsideSlopTicks` — ticks of adverse price you'll accept (worst price)
- `OutsideSlopTicks` — ticks of favourable price you'll accept (best price)

**Test case**: Buy at spread price 10.0. InsideSlopTicks = 1, OutsideSlopTicks = 2. Spread moves to 10.5 (0.5 worse) → no reprice. Spread moves to 11.5 (1.5 worse) → reprice triggered.

**Use case**: Number one message-traffic reducer. Without slop, every tick in the hedge leg triggers cancel/replace. Slop says "accept fills within this band."

**Trade-off**: InsideSlopTicks directly worsens worst-case fill quality. OutsideSlopTicks can improve it. Key tension: wider slop = fewer messages + more fills but worse worst-case quality.

---

### Rule 3: Cancel/New Quote

**What it does**: Forces the ASE to send a cancel followed by a new order, instead of a cancel/replace (amend) message.

**Parameters**: None.

**Test case**: Reprice quote from 95.50 to 95.55. Without rule: one cancel/replace. With rule: cancel, wait for ack, then new order (brief gap).

**Use case**: Required for exchanges that don't support order amendments. CME supports amendments, so **not needed for SR3/SR1/ZQ spreads**. Including it would hurt (gap exposure).

---

### Rule 4: Inside Smart Quote

**What it does**: Suppresses repricing the quote **toward** the inside market if the new price isn't close enough to the inside. Prevents chasing the market inward through many small steps.

**Parameters**:
- `distFromInside` — Number of ticks. If new quote price is more than this many ticks from inside, suppress.

**Test case**: distFromInside = 3. Quote at 95.40, inside bid = 95.55. Calculate new quote at 95.45 (2 ticks from inside) → reprices. Calculate 95.30 (10 ticks from inside) → suppressed.

**Use case**: Prevents wasteful requoting when your quote is deep in the book.

**Trade-off**: Higher distFromInside = fewer messages but your quote becomes stickier. Lower = more responsive but higher message traffic.

---

### Rule 5: Inside Smart Quote with LIMIT

**What it does**: Same as Inside Smart Quote, but adds a **ceiling distance**. If your quote is very far from the inside, it resumes repricing to avoid becoming completely stale.

**Parameters**:
- `distFromInside` — Suppress requoting toward market if new price is more than this many ticks away
- `limit` — Resume requoting if current quote is more than this many ticks from inside

**Test case**: distFromInside = 3, limit = 10. Quote at 95.35 (4 ticks from inside) tries to reprice → suppressed. Quote at 95.00 (11 ticks from inside) → exceeds limit → resumes repricing.

**Use case**: Solves Inside Smart Quote's main weakness: prevents being stuck at a stale price if the market runs away.

---

### Rule 6: Quote Throttle

**What it does**: Rate-limits quote order modifications. If the quote was already changed within the throttle period, suppress the new change.

**Parameters**:
- `InsideThrottle` — Milliseconds for moves toward the market
- `OutsideThrottle` — Milliseconds for moves away from the market

**Test case**: InsideThrottle = 200ms, OutsideThrottle = 50ms. Quote modified toward market at T=0. New inside move at T=150ms → suppressed. Same at T=250ms → allowed.

**Use case**: Hard rate limit on message traffic. Complementary to Slop (price-based). Very useful during volatile periods.

**Trade-off**: InsideThrottle too high = miss fills when market moves favorably. OutsideThrottle too high = slow to retreat, adverse fills.

---

### Rule 7: Quote Best Bid/Ask

**What it does**: Cancels the quote order if its price is outside a user-defined number of ticks from the inside bid/ask.

**Parameters**:
- Tick distance from inside (default: 0, meaning only quote at the inside)

**Test case**: Parameter = 2. Inside bid = 95.50. Quote at 95.50 → allowed. Quote at 95.45 → allowed. Quote at 95.43 → cancelled.

**Use case**: Forces quotes near the top of the book. Prevents deep resting quotes with near-zero fill probability.

**Trade-off**: Aggressive settings = only fill at inside (high quality, fewer fills). Loose settings = more fills, worse quality.

---

### Rule 8: Max Order Move

**What it does**: Limits how far the quote can jump in a single reprice. If the calculated new price is more than `MaxOrderMoveThreshold` ticks from the current working price, the quote is pulled entirely.

**Parameters**:
- `MaxOrderMoveThreshold` — Maximum tick distance per reprice

**Test case**: Threshold = 5. Quote at 95.50. Calculate 95.53 (0.6 ticks) → reprices. Calculate 96.00 (10 ticks) → quote pulled.

**Use case**: Safety circuit breaker against data spikes. If a monitoring instrument prints a bad tick, this catches it and pulls the quote.

**Trade-off**: Threshold too tight = pulled in normal volatile markets. Too loose = only catches extreme events.

---

### Rule 9: Prevent Quote Cross

**What it does**: If the calculated quote price would cross the market (buy above ask, sell below bid), the rule adjusts the price to one tick away from crossing.

**Parameters**: None.

**Test case**: Buy quote. Inside ask = 95.55. Calculated quote = 95.56 (would cross). With rule → quote at 95.545 (rests passively).

**Use case**: Enforces defensive rounding. Never hit the market at the order level. Fills only happen when market comes to you.

---

### Rule 10: Prevent Overfill with Reload

**What it does**: When using Reload with Active Quoting on multiple legs, suppresses quoting on all but the first quoting leg once there's possibility of overfill.

**Parameters**: None.

**Test case**: 2-leg spread, both quote, Reload enabled. Clip 1 fills, both legs quote. Without rule: both clips fire, 6 lots total. With rule: suppressed until fully hedged.

**Use case**: Prevents overfills from multiple quoting legs. Not relevant if only one leg quotes per ASE.

---

### Rule 11: Minimum Increment Quote

**What it does**: Rounds down the quote quantity to the nearest multiple of `minIncrement`.

**Parameters**:
- `minIncrement` — Minimum valid order quantity

**Test case**: minIncrement = 5. Calculate quantity = 13. With rule → rounds to 10.

**Use case**: Exchange compliance for contracts with minimum lot requirements. Typically not needed for CME SOFR/FF contracts.

---

## Pre-Hedge Rules (Stage 2)

### Rule 12: Hedge Price Limit

**What it does**: If the calculated hedge price would cross the market by more than `TickLimit` ticks, the hedge is submitted at the limit instead.

**Parameters**:
- `TickLimit` — Maximum ticks through the opposite inside market

**Test case**: TickLimit = 3. Hedge buy. Inside ask = 95.55. Calculated hedge = 95.70. With rule → hedge at 95.55 + 3 ticks.

**Use case**: Caps worst-case payup. For spreads with unequal multipliers where calculated hedge price can end up far through the market.

**Trade-off**: Directly limits payup but unexecuted portion becomes resting limit, increasing legging.

---

### Rule 13: Hedge Round

**What it does**: By default, the ASE sends a hedge when it calculates at least one full contract is needed. This rule lets you set a threshold (as a percentage) above which the hedge is sent.

**Parameters**:
- `HedgePercent` — Percentage of a full contract delta at which to trigger hedge

**Test case**: HedgePercent = 50. Delta = 0.4 contracts (40%) → hedge not sent. Delta = 0.6 (60%) → hedge sent.

**Use case**: Relevant for spreads with non-integer ratios where partial fills create fractional hedge requirements.

---

### Rule 14: Send Hedge as Market Order

**What it does**: Converts all hedge orders from limit to market orders.

**Parameters**: None.

**Test case**: Quote fills. Without rule: hedge as limit order. With rule: hedge as market order (fills immediately).

**Use case**: Most aggressive anti-legging option. Guarantees hedge fills but at whatever price is available.

**Trade-off**: Terrible for fill quality if market is moved. Unpredictable payup.

---

### Rule 15: Prevent Hedge Cross

**What it does**: If the calculated hedge would cross the market, it's adjusted to one tick away from crossing.

**Parameters**: None.

**Test case**: Hedge buy. Inside ask = 95.55. Calculated hedge = 95.56. With rule → hedge at 95.545.

**Use case**: Forces hedge to rest passively rather than crossing. TD=0 guaranteed if market comes to you.

**Trade-off**: Perfect fill quality at the cost of dramatically increased legging risk and duration.

---

### Rule 16: Minimum Increment Hedge

**What it does**: Rounds down hedge quantity to the nearest multiple of `minIncrement`.

**Parameters**:
- `minIncrement` — Minimum valid hedge quantity

**Use case**: Exchange compliance for contracts with minimum lot requirements.

---

### Rule 17: Liquidity Based Backoff Tick

**What it does**: At the moment of hedging, if the available quantity at the calculated hedge price is ≥ `QtyThreshold`, the hedge order is submitted one tick **less aggressive** (backoff). The logic: if there's plenty of liquidity, you can afford to rest one tick back and try for a better fill.

**Parameters**:
- `QtyThreshold` — Quantity at hedge price level above which to back off

**Test case**: QtyThreshold = 50. Hedge buy at 95.55 (the ask). Ask quantity = 80. 80 ≥ 50 → back off: hedge at 95.545.

**Use case**: **Most important pre-hedge rule for fill quality.** When the book is thick, backing off one tick gives you a chance at TD=−1 (better than limit). When book is thin, you don't back off.

**Trade-off**: Designed to pair with Rule 18 (Liquidity Based Payup). Backoff improves upside; payup prevents excessive legging downside.

---

## Post-Hedge Rules (Stage 3)

### Rule 18: Liquidity Based Payup Tick

**What it does**: After a hedge is placed and resting, monitors the quantity one tick from the working hedge price. If that quantity drops below `QtyThreshold`, the hedge is repriced one tick more aggressive. Can repeat up to `NumberOfPayups` times.

**Parameters**:
- `QtyThreshold` — Quantity below which to pay up
- `NumberOfPayups` — Maximum times to execute payup logic

**Test case**: QtyThreshold = 20, NumberOfPayups = 2. Hedge at 95.545. Ask at 95.55 shows 50 lots → no payup. Ask drops to 15 → payup 1: reprice to 95.55.

**Use case**: Controlled capitulation rule. When you've backed off but the market is thinning, this says "okay, cross, but only N ticks."

**Trade-off**: Each payup tick worsens TD. Without it, you'd be legged indefinitely — which is worse.

---

### Rule 19: Ticks Away Based Go To Market

**What it does**: If the working hedge order is more than `TicksAway` ticks from the opposite inside market, the hedge is repriced to cross the market by `MarketTicks` ticks.

**Parameters**:
- `TicksAway` — Tick distance threshold
- `MarketTicks` — How many ticks through the opposite market to reprice

**Test case**: TicksAway = 3, MarketTicks = 1. Hedge at 95.50. Ask = 95.55 (1 tick away). Ask moves to 95.70 (4 ticks) → exceeds 3 → go to market.

**Use case**: Price-based capitulation. When the market has moved so far from your hedge that you're clearly legged, this rule sweeps you out.

**Trade-off**: TD on this fill will be bad, but alternative is sitting legged with larger exposure.

---

### Rule 20: Time Based Go To Market

**What it does**: If the hedge has been working for more than `TimeInMS` milliseconds, reprice to cross the market by `MarketTicks` ticks.

**Parameters**:
- `TimeInMS` — Milliseconds before triggering
- `MarketTicks` — Ticks through the opposite market

**Important**: A market update must occur for the rule to be evaluated. The timer alone doesn't trigger.

**Test case**: TimeInMS = 5000. Hedge placed at T=0. T=3000ms: no action. T=5500ms: market ticks and elapsed > 5000 → go to market.

**Use case**: Time-based capitulation. Regardless of market movement, if you've been legged for more than N seconds, get out.

**Trade-off**: Similar to Rule 19 — the fill will be worse, but the alternative is indefinite legging.

---

## Summary

TT's default rules cover the full lifecycle: liquidity guards and message throttling at Pre-Quote, fill quality controls at Pre-Hedge, and legging management at Post-Hedge. A typical configuration uses Basic Slop + Quote Throttle (Pre-Quote), Liquidity Based Backoff (Pre-Hedge), and Liquidity Based Payup + Time Based Go To Market (Post-Hedge) to balance message traffic, fill quality, and legging risk.

## Related

- [[ase-mechanics-and-parameters]] — Engine these rules operate in
- [[custom-rules-library]] — Custom rules that complement or replace defaults
- [[custom-rules-production]] — Production rules that interact with defaults
