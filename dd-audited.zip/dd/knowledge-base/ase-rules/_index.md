# ASE Rules — Map of Content

ASE rule mechanics, the complete custom rule library, production rules,
TT-provided defaults, and known issues. This is the largest folder
(~1,453 lines). Load ase-mechanics-and-parameters first as the
foundation, then only the file you need.

## Files

- [[ase-mechanics-and-parameters]] — How ASE works: default engine flow (quote → reprice → fill → hedge), the three rule stages (Pre-Quote, Pre-Hedge, Post-Fill), all configurable parameters, and how rules modify the pipeline. **Read first before any rule discussion.**
- [[custom-rules-library]] — Complete inventory of all 56 custom rules: 4 families (HitMan, ASM, NoQuote, Ghost), spread structures (+1−1, −1+1+1, −1−1+1, +1+1), per-rule conditions and parameters, evolution across versions.
- [[custom-rules-production]] — The 8 production rules in full detail: live ASE config snapshot, conditions with exact formulas, parameter values, test cases, interaction map.
- [[tt-default-rules]] — All 20 TT-provided default rules: classification, parameters, test cases. Covers liquidity guards, message traffic reduction, price discipline, safety, and reload management.
- [[rule-anomalies-and-evolution]] — Known bugs (Rule 35 payup formula, cross-leg tick errors), naming conventions (FF/GJN/L1/L2/M/LTP), feature progression across 5 generations, missing features by version, maintenance priorities.

## Related Folders

- [[core/_index|Core]] — Glossary terms used in rule conditions
- [[strategy/_index|Strategy]] — Strategies that rules execute
- [[execution-analysis/_index|Execution Analysis]] — Measures rule effectiveness
- [[application/_index|Application]] — Application that hosts and runs the ASE
- [[planning/_index|Planning]] — Work plan referencing rule optimization and ASE configuration goals

### Jarvis Analysis
- [[jarvis/timer-logic/_index|Jarvis: Timer Logic]] — WP-04: verified rule interaction with Timer Logic
- [[jarvis/market-profiling/_index|Jarvis: Market Profiling]] — WP-03: per-group rule parameter recommendations
- [[jarvis/strategy-research/_index|Jarvis: Strategy Research]] — Planned bias signal triggering HitMan/ASM rules
