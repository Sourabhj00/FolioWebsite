# Resources — Map of Content

Raw source material for analysis. Not authoritative. Load only when a
task specifically requires examining original source documents.

## Files

*No resources yet.*

## Related Folders

- [[staging/_index|Staging]] — Where extracted knowledge goes before merging
